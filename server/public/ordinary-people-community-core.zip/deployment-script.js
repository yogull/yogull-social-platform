#!/usr/bin/env node

import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));

class DeploymentManager {
  constructor() {
    this.snapshotDir = path.join(process.cwd(), 'deployment-snapshots');
    this.currentSnapshotFile = path.join(process.cwd(), 'deployment-snapshot.json');
    this.workingFiles = [
      'client/src/pages/ProfileWallWorkingFixed.tsx',
      'client/src/pages/GallerySimple.tsx', 
      'client/src/App.tsx',
      'server/routes.ts',
      'shared/schema.ts',
      'client/src/pages/Dashboard.tsx',
      'client/src/pages/CommunityFixed.tsx',
      'client/src/pages/Home.tsx',
      'client/src/pages/DailyNews.tsx'
    ];
    
    // Ensure snapshots directory exists
    if (!fs.existsSync(this.snapshotDir)) {
      fs.mkdirSync(this.snapshotDir, { recursive: true });
    }
  }

  createSnapshot(label = 'auto') {
    const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
    const snapshotName = `${timestamp}_${label}`;
    
    console.log(`📸 Creating deployment snapshot: ${snapshotName}`);
    
    const snapshot = {
      timestamp: new Date().toISOString(),
      label: label,
      version: '2.0.0',
      snapshotName: snapshotName,
      files: {},
      metadata: {
        workingState: 'confirmed',
        buttonsFixed: true,
        navigationWorking: true,
        dailyNewsActive: true
      }
    };

    // Save current working state of all critical files
    this.workingFiles.forEach(filePath => {
      if (fs.existsSync(filePath)) {
        snapshot.files[filePath] = fs.readFileSync(filePath, 'utf8');
        console.log(`✅ Backed up ${filePath}`);
      }
    });

    // Save timestamped snapshot
    const timestampedSnapshot = path.join(this.snapshotDir, `${snapshotName}.json`);
    fs.writeFileSync(timestampedSnapshot, JSON.stringify(snapshot, null, 2));
    
    // Update current snapshot
    fs.writeFileSync(this.currentSnapshotFile, JSON.stringify(snapshot, null, 2));
    
    console.log(`✅ Deployment snapshot saved: ${snapshotName}`);
    return snapshotName;
  }

  listSnapshots() {
    if (!fs.existsSync(this.snapshotDir)) {
      return [];
    }
    
    const snapshots = fs.readdirSync(this.snapshotDir)
      .filter(file => file.endsWith('.json'))
      .map(file => {
        const snapshot = JSON.parse(fs.readFileSync(path.join(this.snapshotDir, file), 'utf8'));
        return {
          name: snapshot.snapshotName || file.replace('.json', ''),
          timestamp: snapshot.timestamp,
          label: snapshot.label || 'unlabeled',
          metadata: snapshot.metadata || {}
        };
      })
      .sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp));
    
    return snapshots;
  }

  restoreFromSnapshot(snapshotName = null) {
    let snapshotFile;
    
    if (snapshotName) {
      snapshotFile = path.join(this.snapshotDir, `${snapshotName}.json`);
      if (!fs.existsSync(snapshotFile)) {
        console.log(`❌ Snapshot ${snapshotName} not found`);
        return false;
      }
    } else {
      snapshotFile = this.currentSnapshotFile;
      if (!fs.existsSync(snapshotFile)) {
        console.log('📋 No snapshot found - creating new one');
        this.createSnapshot();
        return;
      }
    }

    console.log(`🔄 Restoring from deployment snapshot: ${snapshotName || 'current'}...`);
    
    const snapshot = JSON.parse(fs.readFileSync(snapshotFile, 'utf8'));
    
    // Restore all files from snapshot
    Object.keys(snapshot.files).forEach(filePath => {
      try {
        // Ensure directory exists
        const dir = path.dirname(filePath);
        if (!fs.existsSync(dir)) {
          fs.mkdirSync(dir, { recursive: true });
        }
        
        fs.writeFileSync(filePath, snapshot.files[filePath]);
        console.log(`✅ Restored ${filePath}`);
      } catch (error) {
        console.error(`❌ Failed to restore ${filePath}:`, error.message);
      }
    });
    
    console.log(`✅ Deployment restored from ${snapshot.timestamp}`);
    console.log(`📋 Label: ${snapshot.label}`);
    if (snapshot.metadata) {
      console.log(`📊 Metadata:`, snapshot.metadata);
    }
    return true;
  }

  restoreFromSnapshot(snapshotName = null) {
    if (!fs.existsSync(this.snapshotFile)) {
      console.log('❌ No snapshots available');
      return false;
    }

    const snapshotData = JSON.parse(fs.readFileSync(this.snapshotFile, 'utf8'));
    
    // Restore all files to their working state
    Object.entries(snapshot.files).forEach(([filePath, content]) => {
      if (content) {
        fs.writeFileSync(filePath, content);
        console.log(`✅ Restored ${filePath}`);
      }
    });

    console.log('✅ Deployment restoration complete');
    console.log(`📅 Snapshot from: ${snapshot.timestamp}`);
  }

  disableAutoFix() {
    console.log('🛑 Disabling auto-fix systems...');
    
    // Remove auto-fix from main server file
    const serverPath = 'server/server.ts';
    if (fs.existsSync(serverPath)) {
      let serverContent = fs.readFileSync(serverPath, 'utf8');
      
      // Remove auto-fix intervals and monitoring
      serverContent = serverContent.replace(/setInterval.*auto.*fix.*\{[\s\S]*?\}, \d+\);?/gi, '');
      serverContent = serverContent.replace(/\/\/ Auto-fix[\s\S]*?\/\/ End auto-fix/gi, '');
      serverContent = serverContent.replace(/🛡️.*monitoring.*\n/gi, '');
      
      fs.writeFileSync(serverPath, serverContent);
      console.log('✅ Auto-fix systems disabled');
    }
  }
}

// Command line usage
const command = process.argv[2];
const manager = new DeploymentManager();

switch(command) {
  case 'snapshot':
    manager.createSnapshot();
    break;
  case 'restore':
    manager.restoreFromSnapshot();
    manager.disableAutoFix();
    break;
  case 'deploy':
    manager.createSnapshot();
    console.log('🚀 Ready for deployment with snapshot backup');
    break;
  default:
    console.log(`
Usage:
  node deployment-script.js snapshot  - Create snapshot of working state
  node deployment-script.js restore   - Restore from snapshot and disable auto-fix
  node deployment-script.js deploy    - Create snapshot before deployment
    `);
}