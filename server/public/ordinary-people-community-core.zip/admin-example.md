# Admin Guide: Managing Your Supplement Shop

## Adding New Products via API

Use this curl command template to add products:

```bash
curl -X POST http://localhost:5000/api/shop/products \
  -H "Content-Type: application/json" \
  -d '{
    "name": "Your Product Name",
    "brand": "Brand Name", 
    "description": "Detailed product description",
    "price": 2999,  // Price in cents ($29.99)
    "imageUrl": "https://your-image-url.com/image.jpg",
    "affiliateUrl": "https://your-affiliate-link.com/product?tag=YOURID",
    "category": "Vitamins", // or "Minerals", "Herbal", etc.
    "benefits": ["Benefit 1", "Benefit 2", "Benefit 3"],
    "ingredients": ["Ingredient 1", "Ingredient 2"]
  }'
```

## Updating Affiliate Links

To update existing products with your affiliate links:

```bash
curl -X PUT http://localhost:5000/api/shop/products/1 \
  -H "Content-Type: application/json" \
  -d '{
    "affiliateUrl": "https://amazon.com/dp/PRODUCTID?tag=YOURAFFILIATEID-20"
  }'
```

## Common Affiliate Platforms

- **Amazon Associates**: `https://amazon.com/dp/PRODUCTID?tag=YOURID-20`
- **iHerb**: `https://iherb.com/product?pid=PRODUCTID&rcode=YOURCODE`
- **Vitacost**: `https://vitacost.com/product?aff=YOURID`
- **Thrive Market**: `https://thrivemarket.com/product?ref=YOURID`