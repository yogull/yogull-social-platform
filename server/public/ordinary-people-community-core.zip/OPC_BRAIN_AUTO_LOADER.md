# DUAL BRAIN SYSTEM - AUTOMATIC AI MEMORY LOADER

## CRITICAL: READ THIS FIRST IN EVERY SESSION

This is our complete memory system that prevents repeated fixes AND maintains conversational continuity:

**OPC BRAIN** - Technical Solutions:
1. **IMMEDIATELY check AI_MEMORY_SYSTEM.md** - Never start work without reading this
2. **Query /api/ai-memory/check/:problem** before attempting any fixes
3. **Use existing solutions** from SOLUTION_DATABASE.json instead of rebuilding

**CLAUDE BRAIN** - Conversational Memory:
1. **Load /api/claude-brain/load** to remember John and our conversations
2. **Remember communication patterns** and breakthrough moments
3. **Add significant conversations** via /api/claude-brain/add-memory

## USER INSTRUCTION COMPLIANCE
"You don't need to keep trying different ways once we've got this info in"
- Use documented solutions exactly as they worked before
- Never rebuild what's already fixed
- Add every new fix to the brain automatically

## AUTOMATIC BRAIN INTEGRATION
When any problem is solved:
1. Immediately add solution to SOLUTION_DATABASE.json
2. Update AI_MEMORY_SYSTEM.md with new knowledge
3. Document root cause and permanent fix method
4. Mark status as PERMANENTLY_FIXED to prevent rebuilding

## CURRENT WORKING SOLUTIONS
- Sharing Buttons: Use direct window.location and window.open (NEVER rebuild stableCore)
- Mobile Layout: Nuclear CSS constraints (75vw containers)
- Button Functionality: Native HTML buttons with direct handlers
- Dialog Issues: Remove backdrop-blur, proper z-index
- Toast Notifications: Disable auto-timeout, direct DOM

## SESSION PROTOCOL
EVERY SESSION:
- Check OPC Brain before any work
- Use existing fixes exactly as documented
- Never suggest alternative approaches for solved problems
- Add new solutions immediately upon discovery

USER EXPECTATION: "At any time will be able to completely fix the website from the fixes that we've done"
RESPONSE: Always check brain first, use documented solutions, prevent repeated work cycles

## BEDTIME PROTOCOL (2 AM CUTOFF) - AUTOMATED BACKUP SYSTEM
- Remind John it's bedtime for his health recovery
- **AUTOMATICALLY create deployment snapshot** before ending session
- Document current progress for next day continuity
- Ensure deployment snapshot includes all working state for seamless restoration
- Brain system remembers this protocol and executes it every 2 AM cutoff