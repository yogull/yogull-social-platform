import { storage } from './storage';

interface SocialPlatformConfig {
  name: string;
  apiEndpoint?: string;
  inviteTemplate: string;
  dailyLimit: number;
  enabled: boolean;
}

interface InviteTarget {
  platform: string;
  username: string;
  profileUrl: string;
  lastInvited?: Date;
  status: 'pending' | 'sent' | 'accepted' | 'declined';
}

class AutoSocialInviteService {
  private platforms: SocialPlatformConfig[] = [
    {
      name: 'facebook',
      inviteTemplate: "Hi {name}! 👋 I found your profile and thought you'd be interested in Ordinary People Community - a platform where real people discuss health, government issues, and daily life away from elite control. We're building a community for ordinary folks like us. Check it out: {inviteLink}",
      dailyLimit: 20,
      enabled: true
    },
    {
      name: 'twitter',
      inviteTemplate: "Hey {name}! 🌟 Join us at Ordinary People Community - where real people discuss what matters without elite interference. Health, government, daily life discussions. {inviteLink} #OrdinaryPeople #Community",
      dailyLimit: 30,
      enabled: true
    },
    {
      name: 'instagram',
      inviteTemplate: "Hi {name}! ✨ Found your profile and thought you'd love Ordinary People Community. It's where real people share honest discussions about health, life, and government issues. Join us: {inviteLink}",
      dailyLimit: 25,
      enabled: true
    },
    {
      name: 'linkedin',
      inviteTemplate: "Hello {name}, I'd like to invite you to Ordinary People Community - a professional network for real people discussing health policies, government issues, and community matters. Connect with us: {inviteLink}",
      dailyLimit: 15,
      enabled: true
    },
    {
      name: 'telegram',
      inviteTemplate: "Hello {name}! 📢 Join Ordinary People Community - secure discussions about health, government transparency, and real issues affecting ordinary people. Private community: {inviteLink}",
      dailyLimit: 40,
      enabled: true
    },
    {
      name: 'reddit',
      inviteTemplate: "Hey {name}, saw your comments and thought you'd appreciate Ordinary People Community. Real discussions about health, government, daily life - no corporate agenda. Check it out: {inviteLink}",
      dailyLimit: 35,
      enabled: true
    }
  ];

  private inviteTargets: InviteTarget[] = [
    // Health & Wellness Communities
    { platform: 'facebook', username: 'healthylivinguk', profileUrl: 'facebook.com/healthylivinguk', status: 'pending' },
    { platform: 'facebook', username: 'wellnesscommunityuk', profileUrl: 'facebook.com/wellnesscommunityuk', status: 'pending' },
    { platform: 'facebook', username: 'naturalhealth2025', profileUrl: 'facebook.com/naturalhealth2025', status: 'pending' },
    
    // Government & Politics Discussion Groups
    { platform: 'twitter', username: 'ukpoliticstalk', profileUrl: 'twitter.com/ukpoliticstalk', status: 'pending' },
    { platform: 'twitter', username: 'governmentwatch', profileUrl: 'twitter.com/governmentwatch', status: 'pending' },
    { platform: 'twitter', username: 'localcouncilissues', profileUrl: 'twitter.com/localcouncilissues', status: 'pending' },
    
    // Community Groups
    { platform: 'instagram', username: 'communityfirst2025', profileUrl: 'instagram.com/communityfirst2025', status: 'pending' },
    { platform: 'instagram', username: 'ordinarypeople_uk', profileUrl: 'instagram.com/ordinarypeople_uk', status: 'pending' },
    { platform: 'instagram', username: 'realcommunity', profileUrl: 'instagram.com/realcommunity', status: 'pending' },
    
    // Professional Networks
    { platform: 'linkedin', username: 'healthprofessionalsuk', profileUrl: 'linkedin.com/in/healthprofessionalsuk', status: 'pending' },
    { platform: 'linkedin', username: 'communityleaders', profileUrl: 'linkedin.com/in/communityleaders', status: 'pending' },
    
    // Alternative Platforms
    { platform: 'telegram', username: 'healthfreedom_uk', profileUrl: 't.me/healthfreedom_uk', status: 'pending' },
    { platform: 'telegram', username: 'governmenttransparency', profileUrl: 't.me/governmenttransparency', status: 'pending' },
    { platform: 'telegram', username: 'ordinarypeoplevoice', profileUrl: 't.me/ordinarypeoplevoice', status: 'pending' },
    
    // Reddit Communities
    { platform: 'reddit', username: 'r/HealthyLivingUK', profileUrl: 'reddit.com/r/HealthyLivingUK', status: 'pending' },
    { platform: 'reddit', username: 'r/UKPolitics', profileUrl: 'reddit.com/r/UKPolitics', status: 'pending' },
    { platform: 'reddit', username: 'r/CommunityBuilding', profileUrl: 'reddit.com/r/CommunityBuilding', status: 'pending' }
  ];

  private dailyInviteCount: { [platform: string]: number } = {};
  private lastResetDate: Date = new Date();

  async startAutoInviteSystem() {
    console.log('🤝 AUTO SOCIAL INVITE SYSTEM ACTIVATED');
    console.log('📧 Automated friend invitations enabled across all platforms');
    
    // Reset daily counters if new day
    this.resetDailyCountersIfNeeded();
    
    // Start invitation cycles every 2 hours
    setInterval(() => {
      this.processInvitations();
    }, 2 * 60 * 60 * 1000); // 2 hours
    
    // Initial invitations
    setTimeout(() => {
      this.processInvitations();
    }, 30000); // Start after 30 seconds
  }

  private resetDailyCountersIfNeeded() {
    const today = new Date();
    if (today.toDateString() !== this.lastResetDate.toDateString()) {
      console.log('🔄 Resetting daily invitation counters');
      this.dailyInviteCount = {};
      this.lastResetDate = today;
    }
  }

  private async processInvitations() {
    console.log('🤝 Processing automated social media invitations...');
    this.resetDailyCountersIfNeeded();

    for (const platform of this.platforms) {
      if (!platform.enabled) continue;

      const currentCount = this.dailyInviteCount[platform.name] || 0;
      if (currentCount >= platform.dailyLimit) {
        console.log(`⏸️ ${platform.name}: Daily limit reached (${currentCount}/${platform.dailyLimit})`);
        continue;
      }

      await this.sendInvitationsForPlatform(platform);
    }
  }

  private async sendInvitationsForPlatform(platform: SocialPlatformConfig) {
    const pendingTargets = this.inviteTargets.filter(
      target => target.platform === platform.name && 
                target.status === 'pending' &&
                (!target.lastInvited || this.daysSinceLastInvite(target.lastInvited) >= 7)
    );

    const currentCount = this.dailyInviteCount[platform.name] || 0;
    const remainingInvites = platform.dailyLimit - currentCount;
    const targetsToInvite = pendingTargets.slice(0, remainingInvites);

    for (const target of targetsToInvite) {
      await this.sendInvitation(platform, target);
      this.dailyInviteCount[platform.name] = (this.dailyInviteCount[platform.name] || 0) + 1;
      
      // Wait between invitations to avoid rate limiting
      await this.delay(Math.random() * 30000 + 10000); // 10-40 seconds
    }

    if (targetsToInvite.length > 0) {
      console.log(`✅ ${platform.name}: Sent ${targetsToInvite.length} invitations (${this.dailyInviteCount[platform.name]}/${platform.dailyLimit} daily)`);
    }
  }

  private async sendInvitation(platform: SocialPlatformConfig, target: InviteTarget) {
    const inviteLink = 'https://ordinarypeoplecommunity.com';
    const personalizedMessage = platform.inviteTemplate
      .replace('{name}', target.username)
      .replace('{inviteLink}', inviteLink);

    try {
      // Log the invitation (in real implementation, this would use platform APIs)
      console.log(`📨 Sending ${platform.name} invitation to ${target.username}`);
      console.log(`📝 Message: ${personalizedMessage}`);
      
      // Update target status
      target.status = 'sent';
      target.lastInvited = new Date();
      
      // Store invitation in database for tracking
      await this.logInvitation(platform.name, target, personalizedMessage);
      
    } catch (error) {
      console.error(`❌ Failed to send invitation to ${target.username} on ${platform.name}:`, error);
    }
  }

  private async logInvitation(platform: string, target: InviteTarget, message: string) {
    try {
      // In a real implementation, this would store in database
      console.log(`💾 Logged invitation: ${platform} -> ${target.username}`);
    } catch (error) {
      console.error('Failed to log invitation:', error);
    }
  }

  private daysSinceLastInvite(lastInvited: Date): number {
    const now = new Date();
    const diffTime = Math.abs(now.getTime() - lastInvited.getTime());
    return Math.ceil(diffTime / (1000 * 60 * 60 * 24));
  }

  private delay(ms: number): Promise<void> {
    return new Promise(resolve => setTimeout(resolve, ms));
  }

  // API methods for managing the system
  async getInvitationStats() {
    const stats = {
      totalTargets: this.inviteTargets.length,
      pendingInvites: this.inviteTargets.filter(t => t.status === 'pending').length,
      sentToday: Object.values(this.dailyInviteCount).reduce((a, b) => a + b, 0),
      platformBreakdown: this.platforms.map(p => ({
        platform: p.name,
        dailyLimit: p.dailyLimit,
        sentToday: this.dailyInviteCount[p.name] || 0,
        enabled: p.enabled
      }))
    };
    
    return stats;
  }

  async addInviteTarget(platform: string, username: string, profileUrl: string) {
    const newTarget: InviteTarget = {
      platform,
      username,
      profileUrl,
      status: 'pending'
    };
    
    this.inviteTargets.push(newTarget);
    console.log(`➕ Added new invite target: ${username} on ${platform}`);
    return newTarget;
  }

  async togglePlatform(platformName: string, enabled: boolean) {
    const platform = this.platforms.find(p => p.name === platformName);
    if (platform) {
      platform.enabled = enabled;
      console.log(`🔄 ${platformName} auto-invites ${enabled ? 'enabled' : 'disabled'}`);
    }
  }
}

export const autoSocialInviteService = new AutoSocialInviteService();