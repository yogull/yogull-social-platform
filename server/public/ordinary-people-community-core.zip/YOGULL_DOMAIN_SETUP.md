# Yogull.com Domain Redirection Setup

## Overview
This document outlines the setup for redirecting yogull.com to the Ordinary People Community platform.

## DNS Configuration Required

### Option 1: Direct CNAME Record (Recommended)
Configure your DNS provider (where yogull.com is registered) with:

```
Type: CNAME
Name: @
Value: bb5206f0-95f5-4d15-a455-0da279c417dd-00-3oj1hjsvouk14.worf.replit.dev
TTL: 3600
```

```
Type: CNAME  
Name: www
Value: bb5206f0-95f5-4d15-a455-0da279c417dd-00-3oj1hjsvouk14.worf.replit.dev
TTL: 3600
```

### Option 2: A Record with IP Address
If CNAME is not supported for root domain:

1. First get the IP address:
```bash
nslookup bb5206f0-95f5-4d15-a455-0da279c417dd-00-3oj1hjsvouk14.worf.replit.dev
```

2. Configure A records:
```
Type: A
Name: @
Value: [IP ADDRESS FROM STEP 1]
TTL: 3600
```

```
Type: A
Name: www  
Value: [IP ADDRESS FROM STEP 1]
TTL: 3600
```

### Option 3: URL Forwarding (If DNS provider supports it)
- Source: yogull.com
- Destination: https://bb5206f0-95f5-4d15-a455-0da279c417dd-00-3oj1hjsvouk14.worf.replit.dev
- Type: 301 Permanent Redirect
- Include subdirectories: Yes

## Server-Side Configuration

The platform includes automatic redirection middleware that:

1. Detects requests from yogull.com or www.yogull.com
2. Issues a 301 permanent redirect to the Replit domain
3. Preserves the original URL path and query parameters
4. Maintains SEO value through proper redirect codes

## Verification Steps

After DNS configuration:

1. Wait 24-48 hours for DNS propagation
2. Test the redirection:
   ```bash
   curl -I http://yogull.com
   curl -I https://yogull.com
   curl -I http://www.yogull.com
   curl -I https://www.yogull.com
   ```

3. Verify the response includes:
   ```
   HTTP/1.1 301 Moved Permanently
   Location: https://[replit-domain]
   ```

## Backup Redirection Page

A static HTML redirection page (`yogull-redirect.html`) is available as a fallback:

- Contains automatic JavaScript redirection after 5 seconds
- Includes manual redirect link
- SEO-optimized with proper meta tags
- Branded with Ordinary People Community messaging

## SSL Configuration

Once DNS is configured:

1. The platform will automatically handle SSL through Replit's infrastructure
2. Both HTTP and HTTPS requests will be properly redirected
3. Users will be automatically upgraded to HTTPS on the destination

## Testing Checklist

- [ ] yogull.com redirects to community platform
- [ ] www.yogull.com redirects to community platform  
- [ ] HTTPS is working on both domains
- [ ] URL paths are preserved (yogull.com/page → platform.com/page)
- [ ] Redirect returns proper 301 status code
- [ ] Search engines can follow the redirect

## Common DNS Providers

### GoDaddy
1. Login to GoDaddy account
2. Go to Domain Manager
3. Select yogull.com → Manage DNS
4. Add CNAME records as specified above

### Cloudflare  
1. Login to Cloudflare dashboard
2. Select yogull.com domain
3. Go to DNS tab
4. Add CNAME records with orange cloud disabled initially

### Namecheap
1. Login to Namecheap account  
2. Go to Domain List → Manage
3. Advanced DNS tab
4. Add CNAME records as specified

## Support

If you encounter issues with DNS configuration, the specific steps will depend on your domain registrar. Most providers have documentation for setting up CNAME records or URL forwarding.