# Workstation Development Cost Tracker

## Overview
A standalone HTML file that runs in your browser to track daily development spending limits at £20/$20 threshold.

## How to Use

1. **Easy Access via Launcher:**
   - Double-click `workstation-tracker-launcher.html` 
   - Click "Launch Tracker" button for instant access
   - Or use "Direct Tracker" quick link

2. **Direct Access:**
   - Double-click `workstation-spending-tracker.html`
   - Bookmark it for easy access

2. **Features:**
   - Real-time cost tracking (£0.10 per minute)
   - Currency toggle (£ GBP / $ USD)
   - Progress bar with color indicators
   - Audio notifications at 80% and 100% limits
   - Modal popup when £20/$20 limit reached

3. **Notifications:**
   - **80% Warning:** Yellow alert with notification sound
   - **100% Limit:** Modal popup with options to extend or pause
   - **Sound Alerts:** Built-in audio notifications

4. **Controls:**
   - **Reset Day:** Start fresh daily tracking
   - **Pause/Resume:** Stop timer when not working
   - **Extend +£10:** Add £10 to daily limit when needed
   - **Currency Toggle:** Switch between GBP and USD

5. **Data Storage:**
   - Automatically saves progress in browser
   - Resets daily at midnight
   - Persistent across browser sessions

## Usage Tips
- Keep the tracker open in a browser tab while working
- Timer starts automatically when page loads
- Use "Pause Timer" during breaks
- "Reset Day" to start over if needed
- Data saves automatically every 30 seconds

## Cost Calculation
- Base rate: £0.10 per minute (£6/hour)
- USD conversion: Approximately $1.27 per £1
- Tracks active development time only

The tracker is completely independent of GoHealMe and runs locally on your workstation for development cost management.