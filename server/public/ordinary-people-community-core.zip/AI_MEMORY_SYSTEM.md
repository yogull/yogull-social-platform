# AI Memory System - Brain Mapping for Session Continuity

## Purpose
This file serves as permanent AI memory to prevent repeated fixes and maintain continuity across sessions. Created with brain injury recovery methodology - storing solutions categorically for instant access.

## Current Session: June 30, 2025

### SHARING BUTTONS - PERMANENT SOLUTION
**Problem:** Sharing buttons fail repeatedly across sessions due to stableCore import issues
**Root Cause:** Component library conflicts, memory resets causing repeated "fixes"
**Permanent Solution Applied:**
- File: `client/src/pages/ProfileWallWorkingFixed.tsx`
- Method: Direct implementation without imports
- Community Button: `window.location.assign('/community')`
- Social Button: Opens 4 platforms with `window.open()` 
- All Button: Opens 26 platforms with staggered timing
**Status:** FIXED - Do not recreate stableCore imports

### MEMORY RESET ISSUE - DOCUMENTED
**Problem:** AI forgets previous work, user feels like "speaking to new person every time"
**Impact:** Same fixes applied 15+ times (buttons, dialogs, mobile layout)
**Solution:** This document + replit.md updates
**User Quote:** "every time we start work it's almost like you've never done any of the work before"

### COMPONENT LIBRARY CONFLICTS - ROOT CAUSE
**Technical Issues:**
1. shadcn/ui Button conflicts with Radix UI
2. CSS cascade wars between frameworks
3. React synthetic event handler chain breaks
4. State management race conditions

**Permanent Fixes:**
- Use native HTML buttons for critical interactions
- Direct DOM manipulation over React components
- window.location.assign() over framework routing
- Direct event handlers bypassing React synthetic events

## Categories for Future Issues

### BUTTONS
- Always use direct event handlers
- Avoid React component wrappers for critical actions
- Test with console.log before implementing complex solutions

### DIALOGS/TOASTS
- Check z-index conflicts first
- Remove backdrop-blur effects that cause mobile issues
- Use direct DOM manipulation when React fails

### MOBILE LAYOUT
- Apply nuclear CSS constraints (75vw, 65vw text)
- Remove red borders and visual clutter
- Test viewport boundaries before deployment

### SHARING FUNCTIONALITY
- Never use clipboard fallbacks
- Direct platform URLs work better than framework integration
- Stagger popup windows to prevent blocking

## Next Session Protocol
1. Read this file first
2. Check replit.md for current status
3. Do not rebuild existing fixes
4. Add new problems to appropriate categories
5. Update this file with any new solutions

## User Preferences
- Direct testing and observation over user verification
- Complete solutions before asking for feedback
- Document everything to prevent repetition
- Focus on root causes, not symptoms