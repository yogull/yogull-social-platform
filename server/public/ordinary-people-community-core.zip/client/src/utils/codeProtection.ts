/**
 * Code Protection & Anti-Tampering Utilities
 * Copyright (c) 2025 John Proctor. All rights reserved.
 * The People's Health Community Platform
 * 
 * This code is proprietary and confidential. Unauthorized copying,
 * distribution, or modification is strictly prohibited.
 */

// Anti-debugging detection
let devtoolsOpen = false;
const threshold = 160;

export const initCodeProtection = () => {
  // Disabled for user access - no blocking popups
};

// Anti-debugging techniques - disabled
export const antiDebug = () => {
  // Disabled for user access
};

// Obfuscate sensitive data
export const obfuscateString = (str: string): string => {
  return btoa(encodeURIComponent(str));
};

export const deobfuscateString = (str: string): string => {
  try {
    return decodeURIComponent(atob(str));
  } catch {
    return '';
  }
};

// Runtime integrity check
export const integrityCheck = () => {
  const originalLog = console.log;
  const originalWarn = console.warn;
  const originalError = console.error;

  console.log = function(...args) {
    if (args[0]?.includes('protected') || args[0]?.includes('source')) {
      return;
    }
    originalLog.apply(console, args);
  };

  console.warn = function(...args) {
    originalWarn.apply(console, args);
  };

  console.error = function(...args) {
    originalError.apply(console, args);
  };
};