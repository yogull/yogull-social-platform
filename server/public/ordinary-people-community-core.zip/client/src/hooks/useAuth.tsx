import { useState, useEffect } from "react";
import { User as FirebaseUser } from "firebase/auth";
import { User } from "@shared/schema";
import { onAuthStateChange, getCurrentAppUser } from "@/lib/auth";

export function useAuth() {
  const [firebaseUser, setFirebaseUser] = useState<FirebaseUser | null>(null);
  const [appUser, setAppUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Production mode - Firebase authentication only
    // Clear any demo data from localStorage
    localStorage.removeItem('demoUser');
    
    // Initialize Firebase authentication
    const unsubscribe = onAuthStateChange(async (user) => {
      setFirebaseUser(user);
      
      if (user) {
        const userData = await getCurrentAppUser(user.uid);
        setAppUser(userData);
        // Store user data in localStorage for API authentication headers
        if (userData) {
          localStorage.setItem('auth_user', JSON.stringify(userData));
        }
      } else {
        setAppUser(null);
        localStorage.removeItem('auth_user');
      }
      
      setLoading(false);
    });

    return unsubscribe;
  }, []);

  return { firebaseUser, appUser, loading };
}