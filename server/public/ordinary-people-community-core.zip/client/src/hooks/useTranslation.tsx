import { createContext, useContext, useState, useEffect, ReactNode } from 'react';

interface TranslationContextType {
  language: string;
  currency: string;
  translations: Record<string, string>;
  setLanguage: (lang: string) => void;
  t: (key: string) => string;
  formatPrice: (amount: number) => string;
}

const TranslationContext = createContext<TranslationContextType | undefined>(undefined);

// Currency mapping for different countries
const currencyMap: Record<string, { symbol: string; code: string; rate: number }> = {
  en: { symbol: '£', code: 'GBP', rate: 1 },
  fr: { symbol: '€', code: 'EUR', rate: 1.17 },
  de: { symbol: '€', code: 'EUR', rate: 1.17 },
  es: { symbol: '€', code: 'EUR', rate: 1.17 },
  it: { symbol: '€', code: 'EUR', rate: 1.17 },
  nl: { symbol: '€', code: 'EUR', rate: 1.17 }
};

// Comprehensive translation dictionaries
const translationData: Record<string, Record<string, string>> = {
  en: {
    // Navigation
    'nav.dashboard': 'Dashboard',
    'nav.supplements': 'Supplements',
    'nav.biometrics': 'Biometrics',
    'nav.shop': 'Shop',
    'nav.blog': 'Blog',
    'nav.social': 'Social',
    'nav.community': 'Community',
    'nav.illnessGuides': 'Illness Guides',
    'nav.chat': 'Chat',
    'nav.help': 'Help',
    'nav.signOut': 'Sign Out',
    'nav.profile': 'Profile',
    'nav.profileSettings': 'Profile Settings',
    'nav.contact': 'Contact',
    'nav.about': 'About',
    
    // Dashboard
    'dashboard.title': 'Community Dashboard',
    'dashboard.welcome': 'Welcome to Ordinary People Community',
    'dashboard.subtitle': 'Your platform for discussions on government, health, and personal views',
    'dashboard.logSupplement': 'Log Supplement',
    'dashboard.addBiometric': 'Add Biometric',
    'dashboard.viewProgress': 'View Progress',
    'dashboard.askAI': 'Ask AI Anything',
    'dashboard.profileWall': 'Profile Wall',
    'dashboard.features': 'Platform Features',
    
    // Authentication
    'createAccount': 'Create Account',
    'welcomeBack': 'Welcome Back',
    'startHealthJourney': 'Join discussions on government, health, and personal views with Ordinary People Community',
    'signInAccess': 'Sign in to access your community dashboard',
    'fullName': 'Full Name',
    'enterFullName': 'Enter your full name',
    'email': 'Email',
    'enterEmail': 'Enter your email address',
    'password': 'Password',
    'enterPassword': 'Enter your password',
    'confirmPassword': 'Confirm Password',
    'confirmPasswordPlaceholder': 'Confirm your password',
    'signIn': 'Sign In',
    'signUp': 'Sign Up',
    'forgotPassword': 'Forgot Password?',
    'resetPassword': 'Reset Password',
    'backToSignIn': 'Back to Sign In',
    'alreadyHaveAccount': 'Already have an account?',
    'needAccount': 'Need an account?',
    'clickHereSignIn': 'Click here to sign in',
    'clickHereSignUp': 'Click here to sign up',
    'selectLanguage': 'Select Language',
    
    // Common buttons and actions
    'common.loading': 'Loading...',
    'common.save': 'Save',
    'common.cancel': 'Cancel',
    'common.delete': 'Delete',
    'common.edit': 'Edit',
    'common.add': 'Add',
    'common.search': 'Search',
    'common.filter': 'Filter',
    'common.share': 'Share',
    'common.like': 'Like',
    'common.likes': 'Likes',
    'common.comment': 'Comment',
    'common.comments': 'Comments',
    'common.submit': 'Submit',
    'common.continue': 'Continue',
    'common.back': 'Back',
    'common.next': 'Next',
    'common.previous': 'Previous',
    'common.close': 'Close',
    'common.open': 'Open',
    'common.view': 'View',
    'common.download': 'Download',
    'common.upload': 'Upload',
    
    // Health & Wellness
    'health.title': 'Health/Wellness Guide',
    'health.subtitle': 'Comprehensive information about various health conditions',
    'health.searchPlaceholder': 'Type here to search for any illness or condition...',
    'health.browseCategories': 'Browse by Health Category',
    'health.quickBrowse': 'Quick Browse: Click to select any illness',
    'health.noResults': 'No guides found',
    'health.tryDifferent': 'Try different keywords or browse all guides',
    'health.learnMore': 'Learn More',
    'health.allConditions': 'All Conditions',
    'health.conditions': 'conditions',
    'health.dailySteps': 'Daily Steps',
    'health.sleepHours': 'Sleep Hours',
    'health.weight': 'Weight',
    'health.heartRate': 'Heart Rate',
    
    // Categories
    'category.mentalHealth': 'Mental Health',
    'category.cardiovascular': 'Cardiovascular',
    'category.neurological': 'Neurological',
    'category.endocrine': 'Endocrine',
    'category.musculoskeletal': 'Musculoskeletal',
    'category.gastrointestinal': 'Gastrointestinal',
    'category.sleepHealth': 'Sleep Health',
    
    // Community
    'community.title': 'Community Discussions',
    'community.subtitle': 'Connect with others on your health journey',
    'community.joinDiscussion': 'Join Discussion',
    'community.startDiscussion': 'Start New Discussion',
    'community.participants': 'participants',
    'community.messages': 'messages',
    
    // Chat
    'chat.title': 'Chat & Support',
    'chat.findUsers': 'Find Users',
    'chat.conversations': 'Conversations',
    'chat.startConversation': 'Start Your First Conversation',
    'chat.searchUsers': 'Search users by name...',
    'chat.noConversations': 'No conversations yet',
    'chat.typeName': 'Type a name to search for users',
    'chat.noUsers': 'No users found',
    'chat.unreadMessages': 'Unread messages',
    'chat.openChat': 'Open Chat',
    
    // Shop
    'shop.title': 'Supplement Shop',
    'shop.subtitle': 'High-quality supplements for your health journey',
    'shop.addToCart': 'Add to Cart',
    'shop.viewProduct': 'View Product',
    'shop.outOfStock': 'Out of Stock',
    'shop.inStock': 'In Stock',
    
    // Forms
    'form.name': 'Name',
    'form.email': 'Email',
    'form.password': 'Password',
    'form.confirmPassword': 'Confirm Password',
    'form.message': 'Message',
    'form.subject': 'Subject',
    'form.phone': 'Phone',
    'form.address': 'Address',
    'form.required': 'Required',
    
    // Authentication
    'auth.signIn': 'Sign In',
    'auth.signUp': 'Sign Up',
    'auth.signOut': 'Sign Out',
    'auth.forgotPassword': 'Forgot Password?',
    'auth.resetPassword': 'Reset Password',
    'auth.createAccount': 'Create Account',
    'auth.welcomeBack': 'Welcome Back',
    'auth.joinCommunity': 'Join Our Community',
    
    // Login Page
    'login.welcomeTo': 'Welcome to',
    'login.communityName': 'Ordinary People Community',
    'login.awayFromElites': 'Ordinary People Community - Discussions on Government, Health & Personal Views',
    'login.connectShareHeal': 'Connect. Share. Heal Together.',
    'login.joinThousands': 'Join thousands of individuals who believe in open community discussions. Ordinary People Community is where real people share experiences about government topics, health advice, personal views, and life journeys - without corporate influence or elite gatekeeping.',
    'login.shareJourney': 'Share Your Journey',
    'login.shareJourneyDesc': 'Document your supplement regimens, track your energy levels, and share what works for your body.',
    'login.findSupport': 'Find Your Support Tribe',
    'login.findSupportDesc': 'Connect with people who understand your health challenges and celebrate your victories.',
    'login.realExperiences': 'Real Experiences, No Agenda',
    'login.realExperiencesDesc': 'Honest reviews of supplements, treatments, and lifestyle changes from people like you.',
    'login.dataOwnership': 'Own Your Health Data',
    'login.dataOwnershipDesc': 'Your health information belongs to you, not corporations or healthcare systems.',
    'login.globalConnection': 'Global Health Freedom',
    'login.globalConnectionDesc': 'Connect with a worldwide community committed to health independence and natural healing.',
    'login.expertGuidance': 'Community-Driven Insights',
    'login.expertGuidanceDesc': 'Learn from collective wisdom and real-world results, not profit-driven recommendations.',
    
    // Advertising
    'ad.businessPackage': 'Business Advertising Package',
    'ad.advertiseYourBusiness': 'Advertise Your Business',
    'ad.subtitle': 'Reach 10,000+ Health-Conscious Users',
    'ad.description': 'Join our exclusive business community and get premium advertising with your own dedicated storefront.',
    'ad.yearlyPrice': '/Year',
    'ad.getStarted': 'Get Started',
    'ad.contactUs': 'Contact Us',
    'ad.whatsIncluded': 'What\'s Included in Your Package',
    'ad.carouselAds': 'Carousel Advertisements',
    'ad.carouselDetail1': 'Your ads rotate every 8 seconds across 5 major pages',
    'ad.carouselDetail2': 'Dashboard, Shop, Community, Blog, and Contact pages',
    'ad.carouselDetail3': 'High-visibility placement at top of each page',
    'ad.carouselDetail4': 'Professional banner design with your branding',
    'ad.dedicatedStore': 'Your Own Dedicated Online Store',
    'ad.storeDetail1': 'Get your own dedicated store isolated from competitors',
    'ad.storeDetail2': 'Add unlimited products or services with your own pricing',
    'ad.storeDetail3': 'Complete online payment system powered by Stripe',
    'ad.storeDetail4': 'Full product catalog with descriptions, images, and categories',
    'ad.storeDetail5': 'Direct customer orders and payment processing',
    'ad.storeDetail6': 'Prominent link from your Profile Wall to drive traffic',
    'ad.locationTargeting': 'Location-Based Targeting',
    'ad.locationDetail1': 'Nottingham local business priority',
    'ad.locationDetail2': 'UK national business coverage',
    'ad.locationDetail3': 'Health-focused audience targeting',
    'ad.locationDetail4': 'Community integration opportunities',
    'ad.salesAnalytics': 'Sales & Analytics',
    'ad.analyticsDetail1': 'Real product sales through Stripe',
    'ad.analyticsDetail2': 'Order management dashboard',
    'ad.analyticsDetail3': 'Customer interaction tracking',
    'ad.analyticsDetail4': 'Monthly performance reports',
    'ad.howItWorks': 'How Our Advertising System Works',
    'ad.step1': 'Donate £24 to Join',
    'ad.step1Desc': 'Support our community with a yearly contribution to access premium business features',
    'ad.step2': 'Setup Your Business Profile',
    'ad.step2Desc': 'We\'ll help you create your company profile and upload your first advertisement images',
    'ad.step3': 'Launch Your Storefront',
    'ad.step3Desc': 'Add your products/services and start receiving orders from our health-conscious community',
    'ad.step4': 'Track Your Success',
    'ad.step4Desc': 'Monitor your ad performance, customer engagement, and sales through our analytics dashboard',
    
    // Support
    'support.donate': 'Donate',
    'support.support': 'Support',
    'support.thankYou': 'Thank You',
    'support.helpUs': 'Help Support Our Community',
    
    // Tutorial
    'tutorial.tryThis': 'Try this',
    'tutorial.step': 'Step',
    'tutorial.of': 'of',
    'tutorial.previous': 'Previous',
    'tutorial.next': 'Next',
    'tutorial.gotIt': 'Got it!',
    'tutorial.skipTutorial': 'Skip tutorial',
    'tutorial.connectWithOthers': 'Connect with Others',
    'tutorial.findAndConnect': 'Find and connect with other health / wellness-focused community members. Build your support network.',
    'tutorial.useSearch': 'Use the search to find people with similar health / wellness interests',
    
    // Status messages
    'status.success': 'Success',
    'status.error': 'Error',
    'status.warning': 'Warning',
    'status.info': 'Information',
    
    // Time and dates
    'time.today': 'Today',
    'time.yesterday': 'Yesterday',
    'time.thisWeek': 'This Week',
    'time.thisMonth': 'This Month',
    'time.thisYear': 'This Year'
  },
  
  fr: {
    // Navigation
    'nav.dashboard': 'Tableau de Bord',
    'nav.supplements': 'Suppléments',
    'nav.biometrics': 'Biométrie',
    'nav.shop': 'Boutique',
    'nav.blog': 'Blog',
    'nav.social': 'Social',
    'nav.community': 'Communauté',
    'nav.illnessGuides': 'Guides Santé',
    'nav.chat': 'Chat',
    'nav.help': 'Aide',
    'nav.signOut': 'Déconnexion',
    'nav.profile': 'Profil',
    'nav.profileSettings': 'Paramètres de Profil',
    'nav.contact': 'Contact',
    'nav.about': 'À Propos',
    
    // Authentication
    'createAccount': 'Créer un Compte',
    'welcomeBack': 'Bon Retour',
    'startHealthJourney': 'Commencez votre parcours santé avec la Communauté Santé du Peuple',
    'signInAccess': 'Connectez-vous pour accéder à votre tableau de bord santé',
    'fullName': 'Nom Complet',
    'enterFullName': 'Entrez votre nom complet',
    'email': 'Email',
    'enterEmail': 'Entrez votre adresse email',
    'password': 'Mot de Passe',
    'enterPassword': 'Entrez votre mot de passe',
    'confirmPassword': 'Confirmer Mot de Passe',
    'confirmPasswordPlaceholder': 'Confirmez votre mot de passe',
    'signIn': 'Se Connecter',
    'signUp': 'S\'inscrire',
    'forgotPassword': 'Mot de passe oublié ?',
    'resetPassword': 'Réinitialiser Mot de Passe',
    'backToSignIn': 'Retour à la Connexion',
    'alreadyHaveAccount': 'Vous avez déjà un compte ?',
    'needAccount': 'Besoin d\'un compte ?',
    'clickHereSignIn': 'Cliquez ici pour vous connecter',
    'clickHereSignUp': 'Cliquez ici pour vous inscrire',
    'selectLanguage': 'Choisir la Langue',

    // Dashboard
    'dashboard.title': 'Tableau de Bord Communautaire',
    'dashboard.welcome': 'Bienvenue dans la Communauté des Gens Ordinaires',
    'dashboard.subtitle': 'Votre plateforme pour discussions gouvernementales, santé et opinions personnelles',
    'dashboard.logSupplement': 'Enregistrer Supplément',
    'dashboard.addBiometric': 'Ajouter Biométrie',
    'dashboard.viewProgress': 'Voir Progrès',
    'dashboard.askAI': 'Demander à l\'IA',
    'dashboard.profileWall': 'Mur de Profil',
    'dashboard.features': 'Fonctionnalités',
    
    // Common
    'common.loading': 'Chargement...',
    'common.save': 'Enregistrer',
    'common.cancel': 'Annuler',
    'common.delete': 'Supprimer',
    'common.edit': 'Modifier',
    'common.add': 'Ajouter',
    'common.search': 'Rechercher',
    'common.filter': 'Filtrer',
    'common.share': 'Partager',
    'common.like': 'J\'aime',
    'common.likes': 'J\'aime',
    'common.comment': 'Commenter',
    'common.comments': 'Commentaires',
    'common.submit': 'Soumettre',
    'common.continue': 'Continuer',
    'common.back': 'Retour',
    'common.next': 'Suivant',
    'common.previous': 'Précédent',
    'common.close': 'Fermer',
    'common.open': 'Ouvrir',
    'common.view': 'Voir',
    'common.download': 'Télécharger',
    'common.upload': 'Téléverser',
    
    // Health & Wellness
    'health.title': 'Guide Santé/Bien-être',
    'health.subtitle': 'Informations complètes sur diverses conditions de santé',
    'health.searchPlaceholder': 'Tapez ici pour rechercher une maladie ou condition...',
    'health.browseCategories': 'Parcourir par Catégorie Santé',
    'health.quickBrowse': 'Navigation Rapide: Cliquez pour sélectionner une maladie',
    'health.noResults': 'Aucun guide trouvé',
    'health.tryDifferent': 'Essayez des mots-clés différents ou parcourez tous les guides',
    'health.learnMore': 'En Savoir Plus',
    'health.allConditions': 'Toutes les Conditions',
    'health.conditions': 'conditions',
    
    // Categories
    'category.mentalHealth': 'Santé Mentale',
    'category.cardiovascular': 'Cardiovasculaire',
    'category.neurological': 'Neurologique',
    'category.endocrine': 'Endocrinien',
    'category.musculoskeletal': 'Musculo-squelettique',
    'category.gastrointestinal': 'Gastro-intestinal',
    'category.sleepHealth': 'Santé du Sommeil',
    
    // Community
    'community.title': 'Discussions Communautaires',
    'community.subtitle': 'Connectez-vous avec d\'autres sur votre parcours santé',
    'community.joinDiscussion': 'Rejoindre Discussion',
    'community.startDiscussion': 'Nouvelle Discussion',
    'community.participants': 'participants',
    'community.messages': 'messages',
    
    // Chat
    'chat.title': 'Chat et Support',
    'chat.findUsers': 'Trouver Utilisateurs',
    'chat.conversations': 'Conversations',
    'chat.startConversation': 'Commencer Votre Première Conversation',
    'chat.searchUsers': 'Rechercher utilisateurs par nom...',
    'chat.noConversations': 'Aucune conversation encore',
    'chat.typeName': 'Tapez un nom pour rechercher des utilisateurs',
    'chat.noUsers': 'Aucun utilisateur trouvé',
    
    // Shop
    'shop.title': 'Boutique Suppléments',
    'shop.subtitle': 'Suppléments de haute qualité pour votre parcours santé',
    'shop.addToCart': 'Ajouter au Panier',
    'shop.viewProduct': 'Voir Produit',
    'shop.outOfStock': 'Rupture de Stock',
    'shop.inStock': 'En Stock',
    
    // Authentication
    'auth.signIn': 'Se Connecter',
    'auth.signUp': 'S\'inscrire',
    'auth.signOut': 'Déconnexion',
    'auth.forgotPassword': 'Mot de Passe Oublié?',
    'auth.resetPassword': 'Réinitialiser Mot de Passe',
    'auth.createAccount': 'Créer un Compte',
    'auth.welcomeBack': 'Bon Retour',
    'auth.joinCommunity': 'Rejoindre Notre Communauté',
    
    // Login Page
    'login.welcomeTo': 'Bienvenue à',
    'login.communityName': 'La Communauté Santé du Peuple',
    'login.awayFromElites': 'La Communauté Santé du Peuple - Loin des Élites',
    'login.connectShareHeal': 'Connectez. Partagez. Guérissez Ensemble.',
    'login.joinThousands': 'Rejoignez des milliers d\'individus soucieux de leur santé qui croient au pouvoir de la guérison communautaire. La Communauté Santé du Peuple est où de vraies personnes partagent de vraies expériences sur les suppléments, remèdes naturels, routines d\'exercice et parcours de bien-être - sans influence corporative ou élitisme.',
    'login.shareJourney': 'Partagez Votre Parcours',
    'login.shareJourneyDesc': 'Documentez vos régimes de suppléments, suivez vos niveaux d\'énergie et partagez ce qui fonctionne pour votre corps.',
    'login.findSupport': 'Trouvez Votre Tribu de Soutien',
    'login.findSupportDesc': 'Connectez-vous avec des personnes qui comprennent vos défis de santé et célèbrent vos victoires.',
    'login.realExperiences': 'Vraies Expériences, Aucun Agenda',
    'login.realExperiencesDesc': 'Avis honnêtes sur les suppléments, traitements et changements de style de vie de personnes comme vous.',
    'login.dataOwnership': 'Possédez Vos Données de Santé',
    'login.dataOwnershipDesc': 'Vos informations de santé vous appartiennent, pas aux corporations ou systèmes de santé.',
    'login.globalConnection': 'Liberté Sanitaire Mondiale',
    'login.globalConnectionDesc': 'Connectez-vous avec une communauté mondiale engagée dans l\'indépendance sanitaire et la guérison naturelle.',
    'login.expertGuidance': 'Perspectives Communautaires',
    'login.expertGuidanceDesc': 'Apprenez de la sagesse collective et des résultats du monde réel, pas des recommandations motivées par le profit.',
    
    // Advertising
    'ad.businessPackage': 'Package Publicité Entreprise',
    'ad.advertiseYourBusiness': 'Annoncez Votre Entreprise',
    'ad.yearlyPrice': '/An',
    'ad.getStarted': 'Commencer',
    'ad.contactUs': 'Nous Contacter',
    
    // Support
    'support.donate': 'Faire Don',
    'support.support': 'Soutenir',
    'support.thankYou': 'Merci',
    'support.helpUs': 'Aidez à Soutenir Notre Communauté'
  },
  
  de: {
    // Navigation
    'nav.dashboard': 'Dashboard',
    'nav.supplements': 'Nahrungsergänzung',
    'nav.biometrics': 'Biometrie',
    'nav.shop': 'Shop',
    'nav.blog': 'Blog',
    'nav.social': 'Sozial',
    'nav.community': 'Gemeinschaft',
    'nav.illnessGuides': 'Gesundheitsratgeber',
    'nav.chat': 'Chat',
    'nav.help': 'Hilfe',
    'nav.signOut': 'Abmelden',
    'nav.profile': 'Profil',
    'nav.profileSettings': 'Profil-Einstellungen',
    'nav.contact': 'Kontakt',
    'nav.about': 'Über Uns',
    
    // Dashboard
    'dashboard.title': 'Gesundheits-Dashboard',
    'dashboard.welcome': 'Willkommen bei der Volksgesundheitsgemeinschaft',
    'dashboard.subtitle': 'Ihre umfassende Gesundheitsverfolgungsplattform abseits der Eliten',
    'dashboard.logSupplement': 'Supplement Protokollieren',
    'dashboard.addBiometric': 'Biometrie Hinzufügen',
    'dashboard.viewProgress': 'Fortschritt Anzeigen',
    'dashboard.askAI': 'KI Fragen',
    'dashboard.profileWall': 'Profilwand',
    'dashboard.features': 'Funktionen',
    
    // Common
    'common.loading': 'Lädt...',
    'common.save': 'Speichern',
    'common.cancel': 'Abbrechen',
    'common.delete': 'Löschen',
    'common.edit': 'Bearbeiten',
    'common.add': 'Hinzufügen',
    'common.search': 'Suchen',
    'common.filter': 'Filtern',
    'common.share': 'Teilen',
    'common.like': 'Gefällt mir',
    'common.likes': 'Gefällt mir',
    'common.comment': 'Kommentieren',
    'common.comments': 'Kommentare',
    'common.submit': 'Absenden',
    'common.continue': 'Weiter',
    'common.back': 'Zurück',
    'common.next': 'Weiter',
    'common.previous': 'Vorherige',
    'common.close': 'Schließen',
    'common.open': 'Öffnen',
    'common.view': 'Anzeigen',
    'common.download': 'Herunterladen',
    'common.upload': 'Hochladen',
    
    // Health & Wellness
    'health.title': 'Gesundheits-/Wellness-Ratgeber',
    'health.subtitle': 'Umfassende Informationen über verschiedene Gesundheitszustände',
    'health.searchPlaceholder': 'Hier tippen, um nach Krankheiten oder Zuständen zu suchen...',
    'health.browseCategories': 'Nach Gesundheitskategorie durchsuchen',
    'health.quickBrowse': 'Schnellnavigation: Klicken Sie, um eine Krankheit auszuwählen',
    'health.noResults': 'Keine Ratgeber gefunden',
    'health.tryDifferent': 'Versuchen Sie andere Suchbegriffe oder durchsuchen Sie alle Ratgeber',
    'health.learnMore': 'Mehr Erfahren',
    'health.allConditions': 'Alle Zustände',
    'health.conditions': 'Zustände',
    
    // Categories
    'category.mentalHealth': 'Psychische Gesundheit',
    'category.cardiovascular': 'Herz-Kreislauf',
    'category.neurological': 'Neurologisch',
    'category.endocrine': 'Endokrin',
    'category.musculoskeletal': 'Muskel-Skelett',
    'category.gastrointestinal': 'Magen-Darm',
    'category.sleepHealth': 'Schlafgesundheit',
    
    // Community
    'community.title': 'Gemeinschaftsdiskussionen',
    'community.subtitle': 'Vernetzen Sie sich mit anderen auf Ihrer Gesundheitsreise',
    'community.joinDiscussion': 'Diskussion Beitreten',
    'community.startDiscussion': 'Neue Diskussion',
    'community.participants': 'Teilnehmer',
    'community.messages': 'Nachrichten',
    
    // Authentication
    'auth.signIn': 'Anmelden',
    'auth.signUp': 'Registrieren',
    'auth.signOut': 'Abmelden',
    'auth.forgotPassword': 'Passwort Vergessen?',
    'auth.resetPassword': 'Passwort Zurücksetzen',
    'auth.createAccount': 'Konto Erstellen',
    'auth.welcomeBack': 'Willkommen Zurück',
    'auth.joinCommunity': 'Unserer Gemeinschaft Beitreten',
    
    // Advertising
    'ad.businessPackage': 'Business-Werbepaket',
    'ad.advertiseYourBusiness': 'Bewerben Sie Ihr Geschäft',
    'ad.subtitle': 'Erreichen Sie 10.000+ Gesundheitsbewusste Nutzer',
    'ad.description': 'Treten Sie unserer exklusiven Geschäftsgemeinschaft bei und erhalten Sie Premium-Werbung mit Ihrem eigenen Shop.',
    'ad.yearlyPrice': '/Jahr',
    'ad.getStarted': 'Loslegen',
    'ad.contactUs': 'Kontaktieren Sie Uns',
    'ad.whatsIncluded': 'Was ist in Ihrem Paket enthalten',
    'ad.carouselAds': 'Karussell-Anzeigen',
    'ad.carouselDetail1': 'Ihre Anzeigen rotieren alle 8 Sekunden auf 5 Hauptseiten',
    'ad.carouselDetail2': 'Dashboard, Shop, Community, Blog und Kontakt-Seiten',
    'ad.carouselDetail3': 'Hochsichtbare Platzierung oben auf jeder Seite',
    'ad.carouselDetail4': 'Professionelles Banner-Design mit Ihrem Branding',
    'ad.dedicatedStore': 'Ihr Eigener Dedizierter Online-Shop',
    'ad.storeDetail1': 'Erhalten Sie Ihren eigenen Shop isoliert von Konkurrenten',
    'ad.storeDetail2': 'Fügen Sie unbegrenzte Produkte oder Dienstleistungen mit eigenen Preisen hinzu',
    'ad.storeDetail3': 'Komplettes Online-Zahlungssystem von Stripe',
    'ad.storeDetail4': 'Vollständiger Produktkatalog mit Beschreibungen, Bildern und Kategorien',
    'ad.storeDetail5': 'Direkte Kundenbestellungen und Zahlungsabwicklung',
    'ad.storeDetail6': 'Prominenter Link von Ihrer Profilwand für Traffic',
    'ad.locationTargeting': 'Standortbasierte Ausrichtung',
    'ad.locationDetail1': 'Nottingham lokale Geschäftspriorität',
    'ad.locationDetail2': 'UK nationale Geschäftsabdeckung',
    'ad.locationDetail3': 'Gesundheitsfokussierte Zielgruppenansprache',
    'ad.locationDetail4': 'Community-Integrationsmöglichkeiten',
    'ad.salesAnalytics': 'Verkauf & Analysen',
    'ad.analyticsDetail1': 'Echte Produktverkäufe über Stripe',
    'ad.analyticsDetail2': 'Bestellverwaltungs-Dashboard',
    'ad.analyticsDetail3': 'Kundeninteraktions-Tracking',
    'ad.analyticsDetail4': 'Monatliche Leistungsberichte',
    'ad.howItWorks': 'So funktioniert unser Werbesystem',
    'ad.step1': '€28,08 Spenden zum Beitritt',
    'ad.step1Desc': 'Unterstützen Sie unsere Community mit einem Jahresbeitrag für Premium-Geschäftsfunktionen',
    'ad.step2': 'Erstellen Sie Ihr Geschäftsprofil',
    'ad.step2Desc': 'Wir helfen Ihnen beim Erstellen Ihres Firmenprofils und Hochladen Ihrer ersten Werbegrafiken',
    'ad.step3': 'Starten Sie Ihren Shop',
    'ad.step3Desc': 'Fügen Sie Ihre Produkte/Dienstleistungen hinzu und erhalten Sie Bestellungen von unserer gesundheitsbewussten Community',
    'ad.step4': 'Verfolgen Sie Ihren Erfolg',
    'ad.step4Desc': 'Überwachen Sie Ihre Anzeigenleistung, Kundenengagement und Verkäufe über unser Analyse-Dashboard',
    
    // Support
    'support.donate': 'Spenden',
    'support.support': 'Unterstützen',
    'support.thankYou': 'Danke',
    'support.helpUs': 'Helfen Sie Unsere Gemeinschaft zu Unterstützen',
    
    // Tutorial
    'tutorial.tryThis': 'Versuchen Sie dies',
    'tutorial.step': 'Schritt',
    'tutorial.of': 'von',
    'tutorial.previous': 'Zurück',
    'tutorial.next': 'Weiter',
    'tutorial.gotIt': 'Verstanden!',
    'tutorial.skipTutorial': 'Tutorial überspringen',
    'tutorial.connectWithOthers': 'Mit Anderen Verbinden',
    'tutorial.findAndConnect': 'Finden und verbinden Sie sich mit anderen gesundheits- / wellness-fokussierten Gemeinschaftsmitgliedern. Bauen Sie Ihr Unterstützungsnetzwerk auf.',
    'tutorial.useSearch': 'Verwenden Sie die Suche, um Personen mit ähnlichen Gesundheits- / Wellness-Interessen zu finden'
  },
  
  es: {
    // Navigation
    'nav.dashboard': 'Panel de Control',
    'nav.supplements': 'Suplementos',
    'nav.biometrics': 'Biométrica',
    'nav.shop': 'Tienda',
    'nav.blog': 'Blog',
    'nav.social': 'Social',
    'nav.community': 'Comunidad',
    'nav.illnessGuides': 'Guías de Salud',
    'nav.chat': 'Chat',
    'nav.help': 'Ayuda',
    'nav.signOut': 'Cerrar Sesión',
    'nav.profile': 'Perfil',
    'nav.profileSettings': 'Configuración de Perfil',
    'nav.contact': 'Contacto',
    'nav.about': 'Acerca de',
    
    // Dashboard
    'dashboard.title': 'Panel de Salud',
    'dashboard.welcome': 'Bienvenido a la Comunidad de Salud del Pueblo',
    'dashboard.subtitle': 'Su plataforma integral de seguimiento de salud lejos de las élites',
    'dashboard.logSupplement': 'Registrar Suplemento',
    'dashboard.addBiometric': 'Añadir Biométrica',
    'dashboard.viewProgress': 'Ver Progreso',
    'dashboard.askAI': 'Preguntar a IA',
    'dashboard.profileWall': 'Muro de Perfil',
    'dashboard.features': 'Características',
    
    // Common
    'common.loading': 'Cargando...',
    'common.save': 'Guardar',
    'common.cancel': 'Cancelar',
    'common.delete': 'Eliminar',
    'common.edit': 'Editar',
    'common.add': 'Añadir',
    'common.search': 'Buscar',
    'common.filter': 'Filtrar',
    'common.share': 'Compartir',
    'common.like': 'Me gusta',
    'common.likes': 'Me gusta',
    'common.comment': 'Comentar',
    'common.comments': 'Comentarios',
    'common.submit': 'Enviar',
    'common.continue': 'Continuar',
    'common.back': 'Atrás',
    'common.next': 'Siguiente',
    'common.previous': 'Anterior',
    'common.close': 'Cerrar',
    'common.open': 'Abrir',
    'common.view': 'Ver',
    'common.download': 'Descargar',
    'common.upload': 'Subir',
    
    // Health & Wellness
    'health.title': 'Guía de Salud/Bienestar',
    'health.subtitle': 'Información completa sobre varias condiciones de salud',
    'health.searchPlaceholder': 'Escriba aquí para buscar cualquier enfermedad o condición...',
    'health.browseCategories': 'Explorar por Categoría de Salud',
    'health.quickBrowse': 'Navegación Rápida: Haga clic para seleccionar cualquier enfermedad',
    'health.noResults': 'No se encontraron guías',
    'health.tryDifferent': 'Pruebe palabras clave diferentes o explore todas las guías',
    'health.learnMore': 'Saber Más',
    'health.allConditions': 'Todas las Condiciones',
    'health.conditions': 'condiciones',
    
    // Categories
    'category.mentalHealth': 'Salud Mental',
    'category.cardiovascular': 'Cardiovascular',
    'category.neurological': 'Neurológico',
    'category.endocrine': 'Endocrino',
    'category.musculoskeletal': 'Musculoesquelético',
    'category.gastrointestinal': 'Gastrointestinal',
    'category.sleepHealth': 'Salud del Sueño',
    
    // Authentication
    'auth.signIn': 'Iniciar Sesión',
    'auth.signUp': 'Registrarse',
    'auth.signOut': 'Cerrar Sesión',
    'auth.forgotPassword': '¿Olvidó la Contraseña?',
    'auth.resetPassword': 'Restablecer Contraseña',
    'auth.createAccount': 'Crear Cuenta',
    'auth.welcomeBack': 'Bienvenido de Nuevo',
    'auth.joinCommunity': 'Únete a Nuestra Comunidad',
    
    // Advertising
    'ad.businessPackage': 'Paquete de Publicidad Empresarial',
    'ad.advertiseYourBusiness': 'Anuncie Su Negocio',
    'ad.yearlyPrice': '/Año',
    'ad.getStarted': 'Comenzar',
    'ad.contactUs': 'Contáctanos',
    
    // Support
    'support.donate': 'Donar',
    'support.support': 'Apoyar',
    'support.thankYou': 'Gracias',
    'support.helpUs': 'Ayude a Apoyar Nuestra Comunidad',
    
    // Tutorial
    'tutorial.tryThis': 'Pruebe esto',
    'tutorial.step': 'Paso',
    'tutorial.of': 'de',
    'tutorial.previous': 'Anterior',
    'tutorial.next': 'Siguiente',
    'tutorial.gotIt': '¡Entendido!',
    'tutorial.skipTutorial': 'Omitir tutorial',
    'tutorial.connectWithOthers': 'Conectar con Otros',
    'tutorial.findAndConnect': 'Encuentre y conéctese con otros miembros de la comunidad enfocados en salud / bienestar. Construya su red de apoyo.',
    'tutorial.useSearch': 'Use la búsqueda para encontrar personas con intereses similares de salud / bienestar'
  },
  
  it: {
    // Navigation
    'nav.dashboard': 'Dashboard',
    'nav.supplements': 'Integratori',
    'nav.biometrics': 'Biometria',
    'nav.shop': 'Negozio',
    'nav.blog': 'Blog',
    'nav.social': 'Sociale',
    'nav.community': 'Comunità',
    'nav.illnessGuides': 'Guide Salute',
    'nav.chat': 'Chat',
    'nav.help': 'Aiuto',
    'nav.signOut': 'Disconnetti',
    'nav.profile': 'Profilo',
    'nav.profileSettings': 'Impostazioni Profilo',
    'nav.contact': 'Contatto',
    'nav.about': 'Chi Siamo',
    
    // Dashboard
    'dashboard.title': 'Dashboard Salute',
    'dashboard.welcome': 'Benvenuto nella Comunità Sanitaria del Popolo',
    'dashboard.subtitle': 'La vostra piattaforma completa di monitoraggio sanitario lontano dalle élite',
    'dashboard.logSupplement': 'Registra Integratore',
    'dashboard.addBiometric': 'Aggiungi Biometria',
    'dashboard.viewProgress': 'Visualizza Progresso',
    'dashboard.askAI': 'Chiedi all\'IA',
    'dashboard.profileWall': 'Bacheca Profilo',
    'dashboard.features': 'Caratteristiche',
    
    // Health & Wellness (Italian specific)
    'health.dailySteps': 'Passi Giornalieri',
    'health.sleepHours': 'Ore di Sonno',
    'health.weight': 'Peso',
    'health.heartRate': 'Frequenza Cardiaca',
    
    // Chat (Italian specific)
    'chat.unreadMessages': 'Messaggi non letti',
    'chat.openChat': 'Apri Chat',
    
    // Common
    'common.loading': 'Caricamento...',
    'common.save': 'Salva',
    'common.cancel': 'Annulla',
    'common.delete': 'Elimina',
    'common.edit': 'Modifica',
    'common.add': 'Aggiungi',
    'common.search': 'Cerca',
    'common.filter': 'Filtra',
    'common.share': 'Condividi',
    'common.like': 'Mi piace',
    'common.likes': 'Mi piace',
    'common.comment': 'Commenta',
    'common.comments': 'Commenti',
    'common.submit': 'Invia',
    'common.continue': 'Continua',
    'common.back': 'Indietro',
    'common.next': 'Avanti',
    'common.previous': 'Precedente',
    'common.close': 'Chiudi',
    'common.open': 'Apri',
    'common.view': 'Visualizza',
    'common.download': 'Scarica',
    'common.upload': 'Carica',
    

    
    // Categories
    'category.mentalHealth': 'Salute Mentale',
    'category.cardiovascular': 'Cardiovascolare',
    'category.neurological': 'Neurologico',
    'category.endocrine': 'Endocrino',
    'category.musculoskeletal': 'Muscoloscheletrico',
    'category.gastrointestinal': 'Gastrointestinale',
    'category.sleepHealth': 'Salute del Sonno',
    
    // Authentication
    'auth.signIn': 'Accedi',
    'auth.signUp': 'Registrati',
    'auth.signOut': 'Disconnetti',
    'auth.forgotPassword': 'Password Dimenticata?',
    'auth.resetPassword': 'Reimposta Password',
    'auth.createAccount': 'Crea Account',
    'auth.welcomeBack': 'Bentornato',
    'auth.joinCommunity': 'Unisciti alla Nostra Comunità',
    
    // Advertising
    'ad.businessPackage': 'Pacchetto Pubblicitario Aziendale',
    'ad.advertiseYourBusiness': 'Pubblicizza la Tua Attività',
    'ad.yearlyPrice': '/Anno',
    'ad.getStarted': 'Inizia',
    'ad.contactUs': 'Contattaci',
    
    // Support
    'support.donate': 'Dona',
    'support.support': 'Supporta',
    'support.thankYou': 'Grazie',
    'support.helpUs': 'Aiuta a Supportare la Nostra Comunità',
    
    // Tutorial
    'tutorial.tryThis': 'Prova questo',
    'tutorial.step': 'Passo',
    'tutorial.of': 'di',
    'tutorial.previous': 'Precedente',
    'tutorial.next': 'Avanti',
    'tutorial.gotIt': 'Capito!',
    'tutorial.skipTutorial': 'Salta tutorial',
    'tutorial.connectWithOthers': 'Connetti con Altri',
    'tutorial.findAndConnect': 'Trova e connettiti con altri membri della comunità focalizzati sulla salute / benessere. Costruisci la tua rete di supporto.',
    'tutorial.useSearch': 'Usa la ricerca per trovare persone con interessi simili di salute / benessere'
  },
  
  nl: {
    // Navigation
    'nav.dashboard': 'Dashboard',
    'nav.supplements': 'Supplementen',
    'nav.biometrics': 'Biometrie',
    'nav.shop': 'Winkel',
    'nav.blog': 'Blog',
    'nav.social': 'Sociaal',
    'nav.community': 'Gemeenschap',
    'nav.illnessGuides': 'Gezondheidsgidsen',
    'nav.chat': 'Chat',
    'nav.help': 'Help',
    'nav.signOut': 'Uitloggen',
    'nav.profile': 'Profiel',
    'nav.profileSettings': 'Profiel Instellingen',
    'nav.contact': 'Contact',
    'nav.about': 'Over Ons',
    
    // Dashboard
    'dashboard.title': 'Gezondheids Dashboard',
    'dashboard.welcome': 'Welkom bij de Volksgezondheids Gemeenschap',
    'dashboard.subtitle': 'Uw uitgebreide gezondheidsplatform weg van de elites',
    'dashboard.logSupplement': 'Supplement Registreren',
    'dashboard.addBiometric': 'Biometrie Toevoegen',
    'dashboard.viewProgress': 'Voortgang Bekijken',
    'dashboard.askAI': 'Vraag AI',
    'dashboard.profileWall': 'Profiel Muur',
    'dashboard.features': 'Functies',
    
    // Common
    'common.loading': 'Laden...',
    'common.save': 'Opslaan',
    'common.cancel': 'Annuleren',
    'common.delete': 'Verwijderen',
    'common.edit': 'Bewerken',
    'common.add': 'Toevoegen',
    'common.search': 'Zoeken',
    'common.filter': 'Filteren',
    'common.share': 'Delen',
    'common.like': 'Leuk',
    'common.likes': 'Likes',
    'common.comment': 'Reageren',
    'common.comments': 'Reacties',
    'common.submit': 'Versturen',
    'common.continue': 'Doorgaan',
    'common.back': 'Terug',
    'common.next': 'Volgende',
    'common.previous': 'Vorige',
    'common.close': 'Sluiten',
    'common.open': 'Openen',
    'common.view': 'Bekijken',
    'common.download': 'Downloaden',
    'common.upload': 'Uploaden',
    
    // Authentication
    'auth.signIn': 'Inloggen',
    'auth.signUp': 'Registreren',
    'auth.signOut': 'Uitloggen',
    'auth.forgotPassword': 'Wachtwoord Vergeten?',
    'auth.resetPassword': 'Wachtwoord Resetten',
    'auth.createAccount': 'Account Aanmaken',
    'auth.welcomeBack': 'Welkom Terug',
    'auth.joinCommunity': 'Word Lid van Onze Gemeenschap',
    
    // Advertising
    'ad.businessPackage': 'Bedrijfs Advertentie Pakket',
    'ad.advertiseYourBusiness': 'Adverteer Uw Bedrijf',
    'ad.yearlyPrice': '/Jaar',
    'ad.getStarted': 'Begin Nu',
    'ad.contactUs': 'Contacteer Ons',
    
    // Support
    'support.donate': 'Doneren',
    'support.support': 'Ondersteunen',
    'support.thankYou': 'Dank Je',
    'support.helpUs': 'Help Onze Gemeenschap Ondersteunen',
    
    // Tutorial
    'tutorial.tryThis': 'Probeer dit',
    'tutorial.step': 'Stap',
    'tutorial.of': 'van',
    'tutorial.previous': 'Vorige',
    'tutorial.next': 'Volgende',
    'tutorial.gotIt': 'Begrepen!',
    'tutorial.skipTutorial': 'Tutorial overslaan',
    'tutorial.connectWithOthers': 'Verbind met Anderen',
    'tutorial.findAndConnect': 'Vind en verbind met andere gezondheid / wellness-gerichte gemeenschapsleden. Bouw uw ondersteuningsnetwerk op.',
    'tutorial.useSearch': 'Gebruik de zoekopdracht om mensen te vinden met vergelijkbare gezondheid / wellness-interessen'
  }
};

export function TranslationProvider({ children }: { children: ReactNode }) {
  const [language, setLanguage] = useState(() => {
    if (typeof window !== 'undefined') {
      return localStorage.getItem('language') || 'en';
    }
    return 'en';
  });

  const currency = currencyMap[language] || currencyMap.en;
  const translations = translationData[language] || translationData.en;

  useEffect(() => {
    if (typeof window !== 'undefined') {
      localStorage.setItem('language', language);
    }
  }, [language]);

  const t = (key: string): string => {
    return translations[key] || key;
  };

  const formatPrice = (amount: number): string => {
    const convertedAmount = amount * currency.rate;
    return `${currency.symbol}${convertedAmount.toFixed(2)}`;
  };

  return (
    <TranslationContext.Provider value={{
      language,
      currency: currency.code,
      translations,
      setLanguage,
      t,
      formatPrice
    }}>
      {children}
    </TranslationContext.Provider>
  );
}

export function useTranslation() {
  const context = useContext(TranslationContext);
  if (context === undefined) {
    throw new Error('useTranslation must be used within a TranslationProvider');
  }
  return context;
}