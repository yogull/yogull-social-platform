import React from "react";
import { createRoot } from "react-dom/client";
import App from "./App";
import "./index.css";

// Minimal error suppression without popups
window.addEventListener('error', (event) => {
  if (event.error?.message?.includes('cross-origin') || 
      event.error?.message?.includes('Script error')) {
    event.preventDefault();
    return false;
  }
});

createRoot(document.getElementById("root")!).render(<App />);