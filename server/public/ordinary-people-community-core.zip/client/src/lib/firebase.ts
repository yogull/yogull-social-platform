import { initializeApp, getApps, getApp } from "firebase/app";
import { getAuth, connectAuthEmulator } from "firebase/auth";
import { getFirestore, connectFirestoreEmulator } from "firebase/firestore";

// Firebase configuration - using direct values for reliability
const firebaseConfig = {
  apiKey: "AIzaSyAxHlbxOi8qJg8LjrglHZgxZ7qliqg-njI",
  authDomain: "gohealme-9bdf0.firebaseapp.com",
  projectId: "gohealme-9bdf0",
  storageBucket: "gohealme-9bdf0.firebasestorage.app",
  messagingSenderId: "823297665017",
  appId: "1:823297665017:web:3427ba4397e12447ccbf28",
  measurementId: "G-WPZ6J8DSKE",
};

// Initialize Firebase app
let app;
if (getApps().length === 0) {
  app = initializeApp(firebaseConfig);
} else {
  app = getApp();
}

// Initialize Auth and Firestore
export const auth = getAuth(app);
export const db = getFirestore(app);

// Log configuration for debugging
console.log("Firebase Config Check:");
console.log("Project ID:", firebaseConfig.projectId);
console.log("Auth Domain:", firebaseConfig.authDomain);
console.log("API Key present:", !!firebaseConfig.apiKey);
console.log("App ID present:", !!firebaseConfig.appId);

// Test Firebase initialization
try {
  const testAuth = getAuth();
  console.log("Firebase Auth initialized successfully");
} catch (error) {
  console.error("Firebase Auth initialization failed:", error);
}

export default app;
