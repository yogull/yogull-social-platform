/**
 * Copyright (c) 2025 John Proctor. All rights reserved.
 * The People's Health Community Platform
 * Unauthorized copying, distribution, or modification is strictly prohibited.
 */

import React from "react";
import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { TranslationProvider } from "@/hooks/useTranslation";
import { SupportBanner } from "@/components/SupportBanner";
import { CookieConsent } from "@/components/CookieConsent";
import { PWAInstallPrompt } from "@/components/PWAInstallPrompt";
import { Footer } from "@/components/Footer";
import { SEOBooster, usePageSpeed } from "@/components/SEOBooster";
import { GoogleAnalytics } from "@/components/GoogleAnalytics";
import { AdvancedSEO, CoreWebVitalsOptimizer } from "@/components/AdvancedSEO";

import { ErrorAutoFixer } from "@/components/ErrorAutoFixer";
import ErrorBoundary from "@/components/ErrorBoundary";
import { RealTimeButtonFixer } from "@/components/RealTimeButtonFixer";
import Home from "@/pages/Home";
import Login from "@/pages/Login";
import { SimpleLogin } from "@/components/SimpleLogin";
import Supplements from "@/pages/Supplements";
import Biometrics from "@/pages/Biometrics";
import Profile from "@/pages/Profile";
import ProfileSettings from "@/pages/ProfileSettings";
import UserProfile from "@/pages/UserProfile";
import ProfileWallRedirect from "@/pages/ProfileWallRedirect";
import SocialMediaView from "@/pages/SocialMediaView";
import Shop from "@/pages/ShopFixed";
import Admin from "@/pages/Admin";
import MainAdmin from "@/pages/MainAdmin";
import Blog from "@/pages/Blog";
import BlogCategory from "@/pages/BlogCategory";
import Social from "@/pages/Social";
import CommunityFixed from "@/pages/CommunityFixed";
import CategoryDiscussionV2 from "@/pages/CategoryDiscussionV2";
import IllnessGuides from "@/pages/IllnessGuides";
import IllnessDetail from "@/pages/IllnessDetail";
import IllnessAdmin from "@/pages/IllnessAdmin";
import HealthHub from "@/pages/HealthHub";
import Terms from "@/pages/Terms";
import Privacy from "@/pages/Privacy";
import Chat from "@/pages/Chat";
import Contact from "@/pages/Contact";
import AboutUs from "@/pages/AboutUs";
import Disclosures from "@/pages/Disclosures";
import Donate from "@/pages/Donate";
import DonateSuccess from "@/pages/DonateSuccess";
import AdvertisePayment from "@/pages/AdvertisePayment";
import AdvertiseSuccess from "@/pages/AdvertiseSuccess";
import AdvertiserPortal from "@/pages/AdvertiserPortal";
import CompanyStorefront from "@/pages/CompanyStorefront";
import AdminFeedsFixed from "@/pages/AdminFeedsFixed";
import AdminCategories from "@/pages/AdminCategories";
import SuperAdmin from "@/pages/SuperAdmin";
import LocationAds from "@/pages/LocationAds";
import BusinessProfile from "@/pages/BusinessProfile";
import Notifications from "@/pages/Notifications";
import DailyNews from "@/pages/DailyNews";
import PersonalShopSimple from "@/pages/PersonalShopSimple";
import PersonalShopSearch from "@/pages/PersonalShopSearch";
import PersonalShopView from "@/pages/PersonalShopView";
import PersonalShopManage from "@/pages/PersonalShopManage";
import SocialHub from "@/pages/SocialHub";
import BusinessDirectory from "@/pages/BusinessDirectory";
import AdminAffiliateShopsFixed from "@/pages/AdminAffiliateShopsFixed";
import AdminDashboard from "@/pages/AdminDashboard";
import AdminAnalytics from "@/pages/AdminAnalytics";

import ProfileWallWorkingFixed from "@/pages/ProfileWallWorkingFixed";
import SocialMediaViewer from "@/pages/SocialMediaViewer";
import SocialNetworkView from "@/pages/SocialNetworkView";
import GallerySimple from "@/pages/GallerySimple";
import NotFound from "@/pages/not-found";

function Router() {
  usePageSpeed(); // Performance optimization hook
  
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route path="/dashboard" component={Home} />
      <Route path="/login" component={Login} />
      <Route path="/supplements" component={Supplements} />
      <Route path="/daily-log" component={Supplements} />
      <Route path="/biometrics" component={Biometrics} />
      <Route path="/profile" component={Profile} />
      <Route path="/profile-settings" component={ProfileSettings} />
      <Route path="/settings" component={ProfileSettings} />
      <Route path="/users/:userId" component={UserProfile} />
      <Route path="/gallery" component={GallerySimple} />
      <Route path="/gallery/:userId" component={GallerySimple} />
      <Route path="/profile-wall">
        {() => <ProfileWallWorkingFixed key={`profile-wall-${Date.now()}`} />}
      </Route>
      <Route path="/profile-wall/:userId">
        {() => <ProfileWallWorkingFixed key={`profile-wall-${Date.now()}`} />}
      </Route>
      <Route path="/social/:userId/:platform" component={SocialMediaView} />
      <Route path="/social-media/:platform" component={SocialMediaViewer} />
      <Route path="/social-network/:platform" component={SocialNetworkView} />
      <Route path="/shop" component={Shop} />

      <Route path="/social" component={Social} />
      <Route path="/community" component={CommunityFixed} />
      <Route path="/community/category/:categoryId" component={CategoryDiscussionV2} />
      <Route path="/illness-guides" component={IllnessGuides} />
      <Route path="/illness-guides/:illnessId" component={IllnessDetail} />
      <Route path="/illness-admin" component={IllnessAdmin} />
      <Route path="/health-hub" component={HealthHub} />
      <Route path="/chat" component={Chat} />
      <Route path="/news" component={DailyNews} />
      <Route path="/contact" component={Contact} />
      <Route path="/about" component={AboutUs} />
      <Route path="/donate" component={Donate} />
      <Route path="/donate-success" component={DonateSuccess} />
      <Route path="/advertise-payment" component={AdvertisePayment} />
      <Route path="/advertise-success" component={AdvertiseSuccess} />
      <Route path="/advertiser-portal" component={AdvertiserPortal} />
      <Route path="/location-ads" component={LocationAds} />
      <Route path="/business/:id" component={BusinessProfile} />
      <Route path="/business-profile/:id" component={BusinessProfile} />
      <Route path="/business-profile" component={BusinessProfile} />
      <Route path="/personal-shop" component={PersonalShopSimple} />
      <Route path="/personal-shop-search" component={PersonalShopSearch} />
      <Route path="/personal-shop-view/:shopId" component={PersonalShopView} />
      <Route path="/personal-shop-manage/:shopId" component={PersonalShopManage} />
      <Route path="/social-hub" component={SocialHub} />
      <Route path="/business-directory" component={BusinessDirectory} />
      <Route path="/notifications" component={Notifications} />
      <Route path="/daily-news" component={DailyNews} />
      <Route path="/terms" component={Terms} />
      <Route path="/privacy" component={Privacy} />
      <Route path="/disclosures" component={Disclosures} />
      <Route path="/admin" component={MainAdmin} />
      <Route path="/shop-admin" component={Admin} />
      <Route path="/admin/feeds" component={AdminFeedsFixed} />
      <Route path="/admin/categories" component={AdminCategories} />
      <Route path="/admin/affiliate-shops" component={AdminAffiliateShopsFixed} />
      <Route path="/admin-dashboard" component={AdminDashboard} />
      <Route path="/admin-analytics" component={AdminAnalytics} />
      <Route path="/super-admin">
        {() => <div>Super Admin - Coming Soon</div>}
      </Route>
      <Route path="/company/:companyId" component={CompanyStorefront} />
      <Route path="/company/:companyId/purchase-success" component={() => 
        <div className="container mx-auto px-4 py-8 text-center">
          <h1 className="text-3xl font-bold text-green-600 mb-4">Purchase Successful!</h1>
          <p className="text-lg text-gray-600">Thank you for your purchase. You will receive an email confirmation shortly.</p>
        </div>
      } />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  // Code protection disabled for user access

  return (
    <QueryClientProvider client={queryClient}>
      <TranslationProvider>
        <TooltipProvider>
          <SEOBooster />
          <GoogleAnalytics />
          <AdvancedSEO />
          <CoreWebVitalsOptimizer />
          <Router />
          <RealTimeButtonFixer enabled={true} />
          <ErrorAutoFixer />
          <Toaster />
          <CookieConsent />
          <PWAInstallPrompt />
        </TooltipProvider>
      </TranslationProvider>
    </QueryClientProvider>
  );
}

export default App;
