import { useEffect } from 'react';
import { useLocation } from 'wouter';

export function DevelopmentGate() {
  const [, setLocation] = useLocation();

  useEffect(() => {
    const checkDevelopmentBlock = () => {
      const blockData = localStorage.getItem('developmentBlocked');
      if (blockData) {
        const { blocked } = JSON.parse(blockData);
        if (blocked) {
          // Redirect to blocking page
          window.location.href = '/development-gate.html';
          return true;
        }
      }
      return false;
    };

    // Check on component mount
    checkDevelopmentBlock();

    // Check periodically during development session
    const interval = setInterval(checkDevelopmentBlock, 5000);

    return () => clearInterval(interval);
  }, []);

  return null; // This component doesn't render anything
}

// Hook to check blocking status in any component
export function useDevelopmentBlock() {
  const checkBlock = () => {
    const blockData = localStorage.getItem('developmentBlocked');
    if (blockData) {
      const { blocked } = JSON.parse(blockData);
      if (blocked) {
        window.location.href = '/development-gate.html';
        return true;
      }
    }
    return false;
  };

  return { checkBlock };
}