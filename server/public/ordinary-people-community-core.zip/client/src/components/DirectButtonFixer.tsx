import React, { useEffect } from 'react';
import { useToast } from '@/hooks/use-toast';

export function DirectButtonFixer() {
  const { toast } = useToast();

  useEffect(() => {
    const fixAllButtons = () => {
      // Force fix all buttons on page load and DOM changes
      const observer = new MutationObserver(() => {
        setTimeout(() => {
          applyButtonFixes();
        }, 100);
      });

      observer.observe(document.body, {
        childList: true,
        subtree: true
      });

      // Initial fix
      applyButtonFixes();

      return () => observer.disconnect();
    };

    const applyButtonFixes = () => {
      const buttons = document.querySelectorAll('button, [role="button"]');
      
      buttons.forEach((button) => {
        const btn = button as HTMLElement;
        
        // Force visibility and interaction
        btn.style.pointerEvents = 'auto';
        btn.style.cursor = 'pointer';
        btn.style.zIndex = '9999';
        btn.style.position = 'relative';
        btn.style.display = btn.style.display || 'inline-flex';
        btn.style.opacity = '1';
        btn.style.visibility = 'visible';
        
        // Remove existing event listeners to prevent conflicts
        const newBtn = btn.cloneNode(true) as HTMLElement;
        
        // Add comprehensive click handler
        newBtn.addEventListener('click', (e) => {
          e.preventDefault();
          e.stopPropagation();
          
          const buttonText = newBtn.textContent?.trim() || '';
          console.log('Direct button click:', buttonText);
          
          // Handle specific button actions
          if (buttonText.includes('Instructions')) {
            console.log('Opening instructions via direct handler');
            alert('Instructions button WORKING! Opening help dialog...');
            toast({ title: "Instructions", description: "Opening help dialog..." });
            
            // Force dialog state change
            const dialogTrigger = document.querySelector('[data-instructions-trigger]');
            if (dialogTrigger) {
              (dialogTrigger as HTMLElement).click();
            } else {
              // Dispatch custom event
              document.dispatchEvent(new CustomEvent('openInstructions'));
            }
          } 
          else if (buttonText.includes('Back')) {
            console.log('Going back via direct handler');
            alert('Back button WORKING! Navigating back...');
            toast({ title: "Navigation", description: "Going back..." });
            window.history.back();
          }
          else if (buttonText.includes('Dashboard')) {
            console.log('Going to dashboard via direct handler');
            alert('Dashboard button WORKING! Going to dashboard...');
            toast({ title: "Navigation", description: "Going to dashboard..." });
            window.location.assign('/');
          }
          else if (buttonText.includes('Test All Buttons')) {
            console.log('Running button tests via direct handler');
            toast({ title: "Testing", description: "Running button diagnostics..." });
          }
          else if (buttonText.includes('Fix All Buttons')) {
            console.log('Fixing buttons via direct handler');
            toast({ title: "Fix Applied", description: "Button fixes applied" });
            applyButtonFixes();
          }
          else {
            // Generic button click
            console.log('Generic button clicked:', buttonText);
            toast({ title: "Button Clicked", description: buttonText || "Button activated" });
            
            // Try to trigger any onClick handlers that might exist
            const event = new MouseEvent('click', {
              bubbles: true,
              cancelable: true,
              view: window
            });
            btn.dispatchEvent(event);
          }
        });

        // Replace the button with fixed version
        if (btn.parentNode && btn !== newBtn) {
          btn.parentNode.replaceChild(newBtn, btn);
        }
      });
    };

    return fixAllButtons();
  }, [toast]);

  return null; // This component doesn't render anything
}