import { useQuery } from "@tanstack/react-query";
import { User, Supplement, SupplementLog, Biometric } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";
import { BiometricChart } from "./BiometricChart";
import { SupplementCard } from "./SupplementCard";
import { FeatureGallery } from "./FeatureGallery";
import { SupportBanner } from "./SupportBanner";
import { SEO } from "./SEO";
import { AskAIButton } from "./AskAIButton";
import { MobileAwareAdCarousel } from "./MobileAwareAdCarousel";
import { AdvertisingButton } from "./AdvertisingButton";
import { PageHelpSystem } from "./PageHelpSystem";


import { BackButton } from "./BackButton";

import { MessageCircle, X, ArrowDown, Users, ShoppingBag, Store, TrendingUp, MapPin, Navigation } from "lucide-react";
import { useTranslation } from "@/hooks/useTranslation";
import { Footer } from "@/components/Footer";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { useState, useEffect } from "react";

interface ChatNotification {
  roomId: number;
  roomName: string;
  senderName: string;
  lastMessage: string;
  timestamp: string;
}

interface DashboardData {
  supplements: Supplement[];
  todaysLogs: SupplementLog[];
  recentBiometrics: Biometric[];
  latestBiometric: Biometric | null;
  supplementsCount: number;
  todaysTaken: number;
  streak: number;
  unreadChats: number;
  chatNotifications: ChatNotification[];
}

interface DashboardProps {
  user: User;
}

export function Dashboard({ user }: DashboardProps) {
  const { t } = useTranslation();
  const [showAdvertisingInfo, setShowAdvertisingInfo] = useState(false);

  
  const { data, isLoading } = useQuery<DashboardData>({
    queryKey: ['/api/dashboard'],
    enabled: !!user,
  });



  if (isLoading) {
    return (
      <div className="flex-1 overflow-auto">
        <div className="p-4 lg:p-8 pb-20 lg:pb-8">
          <div className="animate-pulse space-y-8">
            <div className="h-8 bg-gray-200 rounded w-64"></div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {[...Array(4)].map((_, i) => (
                <div key={i} className="h-32 bg-gray-200 rounded-xl"></div>
              ))}
            </div>
            <div className="h-96 bg-gray-200 rounded-xl"></div>
          </div>
        </div>
      </div>
    );
  }

  if (!data) {
    return (
      <div className="flex-1 overflow-auto flex items-center justify-center">
        <div className="text-center">
          <h3 className="text-lg font-medium text-gray-900 mb-2">Unable to load dashboard</h3>
          <p className="text-gray-600">Please try refreshing the page</p>
        </div>
      </div>
    );
  }



  const currentDate = new Date().toLocaleDateString('en-US', {
    weekday: 'long',
    year: 'numeric',
    month: 'long',
    day: 'numeric'
  });

  const stepGoal = 10000;
  const stepsProgress = data.latestBiometric?.steps ? 
    Math.min((data.latestBiometric.steps / stepGoal) * 100, 100) : 0;

  const sleepGoal = 8 * 60; // 8 hours in minutes
  const sleepProgress = data.latestBiometric?.sleepHours ? 
    Math.min((data.latestBiometric.sleepHours / sleepGoal) * 100, 100) : 0;

  const supplementProgress = data.supplementsCount > 0 ? 
    (data.todaysTaken / data.supplementsCount) * 100 : 0;

  return (
    <main className="flex-1 overflow-auto max-w-full"
          style={{ maxWidth: '100vw', overflowX: 'hidden' }}>
      <SEO 
        title={`${user.name}'s Health Dashboard - GoHealMe`}
        description="Track your supplements, monitor biometrics, and manage your wellness journey with GoHealMe's comprehensive health dashboard. Join the people's health community for personalized insights."
        keywords={[
          'health dashboard', 'supplement tracking', 'wellness monitoring',
          'biometric data', 'health metrics', 'supplement adherence',
          'health insights', 'wellness analytics', 'health tracking app'
        ]}
      />
      


      {/* Instructions Button */}
      <PageHelpSystem currentPage="dashboard" />
      
      {/* Advertising Button */}
      <AdvertisingButton />
      
      {/* Ask AI Button */}
      <div className="bg-orange-50 border-b border-orange-200 px-2 md:px-4 lg:px-8 py-3">
        <div className="flex justify-center">
          <AskAIButton 
            variant="default" 
            size="lg" 
            className="bg-orange-500 hover:bg-orange-600 text-white border-none shadow-lg"
          />
        </div>
      </div>



      {/* Admin Control Panel Button - Only for Admins */}
      {user.isAdmin && (
        <div className="bg-purple-50 border-b border-purple-200 px-2 md:px-4 lg:px-8 py-3">
          <div className="flex justify-center">
            <a
              href="/admin-dashboard"
              className="inline-flex items-center justify-center space-x-2 px-6 py-3 bg-purple-600 hover:bg-purple-700 text-white rounded-lg transition-colors font-medium shadow-lg"
            >
              <i className="fas fa-chart-bar text-lg"></i>
              <span>Admin Control Panel</span>
            </a>
          </div>
        </div>
      )}

      {/* Dashboard Header */}
      <div className="bg-white border-b border-gray-200 px-2 md:px-4 lg:px-8 py-4 md:py-6">
        <div className="flex flex-col space-y-2 md:space-y-4">
          {/* Navigation Buttons - Mobile and Desktop */}
          <div className="flex items-center justify-center gap-2 mb-4 flex-wrap">
            <a
              href="/chat"
              className="inline-flex items-center justify-center space-x-2 px-4 py-2 bg-green-600 hover:bg-green-700 text-white rounded-lg transition-colors font-medium"
            >
              <i className="fas fa-comments text-sm"></i>
              <span>Chat</span>
            </a>
            <a
              href="/community"
              className="inline-flex items-center justify-center space-x-2 px-4 py-2 bg-purple-600 hover:bg-purple-700 text-white rounded-lg transition-colors font-medium"
            >
              <i className="fas fa-users text-sm"></i>
              <span>Community</span>
            </a>
            <a
              href="/news"
              className="inline-flex items-center justify-center space-x-2 px-4 py-2 bg-red-600 hover:bg-red-700 text-white rounded-lg transition-colors font-medium"
            >
              <i className="fas fa-newspaper text-sm"></i>
              <span>Daily News</span>
            </a>
            <a
              href="/shop"
              className="inline-flex items-center justify-center space-x-2 px-4 py-2 bg-yellow-600 hover:bg-yellow-700 text-white rounded-lg transition-colors font-medium"
            >
              <i className="fas fa-shopping-cart text-sm"></i>
              <span>Shop</span>
            </a>
          </div>
          
          <div>
            <h2 className="text-xl md:text-2xl font-bold text-gray-900">{t('dashboard.title')}</h2>
            <p className="text-gray-600 mt-1 text-sm md:text-base">{currentDate}</p>
          </div>
          <div className="flex items-center space-x-3 flex-wrap">
            <div className="flex items-center space-x-2 px-3 py-2 bg-primary-light rounded-lg">
              <div className="w-2 h-2 bg-success rounded-full"></div>
              <span className="text-sm font-medium text-primary-dark">{t('status.success')}</span>
            </div>
            <button 
              onClick={() => window.location.href = '/daily-log'}
              className="px-4 py-2 bg-primary text-white rounded-lg font-medium hover:bg-primary/90 transition-colors inline-flex items-center"
            >
              <span className="mr-2">+</span>{t('dashboard.logSupplement')}
            </button>
          </div>
        </div>
      </div>

      <div className="p-2 md:p-4 lg:p-8 space-y-4 md:space-y-8 pb-20 lg:pb-8" style={{ maxWidth: '100vw', width: '100%', boxSizing: 'border-box' }}>
        {/* Feature Gallery */}
        <FeatureGallery />
        

        {/* Chat Notifications - Simple Card */}
        <div style={{
          backgroundColor: '#f3f4f6',
          border: '1px solid #d1d5db',
          borderRadius: '8px',
          padding: '15px',
          margin: '10px 0',
          display: 'block',
          width: '100%',
          maxWidth: '100%'
        }}>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '15px' }}>
              <MessageCircle style={{ width: '40px', height: '40px', color: '#6b7280' }} />
              <div>
                <h3 style={{ fontSize: '18px', fontWeight: 'bold', margin: '0', color: '#1f2937' }}>
                  {t('chat.title')}
                </h3>
                <p style={{ fontSize: '14px', margin: '5px 0 0 0', color: '#6b7280' }}>
                  {t('chat.unreadMessages')}: {data?.unreadChats || 0}
                </p>
              </div>
            </div>
            <a 
              href="/chat" 
              style={{
                backgroundColor: '#3b82f6',
                color: 'white',
                padding: '8px 16px',
                borderRadius: '6px',
                textDecoration: 'none',
                fontSize: '14px',
                fontWeight: '500'
              }}
            >
{t('chat.openChat')}
            </a>
          </div>
        </div>

        {/* Health Overview Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-3 md:gap-6">
          <div className="bg-white rounded-xl shadow-sm card-hover-border p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">{t('health.dailySteps')}</p>
                <p className="text-2xl font-bold text-primary-gradient mt-1">
                  {data.latestBiometric?.steps?.toLocaleString() || '0'}
                </p>
              </div>
              <div className="w-12 h-12 bg-primary-gradient rounded-lg flex items-center justify-center">
                <i className="fas fa-walking text-white text-lg"></i>
              </div>
            </div>
            <div className="mt-4 flex items-center space-x-2">
              <div className="flex-1 bg-gray-200 rounded-full h-2">
                <div 
                  className="bg-blue-500 h-2 rounded-full transition-all duration-300" 
                  style={{ width: `${stepsProgress}%` }}
                ></div>
              </div>
              <span className="text-xs text-gray-500">{Math.round(stepsProgress)}%</span>
            </div>
          </div>

          <div className="bg-white rounded-xl shadow-sm card-hover-border p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">{t('health.sleepHours')}</p>
                <p className="text-2xl font-bold text-primary-gradient mt-1">
                  {data.latestBiometric?.sleepHours ? 
                    `${(data.latestBiometric.sleepHours / 60).toFixed(1)}h` : '0h'}
                </p>
              </div>
              <div className="w-12 h-12 bg-primary-gradient rounded-lg flex items-center justify-center">
                <i className="fas fa-moon text-white text-lg"></i>
              </div>
            </div>
            <div className="mt-4 flex items-center space-x-2">
              <div className="flex-1 bg-gray-200 rounded-full h-2">
                <div 
                  className="bg-purple-500 h-2 rounded-full transition-all duration-300" 
                  style={{ width: `${sleepProgress}%` }}
                ></div>
              </div>
              <span className="text-xs text-gray-500">
                {sleepProgress > 80 ? 'Good' : sleepProgress > 60 ? 'Fair' : 'Poor'}
              </span>
            </div>
          </div>

          <div className="bg-white rounded-xl shadow-sm card-hover-border p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Supplements</p>
                <p className="text-2xl font-bold text-primary-gradient mt-1">
                  {data.todaysTaken}/{data.supplementsCount}
                </p>
              </div>
              <div className="w-12 h-12 bg-primary-gradient rounded-lg flex items-center justify-center">
                <i className="fas fa-pills text-white text-lg"></i>
              </div>
            </div>
            <div className="mt-4 flex items-center space-x-2">
              <div className="flex-1 bg-gray-200 rounded-full h-2">
                <div 
                  className="bg-primary h-2 rounded-full transition-all duration-300" 
                  style={{ width: `${supplementProgress}%` }}
                ></div>
              </div>
              <span className="text-xs text-primary-dark">
                {data.supplementsCount - data.todaysTaken} remaining
              </span>
            </div>
          </div>

          <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Streak</p>
                <p className="text-2xl font-bold text-gray-900 mt-1">{data.streak} days</p>
              </div>
              <div className="w-12 h-12 bg-orange-100 rounded-lg flex items-center justify-center">
                <i className="fas fa-fire text-orange-600 text-lg"></i>
              </div>
            </div>
            <div className="mt-4">
              <span className="text-xs text-success bg-green-50 px-2 py-1 rounded-full">
                <i className="fas fa-arrow-up mr-1"></i>Keep it up!
              </span>
            </div>
          </div>
        </div>



        {/* Today's Supplement Schedule */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-200">
          <div className="p-6 border-b border-gray-200">
            <div className="flex items-center justify-between">
              <h3 className="text-lg font-semibold text-gray-900">Today's Schedule</h3>
              <span className="text-sm text-gray-500">
                {new Date().toLocaleTimeString('en-US', { 
                  hour: 'numeric', 
                  minute: '2-digit',
                  hour12: true 
                })}
              </span>
            </div>
          </div>
          <div className="p-6 space-y-4">
            {data.supplements.length === 0 ? (
              <div className="text-center py-8">
                <i className="fas fa-pills text-4xl text-gray-300 mb-4"></i>
                <h4 className="text-lg font-medium text-gray-900 mb-2">No supplements added yet</h4>
                <p className="text-gray-600 mb-4">Start tracking your supplements to see your daily schedule</p>
                <a 
                  href="/supplements"
                  className="inline-flex items-center px-4 py-2 bg-primary text-white rounded-lg font-medium hover:bg-primary/90 transition-colors"
                >
                  <i className="fas fa-plus mr-2"></i>Add Your First Supplement
                </a>
              </div>
            ) : (
              data.supplements.map((supplement) => (
                <SupplementCard 
                  key={supplement.id} 
                  supplement={supplement}
                  isTaken={data.todaysLogs.some(log => log.supplementId === supplement.id)}
                  userId={user.id}
                />
              ))
            )}
          </div>
        </div>

        {/* Progress Charts */}
        {data.recentBiometrics.length > 0 && (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <BiometricChart 
              title="Weekly Compliance"
              subtitle="Supplement adherence over the past week"
              data={data.recentBiometrics}
              type="compliance"
            />
            <BiometricChart 
              title="Biometric Trends"
              subtitle="Steps and sleep patterns"
              data={data.recentBiometrics}
              type="biometrics"
            />
          </div>
        )}

        {/* Feature Gallery - Rotating colorful navigation */}
        <div className="mt-8">
          <FeatureGallery />
        </div>

        {/* Quick Actions - Fixed Desktop Layout */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 md:gap-6 max-w-full">
          <a
            href="/supplements"
            className="p-4 md:p-6 bg-primary text-white rounded-xl shadow-sm hover:bg-primary/90 transition-colors text-left block"
          >
            <div className="flex items-center space-x-3">
              <i className="fas fa-plus-circle text-xl md:text-2xl"></i>
              <div className="min-w-0 flex-1">
                <h4 className="font-semibold truncate">Add Supplement</h4>
                <p className="text-xs md:text-sm opacity-90 mt-1 truncate">Track a new supplement</p>
              </div>
            </div>
          </a>

          <a
            href="/biometrics"
            className="p-4 md:p-6 bg-blue-500 text-white rounded-xl shadow-sm hover:bg-blue-600 transition-colors text-left block"
          >
            <div className="flex items-center space-x-3">
              <i className="fas fa-heartbeat text-xl md:text-2xl"></i>
              <div className="min-w-0 flex-1">
                <h4 className="font-semibold truncate">Log Biometrics</h4>
                <p className="text-xs md:text-sm opacity-90 mt-1 truncate">Update health data</p>
              </div>
            </div>
          </a>

          <a
            href="/chat"
            className="p-4 md:p-6 bg-blue-500 text-white rounded-xl shadow-sm hover:bg-blue-600 transition-colors text-left block"
          >
            <div className="flex items-center space-x-3">
              <i className="fas fa-comments text-xl md:text-2xl"></i>
              <div className="min-w-0 flex-1">
                <h4 className="font-semibold truncate">Chat & AI</h4>
                <p className="text-xs md:text-sm opacity-90 mt-1 truncate">Get AI health guidance</p>
              </div>
            </div>
          </a>

          <a
            href={user?.id ? `/profile-wall/${user.id}` : "/profile-wall"}
            className="p-4 md:p-6 bg-purple-500 text-white rounded-xl shadow-sm hover:bg-purple-600 transition-colors text-left block"
          >
            <div className="flex items-center space-x-3">
              <Users className="w-5 h-5 md:w-6 md:h-6 flex-shrink-0" />
              <div className="min-w-0 flex-1">
                <h4 className="font-semibold truncate">Profile Wall</h4>
                <p className="text-xs md:text-sm opacity-90 mt-1 truncate">Share posts & connect</p>
              </div>
            </div>
          </a>
        </div>



        {/* Advertiser Donation Banner */}
        <div className="bg-gradient-to-r from-pink-50 to-purple-50 border border-pink-200 rounded-xl p-6 mb-6">
          <div className="text-center">
            <h3 className="text-lg font-semibold text-pink-900 mb-2">Advertise on GoHealMe</h3>
            <p className="text-pink-700 mb-4">
              Support our health community with a £24/year donation and get your business featured across all pages
            </p>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4 text-sm">
              <div className="bg-white rounded-lg p-3 border border-pink-100">
                <div className="font-semibold text-pink-800">Unlimited Ads</div>
                <div className="text-pink-600">All pages & locations</div>
              </div>
              <div className="bg-white rounded-lg p-3 border border-pink-100">
                <div className="font-semibold text-pink-800">Company Store</div>
                <div className="text-pink-600">Sell products directly</div>
              </div>
              <div className="bg-white rounded-lg p-3 border border-pink-100">
                <div className="font-semibold text-pink-800">Analytics</div>
                <div className="text-pink-600">Track performance</div>
              </div>
            </div>
            <a 
              href="/advertiser-portal" 
              className="inline-block bg-pink-600 hover:bg-pink-700 text-white font-semibold py-3 px-6 rounded-lg transition-colors"
            >
              Start Advertising - Donate £24/year
            </a>
          </div>
        </div>

        {/* Support Banner */}
        <SupportBanner />
      </div>


      

      
      {/* Website Footer */}
      <Footer />


    </main>
  );
}
