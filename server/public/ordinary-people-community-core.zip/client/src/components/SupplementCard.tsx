import { useState } from "react";
import { Supplement } from "@shared/schema";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface SupplementCardProps {
  supplement: Supplement;
  isTaken: boolean;
  userId: number;
}

export function SupplementCard({ supplement, isTaken, userId }: SupplementCardProps) {
  const [isLogging, setIsLogging] = useState(false);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const logSupplementMutation = useMutation({
    mutationFn: async () => {
      return apiRequest("POST", "/api/supplement-logs", {
        userId,
        supplementId: supplement.id,
        takenAt: new Date().toISOString(),
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/dashboard/${userId}`] });
      toast({
        title: "Supplement logged!",
        description: `${supplement.name} has been marked as taken.`,
      });
      setIsLogging(false);
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to log supplement. Please try again.",
        variant: "destructive",
      });
      setIsLogging(false);
    },
  });

  const handleMarkTaken = () => {
    if (isTaken || isLogging) return;
    setIsLogging(true);
    logSupplementMutation.mutate();
  };

  const getIconForSupplement = (name: string) => {
    const nameLower = name.toLowerCase();
    if (nameLower.includes('vitamin')) return 'fas fa-capsules';
    if (nameLower.includes('omega') || nameLower.includes('fish')) return 'fas fa-tablets';
    if (nameLower.includes('magnesium') || nameLower.includes('mineral')) return 'fas fa-pills';
    return 'fas fa-capsules';
  };

  const getColorForTime = (timeOfDay: string) => {
    switch (timeOfDay.toLowerCase()) {
      case 'morning': return 'bg-primary';
      case 'afternoon': case 'lunch': return 'bg-warning';
      case 'evening': case 'dinner': case 'night': return 'bg-blue-500';
      default: return 'bg-gray-400';
    }
  };

  const getCurrentTime = () => {
    return new Date().toLocaleTimeString('en-US', { 
      hour: 'numeric', 
      minute: '2-digit',
      hour12: true 
    });
  };

  const isUpcoming = () => {
    if (!supplement.specificTime) return false;
    const now = new Date();
    const [time, period] = supplement.specificTime.split(' ');
    const [hours, minutes] = time.split(':').map(Number);
    const scheduleTime = new Date();
    scheduleTime.setHours(period === 'PM' && hours !== 12 ? hours + 12 : hours);
    scheduleTime.setMinutes(minutes);
    
    const timeDiff = scheduleTime.getTime() - now.getTime();
    return timeDiff > 0 && timeDiff <= 30 * 60 * 1000; // within 30 minutes
  };

  const cardClasses = isTaken 
    ? "flex items-center space-x-4 p-4 border border-green-200 bg-green-50 rounded-lg"
    : isUpcoming()
    ? "flex items-center space-x-4 p-4 border-2 border-warning bg-yellow-50 rounded-lg"
    : "flex items-center space-x-4 p-4 border border-gray-200 rounded-lg opacity-60";

  const iconColor = isTaken 
    ? "bg-success" 
    : isUpcoming() 
    ? "bg-warning" 
    : getColorForTime(supplement.timeOfDay);

  const statusBadge = isTaken 
    ? "px-2 py-1 bg-success text-white text-xs rounded-full font-medium"
    : isUpcoming()
    ? "px-2 py-1 bg-warning text-white text-xs rounded-full font-medium"
    : "px-2 py-1 bg-gray-300 text-gray-600 text-xs rounded-full font-medium";

  const statusText = isTaken ? "Taken" : isUpcoming() ? "Due Soon" : "Pending";

  return (
    <div className={cardClasses}>
      <div className={`w-12 h-12 ${iconColor} rounded-lg flex items-center justify-center`}>
        <i className={`${getIconForSupplement(supplement.name)} text-white text-lg`}></i>
      </div>
      <div className="flex-1">
        <div className="flex items-center space-x-2">
          <h4 className="font-medium text-gray-900">{supplement.name}</h4>
          <span className={statusBadge}>{statusText}</span>
        </div>
        <p className="text-sm text-gray-600 mt-1">
          {supplement.dosage} • {supplement.timeOfDay}
        </p>
      </div>
      <div className="text-sm text-gray-500">
        {supplement.specificTime || getCurrentTime()}
      </div>
      {!isTaken && (
        <button 
          onClick={handleMarkTaken}
          disabled={isLogging}
          className="px-4 py-2 bg-primary text-white rounded-lg text-sm font-medium hover:bg-primary/90 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
        >
          {isLogging ? (
            <>
              <i className="fas fa-spinner fa-spin mr-2"></i>
              Logging...
            </>
          ) : (
            "Mark Taken"
          )}
        </button>
      )}
    </div>
  );
}
