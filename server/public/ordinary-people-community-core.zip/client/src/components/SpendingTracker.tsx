import React, { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { AlertTriangle, DollarSign, PoundSterling, Settings, Bell } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface SpendingData {
  currentAmount: number;
  currency: 'GBP' | 'USD';
  dailyLimit: number;
  sessionStart: string;
  lastNotified: string | null;
}

export function SpendingTracker() {
  const { toast } = useToast();
  const [spendingData, setSpendingData] = useState<SpendingData>({
    currentAmount: 0,
    currency: 'GBP',
    dailyLimit: 20,
    sessionStart: new Date().toISOString(),
    lastNotified: null
  });
  const [showLimitDialog, setShowLimitDialog] = useState(false);
  const [showWarning, setShowWarning] = useState(false);
  const [estimatedCost, setEstimatedCost] = useState(0);

  // Load spending data from localStorage on component mount
  useEffect(() => {
    const savedData = localStorage.getItem('spending_tracker_data');
    if (savedData) {
      try {
        const parsed = JSON.parse(savedData);
        // Reset daily if it's a new day
        const today = new Date().toDateString();
        const savedDate = new Date(parsed.sessionStart).toDateString();
        
        if (today !== savedDate) {
          // New day, reset spending
          const newData = {
            ...parsed,
            currentAmount: 0,
            sessionStart: new Date().toISOString(),
            lastNotified: null
          };
          setSpendingData(newData);
          localStorage.setItem('spending_tracker_data', JSON.stringify(newData));
        } else {
          setSpendingData(parsed);
        }
      } catch (error) {
        console.error('Error loading spending data:', error);
      }
    }
  }, []);

  // Save spending data to localStorage whenever it changes
  useEffect(() => {
    localStorage.setItem('spending_tracker_data', JSON.stringify(spendingData));
  }, [spendingData]);

  // Estimate cost based on time and activity
  useEffect(() => {
    const interval = setInterval(() => {
      // Rough estimate: £0.10 per minute of active development
      const sessionDuration = (Date.now() - new Date(spendingData.sessionStart).getTime()) / 1000 / 60;
      const estimated = sessionDuration * 0.10;
      setEstimatedCost(estimated);
      
      // Update current amount with estimated cost
      setSpendingData(prev => ({
        ...prev,
        currentAmount: estimated
      }));

      // Check if we should show warning or limit dialog
      if (estimated >= spendingData.dailyLimit * 0.8 && !showWarning && !spendingData.lastNotified) {
        setShowWarning(true);
        toast({
          title: "Spending Alert",
          description: `You've reached 80% of your daily ${spendingData.currency === 'GBP' ? '£' : '$'}${spendingData.dailyLimit} limit`,
          variant: "destructive",
        });
      }

      if (estimated >= spendingData.dailyLimit && !showLimitDialog) {
        setShowLimitDialog(true);
        setSpendingData(prev => ({
          ...prev,
          lastNotified: new Date().toISOString()
        }));
      }
    }, 30000); // Check every 30 seconds

    return () => clearInterval(interval);
  }, [spendingData.sessionStart, spendingData.dailyLimit, showWarning, showLimitDialog, spendingData.lastNotified, toast]);

  const percentage = (spendingData.currentAmount / spendingData.dailyLimit) * 100;
  const isNearLimit = percentage >= 80;
  const isOverLimit = percentage >= 100;

  const currencySymbol = spendingData.currency === 'GBP' ? '£' : '$';
  const CurrencyIcon = spendingData.currency === 'GBP' ? PoundSterling : DollarSign;

  const handleContinueWork = () => {
    setShowLimitDialog(false);
    setSpendingData(prev => ({
      ...prev,
      dailyLimit: prev.dailyLimit + 10 // Extend limit by £10/$10
    }));
    toast({
      title: "Limit Extended",
      description: `Daily limit increased to ${currencySymbol}${spendingData.dailyLimit + 10}`,
    });
  };

  const handleStopWork = () => {
    setShowLimitDialog(false);
    toast({
      title: "Work Session Ended",
      description: "Consider resuming tomorrow to stay within budget",
    });
    // Could implement actual session pause here
  };

  const resetDailySpending = () => {
    setSpendingData(prev => ({
      ...prev,
      currentAmount: 0,
      sessionStart: new Date().toISOString(),
      lastNotified: null
    }));
    setShowWarning(false);
    setShowLimitDialog(false);
  };

  return (
    <>
      <Card className={`w-full ${isOverLimit ? 'border-red-500 bg-red-50' : isNearLimit ? 'border-orange-500 bg-orange-50' : 'border-green-500 bg-green-50'}`}>
        <CardHeader className="pb-3">
          <CardTitle className="text-sm font-medium flex items-center gap-2">
            <CurrencyIcon className="w-4 h-4" />
            Daily Spending Tracker
            {isOverLimit && <AlertTriangle className="w-4 h-4 text-red-600" />}
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="flex justify-between items-center">
            <span className="text-sm text-gray-600">
              {currencySymbol}{spendingData.currentAmount.toFixed(2)} of {currencySymbol}{spendingData.dailyLimit}
            </span>
            <Badge variant={isOverLimit ? "destructive" : isNearLimit ? "destructive" : "default"}>
              {percentage.toFixed(0)}%
            </Badge>
          </div>
          
          <Progress 
            value={Math.min(percentage, 100)} 
            className={`h-2 ${isOverLimit ? 'bg-red-200' : isNearLimit ? 'bg-orange-200' : 'bg-green-200'}`}
          />
          
          <div className="flex justify-between items-center text-xs text-gray-500">
            <span>Session: {new Date(spendingData.sessionStart).toLocaleTimeString()}</span>
            <Button
              variant="ghost"
              size="sm"
              onClick={resetDailySpending}
              className="h-6 px-2 text-xs"
            >
              <Settings className="w-3 h-3 mr-1" />
              Reset
            </Button>
          </div>

          {isNearLimit && (
            <div className="text-xs p-2 rounded bg-orange-100 text-orange-800 border border-orange-200">
              <Bell className="w-3 h-3 inline mr-1" />
              Approaching daily limit - consider wrapping up soon
            </div>
          )}
        </CardContent>
      </Card>

      {/* Limit Reached Dialog */}
      <Dialog open={showLimitDialog} onOpenChange={setShowLimitDialog}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-orange-600">
              <AlertTriangle className="w-5 h-5" />
              Daily Spending Limit Reached
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div className="text-center">
              <div className="text-2xl font-bold text-gray-900">
                {currencySymbol}{spendingData.currentAmount.toFixed(2)}
              </div>
              <p className="text-sm text-gray-600 mt-1">
                You've reached your daily {currencySymbol}{spendingData.dailyLimit} development limit
              </p>
            </div>
            
            <div className="bg-gray-50 p-3 rounded-lg">
              <p className="text-sm text-gray-700">
                <strong>Options:</strong>
              </p>
              <ul className="text-sm text-gray-600 mt-1 space-y-1">
                <li>• Continue work (extends limit by {currencySymbol}10)</li>
                <li>• Pause until tomorrow to stay on budget</li>
                <li>• Reset counter if this is inaccurate</li>
              </ul>
            </div>

            <div className="flex gap-2">
              <Button
                onClick={handleContinueWork}
                className="flex-1 bg-blue-600 hover:bg-blue-700"
              >
                Continue Work
              </Button>
              <Button
                onClick={handleStopWork}
                variant="outline"
                className="flex-1"
              >
                Pause Session
              </Button>
            </div>
            
            <Button
              onClick={resetDailySpending}
              variant="ghost"
              size="sm"
              className="w-full text-xs"
            >
              Reset Counter
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}