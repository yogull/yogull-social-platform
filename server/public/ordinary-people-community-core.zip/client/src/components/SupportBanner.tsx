import { useState } from "react";
import { Heart, Coffee } from "lucide-react";
import { useTranslation } from "@/hooks/useTranslation";

export function SupportBanner() {
  const [isExpanded, setIsExpanded] = useState(false);
  const { t, formatPrice } = useTranslation();

  const handleDonate = () => {
    // Redirect to donation checkout page
    window.location.href = "/donate";
  };

  return (
    <div className="bg-gradient-to-r from-pink-50 to-purple-50 border-2 border-pink-300 rounded-lg shadow-lg mb-6 mt-6 relative z-10" style={{ minHeight: '100px', display: 'block' }}>
      <div className="max-w-7xl mx-auto px-6 py-6">
        <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
          {/* Main Message */}
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-gradient-to-r from-pink-500 to-purple-500 rounded-full flex items-center justify-center">
              <Heart className="w-5 h-5 text-white" />
            </div>
            <div>
              <h3 className="font-bold text-lg text-gray-900">💝 {t('support.support')}</h3>
              <p className="text-base text-gray-700 font-medium">
                {t('support.helpUs')}
              </p>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex items-center space-x-3">
            <button
              onClick={() => setIsExpanded(!isExpanded)}
              className="text-sm text-pink-600 hover:text-pink-800 underline"
            >
              {t('health.learnMore')}
            </button>
            <button
              onClick={handleDonate}
              className="bg-gradient-to-r from-pink-500 to-purple-500 text-white px-8 py-3 rounded-lg font-bold hover:opacity-90 transition-opacity flex items-center space-x-2 text-lg shadow-md"
            >
              <Coffee className="w-5 h-5" />
              <span>{t('support.donate')} {formatPrice(1)}</span>
            </button>
          </div>
        </div>

        {/* Expanded Details */}
        {isExpanded && (
          <div className="mt-4 pt-4 border-t border-pink-200">
            <div className="max-w-3xl">
              <h4 className="font-medium text-gray-900 mb-2">How Your Support Helps</h4>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm text-gray-600">
                <div className="flex items-start space-x-2">
                  <div className="w-2 h-2 bg-primary rounded-full mt-2 flex-shrink-0"></div>
                  <div>
                    <span className="font-medium">Server Costs</span>
                    <p>Maintaining reliable hosting and database services</p>
                  </div>
                </div>
                <div className="flex items-start space-x-2">
                  <div className="w-2 h-2 bg-primary rounded-full mt-2 flex-shrink-0"></div>
                  <div>
                    <span className="font-medium">Development</span>
                    <p>Adding new features and security updates</p>
                  </div>
                </div>
                <div className="flex items-start space-x-2">
                  <div className="w-2 h-2 bg-primary rounded-full mt-2 flex-shrink-0"></div>
                  <div>
                    <span className="font-medium">Community</span>
                    <p>Moderating discussions and providing support</p>
                  </div>
                </div>
              </div>
              <p className="mt-3 text-xs text-gray-500">
                Donations are completely optional. Your £1 contribution helps keep GoHealMe free for everyone in our health community.
              </p>
            </div>
          </div>
        )}
        
        {/* Optional text in bottom right */}
        <div className="absolute bottom-2 right-4">
          <span className="text-xs text-gray-400">optional</span>
        </div>
      </div>
    </div>
  );
}