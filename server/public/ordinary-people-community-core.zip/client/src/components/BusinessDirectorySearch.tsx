import React, { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { MapPin, Phone, Globe, Mail, Search, Eye } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";

interface Business {
  id: number;
  businessName: string;
  email: string;
  phone: string;
  address: string;
  city: string;
  country: string;
  latitude?: number;
  longitude?: number;
  category: string;
  mainCategory?: string;
  website?: string;
  description?: string;
  estimatedReach?: number;
  priority?: string;
  initialEmailSent?: boolean;
  confirmLinkClicked?: boolean;
  campaignStatus?: string;
}

export function BusinessDirectorySearch() {
  const [searchTerm, setSearchTerm] = useState<string>("");

  // Get all businesses for search
  const { data: allBusinesses = [], isLoading, error } = useQuery<Business[]>({
    queryKey: ["/api/business-prospects"],
  });

  // Debug logging
  console.log("Business data:", { allBusinesses, isLoading, error, count: allBusinesses?.length || 0 });

  // Cast and filter businesses based on search term across all fields
  const businessData = (allBusinesses as Business[]) || [];
  const filteredBusinesses = businessData.filter((business: Business) => {
    if (!searchTerm || searchTerm.trim() === '') return true; // Show all if no search term
    
    const searchLower = searchTerm.toLowerCase().trim();
    
    // Search across all available fields
    const searchableText = [
      business.businessName,
      business.city, 
      business.country,
      business.address,
      business.category,
      business.mainCategory,
      business.description,
      business.website,
      business.phone,
      business.email
    ].filter(Boolean).join(' ').toLowerCase();
    
    return searchableText.includes(searchLower);
  });

  const clearSearch = () => {
    setSearchTerm("");
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case "high": return "bg-red-100 text-red-800";
      case "medium": return "bg-yellow-100 text-yellow-800";
      default: return "bg-green-100 text-green-800";
    }
  };

  const getRatingDisplay = (business: any) => {
    return '4.5'; // Default rating display
  };

  return (
    <div className="max-w-7xl mx-auto p-6 space-y-6">
      <div className="text-center space-y-2">
        <h1 className="text-3xl font-bold">Business Directory</h1>
        <p className="text-gray-600">Find local businesses across 8+ countries</p>
        <Badge variant="secondary" className="text-sm">
          {filteredBusinesses.length} businesses found
        </Badge>
      </div>

      {/* Simple Search */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Search className="w-5 h-5" />
            Business Search
          </CardTitle>
          <CardDescription>
            Search by location, country, business name, category, or any other details
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex gap-2">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
              <Input
                placeholder="Search for businesses (e.g., 'London', 'United Kingdom', 'Pizza', 'Bakery')..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
            {searchTerm && (
              <Button onClick={clearSearch} variant="outline">
                Clear
              </Button>
            )}
          </div>
        </CardContent>
      </Card>

      {isLoading ? (
        <div className="text-center py-8">
          <div className="animate-spin w-8 h-8 border-4 border-blue-600 border-t-transparent rounded-full mx-auto mb-4"></div>
          <p>Loading businesses...</p>
        </div>
      ) : filteredBusinesses.length === 0 ? (
        <Card>
          <CardContent className="text-center py-8">
            <p className="text-gray-500">
              {searchTerm ? `No businesses found matching "${searchTerm}"` : "No businesses available"}
            </p>
          </CardContent>
        </Card>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredBusinesses.map((business: any) => (
            <Card key={business.id} className="hover:shadow-lg transition-shadow">
              <CardHeader>
                <div className="flex justify-between items-start">
                  <CardTitle className="text-lg">{business.businessName || business.business_name || 'Business'}</CardTitle>
                  <Badge className={getPriorityColor(business.priority || 'medium')}>
                    {business.priority || 'Standard'}
                  </Badge>
                </div>
                <CardDescription>{business.description || 'Professional business services'}</CardDescription>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex items-center gap-2 text-sm text-gray-600">
                  <MapPin className="w-4 h-4" />
                  <span>{business.address}, {business.city}, {business.country}</span>
                </div>
                
                {business.phone && (
                  <div className="flex items-center gap-2 text-sm text-gray-600">
                    <Phone className="w-4 h-4" />
                    <span>{business.phone}</span>
                  </div>
                )}
                
                {business.email && (
                  <div className="flex items-center gap-2 text-sm text-gray-600">
                    <Mail className="w-4 h-4" />
                    <span>{business.email}</span>
                  </div>
                )}
                
                {business.website && (
                  <div className="flex items-center gap-2 text-sm text-blue-600">
                    <Globe className="w-4 h-4" />
                    <a 
                      href={business.website} 
                      target="_blank" 
                      rel="noopener noreferrer"
                      className="hover:underline"
                    >
                      Visit Website
                    </a>
                  </div>
                )}
                
                <div className="flex flex-wrap gap-2">
                  <Badge variant="secondary">{business.mainCategory || business.main_category || business.category}</Badge>
                  <Badge variant="outline">{business.category}</Badge>
                </div>
                
                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm text-gray-500">
                    Rating: {getRatingDisplay(business)}
                  </span>
                  <Link href={`/business/${business.id}`}>
                    <Button size="sm" variant="outline">
                      <Eye className="w-4 h-4 mr-1" />
                      View Profile
                    </Button>
                  </Link>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}