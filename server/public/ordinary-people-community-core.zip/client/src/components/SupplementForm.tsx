import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertSupplementSchema } from "@shared/schema";
import { z } from "zod";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

const supplementFormSchema = insertSupplementSchema.extend({
  name: z.string().min(1, "Supplement name is required"),
  dosage: z.string().min(1, "Dosage is required"),
  frequency: z.string().min(1, "Frequency is required"),
  timeOfDay: z.string().min(1, "Time of day is required"),
});

type SupplementFormData = z.infer<typeof supplementFormSchema>;

interface SupplementFormProps {
  userId: number;
  onSuccess?: () => void;
}

export function SupplementForm({ userId, onSuccess }: SupplementFormProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const form = useForm<SupplementFormData>({
    resolver: zodResolver(supplementFormSchema),
    defaultValues: {
      userId,
      name: "",
      dosage: "",
      frequency: "daily",
      timeOfDay: "morning",
      specificTime: "",
      notes: "",
      isActive: true,
    },
  });

  const createSupplementMutation = useMutation({
    mutationFn: async (data: SupplementFormData) => {
      return apiRequest("POST", "/api/supplements", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/supplements/${userId}`] });
      queryClient.invalidateQueries({ queryKey: [`/api/dashboard/${userId}`] });
      toast({
        title: "Supplement added!",
        description: "Your new supplement has been added to your tracking list.",
      });
      form.reset();
      onSuccess?.();
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to add supplement. Please try again.",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: SupplementFormData) => {
    createSupplementMutation.mutate(data);
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center space-x-2">
          <i className="fas fa-plus-circle text-primary"></i>
          <span>Add New Supplement</span>
        </CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="name">Supplement Name *</Label>
              <Input
                id="name"
                placeholder="e.g., Vitamin D3, Omega-3"
                {...form.register("name")}
              />
              {form.formState.errors.name && (
                <p className="text-sm text-red-600">{form.formState.errors.name.message}</p>
              )}
            </div>

            <div className="space-y-2">
              <Label htmlFor="dosage">Dosage *</Label>
              <Input
                id="dosage"
                placeholder="e.g., 2000 IU, 1000mg"
                {...form.register("dosage")}
              />
              {form.formState.errors.dosage && (
                <p className="text-sm text-red-600">{form.formState.errors.dosage.message}</p>
              )}
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="frequency">Frequency *</Label>
              <Select 
                value={form.watch("frequency")} 
                onValueChange={(value) => form.setValue("frequency", value)}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select frequency" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="daily">Daily</SelectItem>
                  <SelectItem value="twice_daily">Twice Daily</SelectItem>
                  <SelectItem value="three_times_daily">Three Times Daily</SelectItem>
                  <SelectItem value="weekly">Weekly</SelectItem>
                  <SelectItem value="as_needed">As Needed</SelectItem>
                </SelectContent>
              </Select>
              {form.formState.errors.frequency && (
                <p className="text-sm text-red-600">{form.formState.errors.frequency.message}</p>
              )}
            </div>

            <div className="space-y-2">
              <Label htmlFor="timeOfDay">Time of Day *</Label>
              <Select 
                value={form.watch("timeOfDay")} 
                onValueChange={(value) => form.setValue("timeOfDay", value)}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select time" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="morning">Morning</SelectItem>
                  <SelectItem value="afternoon">Afternoon</SelectItem>
                  <SelectItem value="evening">Evening</SelectItem>
                  <SelectItem value="bedtime">Bedtime</SelectItem>
                  <SelectItem value="with_breakfast">With Breakfast</SelectItem>
                  <SelectItem value="with_lunch">With Lunch</SelectItem>
                  <SelectItem value="with_dinner">With Dinner</SelectItem>
                </SelectContent>
              </Select>
              {form.formState.errors.timeOfDay && (
                <p className="text-sm text-red-600">{form.formState.errors.timeOfDay.message}</p>
              )}
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="specificTime">Specific Time (Optional)</Label>
            <Input
              id="specificTime"
              placeholder="e.g., 8:00 AM, 7:30 PM"
              {...form.register("specificTime")}
            />
            <p className="text-xs text-gray-500">
              Enter a specific time for reminders (optional)
            </p>
          </div>

          <div className="space-y-2">
            <Label htmlFor="notes">Notes (Optional)</Label>
            <Textarea
              id="notes"
              placeholder="Any additional notes about this supplement..."
              rows={3}
              {...form.register("notes")}
            />
          </div>

          <div className="flex space-x-4">
            <Button 
              type="submit" 
              className="bg-primary hover:bg-primary/90 flex-1"
              disabled={createSupplementMutation.isPending}
            >
              {createSupplementMutation.isPending ? (
                <>
                  <i className="fas fa-spinner fa-spin mr-2"></i>
                  Adding...
                </>
              ) : (
                <>
                  <i className="fas fa-plus mr-2"></i>
                  Add Supplement
                </>
              )}
            </Button>
            
            <Button 
              type="button" 
              variant="outline"
              onClick={() => form.reset()}
              disabled={createSupplementMutation.isPending}
            >
              Clear
            </Button>
          </div>
        </form>
      </CardContent>
    </Card>
  );
}
