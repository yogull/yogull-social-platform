// Stable Toast System - Prevents recurring toast functionality issues
import { useState, useEffect } from 'react';

interface ToastMessage {
  id: string;
  title: string;
  description: string;
  type?: 'default' | 'success' | 'error' | 'warning';
}

let toastQueue: ToastMessage[] = [];
let toastSubscribers: Array<(toasts: ToastMessage[]) => void> = [];

export function addToast(toast: Omit<ToastMessage, 'id'>) {
  const newToast: ToastMessage = {
    ...toast,
    id: Date.now().toString()
  };
  
  toastQueue.push(newToast);
  notifySubscribers();
  
  // Auto-remove after 5 seconds
  setTimeout(() => {
    removeToast(newToast.id);
  }, 5000);
}

export function removeToast(id: string) {
  toastQueue = toastQueue.filter(toast => toast.id !== id);
  notifySubscribers();
}

function notifySubscribers() {
  toastSubscribers.forEach(callback => callback([...toastQueue]));
}

export function StableToastContainer() {
  const [toasts, setToasts] = useState<ToastMessage[]>([]);

  useEffect(() => {
    const unsubscribe = () => {
      const index = toastSubscribers.indexOf(setToasts);
      if (index > -1) {
        toastSubscribers.splice(index, 1);
      }
    };

    toastSubscribers.push(setToasts);
    return unsubscribe;
  }, []);

  if (toasts.length === 0) return null;

  return (
    <div style={{
      position: 'fixed',
      top: '20px',
      right: '20px',
      zIndex: 100000,
      pointerEvents: 'none'
    }}>
      {toasts.map(toast => (
        <div
          key={toast.id}
          style={{
            backgroundColor: '#1f2937',
            color: 'white',
            padding: '16px',
            borderRadius: '8px',
            marginBottom: '8px',
            minWidth: '300px',
            maxWidth: '400px',
            boxShadow: '0 10px 15px -3px rgba(0, 0, 0, 0.1)',
            pointerEvents: 'auto',
            position: 'relative'
          }}
        >
          <button
            onClick={() => removeToast(toast.id)}
            style={{
              position: 'absolute',
              top: '8px',
              right: '8px',
              backgroundColor: 'transparent',
              border: 'none',
              color: 'white',
              cursor: 'pointer',
              fontSize: '18px',
              padding: '4px',
              borderRadius: '4px',
              zIndex: 100001
            }}
          >
            ×
          </button>
          
          <div style={{ fontWeight: '600', marginBottom: '4px' }}>
            {toast.title}
          </div>
          
          <div style={{ fontSize: '14px', opacity: 0.9 }}>
            {toast.description}
          </div>
        </div>
      ))}
    </div>
  );
}