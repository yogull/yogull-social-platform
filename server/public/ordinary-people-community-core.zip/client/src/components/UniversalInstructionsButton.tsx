import { useState, useEffect, useRef } from "react";
import { Button } from "@/components/ui/button";
import { HelpCircle, BookOpen, Users, ShoppingBag, MessageCircle, Heart, Search, Settings, Home, MapPin, X } from "lucide-react";

interface PageHelp {
  id: string;
  title: string;
  icon: any;
  description: string;
  steps: string[];
  tips: string[];
  route: string;
}

const pageHelpData: PageHelp[] = [
  {
    id: "dashboard",
    title: "Community Dashboard",
    icon: Home,
    route: "/",
    description: "Your central hub for community discussions, government topics, and personal experiences sharing.",
    steps: [
      "View your recent activity and community updates on the main dashboard",
      "Use the 'Ask AI Anything' button for instant answers on any topic",
      "Scroll down to explore different platform features and tools",
      "Check notifications for new messages and community interactions",
      "Access Profile Wall, Community discussions, and Shop through the feature gallery"
    ],
    tips: [
      "The dashboard shows a personalized overview of your community activity",
      "Orange 'Ask AI' button provides answers on health, science, government, and more",
      "Feature cards provide quick access to all platform sections",
      "Regular engagement helps build connections within the community"
    ]
  },
  {
    id: "profileWall",
    title: "Profile Wall",
    icon: Users,
    route: "/profile-wall/4",
    description: "Share posts, photos, videos, and connect with the Ordinary People Community for discussions on government, health, and personal topics.",
    steps: [
      "Click 'Edit Cover' to customize your profile header image",
      "Use 'Edit Profile' to update your name, bio, and location",
      "Post updates by typing in the text box and clicking 'Post'",
      "Add photos or videos to posts using the Photo/Video buttons",
      "Select your feeling mood from the dropdown before posting",
      "Like, comment, and share other users' posts",
      "Use 'Share All' button to post to all your connected social media at once",
      "Connect social media accounts through the Social Media section"
    ],
    tips: [
      "Add a profile photo and bio to make connections easier",
      "Share your personal experiences to inspire others",
      "Use the 'Share All' feature to reach your social networks",
      "Engage with others' posts to build community connections"
    ]
  },
  {
    id: "community",
    title: "Community Discussions",
    icon: MessageCircle,
    route: "/community",
    description: "Join discussions on government topics, daily life issues, and connect with ordinary people sharing similar experiences.",
    steps: [
      "Browse discussion categories like Mental Health, Government & Policy, Environmental Issues",
      "Click category buttons to join specific topic discussions",
      "Use 'Start New Discussion' to create topics about your interests and experiences",
      "Reply to existing discussions to share experiences and advice",
      "Filter discussions by category using the dropdown menu",
      "Follow location-based discussions to connect with local community members"
    ],
    tips: [
      "Share your experiences to help others facing similar challenges",
      "Ask questions - the community is here to support you",
      "Use specific categories to find targeted discussions",
      "Respect others' privacy and personal experiences"
    ]
  },
  {
    id: "shop",
    title: "Supplement Shop",
    icon: ShoppingBag,
    route: "/shop",
    description: "Browse and purchase high-quality supplements with expert recommendations.",
    steps: [
      "Browse supplement categories: Vitamins, Minerals, Herbal, Probiotics",
      "Click product cards to view detailed information and benefits",
      "Read product descriptions and recommended dosages carefully",
      "Add items to cart and proceed to secure Stripe checkout",
      "Track your orders through your account dashboard",
      "Leave reviews to help other community members"
    ],
    tips: [
      "Consult healthcare providers before starting new supplements",
      "Read other users' reviews for real experiences",
      "Start with basic vitamins before trying specialized supplements",
      "Track supplement effects in your biometric logs"
    ]
  },
  {
    id: "chat",
    title: "Chat & AI Assistant",
    icon: MessageCircle,
    route: "/chat",
    description: "Private messaging with community members and AI health guidance.",
    steps: [
      "Click 'Find Users' to search for community members to chat with",
      "Start conversations by selecting users from the search results",
      "Ask the AI Health Assistant questions about supplements and wellness",
      "Use chat history to review past conversations and advice",
      "Share posts and content through the chat system"
    ],
    tips: [
      "The AI provides general wellness information - consult doctors for medical advice",
      "Be respectful in all communications",
      "Use chat to build supportive relationships with community members",
      "Save important AI advice for future reference"
    ]
  }
];

interface UniversalInstructionsButtonProps {
  currentPage?: string;
  position?: "top" | "bottom" | "side";
}

export function UniversalInstructionsButton({ currentPage = "dashboard", position = "top" }: UniversalInstructionsButtonProps) {
  // Get help data for selected page
  const selectedHelp = pageHelpData.find(page => page.id === currentPage) || pageHelpData[0];

  // Native HTML dialog implementation - bypassing React state management
  const showNativeDialog = () => {
    const dialogHTML = `
      <div id="native-instructions-dialog" style="
        position: fixed;
        top: 0;
        left: 0;
        width: 100vw;
        height: 100vh;
        background: rgba(0, 0, 0, 0.5);
        z-index: 999999;
        display: flex;
        align-items: center;
        justify-content: center;
        padding: 16px;
      " onclick="this.remove()">
        <div style="
          background: white;
          border-radius: 8px;
          box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.25);
          max-width: 600px;
          width: 100%;
          max-height: 90vh;
          overflow-y: auto;
        " onclick="event.stopPropagation()">
          <div style="padding: 16px; border-bottom: 1px solid #e5e7eb;">
            <div style="display: flex; align-items: center; justify-content: between; margin-bottom: 16px;">
              <h2 style="font-size: 18px; font-weight: bold; color: #2563eb; margin: 0;">
                ${selectedHelp.title}
              </h2>
              <button onclick="document.getElementById('native-instructions-dialog').remove()" style="
                background: none;
                border: none;
                cursor: pointer;
                padding: 4px;
                margin-left: auto;
                color: #6b7280;
              ">✕</button>
            </div>
          </div>
          
          <div style="padding: 16px;">
            <div style="margin-bottom: 16px; font-size: 14px; color: #374151;">
              ${selectedHelp.description}
            </div>
            
            <div style="margin-bottom: 16px;">
              <h3 style="font-weight: 600; color: #1f2937; margin-bottom: 8px;">Step-by-Step Instructions:</h3>
              <ol style="padding-left: 20px; font-size: 14px; color: #4b5563;">
                ${selectedHelp.steps.map((step, index) => `<li style="margin-bottom: 4px;">${step}</li>`).join('')}
              </ol>
            </div>
            
            <div style="margin-bottom: 16px;">
              <h3 style="font-weight: 600; color: #1f2937; margin-bottom: 8px;">Pro Tips:</h3>
              <ul style="padding-left: 20px; font-size: 14px; color: #4b5563;">
                ${selectedHelp.tips.map((tip, index) => `<li style="margin-bottom: 4px;">${tip}</li>`).join('')}
              </ul>
            </div>
            
            <div style="padding-top: 16px; border-top: 1px solid #e5e7eb;">
              <button onclick="document.getElementById('native-instructions-dialog').remove()" style="
                width: 100%;
                background: #2563eb;
                color: white;
                border: none;
                padding: 12px;
                border-radius: 4px;
                cursor: pointer;
                font-weight: 500;
              ">
                Got it! Close Instructions
              </button>
            </div>
          </div>
        </div>
      </div>
    `;

    // Remove any existing dialog
    const existing = document.getElementById('native-instructions-dialog');
    if (existing) existing.remove();

    // Add new dialog to body
    document.body.insertAdjacentHTML('beforeend', dialogHTML);
  };

  // Position classes - avoid interfering with business ads
  const positionClasses = {
    top: "fixed top-4 left-1/2 transform -translate-x-1/2 z-50", // Center-top to avoid hamburger menu
    bottom: "fixed bottom-4 right-4 z-50",
    side: "fixed top-1/2 right-4 transform -translate-y-1/2 z-50"
  };

  return (
    <>
      <div className={positionClasses[position]}>
        <Button 
          onClick={showNativeDialog}
          className="bg-blue-600 hover:bg-blue-700 text-white text-xs px-1.5 py-0.5 rounded-lg shadow-xl animate-pulse border-2 border-white font-bold"
          size="sm"
        >
          Instructions
        </Button>
      </div>


    </>
  );
}