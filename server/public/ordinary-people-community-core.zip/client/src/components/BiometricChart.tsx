import { useEffect, useRef } from "react";
import { Biometric } from "@shared/schema";

interface BiometricChartProps {
  title: string;
  subtitle: string;
  data: Biometric[];
  type: 'compliance' | 'biometrics';
}

export function BiometricChart({ title, subtitle, data, type }: BiometricChartProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const chartRef = useRef<any>(null);

  useEffect(() => {
    if (!canvasRef.current || typeof window === 'undefined') return;

    // Dynamically import Chart.js to avoid SSR issues
    import('chart.js/auto').then((Chart) => {
      const ctx = canvasRef.current!.getContext('2d');
      if (!ctx) return;

      // Destroy existing chart
      if (chartRef.current) {
        chartRef.current.destroy();
      }

      // Prepare data based on chart type
      if (type === 'compliance') {
        // Mock compliance data for now
        const labels = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
        const complianceData = [95, 87, 92, 100, 85, 93, 98];

        chartRef.current = new Chart.default(ctx, {
          type: 'line',
          data: {
            labels,
            datasets: [{
              label: 'Compliance %',
              data: complianceData,
              borderColor: 'hsl(142, 76%, 64%)', // primary color
              backgroundColor: 'hsla(142, 76%, 64%, 0.1)',
              borderWidth: 3,
              fill: true,
              tension: 0.4,
              pointBackgroundColor: 'hsl(142, 76%, 64%)',
              pointBorderColor: 'white',
              pointBorderWidth: 2,
              pointRadius: 5,
            }]
          },
          options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
              legend: {
                display: false
              }
            },
            scales: {
              y: {
                beginAtZero: true,
                max: 100,
                ticks: {
                  callback: function(value) {
                    return value + '%';
                  }
                },
                grid: {
                  color: 'hsl(0, 0%, 92%)',
                }
              },
              x: {
                grid: {
                  display: false,
                }
              }
            }
          }
        });
      } else {
        // Biometric trends chart
        const last7Days = Array.from({ length: 7 }, (_, i) => {
          const date = new Date();
          date.setDate(date.getDate() - (6 - i));
          return date.toLocaleDateString('en-US', { weekday: 'short' });
        });

        // Extract data for the last 7 days
        const stepsData = last7Days.map((_, index) => {
          const dayData = data[6 - index];
          return dayData?.steps ? dayData.steps / 1000 : Math.random() * 3 + 7; // Mock data fallback
        });

        const sleepData = last7Days.map((_, index) => {
          const dayData = data[6 - index];
          return dayData?.sleepHours ? dayData.sleepHours / 60 : Math.random() * 2 + 6; // Mock data fallback
        });

        chartRef.current = new Chart.default(ctx, {
          type: 'bar',
          data: {
            labels: last7Days,
            datasets: [{
              label: 'Steps (thousands)',
              data: stepsData,
              backgroundColor: 'hsl(217, 91%, 60%)', // blue
              borderRadius: 4,
              barThickness: 24,
            }, {
              label: 'Sleep (hours)',
              data: sleepData,
              backgroundColor: 'hsl(255, 58%, 65%)', // purple
              borderRadius: 4,
              barThickness: 24,
            }]
          },
          options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
              legend: {
                position: 'bottom',
                labels: {
                  usePointStyle: true,
                  padding: 20,
                }
              }
            },
            scales: {
              y: {
                beginAtZero: true,
                grid: {
                  color: 'hsl(0, 0%, 92%)',
                }
              },
              x: {
                grid: {
                  display: false,
                }
              }
            }
          }
        });
      }
    });

    // Cleanup
    return () => {
      if (chartRef.current) {
        chartRef.current.destroy();
      }
    };
  }, [data, type]);

  return (
    <div className="bg-white rounded-xl shadow-sm border border-gray-200">
      <div className="p-6 border-b border-gray-200">
        <h3 className="text-lg font-semibold text-gray-900">{title}</h3>
        <p className="text-sm text-gray-600 mt-1">{subtitle}</p>
      </div>
      <div className="p-6">
        <div className="relative h-64">
          <canvas ref={canvasRef} className="w-full h-full"></canvas>
        </div>
      </div>
    </div>
  );
}
