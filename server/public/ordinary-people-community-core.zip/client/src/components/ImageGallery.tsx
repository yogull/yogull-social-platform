import { useState, useRef } from 'react';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Image as ImageIcon, Video, Upload, Edit, Trash2, Share2, Download, Crop, ZoomIn, RotateCw, Grid3X3 } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { apiRequest } from '@/lib/queryClient';

interface ImageGalleryProps {
  userId: number;
  galleryType?: 'photos' | 'videos' | 'all';
}

interface GalleryItem {
  id: number;
  userId: number;
  fileName: string;
  fileType: string;
  fileSize: number;
  fileData: string;
  caption?: string;
  tags?: string[];
  isPublic: boolean;
  createdAt: string;
  likes: number;
  shares: number;
}

export default function ImageGallery({ userId, galleryType = 'all' }: ImageGalleryProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [selectedItem, setSelectedItem] = useState<GalleryItem | null>(null);
  const [isUploading, setIsUploading] = useState(false);
  const [isCropping, setIsCropping] = useState(false);
  const [cropImage, setCropImage] = useState<string | null>(null);
  const [uploadCaption, setUploadCaption] = useState('');
  const [uploadTags, setUploadTags] = useState('');
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');

  // Fetch gallery items
  const { data: galleryItems = [], isLoading } = useQuery({
    queryKey: ['/api/gallery', userId, galleryType],
    queryFn: async () => {
      const response = await fetch(`/api/gallery/${userId}?type=${galleryType}`);
      if (!response.ok) throw new Error('Failed to fetch gallery');
      return response.json();
    }
  });

  const handleFileSelect = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    // Check file size (max 10MB)
    if (file.size > 10 * 1024 * 1024) {
      toast({
        title: "File Too Large",
        description: "Please select a file smaller than 10MB",
        variant: "destructive"
      });
      return;
    }

    // For images, show cropping interface
    if (file.type.startsWith('image/')) {
      const reader = new FileReader();
      reader.onload = (e) => {
        setCropImage(e.target?.result as string);
        setIsCropping(true);
      };
      reader.readAsDataURL(file);
    } else {
      // For videos, upload directly
      await uploadFile(file);
    }
  };

  const uploadFile = async (file: File, croppedData?: string) => {
    setIsUploading(true);
    try {
      const formData = new FormData();
      formData.append('file', file);
      formData.append('userId', userId.toString());
      formData.append('caption', uploadCaption);
      formData.append('tags', uploadTags);
      formData.append('isPublic', 'true');
      
      if (croppedData) {
        formData.append('croppedData', croppedData);
      }

      const response = await fetch('/api/gallery/upload', {
        method: 'POST',
        body: formData
      });

      if (response.ok) {
        toast({
          title: "Upload Successful",
          description: `${file.type.startsWith('image/') ? 'Image' : 'Video'} uploaded to gallery`
        });
        
        // Reset form
        setUploadCaption('');
        setUploadTags('');
        setCropImage(null);
        setIsCropping(false);
        
        // Refresh gallery
        queryClient.invalidateQueries({ queryKey: ['/api/gallery'] });
      }
    } catch (error) {
      toast({
        title: "Upload Failed",
        description: "There was an error uploading your file",
        variant: "destructive"
      });
    } finally {
      setIsUploading(false);
    }
  };

  const handleCropComplete = async (croppedDataUrl: string) => {
    if (!fileInputRef.current?.files?.[0]) return;
    
    // Convert data URL to blob
    const response = await fetch(croppedDataUrl);
    const blob = await response.blob();
    const file = new File([blob], 'cropped-image.jpg', { type: 'image/jpeg' });
    
    await uploadFile(file, croppedDataUrl);
  };

  const handleDeleteItem = async (itemId: number) => {
    try {
      const response = await fetch(`/api/gallery/${itemId}`, {
        method: 'DELETE'
      });

      if (response.ok) {
        toast({
          title: "Item Deleted",
          description: "Gallery item removed successfully"
        });
        queryClient.invalidateQueries({ queryKey: ['/api/gallery'] });
        setSelectedItem(null);
      }
    } catch (error) {
      toast({
        title: "Delete Failed",
        description: "Could not delete the item",
        variant: "destructive"
      });
    }
  };

  const handleShareItem = (item: GalleryItem) => {
    if (navigator.share) {
      navigator.share({
        title: item.caption || 'Shared from Gallery',
        text: `Check out this ${item.fileType.startsWith('image/') ? 'image' : 'video'} from my gallery`,
        url: window.location.href
      });
    } else {
      // Fallback to copying link
      navigator.clipboard.writeText(window.location.href);
      toast({
        title: "Link Copied",
        description: "Gallery link copied to clipboard"
      });
    }
  };

  const filteredItems = galleryItems.filter((item: GalleryItem) => {
    if (galleryType === 'photos') return item.fileType.startsWith('image/');
    if (galleryType === 'videos') return item.fileType.startsWith('video/');
    return true;
  });

  return (
    <div className="space-y-4">
      {/* Header Controls */}
      <div className="flex items-center justify-between">
        <h3 className="text-lg font-semibold">
          {galleryType === 'photos' ? 'Photo Gallery' : 
           galleryType === 'videos' ? 'Video Gallery' : 'Media Gallery'}
        </h3>
        <div className="flex gap-2">
          <Button
            size="sm"
            variant="outline"
            onClick={() => setViewMode(viewMode === 'grid' ? 'list' : 'grid')}
          >
            <Grid3X3 className="w-4 h-4" />
          </Button>
          <Button
            size="sm"
            onClick={() => fileInputRef.current?.click()}
            disabled={isUploading}
          >
            <Upload className="w-4 h-4 mr-2" />
            {isUploading ? 'Uploading...' : 'Add Media'}
          </Button>
        </div>
      </div>

      {/* File Input */}
      <input
        ref={fileInputRef}
        type="file"
        accept={galleryType === 'photos' ? 'image/*' : galleryType === 'videos' ? 'video/*' : 'image/*,video/*'}
        className="hidden"
        onChange={handleFileSelect}
      />

      {/* Upload Form Modal */}
      {isCropping && cropImage && (
        <Dialog open={isCropping} onOpenChange={setIsCropping}>
          <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>Crop & Upload Image</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div className="relative">
                <img 
                  src={cropImage} 
                  alt="Crop preview" 
                  className="max-w-full h-auto max-h-96 mx-auto"
                />
                <div className="absolute inset-0 border-2 border-dashed border-blue-500 pointer-events-none"></div>
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="caption">Caption</Label>
                  <Input
                    id="caption"
                    placeholder="Add a caption..."
                    value={uploadCaption}
                    onChange={(e) => setUploadCaption(e.target.value)}
                  />
                </div>
                <div>
                  <Label htmlFor="tags">Tags (comma separated)</Label>
                  <Input
                    id="tags"
                    placeholder="nature, landscape, photography"
                    value={uploadTags}
                    onChange={(e) => setUploadTags(e.target.value)}
                  />
                </div>
              </div>

              <div className="flex justify-end gap-2">
                <Button variant="outline" onClick={() => setIsCropping(false)}>
                  Cancel
                </Button>
                <Button onClick={() => handleCropComplete(cropImage)} disabled={isUploading}>
                  {isUploading ? 'Uploading...' : 'Upload Image'}
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      )}

      {/* Gallery Grid/List */}
      {isLoading ? (
        <div className="text-center py-8">
          <div className="animate-spin w-8 h-8 border-4 border-blue-500 border-t-transparent rounded-full mx-auto"></div>
          <p className="mt-2 text-gray-500">Loading gallery...</p>
        </div>
      ) : filteredItems.length === 0 ? (
        <Card>
          <CardContent className="p-8 text-center">
            <div className="w-16 h-16 mx-auto mb-4 bg-gray-100 rounded-full flex items-center justify-center">
              <ImageIcon className="w-8 h-8 text-gray-400" />
            </div>
            <h3 className="text-lg font-medium mb-2">No media files yet</h3>
            <p className="text-gray-500 mb-4">Upload your first {galleryType === 'photos' ? 'photo' : galleryType === 'videos' ? 'video' : 'media file'} to get started</p>
            <Button onClick={() => fileInputRef.current?.click()}>
              <Upload className="w-4 h-4 mr-2" />
              Upload {galleryType === 'photos' ? 'Photo' : galleryType === 'videos' ? 'Video' : 'Media'}
            </Button>
          </CardContent>
        </Card>
      ) : (
        <div className={viewMode === 'grid' ? 'grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4' : 'space-y-4'}>
          {filteredItems.map((item: GalleryItem) => (
            <Card key={item.id} className="overflow-hidden hover:shadow-lg transition-shadow">
              <div className="relative aspect-square">
                {item.fileType.startsWith('image/') ? (
                  <img
                    src={`data:${item.fileType};base64,${item.fileData}`}
                    alt={item.caption || 'Gallery image'}
                    className="w-full h-full object-cover cursor-pointer"
                    onClick={() => setSelectedItem(item)}
                  />
                ) : (
                  <div className="w-full h-full bg-gray-100 flex items-center justify-center cursor-pointer"
                       onClick={() => setSelectedItem(item)}>
                    <Video className="w-12 h-12 text-gray-400" />
                  </div>
                )}
                
                {/* Overlay Controls */}
                <div className="absolute inset-0 bg-black bg-opacity-0 hover:bg-opacity-50 transition-all duration-200 flex items-center justify-center opacity-0 hover:opacity-100">
                  <div className="flex gap-2">
                    <Button size="sm" variant="secondary" onClick={() => setSelectedItem(item)}>
                      <ZoomIn className="w-4 h-4" />
                    </Button>
                    <Button size="sm" variant="secondary" onClick={() => handleShareItem(item)}>
                      <Share2 className="w-4 h-4" />
                    </Button>
                    <Button size="sm" variant="destructive" onClick={() => handleDeleteItem(item.id)}>
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              </div>
              
              {viewMode === 'list' && (
                <CardContent className="p-3">
                  <h4 className="font-medium text-sm">{item.caption || 'Untitled'}</h4>
                  <p className="text-xs text-gray-500 mt-1">
                    {new Date(item.createdAt).toLocaleDateString()} • {item.likes} likes • {item.shares} shares
                  </p>
                  {item.tags && item.tags.length > 0 && (
                    <div className="flex flex-wrap gap-1 mt-2">
                      {item.tags.map((tag, index) => (
                        <span key={index} className="px-2 py-1 bg-blue-100 text-blue-800 text-xs rounded">
                          #{tag}
                        </span>
                      ))}
                    </div>
                  )}
                </CardContent>
              )}
            </Card>
          ))}
        </div>
      )}

      {/* Full View Modal */}
      {selectedItem && (
        <Dialog open={!!selectedItem} onOpenChange={() => setSelectedItem(null)}>
          <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>{selectedItem.caption || 'Gallery Item'}</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div className="text-center">
                {selectedItem.fileType.startsWith('image/') ? (
                  <img
                    src={`data:${selectedItem.fileType};base64,${selectedItem.fileData}`}
                    alt={selectedItem.caption || 'Gallery image'}
                    className="max-w-full max-h-96 mx-auto rounded-lg"
                  />
                ) : (
                  <video
                    src={`data:${selectedItem.fileType};base64,${selectedItem.fileData}`}
                    controls
                    className="max-w-full max-h-96 mx-auto rounded-lg"
                  />
                )}
              </div>
              
              <div className="flex items-center justify-between">
                <div className="text-sm text-gray-600">
                  <p>Uploaded: {new Date(selectedItem.createdAt).toLocaleDateString()}</p>
                  <p>Size: {(selectedItem.fileSize / 1024 / 1024).toFixed(2)} MB</p>
                </div>
                <div className="flex gap-2">
                  <Button size="sm" variant="outline" onClick={() => handleShareItem(selectedItem)}>
                    <Share2 className="w-4 h-4 mr-1" />
                    Share
                  </Button>
                  <Button size="sm" variant="destructive" onClick={() => handleDeleteItem(selectedItem.id)}>
                    <Trash2 className="w-4 h-4 mr-1" />
                    Delete
                  </Button>
                </div>
              </div>

              {selectedItem.tags && selectedItem.tags.length > 0 && (
                <div className="flex flex-wrap gap-2">
                  {selectedItem.tags.map((tag, index) => (
                    <span key={index} className="px-3 py-1 bg-blue-100 text-blue-800 text-sm rounded-full">
                      #{tag}
                    </span>
                  ))}
                </div>
              )}
            </div>
          </DialogContent>
        </Dialog>
      )}
    </div>
  );
}