import React, { useState } from 'react';
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Heart, MessageCircle, Share2, MoreHorizontal } from "lucide-react";
import { formatDistanceToNow } from "date-fns";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";

interface UniversalFeedProps {
  posts: any[];
  currentUser: any;
  type: 'profile' | 'community' | 'discussion';
  enableComments?: boolean;
  enableSharing?: boolean;
}

export default function UniversalFeed({ 
  posts = [], 
  currentUser, 
  type = 'profile',
  enableComments = true,
  enableSharing = true 
}: UniversalFeedProps) {
  const [expandedPost, setExpandedPost] = useState<number | null>(null);
  const [newComment, setNewComment] = useState<{ [key: number]: string }>({});
  const queryClient = useQueryClient();
  const { toast } = useToast();

  // Like mutation
  const likeMutation = useMutation({
    mutationFn: async (postId: number) => {
      const endpoint = type === 'profile' ? `/api/profile-wall/${postId}/like` : `/api/discussions/${postId}/like`;
      const response = await fetch(endpoint, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' }
      });
      if (!response.ok) throw new Error('Failed to like post');
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/profile-wall"] });
      queryClient.invalidateQueries({ queryKey: ["/api/discussions"] });
    }
  });

  // Comment mutation
  const commentMutation = useMutation({
    mutationFn: async ({ postId, content }: { postId: number; content: string }) => {
      const endpoint = type === 'profile' ? `/api/profile-wall/${postId}/comments` : `/api/discussions/${postId}/comments`;
      const response = await fetch(endpoint, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ content })
      });
      if (!response.ok) throw new Error('Failed to add comment');
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/profile-wall"] });
      queryClient.invalidateQueries({ queryKey: ["/api/discussions"] });
    }
  });

  const handleLike = async (postId: number) => {
    try {
      await likeMutation.mutateAsync(postId);
    } catch (error) {
      console.error('Failed to like post:', error);
    }
  };

  const handleComment = async (postId: number) => {
    const content = newComment[postId]?.trim();
    if (!content) return;

    try {
      await commentMutation.mutateAsync({ postId, content });
      setNewComment(prev => ({ ...prev, [postId]: '' }));
    } catch (error) {
      console.error('Failed to add comment:', error);
      toast({
        title: "Error",
        description: "Failed to add comment. Please try again.",
        variant: "destructive"
      });
    }
  };

  const handleMultiShare = async (postId: number, post: any) => {
    const shareData = {
      title: `${post.user?.name || post.authorName}'s post`,
      text: post.content?.substring(0, 100) + (post.content?.length > 100 ? '...' : ''),
      url: window.location.href
    };

    // Try native sharing first
    if (navigator.share) {
      try {
        await navigator.share(shareData);
        return;
      } catch (error) {
        console.log('Native share cancelled');
      }
    }

    // Multi-platform sharing fallback
    const platforms = [
      {
        name: 'Facebook',
        url: `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(window.location.href)}`
      },
      {
        name: 'Twitter',
        url: `https://twitter.com/intent/tweet?text=${encodeURIComponent(shareData.text)}&url=${encodeURIComponent(window.location.href)}`
      },
      {
        name: 'LinkedIn',
        url: `https://www.linkedin.com/sharing/share-offsite/?url=${encodeURIComponent(window.location.href)}`
      },
      {
        name: 'WhatsApp',
        url: `https://wa.me/?text=${encodeURIComponent(shareData.text + ' ' + window.location.href)}`
      }
    ];

    // Open multiple sharing windows
    platforms.forEach(platform => {
      window.open(platform.url, '_blank', 'width=600,height=400');
    });

    toast({
      title: "Multi-Share Activated!",
      description: "Sharing to multiple platforms simultaneously"
    });
  };

  if (!posts || posts.length === 0) {
    return (
      <Card className="max-w-2xl mx-auto">
        <CardContent className="p-8 text-center">
          <div className="text-gray-500">
            <MessageCircle className="w-12 h-12 mx-auto mb-3 text-gray-300" />
            <p className="text-sm">No posts to display yet</p>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-4 max-w-2xl mx-auto">
      {posts.map((post: any) => (
        <Card key={post.id} className="shadow-sm border border-gray-200">
          <CardContent className="p-0">
            {/* Post Header */}
            <div className="p-4 border-b border-gray-100">
              <div className="flex items-center space-x-3">
                <Avatar className="w-10 h-10">
                  <AvatarImage 
                    src={post.user?.profileImageUrl || post.authorProfileImage} 
                    alt={post.user?.name || post.authorName}
                  />
                  <AvatarFallback>
                    {(post.user?.name || post.authorName)?.charAt(0)?.toUpperCase() || 'U'}
                  </AvatarFallback>
                </Avatar>
                <div className="flex-1">
                  <h3 className="font-semibold text-sm">{post.user?.name || post.authorName}</h3>
                  <p className="text-xs text-gray-500">
                    {formatDistanceToNow(new Date(post.createdAt), { addSuffix: true })}
                  </p>
                </div>
                <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
                  <MoreHorizontal className="h-4 w-4" />
                </Button>
              </div>
            </div>

            {/* Post Content */}
            <div className="p-4">
              <p className="text-sm text-gray-900 whitespace-pre-wrap mb-3">
                {post.content}
              </p>
              
              {/* Media Content */}
              {post.mediaUrl && (
                <div className="mt-3 rounded-lg overflow-hidden">
                  {post.mediaType === 'video' ? (
                    <video controls className="w-full max-h-96 object-cover">
                      <source src={post.mediaUrl} type="video/mp4" />
                      Your browser does not support the video tag.
                    </video>
                  ) : (
                    <img 
                      src={post.mediaUrl} 
                      alt="Post media" 
                      className="w-full max-h-96 object-cover cursor-pointer hover:opacity-90 transition-opacity"
                      onClick={() => window.open(post.mediaUrl, '_blank')}
                    />
                  )}
                </div>
              )}
            </div>

            {/* Engagement Stats */}
            <div className="px-4 py-2 border-b border-gray-100">
              <div className="flex items-center justify-between text-xs text-gray-500">
                <span>{(post.likes || 0)} likes</span>
                <div className="flex space-x-3">
                  <span>{(post.comments?.length || 0)} comments</span>
                  <span>{(post.shares || 0)} shares</span>
                </div>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="px-4 py-2">
              <div className="flex justify-around">
                <Button
                  size="sm"
                  variant="ghost"
                  onClick={() => handleLike(post.id)}
                  disabled={likeMutation.isPending}
                  className="flex-1 flex items-center justify-center gap-2 py-2 hover:bg-gray-50 rounded-md transition-colors"
                >
                  <Heart className={`h-4 w-4 ${post.userHasLiked ? 'fill-red-500 text-red-500' : 'text-gray-600'}`} />
                  <span className="text-sm font-medium text-gray-700">Like</span>
                </Button>
                
                {enableComments && (
                  <Button
                    size="sm"
                    variant="ghost"
                    onClick={() => setExpandedPost(expandedPost === post.id ? null : post.id)}
                    className="flex-1 flex items-center justify-center gap-2 py-2 hover:bg-gray-50 rounded-md transition-colors"
                  >
                    <MessageCircle className="h-4 w-4 text-gray-600" />
                    <span className="text-sm font-medium text-gray-700">Comment</span>
                  </Button>
                )}
                
                {enableSharing && (
                  <Button
                    size="sm"
                    variant="ghost"
                    onClick={() => handleMultiShare(post.id, post)}
                    className="flex-1 flex items-center justify-center gap-2 py-2 hover:bg-gray-50 rounded-md transition-colors"
                  >
                    <Share2 className="h-4 w-4 text-gray-600" />
                    <span className="text-sm font-medium text-gray-700">Multi-Share</span>
                  </Button>
                )}
              </div>
            </div>

            {/* Comments Section */}
            {enableComments && expandedPost === post.id && (
              <div className="border-t border-gray-100 p-4 bg-gray-50">
                <div className="space-y-3">
                  {/* Existing Comments */}
                  {post.comments && post.comments.length > 0 && (
                    <div className="space-y-2">
                      {post.comments.map((comment: any) => (
                        <div key={comment.id} className="flex space-x-2">
                          <Avatar className="w-8 h-8 flex-shrink-0">
                            <AvatarImage src={comment.user?.profileImageUrl} />
                            <AvatarFallback>
                              {comment.user?.name?.charAt(0)?.toUpperCase() || 'U'}
                            </AvatarFallback>
                          </Avatar>
                          <div className="flex-1 bg-gray-100 rounded-lg p-2">
                            <p className="text-xs font-semibold">{comment.user?.name}</p>
                            <p className="text-sm">{comment.content}</p>
                            <p className="text-xs text-gray-500 mt-1">
                              {formatDistanceToNow(new Date(comment.createdAt), { addSuffix: true })}
                            </p>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                  
                  {/* Add Comment */}
                  <div className="flex space-x-2">
                    <Avatar className="w-8 h-8 flex-shrink-0">
                      <AvatarImage src={currentUser?.profileImageUrl} />
                      <AvatarFallback>
                        {currentUser?.name?.charAt(0)?.toUpperCase() || 'U'}
                      </AvatarFallback>
                    </Avatar>
                    <div className="flex-1 flex space-x-2">
                      <input
                        type="text"
                        placeholder="Write a comment..."
                        value={newComment[post.id] || ''}
                        onChange={(e) => setNewComment(prev => ({ ...prev, [post.id]: e.target.value }))}
                        className="flex-1 px-3 py-2 bg-gray-100 rounded-full text-sm border-0 focus:outline-none focus:ring-2 focus:ring-blue-500"
                        onKeyPress={(e) => {
                          if (e.key === 'Enter') {
                            handleComment(post.id);
                          }
                        }}
                      />
                      <Button
                        size="sm"
                        onClick={() => handleComment(post.id)}
                        disabled={commentMutation.isPending || !newComment[post.id]?.trim()}
                        className="px-4 py-2 bg-blue-500 text-white rounded-full hover:bg-blue-600"
                      >
                        Post
                      </Button>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      ))}
    </div>
  );
}