import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { X, Cookie, Settings } from "lucide-react";

export function CookieConsent() {
  const [isVisible, setIsVisible] = useState(false);
  const [showSettings, setShowSettings] = useState(false);
  const [preferences, setPreferences] = useState({
    necessary: true, // Always required
    analytics: false,
    marketing: false,
    functional: false
  });

  useEffect(() => {
    // Check if user has already made a choice
    const consent = localStorage.getItem('ordinarypeople-cookie-consent');
    if (!consent) {
      // Show popup after a short delay
      const timer = setTimeout(() => setIsVisible(true), 1000);
      return () => clearTimeout(timer);
    }
  }, []);

  const handleAcceptAll = () => {
    const allAccepted = {
      necessary: true,
      analytics: true,
      marketing: true,
      functional: true,
      timestamp: new Date().toISOString()
    };
    localStorage.setItem('ordinarypeople-cookie-consent', JSON.stringify(allAccepted));
    setIsVisible(false);
  };

  const handleRejectAll = () => {
    const onlyNecessary = {
      necessary: true,
      analytics: false,
      marketing: false,
      functional: false,
      timestamp: new Date().toISOString()
    };
    localStorage.setItem('ordinarypeople-cookie-consent', JSON.stringify(onlyNecessary));
    setIsVisible(false);
  };

  const handleSavePreferences = () => {
    const savedPreferences = {
      ...preferences,
      timestamp: new Date().toISOString()
    };
    localStorage.setItem('ordinarypeople-cookie-consent', JSON.stringify(savedPreferences));
    setIsVisible(false);
  };

  if (!isVisible) return null;

  return (
    <div className="fixed inset-0 bg-black/50 z-50 flex items-end md:items-center justify-center p-4">
      <Card className="w-full max-w-2xl bg-white shadow-2xl border-primary/20">
        <CardHeader className="pb-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Cookie className="w-5 h-5 text-primary" />
              <CardTitle className="text-lg">Cookie Preferences</CardTitle>
            </div>
            <Button 
              variant="ghost" 
              size="sm" 
              onClick={() => setIsVisible(false)}
              className="p-1"
            >
              <X className="w-4 h-4" />
            </Button>
          </div>
        </CardHeader>
        
        <CardContent className="space-y-4">
          <div className="text-sm text-gray-600">
            <p className="mb-4">
              GoHealMe uses cookies to enhance your experience, provide personalized content, and analyze our traffic. 
              We respect your privacy and give you control over your data.
            </p>
            
            {!showSettings ? (
              <div className="space-y-4">
                <p>
                  By clicking "Accept All", you consent to our use of cookies. You can manage your preferences anytime in settings.
                </p>
                
                <div className="flex flex-col sm:flex-row gap-3">
                  <Button onClick={handleAcceptAll} className="flex-1">
                    Accept All Cookies
                  </Button>
                  <Button onClick={handleRejectAll} variant="outline" className="flex-1">
                    Reject Non-Essential
                  </Button>
                  <Button 
                    onClick={() => setShowSettings(true)} 
                    variant="ghost"
                    className="flex items-center gap-2"
                  >
                    <Settings className="w-4 h-4" />
                    Customise
                  </Button>
                </div>
              </div>
            ) : (
              <div className="space-y-4">
                <div className="space-y-3">
                  <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                    <div>
                      <h4 className="font-medium">Necessary Cookies</h4>
                      <p className="text-xs text-gray-500">Required for basic site functionality</p>
                    </div>
                    <div className="text-sm text-gray-500">Always Active</div>
                  </div>
                  
                  <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                    <div>
                      <h4 className="font-medium">Analytics Cookies</h4>
                      <p className="text-xs text-gray-500">Help us understand how you use our site</p>
                    </div>
                    <input
                      type="checkbox"
                      checked={preferences.analytics}
                      onChange={(e) => setPreferences({...preferences, analytics: e.target.checked})}
                      className="w-4 h-4 text-primary rounded focus:ring-primary"
                    />
                  </div>
                  
                  <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                    <div>
                      <h4 className="font-medium">Functional Cookies</h4>
                      <p className="text-xs text-gray-500">Remember your preferences and settings</p>
                    </div>
                    <input
                      type="checkbox"
                      checked={preferences.functional}
                      onChange={(e) => setPreferences({...preferences, functional: e.target.checked})}
                      className="w-4 h-4 text-primary rounded focus:ring-primary"
                    />
                  </div>
                  
                  <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                    <div>
                      <h4 className="font-medium">Marketing Cookies</h4>
                      <p className="text-xs text-gray-500">Deliver relevant ads and content</p>
                    </div>
                    <input
                      type="checkbox"
                      checked={preferences.marketing}
                      onChange={(e) => setPreferences({...preferences, marketing: e.target.checked})}
                      className="w-4 h-4 text-primary rounded focus:ring-primary"
                    />
                  </div>
                </div>
                
                <div className="flex flex-col sm:flex-row gap-3 pt-4 border-t">
                  <Button onClick={handleSavePreferences} className="flex-1">
                    Save Preferences
                  </Button>
                  <Button onClick={() => setShowSettings(false)} variant="outline">
                    Back
                  </Button>
                </div>
              </div>
            )}
            
            <p className="text-xs text-gray-500 mt-4">
              Read our <a href="/privacy-policy" className="text-primary hover:underline">Privacy Policy</a> and{' '}
              <a href="/terms" className="text-primary hover:underline">Terms of Service</a> for more information.
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}