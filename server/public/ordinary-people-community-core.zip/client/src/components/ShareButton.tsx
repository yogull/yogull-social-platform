import { Share2 } from "lucide-react";
import { Button } from "@/components/ui/button";

interface ShareButtonProps {
  className?: string;
}

export function ShareButton({ className = "" }: ShareButtonProps) {
  const handleShare = async () => {
    const shareData = {
      title: 'Ordinary People Community',
      text: 'Join Ordinary People Community - A platform for open discussions on government topics, personal views, and health advice. Connect with real people and share experiences.',
      url: window.location.origin
    };

    try {
      if (navigator.share && navigator.canShare(shareData)) {
        await navigator.share(shareData);
      } else {
        // Fallback to clipboard
        await navigator.clipboard.writeText(`${shareData.title}\n${shareData.text}\n${shareData.url}`);
        // Show a simple alert since we don't have toast in this context
        alert('Link copied to clipboard!');
      }
    } catch (error) {
      // If all else fails, just copy the URL
      try {
        await navigator.clipboard.writeText(window.location.origin);
        alert('Website link copied to clipboard!');
      } catch (clipboardError) {
        console.error('Share failed:', error);
      }
    }
  };

  return (
    <Button
      onClick={handleShare}
      className={`bg-blue-600 hover:bg-blue-700 text-white font-semibold px-6 py-3 text-lg shadow-lg transition-all duration-200 hover:shadow-xl ${className}`}
      size="lg"
    >
      <Share2 className="w-5 h-5 mr-2" />
      Share Community
    </Button>
  );
}