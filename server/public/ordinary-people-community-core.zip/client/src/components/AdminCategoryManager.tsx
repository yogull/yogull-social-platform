import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { Trash2, Edit, Plus, Save, X } from "lucide-react";

interface DiscussionCategory {
  id: number;
  name: string;
  description: string;
  color: string;
  icon: string;
  createdAt: string;
}

export function AdminCategoryManager() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [showCreateDialog, setShowCreateDialog] = useState(false);
  const [editingCategory, setEditingCategory] = useState<DiscussionCategory | null>(null);
  const [formData, setFormData] = useState({
    name: "",
    description: "",
    color: "#3b82f6",
    icon: "💬"
  });

  // Fetch categories
  const { data: categories, isLoading } = useQuery<DiscussionCategory[]>({
    queryKey: ['/api/discussion-categories'],
  });

  // Create category mutation
  const createCategoryMutation = useMutation({
    mutationFn: (categoryData: typeof formData) => 
      apiRequest("POST", "/api/discussion-categories", categoryData),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/discussion-categories'] });
      setShowCreateDialog(false);
      resetForm();
      toast({
        title: "Category Created",
        description: "New discussion category has been created successfully.",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to create category",
        variant: "destructive",
      });
    },
  });

  // Update category mutation
  const updateCategoryMutation = useMutation({
    mutationFn: ({ id, data }: { id: number, data: typeof formData }) => 
      apiRequest("PUT", `/api/discussion-categories/${id}`, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/discussion-categories'] });
      setEditingCategory(null);
      resetForm();
      toast({
        title: "Category Updated",
        description: "Discussion category has been updated successfully.",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to update category",
        variant: "destructive",
      });
    },
  });

  // Delete category mutation
  const deleteCategoryMutation = useMutation({
    mutationFn: (id: number) => 
      apiRequest("DELETE", `/api/discussion-categories/${id}`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/discussion-categories'] });
      toast({
        title: "Category Deleted",
        description: "Discussion category has been deleted successfully.",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to delete category",
        variant: "destructive",
      });
    },
  });

  const resetForm = () => {
    setFormData({
      name: "",
      description: "",
      color: "#3b82f6",
      icon: "💬"
    });
  };

  const handleEdit = (category: DiscussionCategory) => {
    setEditingCategory(category);
    setFormData({
      name: category.name,
      description: category.description || "",
      color: category.color,
      icon: category.icon
    });
  };

  const handleSave = () => {
    if (editingCategory) {
      updateCategoryMutation.mutate({ id: editingCategory.id, data: formData });
    } else {
      createCategoryMutation.mutate(formData);
    }
  };

  const handleCancel = () => {
    setEditingCategory(null);
    setShowCreateDialog(false);
    resetForm();
  };

  if (isLoading) {
    return <div className="p-4">Loading categories...</div>;
  }

  return (
    <Card className="w-full">
      <CardHeader>
        <div className="flex justify-between items-center">
          <CardTitle>Discussion Categories Management</CardTitle>
          <Dialog open={showCreateDialog} onOpenChange={setShowCreateDialog}>
            <DialogTrigger asChild>
              <Button onClick={() => resetForm()}>
                <Plus className="w-4 h-4 mr-2" />
                Create Category
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Create New Discussion Category</DialogTitle>
              </DialogHeader>
              <CategoryForm 
                formData={formData}
                setFormData={setFormData}
                onSave={handleSave}
                onCancel={handleCancel}
                isLoading={createCategoryMutation.isPending}
              />
            </DialogContent>
          </Dialog>
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {categories?.map((category) => (
            <div key={category.id} className="border rounded-lg p-3 md:p-4 max-w-[95vw] overflow-hidden">
              {editingCategory?.id === category.id ? (
                <CategoryForm 
                  formData={formData}
                  setFormData={setFormData}
                  onSave={handleSave}
                  onCancel={handleCancel}
                  isLoading={updateCategoryMutation.isPending}
                />
              ) : (
                <div className="flex flex-col md:flex-row md:justify-between md:items-start gap-3">
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-2 flex-wrap">
                      <span className="text-lg shrink-0">{category.icon}</span>
                      <h3 className="font-semibold text-lg break-words min-w-0">{category.name}</h3>
                      <Badge style={{ backgroundColor: category.color, color: 'white' }} className="shrink-0 text-xs">
                        {category.color}
                      </Badge>
                    </div>
                    {category.description && (
                      <p className="text-gray-600 mb-2 break-words text-sm md:text-base">{category.description}</p>
                    )}
                    <p className="text-xs md:text-sm text-gray-500">
                      Created: {new Date(category.createdAt).toLocaleDateString()}
                    </p>
                  </div>
                  <div className="flex gap-2 shrink-0">
                    <Button
                      variant="outline"
                      size="sm"
                      className="text-xs"
                      onClick={() => handleEdit(category)}
                    >
                      <Edit className="w-4 h-4" />
                    </Button>
                    <Button
                      variant="destructive"
                      size="sm"
                      onClick={() => deleteCategoryMutation.mutate(category.id)}
                      disabled={deleteCategoryMutation.isPending}
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              )}
            </div>
          ))}
          {(!categories || categories.length === 0) && (
            <div className="text-center py-8 text-gray-500">
              No categories created yet. Create your first category to get started.
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}

interface CategoryFormProps {
  formData: {
    name: string;
    description: string;
    color: string;
    icon: string;
  };
  setFormData: (data: any) => void;
  onSave: () => void;
  onCancel: () => void;
  isLoading: boolean;
}

function CategoryForm({ formData, setFormData, onSave, onCancel, isLoading }: CategoryFormProps) {
  const commonIcons = ["💬", "🏥", "🏛️", "🌍", "🏘️", "🌟", "💻", "🚗", "🏠", "💰", "⚖️", "🎓", "🛡️", "🌱"];

  return (
    <div className="space-y-4">
      <div>
        <Label htmlFor="name">Category Name</Label>
        <Input
          id="name"
          value={formData.name}
          onChange={(e) => setFormData({ ...formData, name: e.target.value })}
          placeholder="e.g., Government & Policy"
          required
        />
      </div>
      
      <div>
        <Label htmlFor="description">Description</Label>
        <Textarea
          id="description"
          value={formData.description}
          onChange={(e) => setFormData({ ...formData, description: e.target.value })}
          placeholder="Brief description of what discussions belong in this category"
          rows={3}
        />
      </div>

      <div>
        <Label htmlFor="icon">Icon</Label>
        <div className="flex flex-wrap gap-2 mb-2">
          {commonIcons.map((icon) => (
            <Button
              key={icon}
              variant={formData.icon === icon ? "default" : "outline"}
              size="sm"
              onClick={() => setFormData({ ...formData, icon })}
              className="text-lg"
            >
              {icon}
            </Button>
          ))}
        </div>
        <Input
          id="icon"
          value={formData.icon}
          onChange={(e) => setFormData({ ...formData, icon: e.target.value })}
          placeholder="Enter custom emoji or icon"
        />
      </div>

      <div>
        <Label htmlFor="color">Color</Label>
        <div className="flex items-center gap-2">
          <input
            type="color"
            id="color"
            value={formData.color}
            onChange={(e) => setFormData({ ...formData, color: e.target.value })}
            className="w-12 h-10 border rounded"
          />
          <Input
            value={formData.color}
            onChange={(e) => setFormData({ ...formData, color: e.target.value })}
            placeholder="#3b82f6"
            className="flex-1"
          />
        </div>
      </div>

      <div className="flex justify-end gap-2 pt-4">
        <Button variant="outline" onClick={onCancel} disabled={isLoading}>
          <X className="w-4 h-4 mr-2" />
          Cancel
        </Button>
        <Button onClick={onSave} disabled={isLoading || !formData.name.trim()}>
          <Save className="w-4 h-4 mr-2" />
          {isLoading ? "Saving..." : "Save"}
        </Button>
      </div>
    </div>
  );
}