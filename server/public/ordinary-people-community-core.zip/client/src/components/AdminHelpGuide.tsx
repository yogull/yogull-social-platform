import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Settings, Users, Rss, Building2, MessageSquare, 
  FileText, BarChart3, Shield, HelpCircle,
  ChevronRight, Monitor, Database, Mail
} from "lucide-react";

const adminSections = {
  "feeds": {
    title: "RSS Feeds Management",
    icon: <Rss className="w-5 h-5" />,
    description: "Manage automated content feeds and posting",
    features: [
      "Add RSS feed sources from news sites and blogs",
      "Configure auto-posting to discussion categories", 
      "Set posting frequency (hourly, daily, weekly)",
      "Monitor feed health and content quality",
      "Review and approve posts before publishing"
    ],
    howTo: [
      "Click 'Add New Feed' to create RSS source",
      "Enter feed URL (e.g., https://example.com/rss)",
      "Select target discussion category",
      "Set auto-posting schedule",
      "Enable/disable feed as needed"
    ]
  },
  "categories": {
    title: "Discussion Categories",
    icon: <MessageSquare className="w-5 h-5" />,
    description: "Create and manage community discussion topics",
    features: [
      "Create new discussion categories",
      "Set category descriptions and rules",
      "Manage category visibility and permissions",
      "Monitor category activity and engagement",
      "Moderate discussions and remove inappropriate content"
    ],
    howTo: [
      "Click 'Create Category' button",
      "Enter category name and description",
      "Set category icon and color",
      "Configure posting permissions",
      "Save and activate category"
    ]
  },
  "users": {
    title: "User Management", 
    icon: <Users className="w-5 h-5" />,
    description: "Manage user accounts and permissions",
    features: [
      "View all registered users",
      "Block or unblock user accounts",
      "Reset user passwords",
      "Manage admin privileges",
      "View user activity logs"
    ],
    howTo: [
      "Search users by name or email",
      "Click user to view full profile",
      "Use 'Block User' for violations",
      "Grant admin access with caution",
      "Review activity for suspicious behavior"
    ]
  },
  "business": {
    title: "Business Directory",
    icon: <Building2 className="w-5 h-5" />,
    description: "Manage business listings and advertisements",
    features: [
      "Add and edit business listings",
      "Manage advertisement campaigns",
      "Set pricing and subscription terms",
      "Monitor ad performance metrics",
      "Handle business verification requests"
    ],
    howTo: [
      "Access business listings via admin panel",
      "Click 'Add Business' for new listings",
      "Upload business logos and images",
      "Set advertisement pricing (£24/year)",
      "Monitor clicks and impressions"
    ]
  },
  "content": {
    title: "Content Moderation",
    icon: <FileText className="w-5 h-5" />,
    description: "Review and moderate user-generated content",
    features: [
      "Review reported posts and comments",
      "Remove inappropriate content",
      "Manage community guidelines",
      "Handle user reports and complaints",
      "Moderate chat messages and discussions"
    ],
    howTo: [
      "Check 'Reported Content' queue daily",
      "Review context before taking action",
      "Remove content violating guidelines",
      "Send warnings to users when appropriate",
      "Document moderation decisions"
    ]
  },
  "analytics": {
    title: "Site Analytics",
    icon: <BarChart3 className="w-5 h-5" />,
    description: "Monitor site performance and user engagement",
    features: [
      "Track user registration and activity",
      "Monitor page views and engagement",
      "Analyze discussion participation",
      "Review advertisement performance",
      "Generate usage reports"
    ],
    howTo: [
      "Access analytics dashboard",
      "Review daily/weekly/monthly reports",
      "Identify trending discussions",
      "Monitor user retention rates",
      "Export data for external analysis"
    ]
  }
};

export function AdminHelpGuide() {
  const [selectedSection, setSelectedSection] = useState("feeds");

  return (
    <Dialog>
      <DialogTrigger asChild>
        <Button variant="outline" size="sm" className="gap-2">
          <HelpCircle className="w-4 h-4" />
          Admin Guide
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-[95vw] md:max-w-4xl max-h-[85vh] overflow-y-auto p-4 m-2">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Shield className="w-5 h-5 text-blue-600" />
            Complete Admin Guide - Ordinary People Community
          </DialogTitle>
        </DialogHeader>

        <Tabs value={selectedSection} onValueChange={setSelectedSection} className="mt-2">
          <TabsList className="grid grid-cols-3 lg:grid-cols-6 gap-1 mb-4">
            {Object.entries(adminSections).map(([key, section]) => (
              <TabsTrigger key={key} value={key} className="text-xs flex flex-col gap-1 h-auto p-2">
                {section.icon}
                <span className="hidden sm:inline">{section.title.split(' ')[0]}</span>
              </TabsTrigger>
            ))}
          </TabsList>

          {Object.entries(adminSections).map(([key, section]) => (
            <TabsContent key={key} value={key} className="mt-0">
              <Card className="border-0 shadow-none">
                <CardHeader className="px-0 pt-0 pb-2">
                  <CardTitle className="flex items-center gap-2 text-base md:text-lg">
                    {section.icon}
                    {section.title}
                  </CardTitle>
                  <p className="text-gray-600 text-sm">{section.description}</p>
                </CardHeader>
                <CardContent className="space-y-4 px-0">
                  <div>
                    <h4 className="font-semibold mb-2 flex items-center gap-2 text-sm">
                      <span className="w-5 h-5 rounded-full bg-green-100 text-green-600 flex items-center justify-center text-xs font-bold">
                        ✓
                      </span>
                      Key Features
                    </h4>
                    <ul className="space-y-1">
                      {section.features.map((feature, index) => (
                        <li key={index} className="flex items-start gap-2">
                          <ChevronRight className="w-3 h-3 text-green-500 mt-1 flex-shrink-0" />
                          <span className="text-xs leading-tight">{feature}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  <div>
                    <h4 className="font-semibold mb-2 flex items-center gap-2 text-sm">
                      <span className="w-5 h-5 rounded-full bg-blue-100 text-blue-600 flex items-center justify-center text-xs font-bold">
                        →
                      </span>
                      How to Use
                    </h4>
                    <ol className="space-y-1">
                      {section.howTo.map((step, index) => (
                        <li key={index} className="flex items-start gap-2">
                          <span className="w-5 h-5 rounded-full bg-blue-500 text-white flex items-center justify-center text-xs font-bold flex-shrink-0 mt-0.5">
                            {index + 1}
                          </span>
                          <span className="text-xs leading-tight">{step}</span>
                        </li>
                      ))}
                    </ol>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          ))}
        </Tabs>

        <div className="mt-4 p-3 bg-blue-50 rounded-lg border border-blue-200">
          <h4 className="font-semibold text-blue-900 mb-2 flex items-center gap-2 text-sm">
            <Database className="w-4 h-4" />
            Admin Access & Security
          </h4>
          <ul className="text-xs text-blue-800 space-y-1">
            <li>• Only John Proctor has full admin privileges</li>
            <li>• Admin panel accessible via sidebar navigation</li>
            <li>• All admin actions are logged for security</li>
            <li>• Use admin powers responsibly for community benefit</li>
          </ul>
        </div>

        <div className="mt-3 p-3 bg-green-50 rounded-lg border border-green-200">
          <h4 className="font-semibold text-green-900 mb-2 flex items-center gap-2 text-sm">
            <Mail className="w-4 h-4" />
            Need Help?
          </h4>
          <p className="text-xs text-green-800">
            Contact support at ordinarypeoplecommunity.com@gmail.com for technical assistance
            or questions about admin features.
          </p>
        </div>
      </DialogContent>
    </Dialog>
  );
}