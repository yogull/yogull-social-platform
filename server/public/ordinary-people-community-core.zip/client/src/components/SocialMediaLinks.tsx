/**
 * Copyright (c) 2025 John Proctor. All rights reserved.
 * The People's Health Community Platform
 */

import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { apiRequest } from "@/lib/queryClient";
import { 
  Facebook, 
  Twitter, 
  Instagram, 
  Linkedin, 
  Youtube, 
  MessageCircle,
  Send,
  Globe,
  Edit3,
  ExternalLink
} from "lucide-react";

interface SocialMediaLinksProps {
  userId: number;
  currentUser?: any;
  socialLinks?: {
    facebookUrl?: string;
    twitterUrl?: string;
    whatsappUrl?: string;
    telegramUrl?: string;
    instagramUrl?: string;
    linkedinUrl?: string;
    youtubeUrl?: string;
    tiktokUrl?: string;
    snapchatUrl?: string;
    discordUrl?: string;
    redditUrl?: string;
    pinterestUrl?: string;
    tumblrUrl?: string;
    twitchUrl?: string;
    spotifyUrl?: string;
    mediumUrl?: string;
    githubUrl?: string;
    vimeoUrl?: string;
    skypeUrl?: string;
    flickrUrl?: string;
    soundcloudUrl?: string;
    behanceUrl?: string;
    dribbbleUrl?: string;
    deviantartUrl?: string;
    stackoverflowUrl?: string;
    quoraUrl?: string;
    personalWebsite?: string;
  };
  isOwnProfile?: boolean;
}

interface SocialPlatform {
  key: keyof NonNullable<SocialMediaLinksProps['socialLinks']>;
  name: string;
  icon: React.ComponentType<{ className?: string }>;
  placeholder: string;
  color: string;
  baseUrl?: string;
}

const socialPlatforms: SocialPlatform[] = [
  {
    key: 'facebookUrl',
    name: 'Facebook',
    icon: Facebook,
    placeholder: 'Just your username - what comes after facebook.com/',
    color: 'text-blue-600',
    baseUrl: 'https://facebook.com/'
  },
  {
    key: 'twitterUrl',
    name: 'Twitter/X',
    icon: Twitter,
    placeholder: 'Your handle without @ - what comes after twitter.com/',
    color: 'text-blue-400',
    baseUrl: 'https://twitter.com/'
  },
  {
    key: 'instagramUrl',
    name: 'Instagram',
    icon: Instagram,
    placeholder: 'Your username - what comes after instagram.com/',
    color: 'text-pink-600',
    baseUrl: 'https://instagram.com/'
  },
  {
    key: 'linkedinUrl',
    name: 'LinkedIn',
    icon: Linkedin,
    placeholder: 'Your profile name - what comes after linkedin.com/in/',
    color: 'text-blue-700',
    baseUrl: 'https://linkedin.com/in/'
  },
  {
    key: 'youtubeUrl',
    name: 'YouTube',
    icon: Youtube,
    placeholder: 'Your channel name - what comes after youtube.com/@',
    color: 'text-red-600',
    baseUrl: 'https://youtube.com/@'
  },
  {
    key: 'whatsappUrl',
    name: 'WhatsApp',
    icon: MessageCircle,
    placeholder: 'Your phone number with country code (e.g., 447123456789)',
    color: 'text-green-600',
    baseUrl: 'https://wa.me/'
  },
  {
    key: 'telegramUrl',
    name: 'Telegram',
    icon: Send,
    placeholder: 'Enter username without @ (e.g., alansmith)',
    color: 'text-blue-500',
    baseUrl: 'https://t.me/'
  },
  {
    key: 'tiktokUrl',
    name: 'TikTok',
    icon: MessageCircle,
    placeholder: 'Enter username (e.g., johnproctor)',
    color: 'text-black',
    baseUrl: 'https://tiktok.com/@'
  },
  {
    key: 'snapchatUrl',
    name: 'Snapchat',
    icon: MessageCircle,
    placeholder: 'Enter username (e.g., johnproctor)',
    color: 'text-yellow-500',
    baseUrl: 'https://snapchat.com/add/'
  },
  {
    key: 'discordUrl',
    name: 'Discord',
    icon: MessageCircle,
    placeholder: 'Enter username#1234 (e.g., johnproctor#1234)',
    color: 'text-indigo-600',
    baseUrl: 'https://discord.com/users/'
  },
  {
    key: 'redditUrl',
    name: 'Reddit',
    icon: Globe,
    placeholder: 'Enter username (e.g., johnproctor)',
    color: 'text-orange-600',
    baseUrl: 'https://reddit.com/u/'
  },
  {
    key: 'pinterestUrl',
    name: 'Pinterest',
    icon: Globe,
    placeholder: 'Enter username (e.g., johnproctor)',
    color: 'text-red-500',
    baseUrl: 'https://pinterest.com/'
  },
  {
    key: 'tumblrUrl',
    name: 'Tumblr',
    icon: Globe,
    placeholder: 'Enter blog name (e.g., johnproctor)',
    color: 'text-blue-900',
    baseUrl: 'https://'
  },
  {
    key: 'twitchUrl',
    name: 'Twitch',
    icon: Youtube,
    placeholder: 'Enter username (e.g., johnproctor)',
    color: 'text-purple-600',
    baseUrl: 'https://twitch.tv/'
  },
  {
    key: 'spotifyUrl',
    name: 'Spotify',
    icon: Globe,
    placeholder: 'Enter username (e.g., johnproctor)',
    color: 'text-green-600',
    baseUrl: 'https://open.spotify.com/user/'
  },
  {
    key: 'mediumUrl',
    name: 'Medium',
    icon: Edit3,
    placeholder: 'Enter username (e.g., johnproctor)',
    color: 'text-gray-800',
    baseUrl: 'https://medium.com/@'
  },
  {
    key: 'githubUrl',
    name: 'GitHub',
    icon: Globe,
    placeholder: 'Enter username (e.g., johnproctor)',
    color: 'text-gray-700',
    baseUrl: 'https://github.com/'
  },
  {
    key: 'vimeoUrl',
    name: 'Vimeo',
    icon: Youtube,
    placeholder: 'Enter username (e.g., johnproctor)',
    color: 'text-blue-500',
    baseUrl: 'https://vimeo.com/'
  },
  {
    key: 'skypeUrl',
    name: 'Skype',
    icon: MessageCircle,
    placeholder: 'Enter username (e.g., john.proctor)',
    color: 'text-sky-500',
    baseUrl: 'skype:'
  },
  {
    key: 'flickrUrl',
    name: 'Flickr',
    icon: Globe,
    placeholder: 'Enter username (e.g., johnproctor)',
    color: 'text-pink-500',
    baseUrl: 'https://flickr.com/people/'
  },
  {
    key: 'soundcloudUrl',
    name: 'SoundCloud',
    icon: Globe,
    placeholder: 'Enter username (e.g., johnproctor)',
    color: 'text-orange-500',
    baseUrl: 'https://soundcloud.com/'
  },
  {
    key: 'behanceUrl',
    name: 'Behance',
    icon: Globe,
    placeholder: 'Enter username (e.g., johnproctor)',
    color: 'text-blue-600',
    baseUrl: 'https://behance.net/'
  },
  {
    key: 'dribbbleUrl',
    name: 'Dribbble',
    icon: Globe,
    placeholder: 'Enter username (e.g., johnproctor)',
    color: 'text-pink-400',
    baseUrl: 'https://dribbble.com/'
  },
  {
    key: 'deviantartUrl',
    name: 'DeviantArt',
    icon: Globe,
    placeholder: 'Enter username (e.g., johnproctor)',
    color: 'text-green-700',
    baseUrl: 'https://deviantart.com/'
  },
  {
    key: 'stackoverflowUrl',
    name: 'Stack Overflow',
    icon: Globe,
    placeholder: 'Enter profile number or username',
    color: 'text-orange-400',
    baseUrl: 'https://stackoverflow.com/users/'
  },
  {
    key: 'quoraUrl',
    name: 'Quora',
    icon: Globe,
    placeholder: 'Enter profile name (e.g., John-Proctor)',
    color: 'text-red-700',
    baseUrl: 'https://quora.com/profile/'
  },
  {
    key: 'personalWebsite',
    name: 'Personal Website',
    icon: Globe,
    placeholder: 'Enter full website URL (e.g., https://johnproctor.com)',
    color: 'text-gray-600'
  }
];

export function SocialMediaLinks({ userId, currentUser, socialLinks, isOwnProfile }: SocialMediaLinksProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [cardSize, setCardSize] = useState('medium'); // small, medium, large
  const [formData, setFormData] = useState(() => {
    // Try to restore from sessionStorage first, then fallback to socialLinks
    const savedData = sessionStorage.getItem(`socialLinks_${userId}`);
    if (savedData) {
      try {
        return JSON.parse(savedData);
      } catch (e) {
        console.error('Failed to parse saved social links:', e);
      }
    }
    
    return {
      facebookUrl: socialLinks?.facebookUrl || '',
      twitterUrl: socialLinks?.twitterUrl || '',
      whatsappUrl: socialLinks?.whatsappUrl || '',
      telegramUrl: socialLinks?.telegramUrl || '',
      instagramUrl: socialLinks?.instagramUrl || '',
      linkedinUrl: socialLinks?.linkedinUrl || '',
      youtubeUrl: socialLinks?.youtubeUrl || '',
      tiktokUrl: socialLinks?.tiktokUrl || '',
      snapchatUrl: socialLinks?.snapchatUrl || '',
      discordUrl: socialLinks?.discordUrl || '',
      redditUrl: socialLinks?.redditUrl || '',
      pinterestUrl: socialLinks?.pinterestUrl || '',
      tumblrUrl: socialLinks?.tumblrUrl || '',
      twitchUrl: socialLinks?.twitchUrl || '',
      spotifyUrl: socialLinks?.spotifyUrl || '',
      mediumUrl: socialLinks?.mediumUrl || '',
      githubUrl: socialLinks?.githubUrl || '',
      vimeoUrl: socialLinks?.vimeoUrl || '',
      skypeUrl: socialLinks?.skypeUrl || '',
      flickrUrl: socialLinks?.flickrUrl || '',
      soundcloudUrl: socialLinks?.soundcloudUrl || '',
      behanceUrl: socialLinks?.behanceUrl || '',
      dribbbleUrl: socialLinks?.dribbbleUrl || '',
      deviantartUrl: socialLinks?.deviantartUrl || '',
      stackoverflowUrl: socialLinks?.stackoverflowUrl || '',
      quoraUrl: socialLinks?.quoraUrl || '',
      personalWebsite: socialLinks?.personalWebsite || '',
    };
  });

  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [, setLocation] = useLocation();

  const updateSocialLinks = useMutation({
    mutationFn: async (data: typeof formData) => {
      const response = await fetch(`/api/users/${userId}/social-links`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(data),
      });
      if (!response.ok) {
        throw new Error('Failed to update social links');
      }
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Social Media Links Updated",
        description: "Your social media profiles have been saved successfully.",
      });
      setIsOpen(false);
      
      // Clear session storage after successful save
      sessionStorage.removeItem(`socialLinks_${userId}`);
      
      queryClient.invalidateQueries({ queryKey: [`/api/users/${userId}`] });
      queryClient.invalidateQueries({ queryKey: [`/api/profile-wall/${userId}`] });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to update social media links. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleInputChange = (key: string, value: string) => {
    const newData = {
      ...formData,
      [key]: value
    };
    setFormData(newData);
    
    // Auto-save to sessionStorage for persistence
    sessionStorage.setItem(`socialLinks_${userId}`, JSON.stringify(newData));
  };

  const convertUsernameToUrl = (platform: string, value: string): string => {
    if (!value.trim()) return '';
    
    // If already a full URL, return as is
    if (value.startsWith('http://') || value.startsWith('https://')) {
      return value;
    }
    
    // Convert username to full URL based on platform
    const platformConfig = socialPlatforms.find(p => p.key === platform);
    if (!platformConfig?.baseUrl) return value;
    
    // Clean username (remove @ symbols, spaces, etc.)
    const cleanUsername = value.replace(/[@\s]/g, '');
    
    switch (platform) {
      case 'personalWebsite':
        // For websites, add https:// if missing
        return value.startsWith('www.') ? `https://${value}` : 
               value.includes('.') ? (value.startsWith('http') ? value : `https://${value}`) : value;
      case 'whatsappUrl':
        // WhatsApp expects just the phone number
        return `${platformConfig.baseUrl}${cleanUsername}`;
      case 'youtubeUrl':
        // YouTube channels use @
        return `${platformConfig.baseUrl}${cleanUsername}`;
      case 'tiktokUrl':
        // TikTok uses @
        return `https://tiktok.com/@${cleanUsername}`;
      default:
        // Most platforms just append the username
        return `${platformConfig.baseUrl}${cleanUsername}`;
    }
  };

  const convertUsernameToUrl2 = (key: string, value: string) => {
    const platform = socialPlatforms.find(p => p.key === key);
    if (!platform || !platform.baseUrl) return value;
    
    if (value.startsWith('http')) return value;
    return platform.baseUrl + value;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Convert usernames to full URLs before saving
    const processedData = Object.keys(formData).reduce((acc, key) => {
      const typedKey = key as keyof typeof formData;
      acc[typedKey] = convertUsernameToUrl(key, formData[typedKey]);
      return acc;
    }, {} as typeof formData);
    
    updateSocialLinks.mutate(processedData);
  };

  const handleSocialClick = (platform: string, url?: string) => {
    console.log('handleSocialClick called with:', { platform, url });
    if (!url || url === '#' || url === '') {
      console.log('No valid URL provided for platform:', platform);
      return;
    }
    
    console.log('Opening URL:', url, 'for platform:', platform);
    try {
      window.open(url, '_blank', 'noopener,noreferrer');
    } catch (error) {
      console.error('Failed to open URL:', error);
    }
  };

  const handleCardResize = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    const sizes = ['small', 'medium', 'large'];
    const currentIndex = sizes.indexOf(cardSize);
    const nextIndex = (currentIndex + 1) % sizes.length;
    setCardSize(sizes[nextIndex]);
  };

  const getCardSizeClasses = () => {
    switch (cardSize) {
      case 'small':
        return 'grid-cols-1 sm:grid-cols-3 gap-1';
      case 'large':
        return 'grid-cols-1 gap-4';
      default: // medium
        return 'grid-cols-1 sm:grid-cols-2 gap-2';
    }
  };

  const getButtonSizeClasses = () => {
    switch (cardSize) {
      case 'small':
        return 'p-1.5 text-xs';
      case 'large':
        return 'p-4 text-base';
      default: // medium
        return 'p-2 text-xs';
    }
  };

  const getIconSizeClasses = () => {
    switch (cardSize) {
      case 'small':
        return 'w-3 h-3';
      case 'large':
        return 'w-6 h-6';
      default: // medium
        return 'w-4 h-4';
    }
  };

  const getDisplayedLinks = () => {
    return socialPlatforms.filter(platform => 
      socialLinks?.[platform.key] && socialLinks[platform.key]?.trim() !== ''
    );
  };

  const displayedLinks = getDisplayedLinks();

  return (
    <div className="bg-white rounded-lg shadow-sm p-3 protected-content w-full max-w-full overflow-hidden">
      <div className="flex items-center justify-between mb-3">
        <h3 className="text-sm font-semibold text-gray-900">Social Media</h3>
        {isOwnProfile && (
          <Dialog open={isOpen} onOpenChange={setIsOpen}>
            <DialogTrigger asChild>
              <Button variant="outline" size="sm" className="text-xs px-2 py-1 h-7">
                <Edit3 className="w-3 h-3 mr-1" />
                Edit
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle>Connect Your Social Media</DialogTitle>
                <p className="text-sm text-gray-600 mt-2">
                  Set up once - just enter your usernames and we'll handle the rest! 
                  Your links will appear on your profile for the community to connect with you.
                </p>
              </DialogHeader>
              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="bg-blue-50 p-4 rounded-lg border border-blue-200 mb-6">
                  <h4 className="font-medium text-blue-900 mb-2">Quick Setup Guide:</h4>
                  <div className="text-sm text-blue-800 space-y-2">
                    <p className="font-medium">What to enter in each box:</p>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-2 text-xs">
                      <div>• <strong>Facebook:</strong> alan.smith</div>
                      <div>• <strong>Twitter:</strong> alansmith</div>
                      <div>• <strong>Instagram:</strong> alansmith</div>
                      <div>• <strong>LinkedIn:</strong> alan-smith</div>
                      <div>• <strong>YouTube:</strong> alansmith</div>
                      <div>• <strong>WhatsApp:</strong> 447123456789</div>
                    </div>
                    <p className="mt-2 font-medium">We'll automatically create the full links for you!</p>
                  </div>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {socialPlatforms.map((platform) => {
                    const IconComponent = platform.icon;
                    return (
                      <div key={platform.key} className="space-y-2">
                        <Label htmlFor={platform.key} className="flex items-center gap-2">
                          <IconComponent className={`w-4 h-4 ${platform.color}`} />
                          {platform.name}
                        </Label>
                        <Input
                          id={platform.key}
                          type={platform.key === 'personalWebsite' ? 'url' : 'text'}
                          placeholder={platform.placeholder}
                          value={formData[platform.key]}
                          onChange={(e) => handleInputChange(platform.key, e.target.value)}
                          className="w-full"
                        />
                        <div className="text-xs text-gray-600 space-y-1">
                          {platform.key === 'facebookUrl' && (
                            <div>
                              <p><strong>What to enter:</strong> alan.smith</p>
                              <p><strong>From URL:</strong> facebook.com/<span className="bg-yellow-100">alan.smith</span></p>
                            </div>
                          )}
                          {platform.key === 'twitterUrl' && (
                            <div>
                              <p><strong>What to enter:</strong> alansmith</p>
                              <p><strong>From URL:</strong> twitter.com/<span className="bg-yellow-100">alansmith</span></p>
                            </div>
                          )}
                          {platform.key === 'instagramUrl' && (
                            <div>
                              <p><strong>What to enter:</strong> alansmith</p>
                              <p><strong>From URL:</strong> instagram.com/<span className="bg-yellow-100">alansmith</span></p>
                            </div>
                          )}
                          {platform.key === 'linkedinUrl' && (
                            <div>
                              <p><strong>What to enter:</strong> alan-smith</p>
                              <p><strong>From URL:</strong> linkedin.com/in/<span className="bg-yellow-100">alan-smith</span></p>
                            </div>
                          )}
                          {platform.key === 'youtubeUrl' && (
                            <div>
                              <p><strong>What to enter:</strong> alansmith</p>
                              <p><strong>From URL:</strong> youtube.com/@<span className="bg-yellow-100">alansmith</span></p>
                            </div>
                          )}
                          {platform.key === 'whatsappUrl' && (
                            <div>
                              <p><strong>What to enter:</strong> 447123456789</p>
                              <p><strong>Format:</strong> Country code + phone number</p>
                            </div>
                          )}
                          {platform.key === 'telegramUrl' && (
                            <div>
                              <p><strong>What to enter:</strong> alansmith</p>
                              <p><strong>From URL:</strong> t.me/<span className="bg-yellow-100">alansmith</span></p>
                            </div>
                          )}
                          {platform.key === 'tiktokUrl' && (
                            <div>
                              <p><strong>What to enter:</strong> alansmith</p>
                              <p><strong>From URL:</strong> tiktok.com/@<span className="bg-yellow-100">alansmith</span></p>
                            </div>
                          )}
                          {platform.key === 'personalWebsite' && (
                            <div>
                              <p><strong>What to enter:</strong> alansmith.com</p>
                              <p><strong>Or full URL:</strong> https://alansmith.com</p>
                            </div>
                          )}
                        </div>
                        {formData[platform.key] && !formData[platform.key].startsWith('http') && platform.baseUrl && (
                          <div className="text-xs text-green-600 bg-green-50 p-2 rounded border border-green-200 mt-1">
                            <strong>✓ Will create link:</strong> {convertUsernameToUrl(platform.key, formData[platform.key])}
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
                <div className="flex justify-end gap-3">
                  <Button type="button" variant="outline" onClick={() => setIsOpen(false)}>
                    Cancel
                  </Button>
                  <Button type="submit" disabled={updateSocialLinks.isPending}>
                    {updateSocialLinks.isPending ? 'Saving...' : 'Save Changes'}
                  </Button>
                </div>
              </form>
            </DialogContent>
          </Dialog>
        )}
      </div>

      {displayedLinks.length > 0 ? (
        <div>
          {isOwnProfile && (
            <div className="mb-2 flex justify-end">
              <button
                onClick={handleCardResize}
                className="text-xs text-gray-500 hover:text-gray-700 px-2 py-1 rounded border border-gray-300 hover:border-gray-400 transition-colors"
              >
                Resize Cards ({cardSize})
              </button>
            </div>
          )}
          <div className={`grid ${getCardSizeClasses()} w-full max-w-full`}>
            {displayedLinks.map((platform) => {
              const IconComponent = platform.icon;
              const rawUrl = socialLinks?.[platform.key];
              const fullUrl = convertUsernameToUrl(platform.key, rawUrl || '');
              
              return (
                <button
                  key={platform.key}
                  onClick={(e) => {
                    e.preventDefault();
                    e.stopPropagation();
                    console.log('Green button clicked for:', platform.key, 'URL:', fullUrl);
                    
                    let targetUrl = '';
                    if (fullUrl && fullUrl !== '#' && fullUrl.trim() !== '') {
                      // Use the actual URL provided
                      targetUrl = fullUrl.startsWith('http') ? fullUrl : `https://${fullUrl}`;
                    } else {
                      // Fallback to platform homepage
                      targetUrl = `https://${platform.key}.com`;
                    }
                    
                    console.log('Opening URL:', targetUrl);
                    try {
                      const newWindow = window.open(targetUrl, '_blank', 'noopener,noreferrer');
                      if (!newWindow) {
                        console.error('Popup blocked - trying direct navigation');
                        window.location.href = targetUrl;
                      }
                    } catch (error) {
                      console.error('Failed to open URL:', error);
                      window.location.href = targetUrl;
                    }
                  }}
                  className={`flex items-center gap-2 ${getButtonSizeClasses()} rounded-lg border-2 border-green-500 bg-green-50 hover:border-green-600 hover:bg-green-100 hover:shadow-md transition-all group w-full text-left cursor-pointer active:bg-green-200 active:scale-95`}
                >
                  <IconComponent className={`${getIconSizeClasses()} ${platform.color} group-hover:scale-110 transition-transform flex-shrink-0`} />
                  <span className={`${cardSize === 'small' ? 'text-xs' : cardSize === 'large' ? 'text-sm' : 'text-xs'} font-medium text-green-700 group-hover:text-green-900 truncate`}>
                    {platform.name}
                  </span>
                  <Globe className={`${cardSize === 'small' ? 'w-2 h-2' : cardSize === 'large' ? 'w-4 h-4' : 'w-3 h-3'} text-gray-400 ml-auto opacity-0 group-hover:opacity-100 transition-opacity flex-shrink-0`} />
                </button>
              );
            })}
          </div>
        </div>
      ) : (
        <div className="text-center py-8 text-gray-500">
          <Globe className="w-12 h-12 mx-auto mb-3 text-gray-300" />
          <p className="text-sm">
            {isOwnProfile 
              ? "Add your social media links to connect with the community" 
              : "No social media links shared yet"
            }
          </p>
          {isOwnProfile && (
            <Button 
              variant="outline" 
              size="sm" 
              className="mt-3"
              onClick={() => setIsOpen(true)}
            >
              Add Social Links
            </Button>
          )}
        </div>
      )}
    </div>
  );
}