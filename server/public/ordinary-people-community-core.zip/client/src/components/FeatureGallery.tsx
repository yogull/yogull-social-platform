import { useState, useEffect } from "react";
import { Link } from "wouter";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useTranslation } from "@/hooks/useTranslation";
import { 
  Users, 
  MessageCircle, 
  ShoppingBag, 
  Activity, 
  User, 
  BookOpen, 
  Pill,
  Heart,
  ArrowRight,
  MapPin
} from "lucide-react";

interface FeatureCard {
  id: string;
  title: string;
  description: string;
  href: string;
  icon: React.ReactNode;
  gradient: string;
  badge?: string;
  color: string;
}

const features: FeatureCard[] = [
  {
    id: "profile-wall",
    title: "Profile Wall",
    description: "Your personal social space and connections",
    href: "/profile-wall/4",
    icon: <User className="w-8 h-8" />,
    gradient: "from-pink-500 to-purple-600",
    badge: "Social",
    color: "text-pink-600"
  },
  {
    id: "social",
    title: "Social Network",
    description: "Connect with others on your health journey",
    href: "/social",
    icon: <Users className="w-8 h-8" />,
    gradient: "from-blue-500 to-purple-600",
    badge: "Connect",
    color: "text-blue-600"
  },
  {
    id: "community",
    title: "Community Discussions",
    description: "Join conversations about health topics",
    href: "/community",
    icon: <MessageCircle className="w-8 h-8" />,
    gradient: "from-green-500 to-teal-600",
    badge: "Discuss",
    color: "text-green-600"
  },
  {
    id: "chat",
    title: "Chat & AI",
    description: "Direct messaging with AI health guidance",
    href: "/chat",
    icon: <MessageCircle className="w-8 h-8" />,
    gradient: "from-blue-500 to-purple-600",
    badge: "AI Chat",
    color: "text-blue-600"
  },
  {
    id: "location-ads",
    title: "Find Local Businesses",
    description: "Search businesses in your area - perfect for travelers",
    href: "/location-ads",
    icon: <MapPin className="w-8 h-8" />,
    gradient: "from-emerald-500 to-green-600",
    badge: "Local",
    color: "text-emerald-600"
  },
  {
    id: "shop",
    title: "Supplement Shop",
    description: "Discover quality supplements and products",
    href: "/shop",
    icon: <ShoppingBag className="w-8 h-8" />,
    gradient: "from-orange-500 to-yellow-600",
    badge: "Shop",
    color: "text-orange-600"
  },
  {
    id: "biometrics",
    title: "Health Tracking",
    description: "Monitor your vital signs and wellness metrics",
    href: "/biometrics",
    icon: <Activity className="w-8 h-8" />,
    gradient: "from-blue-500 to-cyan-600",
    badge: "Track",
    color: "text-blue-600"
  },
  {
    id: "supplements",
    title: "Supplement Diary",
    description: "Log and track your daily supplements",
    href: "/supplements",
    icon: <Pill className="w-8 h-8" />,
    gradient: "from-indigo-500 to-blue-600",
    badge: "Log",
    color: "text-indigo-600"
  },
  {
    id: "illness-guides",
    title: "Health Guides",
    description: "Learn about conditions and treatments",
    href: "/illness-guides",
    icon: <BookOpen className="w-8 h-8" />,
    gradient: "from-purple-500 to-blue-600",
    badge: "Learn",
    color: "text-purple-600"
  },
  {
    id: "profile",
    title: "Your Profile",
    description: "Manage your account and preferences",
    href: "/profile",
    icon: <User className="w-8 h-8" />,
    gradient: "from-teal-500 to-cyan-600",
    badge: "Settings",
    color: "text-teal-600"
  },
  {
    id: "blog",
    title: "Health Blog",
    description: "Share your health journey and insights",
    href: "/blog",
    icon: <Heart className="w-8 h-8" />,
    gradient: "from-green-500 to-emerald-600",
    badge: "Share",
    color: "text-green-600"
  }
];

export function FeatureGallery() {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isHovered, setIsHovered] = useState(false);
  const { t } = useTranslation();

  // Auto-rotate every 3 seconds when not hovered
  useEffect(() => {
    if (!isHovered) {
      const interval = setInterval(() => {
        setCurrentIndex((prev) => (prev + 1) % features.length);
      }, 3000);
      return () => clearInterval(interval);
    }
  }, [isHovered]);

  // Get visible features (current + next 2)
  const getVisibleFeatures = () => {
    const visible = [];
    for (let i = 0; i < 3; i++) {
      const index = (currentIndex + i) % features.length;
      visible.push(features[index]);
    }
    return visible;
  };

  const visibleFeatures = getVisibleFeatures();

  return (
    <div className="w-full">
      <div className="text-center mb-6">
        <h2 className="text-2xl font-bold text-gray-900 mb-2">
          {t('dashboard.features')}
        </h2>
        <p className="text-gray-600">
          {t('dashboard.subtitle')}
        </p>
      </div>

      <div 
        className="relative overflow-hidden"
        onMouseEnter={() => setIsHovered(true)}
        onMouseLeave={() => setIsHovered(false)}
      >
        {/* Main Gallery */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6 max-w-full">
          {visibleFeatures.map((feature, index) => (
            <Link key={feature.id} href={feature.href}>
              <Card 
                className={`
                  group cursor-pointer transition-all duration-500 hover:scale-105 hover:shadow-xl
                  ${index === 0 ? 'md:scale-110 ring-2 ring-blue-200' : ''}
                  transform-gpu
                `}
              >
                <CardContent className="p-4 md:p-6">
                  {/* Gradient Background */}
                  <div className={`
                    absolute inset-0 bg-gradient-to-br ${feature.gradient} opacity-5 
                    group-hover:opacity-10 transition-opacity duration-300
                  `} />
                  
                  {/* Badge */}
                  {feature.badge && (
                    <div className="flex justify-end mb-2">
                      <Badge 
                        variant="secondary" 
                        className={`${feature.color} bg-opacity-10 text-xs font-medium`}
                      >
                        {feature.badge}
                      </Badge>
                    </div>
                  )}

                  {/* Icon */}
                  <div className={`
                    w-16 h-16 rounded-xl bg-gradient-to-br ${feature.gradient} 
                    flex items-center justify-center text-white mb-4 mx-auto
                    group-hover:scale-110 transition-transform duration-300
                  `}>
                    {feature.icon}
                  </div>

                  {/* Content */}
                  <div className="text-center">
                    <h3 className="font-semibold text-base text-gray-900 mb-1 group-hover:text-blue-600 transition-colors">
                      {feature.title}
                    </h3>
                    <p className="text-xs text-gray-600 mb-3 leading-relaxed">
                      {feature.description}
                    </p>
                    
                    {/* CTA */}
                    <div className="flex items-center justify-center space-x-1 text-blue-600 group-hover:text-blue-700 transition-colors">
                      <span className="text-xs font-medium">Explore</span>
                      <ArrowRight className="w-3 h-3 group-hover:translate-x-1 transition-transform" />
                    </div>
                  </div>
                </CardContent>
              </Card>
            </Link>
          ))}
        </div>

        {/* Navigation Dots */}
        <div className="flex justify-center space-x-2">
          {features.map((_, index) => (
            <button
              key={index}
              onClick={() => setCurrentIndex(index)}
              className={`
                w-2 h-2 rounded-full transition-all duration-300
                ${index === currentIndex ? 'bg-blue-600 w-6' : 'bg-gray-300 hover:bg-gray-400'}
              `}
            />
          ))}
        </div>
      </div>

      {/* Quick Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-8">
        <div className="text-center p-4 bg-blue-50 rounded-lg">
          <div className="text-2xl font-bold text-blue-600">9</div>
          <div className="text-sm text-gray-600">Features</div>
        </div>
        <div className="text-center p-4 bg-green-50 rounded-lg">
          <div className="text-2xl font-bold text-green-600">∞</div>
          <div className="text-sm text-gray-600">Possibilities</div>
        </div>
        <div className="text-center p-4 bg-purple-50 rounded-lg">
          <div className="text-2xl font-bold text-purple-600">24/7</div>
          <div className="text-sm text-gray-600">Available</div>
        </div>
        <div className="text-center p-4 bg-orange-50 rounded-lg">
          <div className="text-2xl font-bold text-orange-600">Free</div>
          <div className="text-sm text-gray-600">Platform</div>
        </div>
      </div>
    </div>
  );
}