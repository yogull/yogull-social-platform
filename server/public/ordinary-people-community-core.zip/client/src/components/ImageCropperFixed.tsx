import { useState, useRef, useCallback } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { useToast } from '@/hooks/use-toast';

interface ImageCropperProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onImageCropped: (croppedImage: string) => void;
  aspectRatio?: number;
  title?: string;
}

export default function ImageCropperFixed({
  open,
  onOpenChange,
  onImageCropped,
  aspectRatio = 1,
  title = "Crop Profile Picture"
}: ImageCropperProps) {
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const [cropPosition, setCropPosition] = useState({ x: 50, y: 50 });
  const [isDragging, setIsDragging] = useState(false);
  const [dragStart, setDragStart] = useState({ x: 0, y: 0 });
  const [isLoading, setIsLoading] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const imageRef = useRef<HTMLImageElement>(null);
  const { toast } = useToast();
  
  const cropSize = { width: 200, height: 200 };

  const handleFileSelect = useCallback((event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      // Validate file type
      if (!file.type.startsWith('image/')) {
        toast({ title: "Error", description: "Please select an image file" });
        return;
      }
      
      // Validate file size (max 5MB)
      if (file.size > 5 * 1024 * 1024) {
        toast({ title: "Error", description: "Image must be smaller than 5MB" });
        return;
      }

      setIsLoading(true);
      const reader = new FileReader();
      
      reader.onload = (e) => {
        try {
          const result = e.target?.result as string;
          console.log('Image loaded, result length:', result?.length);
          if (result && result.startsWith('data:image/')) {
            console.log('Setting selected image');
            setSelectedImage(result);
            setCropPosition({ x: 50, y: 50 });
            setIsDragging(false);
            console.log('Image state updated');
          } else {
            console.error('Invalid image data:', result?.substring(0, 50));
            toast({ title: "Error", description: "Invalid image format" });
          }
        } catch (error) {
          console.error('Error loading image:', error);
          toast({ title: "Error", description: "Failed to load image" });
        } finally {
          setIsLoading(false);
        }
      };
      
      reader.onerror = () => {
        setIsLoading(false);
        toast({ title: "Error", description: "Failed to read file" });
      };
      
      reader.readAsDataURL(file);
    }
    
    // Clear the input value to allow selecting the same file again
    event.target.value = '';
  }, [toast]);

  const handlePointerDown = useCallback((e: React.PointerEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(true);
    
    const rect = imageRef.current?.getBoundingClientRect();
    if (!rect) return;
    
    setDragStart({
      x: e.clientX - cropPosition.x,
      y: e.clientY - cropPosition.y
    });
  }, [cropPosition]);

  const handlePointerMove = useCallback((e: React.PointerEvent) => {
    if (!isDragging || !imageRef.current) return;
    e.preventDefault();
    e.stopPropagation();

    const rect = imageRef.current.getBoundingClientRect();
    const newX = e.clientX - dragStart.x;
    const newY = e.clientY - dragStart.y;
    
    // Constrain to image boundaries
    const maxX = rect.width - cropSize.width;
    const maxY = rect.height - cropSize.height;
    
    setCropPosition({
      x: Math.max(0, Math.min(maxX, newX)),
      y: Math.max(0, Math.min(maxY, newY))
    });
  }, [isDragging, dragStart, cropSize]);

  const handlePointerUp = useCallback((e: React.PointerEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);
  }, []);

  const handleCrop = useCallback(() => {
    if (!selectedImage || !canvasRef.current || !imageRef.current) {
      toast({ title: "Error", description: "Please select an image first" });
      return;
    }

    setIsProcessing(true);
    
    try {
      const canvas = canvasRef.current;
      const ctx = canvas.getContext('2d');
      if (!ctx) {
        toast({ title: "Error", description: "Canvas not supported" });
        setIsProcessing(false);
        return;
      }

      const img = new Image();
      img.onload = () => {
        try {
          // Calculate scale factors
          const rect = imageRef.current!.getBoundingClientRect();
          const scaleX = img.width / rect.width;
          const scaleY = img.height / rect.height;

          // Set canvas size
          canvas.width = cropSize.width * scaleX;
          canvas.height = cropSize.height * scaleY;

          // Clear canvas first
          ctx.clearRect(0, 0, canvas.width, canvas.height);

          // Draw cropped image
          ctx.drawImage(
            img,
            cropPosition.x * scaleX,
            cropPosition.y * scaleY,
            cropSize.width * scaleX,
            cropSize.height * scaleY,
            0,
            0,
            canvas.width,
            canvas.height
          );

          // Convert to base64
          const croppedImage = canvas.toDataURL('image/jpeg', 0.9);
          onImageCropped(croppedImage);
          
          // Reset state and close modal
          setSelectedImage(null);
          setCropPosition({ x: 50, y: 50 });
          setIsDragging(false);
          setIsProcessing(false);
          onOpenChange(false);
          
          toast({ title: "Success", description: "Image cropped successfully!" });
        } catch (error) {
          console.error('Error during crop:', error);
          setIsProcessing(false);
          toast({ title: "Error", description: "Failed to crop image" });
        }
      };
      
      img.onerror = () => {
        setIsProcessing(false);
        toast({ title: "Error", description: "Failed to load image for cropping" });
      };
      
      img.src = selectedImage;
    } catch (error) {
      console.error('Error in handleCrop:', error);
      setIsProcessing(false);
      toast({ title: "Error", description: "Cropping failed" });
    }
  }, [selectedImage, cropPosition, cropSize, onImageCropped, onOpenChange, toast]);

  const triggerFileSelect = useCallback(() => {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = 'image/*';
    input.onchange = handleFileSelect as any;
    input.click();
  }, [handleFileSelect]);

  const handleDialogClose = useCallback((isOpen: boolean) => {
    if (!isOpen) {
      // Reset state when closing
      setSelectedImage(null);
      setCropPosition({ x: 50, y: 50 });
      setIsDragging(false);
    }
    onOpenChange(isOpen);
  }, [onOpenChange]);

  return (
    <Dialog open={open} onOpenChange={handleDialogClose}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-auto">
        <DialogHeader>
          <DialogTitle>{title}</DialogTitle>
        </DialogHeader>
        
        <div className="space-y-4">
          {!selectedImage && !isLoading && (
            <div className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center">
              <Button onClick={triggerFileSelect} className="mb-4 bg-blue-600 hover:bg-blue-700">
                Select Image
              </Button>
              <p className="text-gray-500">Choose an image to crop</p>
            </div>
          )}

          {isLoading && (
            <div className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto mb-4"></div>
              <p className="text-gray-500">Loading image...</p>
            </div>
          )}

          {selectedImage && (
            <div className="space-y-4">
              <p className="text-sm text-green-600">Image loaded successfully! Drag the blue box to crop.</p>
              <div 
                className="relative border border-gray-300 inline-block max-w-full touch-none select-none"
                onPointerMove={handlePointerMove}
                onPointerUp={handlePointerUp}
                onPointerLeave={handlePointerUp}
                style={{ touchAction: 'none' }}
              >
                <img
                  ref={imageRef}
                  src={selectedImage}
                  alt="Image to crop"
                  className="max-w-full max-h-96 block"
                  draggable={false}
                />
                
                {/* Crop overlay */}
                <div
                  className="absolute border-2 border-blue-500 bg-blue-500 bg-opacity-20 cursor-move touch-none select-none"
                  style={{
                    left: Math.max(0, cropPosition.x),
                    top: Math.max(0, cropPosition.y),
                    width: cropSize.width,
                    height: cropSize.height,
                    touchAction: 'none'
                  }}
                  onPointerDown={handlePointerDown}
                >
                  <div className="absolute inset-0 border border-white border-opacity-50" />
                  <div className="absolute top-1 left-1 bg-white text-black text-xs px-1 rounded opacity-75">
                    Drag to position
                  </div>
                  <div className="absolute bottom-1 right-1 bg-blue-600 text-white text-xs px-1 rounded opacity-75">
                    {cropSize.width}×{cropSize.height}
                  </div>
                </div>
              </div>

              <div className="flex flex-wrap gap-2">
                <Button 
                  onClick={handleCrop} 
                  disabled={isProcessing}
                  className="bg-green-600 hover:bg-green-700 disabled:bg-gray-400"
                >
                  {isProcessing ? (
                    <>
                      <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                      Processing...
                    </>
                  ) : (
                    'Crop & Save'
                  )}
                </Button>
                <Button 
                  variant="outline" 
                  onClick={triggerFileSelect}
                  disabled={isProcessing}
                >
                  Select Different Image
                </Button>
                <Button 
                  variant="outline" 
                  onClick={() => onOpenChange(false)}
                  disabled={isProcessing}
                >
                  Cancel
                </Button>
              </div>
            </div>
          )}
        </div>

        <canvas ref={canvasRef} className="hidden" />
      </DialogContent>
    </Dialog>
  );
}