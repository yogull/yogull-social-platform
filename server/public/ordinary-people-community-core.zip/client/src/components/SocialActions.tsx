import { useState } from 'react';
import { Heart, Share2, MessageCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/hooks/use-toast';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';

interface SocialActionsProps {
  itemId: number;
  itemType: 'blog' | 'product' | 'image' | 'discussion';
  initialLikes?: number;
  initialComments?: number;
  isLiked?: boolean;
  showComments?: boolean;
  compact?: boolean;
}

export default function SocialActions({
  itemId,
  itemType,
  initialLikes = 0,
  initialComments = 0,
  isLiked = false,
  showComments = true,
  compact = false
}: SocialActionsProps) {
  const [liked, setLiked] = useState(isLiked);
  const [likeCount, setLikeCount] = useState(initialLikes);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const likeMutation = useMutation({
    mutationFn: async () => {
      if (liked) {
        return apiRequest('DELETE', `/api/${itemType}s/${itemId}/like`);
      } else {
        return apiRequest('POST', `/api/${itemType}s/${itemId}/like`);
      }
    },
    onSuccess: () => {
      setLiked(!liked);
      setLikeCount(prev => liked ? prev - 1 : prev + 1);
      // Invalidate multiple query keys to ensure updates
      queryClient.invalidateQueries({ queryKey: [`/api/${itemType}s`] });
      queryClient.invalidateQueries({ queryKey: ['/api/profile-wall'] });
      queryClient.invalidateQueries({ queryKey: ['/api/community-discussions'] });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to update like status",
        variant: "destructive"
      });
    }
  });

  const handleLike = () => {
    likeMutation.mutate();
  };

  const handleShare = async () => {
    const shareData = {
      title: `Check out this ${itemType} on GoHealMe`,
      text: `Found something interesting on GoHealMe - The People's Health Community`,
      url: window.location.href
    };

    try {
      if (navigator.share && navigator.canShare && navigator.canShare(shareData)) {
        await navigator.share(shareData);
      } else {
        // Fallback to clipboard
        await navigator.clipboard.writeText(window.location.href);
        toast({
          title: "Link Copied",
          description: "Share link copied to clipboard"
        });
      }
    } catch (error) {
      // Fallback for older browsers
      const textArea = document.createElement('textarea');
      textArea.value = window.location.href;
      document.body.appendChild(textArea);
      textArea.select();
      document.execCommand('copy');
      document.body.removeChild(textArea);
      
      toast({
        title: "Link Copied",
        description: "Share link copied to clipboard"
      });
    }
  };

  if (compact) {
    return (
      <div className="flex items-center gap-2 text-sm">
        <Button
          variant="ghost"
          size="sm"
          onClick={handleLike}
          disabled={likeMutation.isPending}
          className={`p-1 h-auto ${liked ? 'text-red-500' : 'text-muted-foreground'}`}
        >
          <Heart className={`w-4 h-4 ${liked ? 'fill-current' : ''}`} />
          <span className="ml-1">{likeCount}</span>
        </Button>
        
        {showComments && (
          <span className="flex items-center gap-1 text-muted-foreground">
            <MessageCircle className="w-4 h-4" />
            {initialComments}
          </span>
        )}
        
        <Button
          variant="ghost"
          size="sm"
          onClick={handleShare}
          className="p-1 h-auto text-muted-foreground"
        >
          <Share2 className="w-4 h-4" />
        </Button>
      </div>
    );
  }

  return (
    <div className="flex items-center gap-4 py-3 border-t">
      <Button
        variant="ghost"
        onClick={handleLike}
        disabled={likeMutation.isPending}
        className={`flex items-center gap-2 ${liked ? 'text-red-500' : 'text-muted-foreground'}`}
      >
        <Heart className={`w-5 h-5 ${liked ? 'fill-current' : ''}`} />
        <span className="font-medium">{likeCount}</span>
        <span>Like{likeCount !== 1 ? 's' : ''}</span>
      </Button>

      {showComments && (
        <div className="flex items-center gap-2 text-muted-foreground">
          <MessageCircle className="w-5 h-5" />
          <span className="font-medium">{initialComments}</span>
          <span>Comment{initialComments !== 1 ? 's' : ''}</span>
        </div>
      )}

      <Button
        variant="ghost"
        onClick={handleShare}
        className="flex items-center gap-2 text-muted-foreground ml-auto"
      >
        <Share2 className="w-5 h-5" />
        <span>Share</span>
      </Button>
    </div>
  );
}