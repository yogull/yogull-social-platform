import { useState, useEffect } from "react";
import { User } from "@shared/schema";
import { signOut } from "@/lib/auth";
import { useLocation } from "wouter";
import { LanguageSelector } from "./LanguageSelector";
import { ShareButton } from "@/components/ShareButton";
import { useTranslation } from "@/hooks/useTranslation";
import { BarChart3, Pill, ShoppingCart, User as UserIcon, Menu, X, MessageCircle, Bot, LogOut, Phone, Video, MapPin } from "lucide-react";
import NotificationCenter from "@/components/NotificationCenter";

interface MobileNavProps {
  user: User;
}

export function MobileNav({ user }: MobileNavProps) {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [location, setLocation] = useLocation();
  const { t } = useTranslation();

  const toggleMenu = () => setIsMenuOpen(!isMenuOpen);

  // Direct DOM manipulation to bypass React conflicts
  useEffect(() => {
    const hamburgerBtn = document.getElementById('hamburger-menu-btn');
    const handleHamburgerClick = (e: Event) => {
      e.preventDefault();
      e.stopPropagation();
      const currentState = !isMenuOpen;
      setIsMenuOpen(currentState);
      console.log('DOM Hamburger clicked, menu open:', currentState);
    };

    if (hamburgerBtn) {
      hamburgerBtn.addEventListener('click', handleHamburgerClick);
      console.log('✅ Direct DOM event listener added to hamburger menu');
    }

    return () => {
      if (hamburgerBtn) {
        hamburgerBtn.removeEventListener('click', handleHamburgerClick);
      }
    };
  }, [isMenuOpen]);

  const handleSignOut = async () => {
    try {
      await signOut();
      localStorage.clear();
      sessionStorage.clear();
      window.location.href = "/login";
    } catch (error) {
      console.error("Sign out failed:", error);
      window.location.href = "/login";
    }
  };

  const baseNavItems = [
    { href: "/profile", icon: "fas fa-user-cog", label: t('nav.profileSettings'), active: location === "/profile" },
    { href: "/profile-wall", icon: "fas fa-user", label: "Profile Wall", active: location === "/profile-wall" },
    { href: "/", icon: "fas fa-chart-line", label: t('nav.dashboard'), active: location === "/" },
    { href: "/personal-shop", icon: "fas fa-store", label: "My Personal Shop", active: location === "/personal-shop" },
    { href: "/personal-shop-search", icon: "fas fa-search", label: "Search Personal Shops", active: location === "/personal-shop-search" },
    { href: "/health-hub", icon: "fas fa-heartbeat", label: "Health", active: location.includes("/supplements") || location.includes("/daily-log") || location.includes("/biometrics") || location.includes("/illness-guides") || location === "/health-hub" },
    { href: "/business-directory", icon: "fas fa-building", label: "Business Directory", active: location === "/business-directory" },
    { href: "/business-profile", icon: "fas fa-building", label: "Business Profile", active: location === "/business-profile" },
    { href: "/location-ads", icon: "fas fa-map-marker-alt", label: "Find Local Businesses", active: location === "/location-ads" },
    { href: "/daily-news", icon: "fas fa-newspaper", label: "Daily News", active: location === "/daily-news" },
    { href: "/social", icon: "fas fa-users", label: t('nav.social'), active: location === "/social" },
    { href: "/community", icon: "fas fa-comments", label: "Community Blog", active: location === "/community" },
    { href: "/shop", icon: "fas fa-shopping-cart", label: t('nav.shop'), active: location === "/shop" },
    { href: "/about", icon: "fas fa-info-circle", label: "About Us", active: location === "/about" },
    { href: "/contact", icon: "fas fa-envelope", label: t('nav.contact'), active: location === "/contact" },
  ];

  const navItems = user.isAdmin 
    ? [
        { href: "/profile", icon: "fas fa-user-cog", label: t('nav.profileSettings'), active: location === "/profile" },
        { href: "/profile-wall", icon: "fas fa-user", label: "Profile Wall", active: location === "/profile-wall" },
        { href: "/business-profile", icon: "fas fa-building", label: "Business Profile", active: location === "/business-profile" },
        { href: "/", icon: "fas fa-chart-line", label: t('nav.dashboard'), active: location === "/" },
        { href: "/personal-shop", icon: "fas fa-store", label: "My Personal Shop", active: location === "/personal-shop" },
        { href: "/personal-shop-search", icon: "fas fa-search", label: "Search Personal Shops", active: location === "/personal-shop-search" },
        { href: "/health-hub", icon: "fas fa-heartbeat", label: "Health", active: location.includes("/supplements") || location.includes("/daily-log") || location.includes("/biometrics") || location.includes("/illness-guides") || location === "/health-hub" },
        { href: "/business-directory", icon: "fas fa-building", label: "Business Directory", active: location === "/business-directory" },
        { href: "/location-ads", icon: "fas fa-map-marker-alt", label: "Find Local Businesses", active: location === "/location-ads" },
        { href: "/daily-news", icon: "fas fa-newspaper", label: "Daily News", active: location === "/daily-news" },
        { href: "/social", icon: "fas fa-users", label: t('nav.social'), active: location === "/social" },
        { href: "/community", icon: "fas fa-comments", label: "Community Blog", active: location === "/community" },
        { href: "/shop", icon: "fas fa-shopping-cart", label: t('nav.shop'), active: location === "/shop" },
        { href: "/admin-dashboard", icon: "fas fa-shield-alt", label: "Admin Dashboard", active: location === "/admin-dashboard" || location === "/super-admin" || location === "/admin" },
        { href: "/about", icon: "fas fa-info-circle", label: "About Us", active: location === "/about" },
        { href: "/contact", icon: "fas fa-envelope", label: t('nav.contact'), active: location === "/contact" },
      ]
    : baseNavItems;

  const bottomNavItems = [
    { href: "/", icon: BarChart3, label: t('nav.dashboard') },
    { href: "/health-hub", icon: Pill, label: "Health" },
    { href: "/shop", icon: ShoppingCart, label: t('nav.shop') },
    { href: "/profile", icon: UserIcon, label: t('nav.profile') },
  ];

  return (
    <>
      {/* Top Mobile Navigation */}
      <nav className="lg:hidden bg-white shadow-sm border-b border-gray-200 sticky top-0 z-50">
        {/* Main Header Row */}
        <div className="px-2 py-2 flex items-center justify-between">
          <div className="flex items-center space-x-1 flex-1 min-w-0 -ml-6">
            <div className="w-8 h-8 rounded-lg bg-primary flex items-center justify-center flex-shrink-0">
              <span className="text-white font-bold text-sm">O</span>
            </div>
            <div className="flex flex-col min-w-0 flex-shrink">
              <span className="font-semibold text-xs text-primary-dark truncate">Ordinary People</span>
              <span className="text-xs text-primary font-medium truncate">Community</span>
            </div>
          </div>
          <div className="flex items-center space-x-1 flex-shrink-0">
            <button 
              id="hamburger-menu-btn"
              className="w-12 h-12 rounded-lg text-white bg-gray-900 hover:bg-black border-2 border-gray-900 shadow-lg transition-all duration-200 relative z-50 flex items-center justify-center"
              aria-label="Open menu"
            >
              <Menu className="w-6 h-6 stroke-2" />
            </button>
          </div>
        </div>
        
        {/* Secondary Button Row */}
        <div className="px-2 pb-2 flex items-center justify-between border-t border-gray-100 pt-2">
          <div className="flex items-center space-x-1">
            <LanguageSelector variant="compact" />
            <NotificationCenter user={user} />
            
            <a 
              href="/location-ads"
              className="w-12 h-12 rounded bg-emerald-600 hover:bg-emerald-700 text-white transition-colors text-xs font-medium flex flex-col items-center justify-center leading-tight"
              title="Find Local Businesses"
            >
              <span>Local</span>
              <span>Biz</span>
            </a>
            <a 
              href="/chat"
              className="flex items-center px-2 py-1 rounded bg-primary hover:bg-primary/90 text-white transition-colors text-xs"
              title="Chat"
            >
              <MessageCircle className="w-3 h-3" />
            </a>
            <a 
              href="/chat?ai=true"
              className="flex items-center px-2 py-1 rounded bg-blue-900 hover:bg-blue-800 text-white transition-colors text-xs"
              title="Ask AI"
            >
              <Bot className="w-3 h-3" />
            </a>
          </div>
          
          {/* Sign Out Button - Compact */}
          <button 
            onClick={handleSignOut}
            className="flex items-center px-2 py-1 rounded bg-red-600 hover:bg-red-700 text-white transition-colors text-xs font-medium"
            title="Sign Out"
          >
            <LogOut className="w-3 h-3 mr-1" />
            Out
          </button>
        </div>
        
        {/* Profile Wall Button - Above Share Community */}
        <div className="px-4 py-2 border-t border-gray-100">
          <a
            href={user?.id ? `/profile-wall/${user.id}` : "/profile-wall"}
            className="w-full flex items-center justify-center gap-2 px-4 py-3 bg-purple-600 hover:bg-purple-700 text-white rounded-lg font-medium transition-colors no-underline"
          >
            <UserIcon className="w-4 h-4" />
            My Profile Wall
          </a>
        </div>

        {/* Large Share Button for Mobile */}
        <div className="px-4 py-2 border-t border-gray-100">
          <ShareButton className="w-full" />
        </div>
        
        {/* WhatsApp and Messenger Communication Buttons */}
        <div className="px-4 py-2 border-t border-gray-100">
          <div className="flex gap-2">
            <button
              onClick={() => {
                // For mobile devices, try direct WhatsApp calling
                if (/Android|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent)) {
                  // Try direct WhatsApp call protocol first, fallback to message
                  try {
                    window.open('whatsapp://call?phone=447711776304', '_blank');
                  } catch (e) {
                    // Fallback to WhatsApp with call request message
                    window.open('whatsapp://send?phone=447711776304&text=Please%20call%20me', '_blank');
                  }
                } else {
                  // For desktop browsers, redirect to WhatsApp Web with direct call option
                  window.open('https://web.whatsapp.com/send?phone=447711776304&text=Please%20call%20me%20-%20clicking%20this%20for%20voice%20call', '_blank');
                }
              }}
              className="flex-1 flex items-center justify-center gap-2 px-4 py-3 bg-green-500 hover:bg-green-600 text-white rounded-lg font-medium transition-colors"
            >
              <Phone className="w-4 h-4" />
              Call WhatsApp
            </button>
            <button
              onClick={() => {
                // For mobile devices, try Messenger app with video call intent
                if (/Android|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent)) {
                  // Try to open Messenger with video call intent
                  window.open('fb-messenger://user/100000000000000', '_blank');
                } else {
                  // For desktop browsers, redirect to Messenger Web for full functionality
                  window.open('https://www.messenger.com/', '_blank');
                }
              }}
              className="flex-1 flex items-center justify-center gap-2 px-4 py-3 bg-blue-500 hover:bg-blue-600 text-white rounded-lg font-medium transition-colors"
            >
              <Video className="w-4 h-4" />
              Use Messenger
            </button>
          </div>
        </div>
        
        {/* Mobile Menu Overlay */}
        {isMenuOpen && (
          <div className="fixed inset-0 bg-black bg-opacity-50 z-40" onClick={toggleMenu}>
            <div 
              className="absolute right-0 top-0 h-full w-64 bg-white shadow-xl transform transition-transform duration-300 flex flex-col"
              onClick={(e) => e.stopPropagation()}
            >
              <div className="p-4 border-b border-gray-200">
                <div className="flex items-center justify-between">
                  <span className="font-semibold text-lg text-primary-dark">Menu</span>
                  <button onClick={toggleMenu} className="p-1 rounded-md text-gray-600 hover:text-gray-900">
                    <X className="w-5 h-5" />
                  </button>
                </div>
              </div>
              <div className="flex-1 p-4 space-y-3 overflow-y-auto">
                {navItems.slice(0, 3).map((item) => (
                  <a
                    key={item.href}
                    href={item.href}
                    className={`block py-2 px-3 rounded-lg ${
                      item.active
                        ? "bg-primary-light text-primary-dark font-medium"
                        : "text-gray-700 hover:bg-gray-100"
                    }`}
                    onClick={toggleMenu}
                  >
                    <i className={`${item.icon} mr-3`}></i>{item.label}
                  </a>
                ))}
                

                
                {navItems.slice(3).map((item) => (
                  <a
                    key={item.href}
                    href={item.href}
                    className={`block py-2 px-3 rounded-lg ${
                      item.active
                        ? "bg-primary-light text-primary-dark font-medium"
                        : "text-gray-700 hover:bg-gray-100"
                    }`}
                    onClick={toggleMenu}
                  >
                    <i className={`${item.icon} mr-3`}></i>{item.label}
                  </a>
                ))}
              </div>
              
              {/* Sign Out Button - Fixed at bottom */}
              <div className="p-4 border-t border-gray-200 bg-gray-50">
                <button 
                  onClick={(e) => {
                    e.preventDefault();
                    e.stopPropagation();
                    console.log("Mobile sign out button clicked");
                    setIsMenuOpen(false);
                    handleSignOut();
                  }}
                  className="w-full py-4 px-4 bg-red-500 text-white rounded-lg font-bold hover:bg-red-600 flex items-center justify-center text-lg shadow-lg"
                >
                  <LogOut className="w-5 h-5 mr-2" />
                  SIGN OUT
                </button>
              </div>
            </div>
          </div>
        )}
      </nav>

      {/* Bottom Mobile Navigation */}
      <nav className="lg:hidden fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 px-4 py-2 z-50 shadow-lg">
        <div className="flex items-center justify-around">
          {bottomNavItems.map((item) => {
            const IconComponent = item.icon;
            return (
              <a
                key={item.href}
                href={item.href}
                className={`flex flex-col items-center py-2 px-3 ${
                  location === item.href ? "text-primary" : "text-gray-600"
                }`}
              >
                <IconComponent size={20} />
                <span className="text-xs mt-1 font-medium">{item.label}</span>
              </a>
            );
          })}
        </div>
      </nav>

    </>
  );
}
