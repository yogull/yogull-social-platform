import { ArrowLeft } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useLocation } from "wouter";

interface BackButtonProps {
  className?: string;
  fallbackPath?: string;
}

export function BackButton({ className = "", fallbackPath = "/" }: BackButtonProps) {
  const [, setLocation] = useLocation();

  const handleBack = () => {
    // Always navigate to the specified fallback path instead of browser history
    setLocation(fallbackPath);
  };

  return (
    <Button
      onClick={handleBack}
      variant="outline"
      size="sm"
      className={`flex items-center gap-2 ${className}`}
    >
      <ArrowLeft className="w-4 h-4" />
      <span>Back</span>
    </Button>
  );
}