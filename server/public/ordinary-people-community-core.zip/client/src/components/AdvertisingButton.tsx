import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { useTranslation } from "@/hooks/useTranslation";
import { ShoppingBag, Store, TrendingUp, Users, MessageCircle, DollarSign } from "lucide-react";

export function AdvertisingButton() {
  const [showAdvertisingInfo, setShowAdvertisingInfo] = useState(false);
  const { t, formatPrice, language } = useTranslation();
  
  // Get translation text directly
  const buttonText = `${t('ad.advertiseYourBusiness')} - ${formatPrice(24)} per Ad Card/Year`;

  return (
    <>
      {/* Purple Advertising Button */}
      <div className="bg-purple-100 border-b border-purple-200 px-2 md:px-4 lg:px-8 py-3" key={`ad-${language}`}>
        <div className="flex justify-center">
          <Button
            onClick={() => setShowAdvertisingInfo(true)}
            className="bg-purple-600 hover:bg-purple-700 text-white border-none shadow-lg px-2 md:px-4 py-1 md:py-2 text-xs md:text-sm font-semibold w-full max-w-xs md:max-w-md whitespace-nowrap overflow-hidden text-ellipsis"
            size="sm"
          >
            <Store className="w-3 h-3 md:w-4 md:h-4 mr-1 md:mr-2" />
            <span className="truncate">{buttonText}</span>
          </Button>
        </div>
      </div>

      {/* Advertising Information Dialog */}
      <Dialog open={showAdvertisingInfo} onOpenChange={setShowAdvertisingInfo}>
        <DialogContent className="max-w-sm md:max-w-4xl max-h-[90vh] overflow-y-auto mx-2">
          <DialogHeader>
            <DialogTitle className="text-lg md:text-2xl font-bold text-purple-700 flex items-center gap-2">
              <Store className="w-4 h-4 md:w-6 md:h-6" />
              {t('ad.businessPackage')}
            </DialogTitle>
          </DialogHeader>
          
          <div className="space-y-4 md:space-y-6 py-2 md:py-4">
            {/* Hero Section */}
            <div className="bg-gradient-to-r from-purple-100 to-pink-100 p-3 md:p-6 rounded-lg">
              <h3 className="text-sm md:text-xl font-bold text-purple-800 mb-2 md:mb-3">
                🚀 {t('ad.subtitle')} - {formatPrice(24)} per Advertisement Card per Year
              </h3>
              <p className="text-purple-700 text-xs md:text-lg">
                Each advertisement card costs {formatPrice(24)} annually. Create multiple advertisement cards to increase your business visibility across the platform.
              </p>
            </div>

            {/* Pricing Clarification */}
            <div className="bg-yellow-50 border border-yellow-200 p-3 md:p-4 rounded-lg">
              <h3 className="text-sm md:text-lg font-bold text-yellow-800 mb-2">💰 Pricing Structure</h3>
              <ul className="text-xs md:text-sm text-yellow-700 space-y-1">
                <li>• <strong>First Advertisement Card:</strong> {formatPrice(24)} per year</li>
                <li>• <strong>Additional Advertisement Cards:</strong> {formatPrice(24)} per year each</li>
                <li>• <strong>Business Package Includes:</strong> Storefront + Location targeting + E-commerce system</li>
                <li>• <strong>Create multiple ads</strong> to increase visibility across different product categories</li>
              </ul>
            </div>

            {/* What You Get */}
            <div>
              <h3 className="text-sm md:text-xl font-bold text-gray-800 mb-2 md:mb-4 flex items-center gap-1 md:gap-2">
                <TrendingUp className="w-3 h-3 md:w-5 md:h-5 text-purple-600" />
                What's Included with Each Advertisement Card
              </h3>
              <div className="grid md:grid-cols-2 gap-2 md:gap-4">
                <div className="bg-purple-50 p-2 md:p-4 rounded-lg border border-purple-200">
                  <h4 className="text-xs md:text-sm font-semibold text-purple-800 mb-1 md:mb-2 flex items-center gap-1 md:gap-2">
                    <MessageCircle className="w-3 h-3 md:w-4 md:h-4" />
                    {t('ad.carouselAds')}
                  </h4>
                  <ul className="text-xs md:text-sm text-purple-700 space-y-0.5 md:space-y-1">
                    <li>• {t('ad.carouselDetail1')}</li>
                    <li>• {t('ad.carouselDetail2')}</li>
                    <li>• {t('ad.carouselDetail3')}</li>
                    <li>• {t('ad.carouselDetail4')}</li>
                  </ul>
                </div>
                <div className="bg-green-50 p-2 md:p-4 rounded-lg border border-green-200">
                  <h4 className="text-xs md:text-sm font-semibold text-green-800 mb-1 md:mb-2 flex items-center gap-1 md:gap-2">
                    <Store className="w-3 h-3 md:w-4 md:h-4" />
                    {t('ad.dedicatedStore')}
                  </h4>
                  <ul className="text-xs md:text-sm text-green-700 space-y-0.5 md:space-y-1">
                    <li>• {t('ad.storeDetail1')}</li>
                    <li>• {t('ad.storeDetail2')}</li>
                    <li>• {t('ad.storeDetail3')}</li>
                    <li>• {t('ad.storeDetail4')}</li>
                    <li>• {t('ad.storeDetail5')}</li>
                    <li>• {t('ad.storeDetail6')}</li>
                  </ul>
                </div>
                <div className="bg-blue-50 p-2 md:p-4 rounded-lg border border-blue-200">
                  <h4 className="text-xs md:text-sm font-semibold text-blue-800 mb-1 md:mb-2 flex items-center gap-1 md:gap-2">
                    <Users className="w-3 h-3 md:w-4 md:h-4" />
                    {t('ad.locationTargeting')}
                  </h4>
                  <ul className="text-xs md:text-sm text-blue-700 space-y-0.5 md:space-y-1">
                    <li>• {t('ad.locationDetail1')}</li>
                    <li>• {t('ad.locationDetail2')}</li>
                    <li>• {t('ad.locationDetail3')}</li>
                    <li>• {t('ad.locationDetail4')}</li>
                  </ul>
                </div>
                <div className="bg-orange-50 p-2 md:p-4 rounded-lg border border-orange-200">
                  <h4 className="text-xs md:text-sm font-semibold text-orange-800 mb-1 md:mb-2 flex items-center gap-1 md:gap-2">
                    <DollarSign className="w-3 h-3 md:w-4 md:h-4" />
                    {t('ad.salesAnalytics')}
                  </h4>
                  <ul className="text-xs md:text-sm text-orange-700 space-y-0.5 md:space-y-1">
                    <li>• {t('ad.analyticsDetail1')}</li>
                    <li>• {t('ad.analyticsDetail2')}</li>
                    <li>• {t('ad.analyticsDetail3')}</li>
                    <li>• {t('ad.analyticsDetail4')}</li>
                  </ul>
                </div>
              </div>
            </div>

            {/* How It Works */}
            <div>
              <h3 className="text-xl font-bold text-gray-800 mb-4">
                🎯 {t('ad.howItWorks')}
              </h3>
              <div className="space-y-3">
                <div className="flex items-start gap-3 p-3 bg-gray-50 rounded-lg">
                  <div className="bg-purple-600 text-white w-6 h-6 rounded-full flex items-center justify-center text-sm font-bold">1</div>
                  <div>
                    <h4 className="font-semibold">{t('ad.step1')}</h4>
                    <p className="text-sm text-gray-600">{t('ad.step1Desc')}</p>
                  </div>
                </div>
                <div className="flex items-start gap-3 p-3 bg-gray-50 rounded-lg">
                  <div className="bg-purple-600 text-white w-6 h-6 rounded-full flex items-center justify-center text-sm font-bold">2</div>
                  <div>
                    <h4 className="font-semibold">{t('ad.step2')}</h4>
                    <p className="text-sm text-gray-600">{t('ad.step2Desc')}</p>
                  </div>
                </div>
                <div className="flex items-start gap-3 p-3 bg-gray-50 rounded-lg">
                  <div className="bg-purple-600 text-white w-6 h-6 rounded-full flex items-center justify-center text-sm font-bold">3</div>
                  <div>
                    <h4 className="font-semibold">{t('ad.step3')}</h4>
                    <p className="text-sm text-gray-600">{t('ad.step3Desc')}</p>
                  </div>
                </div>
                <div className="flex items-start gap-3 p-3 bg-gray-50 rounded-lg">
                  <div className="bg-purple-600 text-white w-6 h-6 rounded-full flex items-center justify-center text-sm font-bold">4</div>
                  <div>
                    <h4 className="font-semibold">{t('ad.step4')}</h4>
                    <p className="text-sm text-gray-600">{t('ad.step4Desc')}</p>
                  </div>
                </div>
              </div>
            </div>

            {/* Pricing & Benefits */}
            <div className="bg-gradient-to-r from-green-100 to-blue-100 p-6 rounded-lg">
              <h3 className="text-xl font-bold text-gray-800 mb-3">
                💰 Unbeatable Value: £24 per Advertisement Card per Year = £2/Month per Ad
              </h3>
              <div className="grid md:grid-cols-3 gap-4 text-sm">
                <div>
                  <h4 className="font-semibold text-green-800">Compare to Facebook Ads:</h4>
                  <p className="text-gray-700">Facebook: £100+ per month minimum</p>
                  <p className="text-green-700 font-semibold">Our Platform: £2 per month per ad</p>
                </div>
                <div>
                  <h4 className="font-semibold text-blue-800">Compare to Google Ads:</h4>
                  <p className="text-gray-700">Google: £200+ per month typical</p>
                  <p className="text-blue-700 font-semibold">Our Platform: £2 per month per ad</p>
                </div>
                <div>
                  <h4 className="font-semibold text-purple-800">Our Advantage:</h4>
                  <p className="text-gray-700">Targeted community audience</p>
                  <p className="text-purple-700 font-semibold">Create multiple ads for different products</p>
                </div>
              </div>
            </div>

            {/* Call to Action */}
            <div className="bg-purple-600 text-white p-3 md:p-6 rounded-lg text-center">
              <h3 className="text-sm md:text-xl font-bold mb-2 md:mb-3">Ready to Create Your First Advertisement Card?</h3>
              <p className="mb-3 md:mb-4 text-xs md:text-base">Join hundreds of businesses already growing with Ordinary People Community</p>
              <div className="space-y-2 md:space-y-3">
                <Button
                  onClick={() => {
                    setShowAdvertisingInfo(false);
                    window.location.href = '/advertise-payment';
                  }}
                  className="bg-white text-purple-600 hover:bg-gray-100 px-3 md:px-8 py-2 md:py-3 text-xs md:text-lg font-semibold"
                  size="sm"
                >
                  Create First Ad Card - {formatPrice(24)}/Year
                </Button>
                <p className="text-xs md:text-sm text-purple-200">
                  Questions? Contact us at ordinarypeoplecommunity.com@gmail.com or +44 7711 776 304
                </p>
              </div>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}