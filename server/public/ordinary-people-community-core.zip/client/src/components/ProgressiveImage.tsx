import { useState } from 'react';
import { useLazyLoading } from '@/hooks/usePerformance';
import { cn } from '@/lib/utils';

interface ProgressiveImageProps {
  src: string;
  alt: string;
  className?: string;
  fallback?: string;
  onLoad?: () => void;
  onError?: () => void;
}

export function ProgressiveImage({ 
  src, 
  alt, 
  className, 
  fallback = '/placeholder.svg',
  onLoad,
  onError 
}: ProgressiveImageProps) {
  const [isLoaded, setIsLoaded] = useState(false);
  const [hasError, setHasError] = useState(false);
  const { isVisible, ref } = useLazyLoading();

  const handleLoad = () => {
    setIsLoaded(true);
    onLoad?.();
  };

  const handleError = () => {
    setHasError(true);
    onError?.();
  };

  return (
    <div 
      ref={ref} 
      className={cn("relative overflow-hidden bg-gray-100", className)}
    >
      {!isVisible && (
        <div className="absolute inset-0 bg-gray-200 animate-pulse" />
      )}
      
      {isVisible && (
        <img
          src={hasError ? fallback : src}
          alt={alt}
          onLoad={handleLoad}
          onError={handleError}
          className={cn(
            "transition-opacity duration-300",
            isLoaded ? "opacity-100" : "opacity-0",
            className
          )}
          loading="lazy"
        />
      )}
      
      {isVisible && !isLoaded && !hasError && (
        <div className="absolute inset-0 bg-gray-200 animate-pulse" />
      )}
    </div>
  );
}