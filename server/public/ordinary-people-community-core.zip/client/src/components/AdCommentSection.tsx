import React, { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Heart, Share2, MessageCircle, Send, Facebook, Twitter, Linkedin } from "lucide-react";
import { useAuth } from "@/hooks/useAuth";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";

interface AdComment {
  id: number;
  adId: number;
  userId: number;
  content: string;
  likes: number;
  shares: number;
  createdAt: string;
  userName: string;
  userLiked?: boolean;
}

interface AdCommentSectionProps {
  adId: number;
  adTitle: string;
  adDescription: string;
}

export function AdCommentSection({ adId, adTitle, adDescription }: AdCommentSectionProps) {
  const [newComment, setNewComment] = useState("");
  const [showComments, setShowComments] = useState(false);
  const { appUser } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: comments = [] } = useQuery<AdComment[]>({
    queryKey: ["/api/advertisement-comments", adId],
    enabled: showComments,
  });

  const createCommentMutation = useMutation({
    mutationFn: async (content: string) => {
      return await apiRequest("POST", "/api/advertisement-comments", {
        adId,
        content,
      });
    },
    onSuccess: () => {
      setNewComment("");
      queryClient.invalidateQueries({ queryKey: ["/api/advertisement-comments", adId] });
      toast({
        title: "Comment Posted",
        description: "Your comment has been added successfully.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to post comment. Please try again.",
        variant: "destructive",
      });
    },
  });

  const likeCommentMutation = useMutation({
    mutationFn: async (commentId: number) => {
      return await apiRequest("POST", `/api/advertisement-comments/${commentId}/like`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/advertisement-comments", adId] });
    },
  });

  const shareToAllMutation = useMutation({
    mutationFn: async () => {
      const shareText = `Check out this great local business: ${adTitle} - ${adDescription}`;
      const shareUrl = window.location.href;

      // Open sharing windows for multiple platforms
      const platforms = [
        { name: 'facebook', url: `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(shareUrl)}&quote=${encodeURIComponent(shareText)}` },
        { name: 'twitter', url: `https://twitter.com/intent/tweet?url=${encodeURIComponent(shareUrl)}&text=${encodeURIComponent(shareText)}` },
        { name: 'linkedin', url: `https://www.linkedin.com/sharing/share-offsite/?url=${encodeURIComponent(shareUrl)}` },
        { name: 'whatsapp', url: `https://wa.me/?text=${encodeURIComponent(shareText + ' ' + shareUrl)}` },
        { name: 'telegram', url: `https://t.me/share/url?url=${encodeURIComponent(shareUrl)}&text=${encodeURIComponent(shareText)}` }
      ];

      platforms.forEach((platform, index) => {
        setTimeout(() => {
          window.open(platform.url, '_blank', 'width=600,height=400');
        }, index * 500);
      });

      return { success: true };
    },
    onSuccess: () => {
      toast({
        title: "Sharing Advertisement",
        description: "Opening social media platforms for sharing this business.",
      });
    },
  });

  const handleSubmitComment = () => {
    if (!appUser) {
      toast({
        title: "Login Required",
        description: "Please sign in to comment on advertisements.",
        variant: "destructive",
      });
      return;
    }

    if (!newComment.trim()) {
      toast({
        title: "Empty Comment",
        description: "Please write a comment before posting.",
        variant: "destructive",
      });
      return;
    }

    createCommentMutation.mutate(newComment.trim());
  };

  const handleLikeComment = (commentId: number) => {
    if (!appUser) {
      toast({
        title: "Login Required",
        description: "Please sign in to like comments.",
        variant: "destructive",
      });
      return;
    }

    likeCommentMutation.mutate(commentId);
  };

  return (
    <Card className="mt-4 border-purple-200 bg-purple-50">
      <CardContent className="p-4">
        {/* Action Buttons */}
        <div className="flex items-center gap-4 mb-4">
          <Button
            variant="outline"
            size="sm"
            onClick={() => setShowComments(!showComments)}
            className="flex items-center gap-2"
          >
            <MessageCircle className="w-4 h-4" />
            {showComments ? 'Hide Comments' : `Comments (${comments.length})`}
          </Button>
          
          <Button
            variant="outline"
            size="sm"
            onClick={() => shareToAllMutation.mutate()}
            disabled={shareToAllMutation.isPending}
            className="flex items-center gap-2 bg-gradient-to-r from-pink-100 to-purple-100 hover:from-pink-200 hover:to-purple-200"
          >
            <Share2 className="w-4 h-4" />
            Post to All Social Media
          </Button>
        </div>

        {/* Comment Input */}
        {appUser && (
          <div className="mb-4">
            <Textarea
              placeholder="Share your thoughts about this business..."
              value={newComment}
              onChange={(e) => setNewComment(e.target.value)}
              className="mb-2 min-h-[80px]"
            />
            <Button
              onClick={handleSubmitComment}
              disabled={createCommentMutation.isPending || !newComment.trim()}
              className="bg-purple-600 hover:bg-purple-700"
            >
              <Send className="w-4 h-4 mr-2" />
              {createCommentMutation.isPending ? 'Posting...' : 'Post Comment'}
            </Button>
          </div>
        )}

        {/* Comments List */}
        {showComments && (
          <div className="space-y-3">
            {comments.length === 0 ? (
              <p className="text-gray-500 text-center py-4">
                No comments yet. Be the first to share your thoughts about this business!
              </p>
            ) : (
              comments.map((comment) => (
                <div key={comment.id} className="bg-white p-3 rounded-lg border">
                  <div className="flex justify-between items-start mb-2">
                    <span className="font-medium text-sm text-purple-700">
                      {comment.userName}
                    </span>
                    <span className="text-xs text-gray-500">
                      {new Date(comment.createdAt).toLocaleDateString()}
                    </span>
                  </div>
                  <p className="text-gray-800 mb-2">{comment.content}</p>
                  <div className="flex items-center gap-3">
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => handleLikeComment(comment.id)}
                      className="flex items-center gap-1 text-purple-600 hover:text-purple-700"
                    >
                      <Heart className={`w-4 h-4 ${comment.userLiked ? 'fill-current' : ''}`} />
                      {comment.likes}
                    </Button>
                  </div>
                </div>
              ))
            )}
          </div>
        )}
      </CardContent>
    </Card>
  );
}