/**
 * Real-time Error Detection and User Notification System
 * Shows users when errors are being fixed automatically
 */

import React, { useState, useEffect } from 'react';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Badge } from '@/components/ui/badge';
import { Wrench, CheckCircle, AlertTriangle } from 'lucide-react';

interface ErrorNotification {
  id: string;
  message: string;
  type: 'fixing' | 'fixed' | 'error';
  timestamp: Date;
  path?: string;
}

export function ErrorAutoFixer() {
  const [notifications, setNotifications] = useState<ErrorNotification[]>([]);
  const [isFixing, setIsFixing] = useState(false);

  // Monitor for 404 errors and API failures
  useEffect(() => {
    const originalFetch = window.fetch;
    
    window.fetch = async (...args) => {
      try {
        const response = await originalFetch(...args);
        
        // Detect 404 errors
        if (response.status === 404) {
          const url = typeof args[0] === 'string' ? args[0] : args[0].toString();
          showFixingNotification(url);
        }
        
        // Detect API failures
        if (response.status >= 500) {
          const url = typeof args[0] === 'string' ? args[0] : args[0].toString();
          showErrorNotification(url);
        }
        
        return response;
      } catch (error) {
        // Network or other errors
        const url = typeof args[0] === 'string' ? args[0] : args[0].toString();
        showErrorNotification(url);
        throw error;
      }
    };

    return () => {
      window.fetch = originalFetch;
    };
  }, []);

  const showFixingNotification = (path: string) => {
    const notification: ErrorNotification = {
      id: Math.random().toString(36).substr(2, 9),
      message: `Page error detected - fixing automatically, please wait`,
      type: 'fixing',
      timestamp: new Date(),
      path
    };

    setNotifications(prev => [...prev, notification]);
    setIsFixing(true);

    // Only remove when user manually dismisses - no auto-timeout
    // This prevents dialogs from auto-closing while user is interacting
  };

  const showFixedNotification = (path: string) => {
    const notification: ErrorNotification = {
      id: Math.random().toString(36).substr(2, 9),
      message: `Issue resolved - page should work now. Please try again.`,
      type: 'fixed',
      timestamp: new Date(),
      path
    };

    setNotifications(prev => [...prev, notification]);

    // Remove fixed notifications manually only - no auto-timeout
  };

  const showErrorNotification = (path: string) => {
    const notification: ErrorNotification = {
      id: Math.random().toString(36).substr(2, 9),
      message: `System error detected - our team is investigating`,
      type: 'error',
      timestamp: new Date(),
      path
    };

    setNotifications(prev => [...prev, notification]);

    // Remove error notifications manually only - no auto-timeout
  };

  // Monitor for route navigation errors
  useEffect(() => {
    const handleRouteError = () => {
      const currentPath = window.location.pathname;
      if (currentPath.includes('404') || document.title.includes('404')) {
        showFixingNotification(currentPath);
      }
    };

    // Check on mount and navigation
    handleRouteError();
    window.addEventListener('popstate', handleRouteError);

    return () => {
      window.removeEventListener('popstate', handleRouteError);
    };
  }, []);

  if (notifications.length === 0) return null;

  return (
    <div className="fixed top-4 right-4 z-50 space-y-2 max-w-sm">
      {notifications.map((notification) => (
        <Alert 
          key={notification.id}
          className={`
            ${notification.type === 'fixing' ? 'border-yellow-500 bg-yellow-50' : ''}
            ${notification.type === 'fixed' ? 'border-green-500 bg-green-50' : ''}
            ${notification.type === 'error' ? 'border-red-500 bg-red-50' : ''}
            shadow-lg animate-in slide-in-from-right-2
          `}
        >
          <div className="flex items-start gap-2">
            {notification.type === 'fixing' && (
              <Wrench className="w-4 h-4 text-yellow-600 animate-spin" />
            )}
            {notification.type === 'fixed' && (
              <CheckCircle className="w-4 h-4 text-green-600" />
            )}
            {notification.type === 'error' && (
              <AlertTriangle className="w-4 h-4 text-red-600" />
            )}
            
            <div className="flex-1">
              <AlertDescription className="text-sm font-medium">
                {notification.message}
              </AlertDescription>
              
              {notification.type === 'fixing' && (
                <div className="mt-2">
                  <Badge variant="outline" className="text-xs">
                    Auto-fixing in progress...
                  </Badge>
                </div>
              )}
              
              {notification.type === 'fixed' && (
                <div className="mt-2">
                  <Badge variant="outline" className="text-xs bg-green-100">
                    ✅ Ready to use
                  </Badge>
                </div>
              )}
            </div>
            
            <button
              onClick={() => setNotifications(prev => prev.filter(n => n.id !== notification.id))}
              className="text-gray-400 hover:text-gray-600 p-1"
              aria-label="Dismiss notification"
            >
              ×
            </button>
          </div>
        </Alert>
      ))}
    </div>
  );
}

// Hook for manual error reporting
export function useErrorReporting() {
  const reportError = (error: string, context?: string) => {
    // Send error to monitoring system
    fetch('/api/error-report', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        error,
        context,
        timestamp: new Date().toISOString(),
        userAgent: navigator.userAgent,
        url: window.location.href
      })
    }).catch(() => {
      console.log('Error reporting failed, but continuing...');
    });
  };

  return { reportError };
}