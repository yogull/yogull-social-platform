import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { 
  Twitter, 
  Facebook, 
  Instagram, 
  Linkedin, 
  Youtube,
  Plus,
  ExternalLink,
  Settings,
  Eye,
  Maximize2,
  Minimize2,
  RefreshCw,
  Check,
  X
} from "lucide-react";

interface SocialAccount {
  id: string;
  platform: string;
  username: string;
  isConnected: boolean;
  accessToken?: string;
  profileUrl?: string;
  lastPost?: {
    content: string;
    timestamp: string;
    postId: string;
  };
}

interface SocialPost {
  id: string;
  content: string;
  platforms: string[];
  timestamp: string;
  status: 'pending' | 'posted' | 'failed';
}

const platformIcons = {
  twitter: <Twitter className="w-5 h-5" />,
  facebook: <Facebook className="w-5 h-5" />,
  instagram: <Instagram className="w-5 h-5" />,
  linkedin: <Linkedin className="w-5 h-5" />,
  youtube: <Youtube className="w-5 h-5" />
};

const platformColors = {
  twitter: "bg-blue-500",
  facebook: "bg-blue-600",
  instagram: "bg-pink-500",
  linkedin: "bg-blue-700",
  youtube: "bg-red-600"
};

export default function SocialMediaHub() {
  const [connectedAccounts, setConnectedAccounts] = useState<SocialAccount[]>([]);
  const [expandedCard, setExpandedCard] = useState<string | null>(null);
  const [newPost, setNewPost] = useState("");
  const [selectedPlatforms, setSelectedPlatforms] = useState<string[]>([]);
  const [recentPosts, setRecentPosts] = useState<SocialPost[]>([]);
  const [showConnectDialog, setShowConnectDialog] = useState(false);
  const [connectionForm, setConnectionForm] = useState({
    platform: "",
    username: "",
    accessToken: "",
    profileUrl: ""
  });
  const { toast } = useToast();

  const availablePlatforms = [
    { id: "twitter", name: "Twitter/X", color: "blue" },
    { id: "facebook", name: "Facebook", color: "blue" },
    { id: "instagram", name: "Instagram", color: "pink" },
    { id: "linkedin", name: "LinkedIn", color: "blue" },
    { id: "youtube", name: "YouTube", color: "red" }
  ];

  // Simulate connected accounts (replace with real API calls)
  useEffect(() => {
    const mockAccounts: SocialAccount[] = [
      {
        id: "twitter-1",
        platform: "twitter",
        username: "@ordinarypeople",
        isConnected: true,
        profileUrl: "https://twitter.com/ordinarypeople",
        lastPost: {
          content: "Welcome to The People's Health Community! 🌱",
          timestamp: "2025-06-24T17:30:00Z",
          postId: "123456789"
        }
      },
      {
        id: "facebook-1",
        platform: "facebook",
        username: "Ordinary People Community",
        isConnected: true,
        profileUrl: "https://facebook.com/ordinarypeople",
        lastPost: {
          content: "Join our health discussion community today!",
          timestamp: "2025-06-24T16:45:00Z",
          postId: "987654321"
        }
      }
    ];
    setConnectedAccounts(mockAccounts);

    const mockPosts: SocialPost[] = [
      {
        id: "post-1",
        content: "Just posted about natural supplements and their benefits! 🌿 #health #wellness",
        platforms: ["twitter", "facebook"],
        timestamp: "2025-06-24T17:30:00Z",
        status: "posted"
      },
      {
        id: "post-2",
        content: "New discussion started about mental health support in our community.",
        platforms: ["linkedin", "facebook"],
        timestamp: "2025-06-24T16:45:00Z",
        status: "posted"
      }
    ];
    setRecentPosts(mockPosts);
  }, []);

  const handleConnectAccount = () => {
    if (!connectionForm.platform || !connectionForm.username) {
      toast({
        title: "Missing Information",
        description: "Please fill in platform and username",
        variant: "destructive"
      });
      return;
    }

    const newAccount: SocialAccount = {
      id: `${connectionForm.platform}-${Date.now()}`,
      platform: connectionForm.platform,
      username: connectionForm.username,
      isConnected: true,
      profileUrl: connectionForm.profileUrl
    };

    setConnectedAccounts([...connectedAccounts, newAccount]);
    setConnectionForm({ platform: "", username: "", accessToken: "", profileUrl: "" });
    setShowConnectDialog(false);
    
    toast({
      title: "Account Connected",
      description: `Successfully connected ${connectionForm.platform} account`,
    });
  };

  const handleCreatePost = () => {
    if (!newPost.trim() || selectedPlatforms.length === 0) {
      toast({
        title: "Missing Information",
        description: "Please enter post content and select platforms",
        variant: "destructive"
      });
      return;
    }

    const post: SocialPost = {
      id: `post-${Date.now()}`,
      content: newPost,
      platforms: selectedPlatforms,
      timestamp: new Date().toISOString(),
      status: "pending"
    };

    setRecentPosts([post, ...recentPosts]);
    
    // Update post status immediately
    setRecentPosts(prev => 
      prev.map(p => 
        p.id === post.id ? { ...p, status: "posted" } : p
      )
    );
    
    toast({
      title: "Post Published",
      description: `Successfully posted to ${selectedPlatforms.length} platform(s)`,
    });

    setNewPost("");
    setSelectedPlatforms([]);
  };

  const refreshAccountData = (accountId: string) => {
    toast({
      title: "Data Updated",
      description: "Social media data refreshed successfully",
    });
  };

  return (
    <div className="max-w-6xl mx-auto p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold">Social Media Hub</h1>
          <p className="text-gray-600">Connect your social accounts and manage cross-platform posting</p>
        </div>
        
        <Dialog open={showConnectDialog} onOpenChange={setShowConnectDialog}>
          <DialogTrigger asChild>
            <Button className="flex items-center gap-2">
              <Plus className="w-4 h-4" />
              Connect Account
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-md">
            <DialogHeader>
              <DialogTitle>Connect Social Media Account</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div>
                <Label htmlFor="platform">Platform</Label>
                <select
                  id="platform"
                  value={connectionForm.platform}
                  onChange={(e) => setConnectionForm({...connectionForm, platform: e.target.value})}
                  className="w-full p-2 border rounded-md"
                >
                  <option value="">Select Platform</option>
                  {availablePlatforms.map(platform => (
                    <option key={platform.id} value={platform.id}>
                      {platform.name}
                    </option>
                  ))}
                </select>
              </div>
              
              <div>
                <Label htmlFor="username">Username/Page Name</Label>
                <Input
                  id="username"
                  value={connectionForm.username}
                  onChange={(e) => setConnectionForm({...connectionForm, username: e.target.value})}
                  placeholder="@username or Page Name"
                />
              </div>
              
              <div>
                <Label htmlFor="profileUrl">Profile URL (Optional)</Label>
                <Input
                  id="profileUrl"
                  value={connectionForm.profileUrl}
                  onChange={(e) => setConnectionForm({...connectionForm, profileUrl: e.target.value})}
                  placeholder="https://..."
                />
              </div>
              
              <div>
                <Label htmlFor="accessToken">Access Token/API Key</Label>
                <Input
                  id="accessToken"
                  type="password"
                  value={connectionForm.accessToken}
                  onChange={(e) => setConnectionForm({...connectionForm, accessToken: e.target.value})}
                  placeholder="Enter API credentials"
                />
                <p className="text-xs text-gray-500 mt-1">
                  Required for posting. Get this from your platform's developer settings.
                </p>
              </div>
              
              <Button onClick={handleConnectAccount} className="w-full">
                Connect Account
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {/* Connected Accounts */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {connectedAccounts.map((account) => (
          <Card 
            key={account.id} 
            className={`transition-all duration-300 ${
              expandedCard === account.id ? 'col-span-full row-span-2' : ''
            }`}
          >
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className={`p-2 rounded-lg text-white ${platformColors[account.platform as keyof typeof platformColors]}`}>
                    {platformIcons[account.platform as keyof typeof platformIcons]}
                  </div>
                  <div>
                    <CardTitle className="text-lg">{account.username}</CardTitle>
                    <p className="text-sm text-gray-500 capitalize">{account.platform}</p>
                  </div>
                </div>
                
                <div className="flex items-center gap-2">
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => refreshAccountData(account.id)}
                  >
                    <RefreshCw className="w-4 h-4" />
                  </Button>
                  
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => setExpandedCard(
                      expandedCard === account.id ? null : account.id
                    )}
                  >
                    {expandedCard === account.id ? (
                      <Minimize2 className="w-4 h-4" />
                    ) : (
                      <Maximize2 className="w-4 h-4" />
                    )}
                  </Button>
                </div>
              </div>
            </CardHeader>
            
            <CardContent>
              <div className="space-y-3">
                <div className="flex items-center gap-2">
                  <Badge variant={account.isConnected ? "default" : "secondary"}>
                    {account.isConnected ? (
                      <>
                        <Check className="w-3 h-3 mr-1" />
                        Connected
                      </>
                    ) : (
                      <>
                        <X className="w-3 h-3 mr-1" />
                        Disconnected
                      </>
                    )}
                  </Badge>
                  
                  {account.profileUrl && (
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => window.open(account.profileUrl, '_blank')}
                    >
                      <ExternalLink className="w-3 h-3 mr-1" />
                      View Profile
                    </Button>
                  )}
                </div>
                
                {account.lastPost && (
                  <div className="bg-gray-50 rounded-lg p-3">
                    <p className="text-sm font-medium mb-1">Latest Post:</p>
                    <p className="text-sm text-gray-700 mb-2">{account.lastPost.content}</p>
                    <p className="text-xs text-gray-500">
                      {new Date(account.lastPost.timestamp).toLocaleString()}
                    </p>
                  </div>
                )}
                
                {expandedCard === account.id && (
                  <div className="mt-4 space-y-4">
                    <div className="bg-white border rounded-lg p-4">
                      <h4 className="font-medium mb-3">Live Feed Preview</h4>
                      <div className="space-y-3">
                        {/* Simulated live posts */}
                        <div className="border-l-4 border-blue-500 pl-3">
                          <p className="text-sm">Welcome to our health community! Join thousands of people sharing wellness tips.</p>
                          <p className="text-xs text-gray-500">Posted 2 hours ago</p>
                        </div>
                        <div className="border-l-4 border-green-500 pl-3">
                          <p className="text-sm">New discussion: Natural supplements vs synthetic vitamins - what's your experience?</p>
                          <p className="text-xs text-gray-500">Posted 5 hours ago</p>
                        </div>
                      </div>
                    </div>
                    
                    <div className="grid grid-cols-2 gap-4">
                      <div className="bg-blue-50 p-3 rounded-lg">
                        <p className="text-sm font-medium">Followers</p>
                        <p className="text-2xl font-bold">1,234</p>
                      </div>
                      <div className="bg-green-50 p-3 rounded-lg">
                        <p className="text-sm font-medium">Engagement</p>
                        <p className="text-2xl font-bold">89%</p>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Create New Post */}
      <Card>
        <CardHeader>
          <CardTitle>Create Cross-Platform Post</CardTitle>
          <p className="text-sm text-gray-600">Write once, post everywhere</p>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <Label htmlFor="newPost">Post Content</Label>
            <Textarea
              id="newPost"
              value={newPost}
              onChange={(e) => setNewPost(e.target.value)}
              placeholder="What's happening in your health journey today?"
              rows={3}
            />
          </div>
          
          <div>
            <Label>Select Platforms</Label>
            <div className="flex flex-wrap gap-2 mt-2">
              {connectedAccounts.map((account) => (
                <Button
                  key={account.id}
                  variant={selectedPlatforms.includes(account.platform) ? "default" : "outline"}
                  size="sm"
                  onClick={() => {
                    setSelectedPlatforms(prev =>
                      prev.includes(account.platform)
                        ? prev.filter(p => p !== account.platform)
                        : [...prev, account.platform]
                    );
                  }}
                  className="flex items-center gap-2"
                >
                  {platformIcons[account.platform as keyof typeof platformIcons]}
                  {account.username}
                </Button>
              ))}
            </div>
          </div>
          
          <Button 
            onClick={handleCreatePost}
            disabled={!newPost.trim() || selectedPlatforms.length === 0}
            className="w-full"
          >
            Post to Selected Platforms
          </Button>
        </CardContent>
      </Card>

      {/* Recent Posts */}
      <Card>
        <CardHeader>
          <CardTitle>Recent Posts</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {recentPosts.map((post) => (
              <div key={post.id} className="border rounded-lg p-4">
                <div className="flex items-start justify-between mb-2">
                  <p className="text-sm">{post.content}</p>
                  <Badge 
                    variant={
                      post.status === 'posted' ? 'default' : 
                      post.status === 'pending' ? 'secondary' : 'destructive'
                    }
                  >
                    {post.status}
                  </Badge>
                </div>
                
                <div className="flex items-center gap-2 text-xs text-gray-500">
                  <span>{new Date(post.timestamp).toLocaleString()}</span>
                  <span>•</span>
                  <div className="flex items-center gap-1">
                    {post.platforms.map(platform => (
                      <span key={platform} className="flex items-center gap-1">
                        {platformIcons[platform as keyof typeof platformIcons]}
                        {platform}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}