import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { MapPin, Navigation, Phone, Globe, Mail, Clock, ArrowRight } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface BusinessLocationMapProps {
  company: {
    id: number;
    name: string;
    address?: string;
    phone?: string;
    email?: string;
    website?: string;
    description?: string;
  };
  isOwner?: boolean;
}

export function BusinessLocationMap({ company, isOwner = false }: BusinessLocationMapProps) {
  const [mapUrl, setMapUrl] = useState<string>("");
  const [coordinates, setCoordinates] = useState<{ lat: number; lng: number } | null>(null);
  const { toast } = useToast();

  useEffect(() => {
    if (company.address) {
      // Create Google Maps embed URL
      const encodedAddress = encodeURIComponent(company.address);
      const embedUrl = `https://www.google.com/maps/embed/v1/place?key=YOUR_API_KEY&q=${encodedAddress}`;
      
      // For demonstration, we'll use a static map approach
      const staticMapUrl = `https://maps.googleapis.com/maps/api/staticmap?center=${encodedAddress}&zoom=15&size=600x300&maptype=roadmap&markers=color:red%7Clabel:B%7C${encodedAddress}&key=YOUR_API_KEY`;
      
      setMapUrl(staticMapUrl);
      
      // Geocode the address (in real implementation, this would use Google Geocoding API)
      geocodeAddress(company.address);
    }
  }, [company.address]);

  const geocodeAddress = async (address: string) => {
    // In a real implementation, this would call Google Geocoding API
    // For demo purposes, we'll simulate coordinates for UK cities
    const ukCityCoordinates: Record<string, { lat: number; lng: number }> = {
      'london': { lat: 51.5074, lng: -0.1278 },
      'birmingham': { lat: 52.4862, lng: -1.8904 },
      'manchester': { lat: 53.4808, lng: -2.2426 },
      'leeds': { lat: 53.8008, lng: -1.5491 },
      'liverpool': { lat: 53.4084, lng: -2.9916 },
      'nottingham': { lat: 52.9548, lng: -1.1581 },
      'sheffield': { lat: 53.3811, lng: -1.4701 },
      'bristol': { lat: 51.4545, lng: -2.5879 },
      'cardiff': { lat: 51.4816, lng: -3.1791 },
      'edinburgh': { lat: 55.9533, lng: -3.1883 },
    };

    const addressLower = address.toLowerCase();
    for (const [city, coords] of Object.entries(ukCityCoordinates)) {
      if (addressLower.includes(city)) {
        setCoordinates(coords);
        return;
      }
    }
    
    // Default to London if no match found
    setCoordinates(ukCityCoordinates.london);
  };

  const handleGetDirections = () => {
    if (company.address) {
      const encodedAddress = encodeURIComponent(company.address);
      const directionsUrl = `https://www.google.com/maps/dir/?api=1&destination=${encodedAddress}`;
      window.open(directionsUrl, '_blank');
      
      toast({
        title: "Opening Directions",
        description: `Getting directions to ${company.name}...`,
      });
    }
  };

  const handleViewOnMaps = () => {
    if (company.address) {
      const encodedAddress = encodeURIComponent(company.address);
      const mapsUrl = `https://www.google.com/maps/search/?api=1&query=${encodedAddress}`;
      window.open(mapsUrl, '_blank');
    }
  };

  const handleCallBusiness = () => {
    if (company.phone) {
      window.location.href = `tel:${company.phone}`;
    }
  };

  const handleEmailBusiness = () => {
    if (company.email) {
      window.location.href = `mailto:${company.email}`;
    }
  };

  const handleVisitWebsite = () => {
    if (company.website) {
      let url = company.website;
      if (!url.startsWith('http://') && !url.startsWith('https://')) {
        url = `https://${url}`;
      }
      window.open(url, '_blank');
    }
  };

  return (
    <div className="space-y-6">
      {/* Location Header */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <MapPin className="w-5 h-5 text-red-500" />
            Business Location & Contact
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Address & Contact Info */}
            <div className="space-y-4">
              {company.address && (
                <div className="space-y-2">
                  <h3 className="font-semibold text-lg">{company.name}</h3>
                  <div className="flex items-start gap-2">
                    <MapPin className="w-4 h-4 text-red-500 mt-1 flex-shrink-0" />
                    <p className="text-gray-700">{company.address}</p>
                  </div>
                </div>
              )}

              <div className="space-y-3">
                {company.phone && (
                  <button
                    onClick={handleCallBusiness}
                    className="flex items-center gap-2 text-blue-600 hover:text-blue-800 transition-colors"
                  >
                    <Phone className="w-4 h-4" />
                    {company.phone}
                  </button>
                )}

                {company.email && (
                  <button
                    onClick={handleEmailBusiness}
                    className="flex items-center gap-2 text-blue-600 hover:text-blue-800 transition-colors"
                  >
                    <Mail className="w-4 h-4" />
                    {company.email}
                  </button>
                )}

                {company.website && (
                  <button
                    onClick={handleVisitWebsite}
                    className="flex items-center gap-2 text-blue-600 hover:text-blue-800 transition-colors"
                  >
                    <Globe className="w-4 h-4" />
                    Visit Website
                  </button>
                )}
              </div>

              {coordinates && (
                <div className="bg-gray-50 rounded-lg p-3 text-sm">
                  <h4 className="font-medium mb-1">Coordinates</h4>
                  <p className="text-gray-600">
                    Lat: {coordinates.lat.toFixed(6)}, Lng: {coordinates.lng.toFixed(6)}
                  </p>
                </div>
              )}
            </div>

            {/* Action Buttons */}
            <div className="space-y-3">
              <h4 className="font-semibold">Quick Actions</h4>
              
              <Button 
                onClick={handleGetDirections} 
                className="w-full flex items-center gap-2 bg-blue-600 hover:bg-blue-700"
                disabled={!company.address}
              >
                <ArrowRight className="w-4 h-4" />
                Get Directions
              </Button>

              <Button 
                onClick={handleViewOnMaps} 
                variant="outline" 
                className="w-full flex items-center gap-2"
                disabled={!company.address}
              >
                <Navigation className="w-4 h-4" />
                View on Google Maps
              </Button>

              {company.phone && (
                <Button 
                  onClick={handleCallBusiness} 
                  variant="outline" 
                  className="w-full flex items-center gap-2 text-green-600 border-green-600 hover:bg-green-50"
                >
                  <Phone className="w-4 h-4" />
                  Call Now
                </Button>
              )}

              {isOwner && (
                <div className="mt-4 p-3 bg-yellow-50 rounded-lg border border-yellow-200">
                  <p className="text-sm text-yellow-800">
                    <strong>Business Owner:</strong> This location information helps customers find you. 
                    Make sure your address is accurate and complete.
                  </p>
                </div>
              )}
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Interactive Map */}
      {company.address && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <MapPin className="w-5 h-5 text-red-500" />
              Location Map
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {/* Map Container */}
              <div className="w-full h-64 bg-gray-100 rounded-lg border overflow-hidden relative">
                {/* Placeholder Map */}
                <div className="w-full h-full flex items-center justify-center bg-gradient-to-br from-blue-100 to-green-100">
                  <div className="text-center space-y-2">
                    <MapPin className="w-12 h-12 text-red-500 mx-auto" />
                    <h3 className="font-semibold text-lg">{company.name}</h3>
                    <p className="text-sm text-gray-600 max-w-xs">{company.address}</p>
                    <Badge variant="secondary" className="mt-2">
                      Interactive Map Location
                    </Badge>
                  </div>
                </div>
                
                {/* Map Controls Overlay */}
                <div className="absolute top-4 right-4 space-y-2">
                  <Button
                    size="sm"
                    variant="secondary"
                    onClick={handleViewOnMaps}
                    className="shadow-md"
                  >
                    <Navigation className="w-3 h-3 mr-1" />
                    Full Map
                  </Button>
                </div>
              </div>

              {/* Map Footer */}
              <div className="flex items-center justify-between text-sm text-gray-600">
                <span>Click "Full Map" to open in Google Maps</span>
                <Button
                  size="sm"
                  onClick={handleGetDirections}
                  className="flex items-center gap-1"
                >
                  <ArrowRight className="w-3 h-3" />
                  Directions
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Visitor Benefits */}
      <Card className="bg-gradient-to-r from-green-50 to-blue-50 border-2 border-green-200">
        <CardHeader>
          <CardTitle className="text-green-800">Perfect for Visitors & Locals</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
            <div>
              <h4 className="font-semibold text-green-800 mb-2">For Customers:</h4>
              <ul className="space-y-1 text-green-700">
                <li>• Easy directions and navigation</li>
                <li>• One-click contact options</li>
                <li>• Visual location confirmation</li>
                <li>• Perfect for travelers and tourists</li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold text-green-800 mb-2">For Business:</h4>
              <ul className="space-y-1 text-green-700">
                <li>• Increased local visibility</li>
                <li>• Easy customer navigation</li>
                <li>• Professional location display</li>
                <li>• Captures passing trade</li>
              </ul>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Map Integration Notice */}
      <Card className="bg-blue-50 border border-blue-200">
        <CardContent className="p-4">
          <div className="flex items-start gap-3">
            <MapPin className="w-5 h-5 text-blue-600 mt-0.5" />
            <div className="text-sm">
              <p className="text-blue-800 font-medium mb-1">Location Integration</p>
              <p className="text-blue-700">
                This business location is integrated with Google Maps for accurate directions and 
                navigation. Customers can easily find you whether they're local residents or visitors 
                to the area.
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}