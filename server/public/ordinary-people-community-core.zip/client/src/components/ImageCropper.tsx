import { useState, useRef, useCallback } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { useToast } from '@/hooks/use-toast';

interface ImageCropperProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onImageCropped: (croppedImage: string) => void;
  aspectRatio?: number;
  title?: string;
}

export default function ImageCropper({
  open,
  onOpenChange,
  onImageCropped,
  aspectRatio = 1,
  title = "Crop Profile Picture"
}: ImageCropperProps) {
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const [cropPosition, setCropPosition] = useState({ x: 50, y: 50 });
  const [isDragging, setIsDragging] = useState(false);
  const [dragStart, setDragStart] = useState({ x: 0, y: 0 });
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const imageRef = useRef<HTMLImageElement>(null);
  const { toast } = useToast();
  
  const cropSize = { width: 200, height: 200 };

  const handleFileSelect = useCallback((event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (e) => {
        const result = e.target?.result as string;
        setSelectedImage(result);
        setCropPosition({ x: 50, y: 50 });
      };
      reader.readAsDataURL(file);
    }
  }, []);

  const handlePointerDown = useCallback((e: React.PointerEvent) => {
    e.preventDefault();
    setIsDragging(true);
    setDragStart({
      x: e.clientX - cropPosition.x,
      y: e.clientY - cropPosition.y
    });
  }, [cropPosition]);

  const handlePointerMove = useCallback((e: React.PointerEvent) => {
    if (!isDragging || !imageRef.current) return;
    e.preventDefault();

    const newX = e.clientX - dragStart.x;
    const newY = e.clientY - dragStart.y;
    
    // Constrain to image boundaries
    const maxX = imageRef.current.clientWidth - cropSize.width;
    const maxY = imageRef.current.clientHeight - cropSize.height;
    
    setCropPosition({
      x: Math.max(0, Math.min(maxX, newX)),
      y: Math.max(0, Math.min(maxY, newY))
    });
  }, [isDragging, dragStart, cropSize]);

  const handlePointerUp = useCallback(() => {
    setIsDragging(false);
  }, []);

  const handleCrop = useCallback(() => {
    if (!selectedImage || !canvasRef.current || !imageRef.current) {
      toast({ title: "Error", description: "Please select an image first" });
      return;
    }

    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const img = new Image();
    img.onload = () => {
      // Calculate scale factors
      const scaleX = img.width / imageRef.current!.clientWidth;
      const scaleY = img.height / imageRef.current!.clientHeight;

      // Set canvas size
      canvas.width = cropSize.width * scaleX;
      canvas.height = cropSize.height * scaleY;

      // Draw cropped image
      ctx.drawImage(
        img,
        cropPosition.x * scaleX,
        cropPosition.y * scaleY,
        cropSize.width * scaleX,
        cropSize.height * scaleY,
        0,
        0,
        canvas.width,
        canvas.height
      );

      // Convert to base64
      const croppedImage = canvas.toDataURL('image/jpeg', 0.9);
      onImageCropped(croppedImage);
      onOpenChange(false);
      toast({ title: "Success", description: "Image cropped successfully!" });
    };
    img.src = selectedImage;
  }, [selectedImage, cropPosition, cropSize, onImageCropped, onOpenChange, toast]);

  const triggerFileSelect = () => {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = 'image/*';
    input.onchange = handleFileSelect as any;
    input.click();
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle>{title}</DialogTitle>
        </DialogHeader>
        
        <div className="space-y-4">
          {!selectedImage && (
            <div className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center">
              <Button onClick={triggerFileSelect} className="mb-4">
                Select Image
              </Button>
              <p className="text-gray-500">Choose an image to crop</p>
            </div>
          )}

          {selectedImage && (
            <div className="space-y-4">
              <div 
                className="relative border border-gray-300 inline-block max-w-full touch-none select-none"
                onPointerMove={handlePointerMove}
                onPointerUp={handlePointerUp}
                onPointerLeave={handlePointerUp}
              >
                <img
                  ref={imageRef}
                  src={selectedImage}
                  alt="Image to crop"
                  className="max-w-full max-h-96 block"
                  draggable={false}
                />
                
                {/* Crop overlay */}
                <div
                  className="absolute border-2 border-blue-500 bg-blue-500 bg-opacity-20 cursor-move touch-none"
                  style={{
                    left: cropPosition.x,
                    top: cropPosition.y,
                    width: cropSize.width,
                    height: cropSize.height
                  }}
                  onPointerDown={handlePointerDown}
                >
                  <div className="absolute inset-0 border border-white border-opacity-50" />
                  <div className="absolute top-1 left-1 bg-white text-black text-xs px-1 rounded">
                    Drag to move
                  </div>
                </div>
              </div>

              <div className="flex space-x-2">
                <Button onClick={handleCrop} className="bg-green-600 hover:bg-green-700">
                  Crop & Save
                </Button>
                <Button variant="outline" onClick={triggerFileSelect}>
                  Select Different Image
                </Button>
                <Button variant="outline" onClick={() => onOpenChange(false)}>
                  Cancel
                </Button>
              </div>
            </div>
          )}
        </div>

        <canvas ref={canvasRef} className="hidden" />
      </DialogContent>
    </Dialog>
  );
}