import { useState, useRef } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { useToast } from '@/hooks/use-toast';

interface DirectImageUploaderProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onImageUploaded: (imageData: string) => void;
  title?: string;
}

export default function DirectImageUploader({ 
  open, 
  onOpenChange, 
  onImageUploaded, 
  title = "Upload Cover Image" 
}: DirectImageUploaderProps) {
  const [isUploading, setIsUploading] = useState(false);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const { toast } = useToast();

  const handleFileSelect = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      setSelectedFile(file);
    }
  };

  const handleUpload = async () => {
    if (!selectedFile) {
      toast({ title: "Error", description: "Please select an image first" });
      return;
    }

    setIsUploading(true);
    
    try {
      const reader = new FileReader();
      reader.onload = (e) => {
        const result = e.target?.result as string;
        if (result) {
          onImageUploaded(result);
          toast({ title: "Success", description: "Cover image uploaded successfully!" });
          setSelectedFile(null);
          onOpenChange(false);
        }
      };
      reader.readAsDataURL(selectedFile);
    } catch (error) {
      toast({ title: "Error", description: "Failed to upload image" });
    } finally {
      setIsUploading(false);
    }
  };

  const resetAndClose = () => {
    setSelectedFile(null);
    setIsUploading(false);
    onOpenChange(false);
  };

  return (
    <Dialog open={open} onOpenChange={resetAndClose}>
      <DialogContent className="max-w-md mx-auto">
        <DialogHeader>
          <DialogTitle>{title}</DialogTitle>
        </DialogHeader>
        
        <div className="space-y-6 p-4">
          <input
            type="file"
            ref={fileInputRef}
            onChange={handleFileSelect}
            accept="image/*"
            className="hidden"
          />
          
          {!selectedFile ? (
            <div className="text-center space-y-4">
              <div className="border-2 border-dashed border-gray-300 rounded-lg p-8">
                <div className="text-gray-400 mb-4">
                  <svg className="mx-auto h-12 w-12" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" />
                  </svg>
                </div>
                <p className="text-lg font-medium text-gray-700">Select Cover Image</p>
                <p className="text-sm text-gray-500">Choose an image from your device</p>
              </div>
              
              <Button 
                onClick={() => fileInputRef.current?.click()}
                className="w-full bg-blue-600 hover:bg-blue-700 text-white py-3"
              >
                Choose Image File
              </Button>
            </div>
          ) : (
            <div className="space-y-4">
              <div className="text-center p-6 bg-green-50 border-2 border-green-300 rounded-lg">
                <div className="text-green-700 mb-2">
                  <span className="text-2xl">✓</span>
                </div>
                <p className="text-lg font-semibold text-green-800">Image Ready to Upload!</p>
                <p className="text-sm text-green-600">{selectedFile.name}</p>
                <p className="text-xs text-green-600 mt-1">Size: {Math.round(selectedFile.size / 1024)}KB</p>
              </div>
              
              <div className="flex flex-col gap-3">
                <Button 
                  onClick={handleUpload}
                  disabled={isUploading}
                  className="w-full bg-green-600 hover:bg-green-700 disabled:bg-gray-400 py-4 text-white font-bold text-lg"
                >
                  {isUploading ? 'Uploading...' : '🚀 UPLOAD AS COVER IMAGE'}
                </Button>
                
                <div className="flex gap-2">
                  <Button 
                    variant="outline" 
                    onClick={() => fileInputRef.current?.click()}
                    disabled={isUploading}
                    className="flex-1"
                  >
                    Choose Different
                  </Button>
                  <Button 
                    variant="outline" 
                    onClick={resetAndClose}
                    disabled={isUploading}
                    className="flex-1"
                  >
                    Cancel
                  </Button>
                </div>
              </div>
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}