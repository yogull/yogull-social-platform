import { useEffect } from 'react';

// Comprehensive SEO optimization component for maximum search ranking
export function SEOBooster() {
  useEffect(() => {
    // Add canonical URL
    const canonical = document.createElement('link');
    canonical.rel = 'canonical';
    canonical.href = window.location.href;
    document.head.appendChild(canonical);

    // Add preconnect for performance
    const preconnect1 = document.createElement('link');
    preconnect1.rel = 'preconnect';
    preconnect1.href = 'https://fonts.googleapis.com';
    document.head.appendChild(preconnect1);

    const preconnect2 = document.createElement('link');
    preconnect2.rel = 'preconnect';
    preconnect2.href = 'https://fonts.gstatic.com';
    preconnect2.crossOrigin = 'anonymous';
    document.head.appendChild(preconnect2);

    // Add DNS prefetch for external resources
    const dnsPrefetch = document.createElement('link');
    dnsPrefetch.rel = 'dns-prefetch';
    dnsPrefetch.href = '//gohealme.org';
    document.head.appendChild(dnsPrefetch);

    // Add language and geo targeting
    const language = document.createElement('meta');
    language.name = 'language';
    language.content = 'en-GB';
    document.head.appendChild(language);

    const geo = document.createElement('meta');
    geo.name = 'geo.region';
    geo.content = 'GB';
    document.head.appendChild(geo);

    const geoPlacename = document.createElement('meta');
    geoPlacename.name = 'geo.placename';
    geoPlacename.content = 'United Kingdom';
    document.head.appendChild(geoPlacename);

    // Add rich schema for community platform
    const communitySchema = {
      "@context": "https://schema.org",
      "@type": "WebSite",
      "name": "Yogull - Your Voice, Government & Community",
      "description": "Yogull - Your voice on government topics, personal views, and health advice. Connect with real people away from the elites.",
      "url": window.location.href,
      "mainEntity": {
        "@type": "Organization",
        "name": "Yogull Community",
        "description": "Community platform for government discussions, personal views, and health advice",
        "url": "https://yogull.com"
      },
      "audience": {
        "@type": "PeopleAudience",
        "audienceType": "General Public seeking authentic community discussions"
      },
      "breadcrumb": {
        "@type": "BreadcrumbList",
        "itemListElement": [
          {
            "@type": "ListItem",
            "position": 1,
            "name": "Home",
            "item": "https://yogull.com"
          }
        ]
      }
    };

    const schemaScript = document.createElement('script');
    schemaScript.type = 'application/ld+json';
    schemaScript.text = JSON.stringify(communitySchema);
    document.head.appendChild(schemaScript);

    return () => {
      document.head.removeChild(canonical);
      document.head.removeChild(preconnect1);
      document.head.removeChild(preconnect2);
      document.head.removeChild(dnsPrefetch);
      document.head.removeChild(language);
      document.head.removeChild(geo);
      document.head.removeChild(geoPlacename);
      document.head.removeChild(schemaScript);
    };
  }, []);

  return null;
}

// Performance optimization hooks
export function usePageSpeed() {
  useEffect(() => {
    // Lazy load images
    const images = document.querySelectorAll('img[data-src]');
    const imageObserver = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          const img = entry.target as HTMLImageElement;
          img.src = img.dataset.src!;
          img.removeAttribute('data-src');
          imageObserver.unobserve(img);
        }
      });
    });

    images.forEach(img => imageObserver.observe(img));

    // Preload critical resources
    const criticalCSS = document.createElement('link');
    criticalCSS.rel = 'preload';
    criticalCSS.href = '/src/index.css';
    criticalCSS.as = 'style';
    document.head.appendChild(criticalCSS);

    return () => {
      imageObserver.disconnect();
    };
  }, []);
}