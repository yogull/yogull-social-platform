import React, { useEffect } from 'react';

export function ForceButtonClicks() {
  useEffect(() => {
    // Aggressive button fixing on component mount
    const forceButtonFunctionality = () => {
      // Target all possible button elements
      const selectors = [
        'button',
        '[role="button"]',
        'input[type="button"]',
        'input[type="submit"]',
        '.btn',
        '[data-instructions-trigger]'
      ];

      selectors.forEach(selector => {
        const elements = document.querySelectorAll(selector);
        elements.forEach((element) => {
          const el = element as HTMLElement;
          
          // Force remove any blocking styles
          el.style.removeProperty('pointer-events');
          el.style.pointerEvents = 'auto';
          el.style.cursor = 'pointer';
          el.style.zIndex = '9999';
          el.style.position = 'relative';
          el.style.display = el.style.display || 'inline-flex';
          el.style.opacity = '1';
          el.style.visibility = 'visible';

          // Force click functionality
          const handleClick = (e: Event) => {
            console.log('Force click handler activated:', el.textContent);
            
            const text = el.textContent?.trim() || '';
            
            if (text.includes('Instructions')) {
              console.log('Force opening instructions');
              // Trigger React state change
              const event = new CustomEvent('forceOpenInstructions');
              document.dispatchEvent(event);
            } else if (text.includes('Back')) {
              console.log('Force navigation back');
              window.history.back();
            } else if (text.includes('Dashboard')) {
              console.log('Force navigation to dashboard');
              window.location.assign('/');
            }
          };

          // Remove existing listeners and add new one
          el.removeEventListener('click', handleClick);
          el.addEventListener('click', handleClick, true);
        });
      });
    };

    // Run immediately
    forceButtonFunctionality();

    // Run on any DOM changes
    const observer = new MutationObserver(() => {
      setTimeout(forceButtonFunctionality, 50);
    });

    observer.observe(document.body, {
      childList: true,
      subtree: true,
      attributes: true,
      attributeFilter: ['style', 'class']
    });

    // Run periodically to catch any missed elements
    const interval = setInterval(forceButtonFunctionality, 1000);

    return () => {
      observer.disconnect();
      clearInterval(interval);
    };
  }, []);

  return null;
}