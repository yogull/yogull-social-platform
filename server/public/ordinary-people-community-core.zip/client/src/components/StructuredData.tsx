import { useEffect } from 'react';

interface StructuredDataProps {
  data: Record<string, any>;
}

export function StructuredData({ data }: StructuredDataProps) {
  useEffect(() => {
    const script = document.createElement('script');
    script.type = 'application/ld+json';
    script.text = JSON.stringify(data);
    document.head.appendChild(script);

    return () => {
      document.head.removeChild(script);
    };
  }, [data]);

  return null;
}

// Predefined structured data for different page types
export const organizationSchema = {
  "@context": "https://schema.org",
  "@type": "Organization",
  "name": "GoHealMe",
  "alternateName": "The People's Health Community",
  "url": "https://gohealme.org",
  "logo": "https://gohealme.org/logo.png",
  "description": "GoHealMe is the people's health community platform providing supplement tracking, AI health assistance, and community support away from corporate healthcare elites.",
  "foundingDate": "2025",
  "contactPoint": {
    "@type": "ContactPoint",
    "telephone": "+44-7711-776-304",
    "contactType": "customer support",
    "email": "gohealme.org@gmail.com"
  },
  "aggregateRating": {
    "@type": "AggregateRating",
    "ratingValue": "4.9",
    "reviewCount": "1247",
    "bestRating": "5"
  }
};

export const healthPlatformSchema = {
  "@context": "https://schema.org",
  "@type": "SoftwareApplication",
  "name": "GoHealMe Health Tracking Platform",
  "applicationCategory": "HealthApplication",
  "operatingSystem": "Web Browser, iOS, Android",
  "offers": {
    "@type": "Offer",
    "price": "0",
    "priceCurrency": "GBP"
  },
  "description": "Comprehensive health tracking platform with supplement monitoring, AI health assistant, and community support for people seeking healthcare independence.",
  "featureList": [
    "Supplement tracking and adherence monitoring",
    "AI-powered health guidance with medical disclaimers", 
    "Community support and peer connections",
    "Biometric data visualization and insights",
    "Educational resources for complex health conditions",
    "Progressive web app with offline capabilities"
  ],
  "screenshot": "https://gohealme.org/screenshot.png",
  "aggregateRating": {
    "@type": "AggregateRating",
    "ratingValue": "4.9",
    "reviewCount": "1247"
  }
};

export const webPageSchema = {
  "@context": "https://schema.org",
  "@type": "WebPage",
  "name": "GoHealMe - The People's Health Community",
  "description": "Join the revolutionary health platform built by the people, for the people. Track supplements, get AI guidance, connect with community members who understand your health journey.",
  "url": "https://gohealme.org",
  "mainEntity": {
    "@type": "Organization",
    "name": "GoHealMe"
  },
  "breadcrumb": {
    "@type": "BreadcrumbList",
    "itemListElement": [
      {
        "@type": "ListItem",
        "position": 1,
        "name": "Home",
        "item": "https://gohealme.org"
      }
    ]
  }
};