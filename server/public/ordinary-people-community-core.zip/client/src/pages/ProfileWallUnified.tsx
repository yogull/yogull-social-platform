import { useState, useEffect } from "react";
import { useParams, useLocation } from "wouter";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Heart, MessageCircle, Share2, Camera, Plus, Edit, Store, Settings, Upload, Video, Image as ImageIcon } from "lucide-react";

import { SimpleImageUpload } from "@/components/SimpleImageUpload";
import { SocialMediaLinks } from "@/components/SocialMediaLinks";
import { SEO } from "@/components/SEO";
import { BackButton } from "@/components/BackButton";

interface User {
  id: number;
  firebaseUid: string;
  email: string;
  name: string;
  bio?: string;
  location?: string;
  profileImageUrl?: string;
  isAdmin: boolean;
  isBlocked: boolean;
  createdAt: Date;
  updatedAt: Date;
}

interface ProfilePost {
  id: number;
  userId: number;
  content: string;
  mediaUrl?: string;
  mediaType?: string;
  likes: number;
  comments: number;
  shares: number;
  createdAt: Date;
  user: {
    id: number;
    name: string;
    profileImageUrl?: string;
  };
}

interface GalleryItem {
  id: number;
  fileName: string;
  fileType: string;
  fileData: string;
  caption?: string;
  createdAt: Date;
}

export default function ProfileWallUnified() {
  const { userId } = useParams();
  const { appUser, loading: authLoading } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [, setLocation] = useLocation();
  
  const [newPost, setNewPost] = useState("");
  const [showEditProfile, setShowEditProfile] = useState(false);
  const [showImageUpload, setShowImageUpload] = useState(false);
  const [uploadType, setUploadType] = useState<'profile' | 'cover' | 'gallery'>('profile');
  const [profileEditData, setProfileEditData] = useState({
    name: "",
    bio: "",
    location: ""
  });

  // Determine which user ID to use - URL param or current user
  const targetUserId = userId ? parseInt(userId) : appUser?.id;

  console.log('ProfileWall Debug:', { userId, appUser: !!appUser, targetUserId, appUserId: appUser?.id });

  // Fetch profile user data
  const { data: profileUser, isLoading, error } = useQuery<User>({
    queryKey: ["/api/users", targetUserId],
    queryFn: async () => {
      const response = await fetch(`/api/users/${targetUserId}`);
      if (!response.ok) {
        throw new Error(`Failed to fetch user: ${response.status}`);
      }
      return response.json();
    },
    enabled: !!targetUserId,
  });

  console.log('ProfileWall Query:', { profileUser, isLoading, error, targetUserId });

  // Fetch profile posts
  const { data: posts = [] } = useQuery<ProfilePost[]>({
    queryKey: ["/api/profile-wall", targetUserId],
    enabled: !!targetUserId,
  });

  // Fetch gallery items for this user
  const { data: galleryItems = [] } = useQuery<GalleryItem[]>({
    queryKey: ["/api/gallery", targetUserId],
    enabled: !!targetUserId,
  });

  // Check if current user owns this profile
  const isOwnProfile = !userId || appUser?.id === profileUser?.id;

  // Redirect to login if not authenticated and no specific user ID provided
  useEffect(() => {
    if (!userId && !appUser && !authLoading && !isLoading) {
      console.log('ProfileWall: Redirecting to login - no user authenticated');
      setLocation('/login');
      return;
    }
  }, [userId, appUser, authLoading, isLoading, setLocation]);

  // Initialize edit data when profile loads
  useEffect(() => {
    if (profileUser && isOwnProfile) {
      setProfileEditData({
        name: (profileUser as User).name || "",
        bio: (profileUser as User).bio || "",
        location: (profileUser as User).location || ""
      });
    }
  }, [profileUser, isOwnProfile]);

  // Handle image upload for profile/cover
  const handleImageUploaded = async (imageUrl: string) => {
    if (!profileUser || !isOwnProfile) return;

    try {
      const response = await fetch(`/api/users/${profileUser.id}`, {
        method: 'PATCH',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          profileImageUrl: imageUrl
        })
      });

      if (response.ok) {
        queryClient.invalidateQueries({ queryKey: ["/api/users"] });
        toast({
          title: "Success",
          description: "Profile image updated successfully!"
        });
        setShowImageUpload(false);
      } else {
        throw new Error('Failed to update profile');
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to update image. Please try again.",
        variant: "destructive"
      });
    }
  };

  // Create new post mutation
  const createPostMutation = useMutation({
    mutationFn: async (content: string) => {
      const response = await fetch('/api/profile-wall', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userId: profileUser?.id,
          content
        })
      });
      if (!response.ok) throw new Error('Failed to create post');
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/profile-wall"] });
      setNewPost("");
      toast({ title: "Success", description: "Post created successfully!" });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to create post. Please try again.",
        variant: "destructive"
      });
    }
  });

  // Update profile mutation
  const updateProfileMutation = useMutation({
    mutationFn: async (data: typeof profileEditData) => {
      const response = await fetch(`/api/users/${profileUser?.id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
      });
      if (!response.ok) throw new Error('Failed to update profile');
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/users"] });
      setShowEditProfile(false);
      toast({ title: "Success", description: "Profile updated successfully!" });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to update profile. Please try again.",
        variant: "destructive"
      });
    }
  });

  // Handle media upload to gallery
  const handleMediaUpload = async () => {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = 'image/*,video/*';
    input.multiple = true;
    
    input.onchange = async (e) => {
      const files = (e.target as HTMLInputElement).files;
      if (!files || files.length === 0) return;

      for (let i = 0; i < files.length; i++) {
        const file = files[i];
        
        // Validate file
        if (!file.type.startsWith('image/') && !file.type.startsWith('video/')) {
          toast({
            title: "Invalid file",
            description: `${file.name} is not a valid media file`,
            variant: "destructive"
          });
          continue;
        }

        const maxSize = file.type.startsWith('video/') ? 50 * 1024 * 1024 : 10 * 1024 * 1024;
        if (file.size > maxSize) {
          toast({
            title: "File too large",
            description: `${file.name} exceeds size limit`,
            variant: "destructive"
          });
          continue;
        }

        try {
          // Convert to base64
          const base64Promise = new Promise<string>((resolve) => {
            const reader = new FileReader();
            reader.onload = () => resolve(reader.result as string);
            reader.readAsDataURL(file);
          });

          const base64Data = await base64Promise;

          // Upload to gallery
          const response = await fetch('/api/files/upload', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              fileName: file.name,
              fileData: base64Data,
              fileType: file.type,
              userId: profileUser?.id
            }),
          });

          if (response.ok) {
            queryClient.invalidateQueries({ queryKey: ["/api/gallery"] });
            toast({
              title: "Success",
              description: `${file.name} uploaded successfully`,
            });
          } else {
            throw new Error('Upload failed');
          }

        } catch (error) {
          console.error('Upload error:', error);
          toast({
            title: "Upload failed",
            description: `Failed to upload ${file.name}`,
            variant: "destructive"
          });
        }
      }
    };

    input.click();
  };

  // Show loading while authentication is in progress
  if (authLoading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin w-8 h-8 border-4 border-blue-600 border-t-transparent rounded-full mx-auto mb-2" />
          <p className="text-gray-600">Loading...</p>
        </div>
      </div>
    );
  }

  // Don't render if we're redirecting unauthenticated users
  if (!userId && !appUser) {
    return null;
  }

  if (isLoading || !targetUserId) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="animate-spin w-8 h-8 border-4 border-blue-600 border-t-transparent rounded-full" />
      </div>
    );
  }

  if (!profileUser && !isLoading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-2xl font-bold mb-4">User Not Found</h1>
          <Button onClick={() => setLocation('/dashboard')}>
            Back to Dashboard
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <SEO
        title={`${profileUser.name} - Profile Wall`}
        description={`View ${profileUser.name}'s profile and posts on Ordinary People Community`}
        keywords={[profileUser.name, 'profile', 'community', 'posts', 'social']}
      />

      <div className="max-w-2xl mx-auto px-4 py-6">
        <BackButton />

        {/* Profile Header */}
        <Card className="mb-6">
          <CardContent className="p-6">
            <div className="flex items-start space-x-4">
              {/* Profile Image */}
              <div className="relative">
                <div className="w-20 h-20 rounded-full overflow-hidden bg-gray-100">
                  {profileUser.profileImageUrl ? (
                    <img 
                      src={profileUser.profileImageUrl} 
                      alt={profileUser.name}
                      className="w-full h-full object-cover"
                    />
                  ) : (
                    <div className="w-full h-full bg-gradient-to-br from-blue-400 to-purple-500 flex items-center justify-center">
                      <span className="text-white font-bold text-xl">
                        {profileUser.name.charAt(0).toUpperCase()}
                      </span>
                    </div>
                  )}
                </div>
                {isOwnProfile && (
                  <Button
                    size="sm"
                    className="absolute -bottom-2 -right-2 rounded-full w-8 h-8 p-0"
                    onClick={() => {
                      setUploadType('profile');
                      setShowImageUpload(true);
                    }}
                  >
                    <Camera className="w-4 h-4" />
                  </Button>
                )}
              </div>

              {/* Profile Info */}
              <div className="flex-1">
                <h1 className="text-2xl font-bold">{profileUser.name}</h1>
                {profileUser.bio && (
                  <p className="text-gray-600 mt-1">{profileUser.bio}</p>
                )}
                {profileUser.location && (
                  <p className="text-gray-500 text-sm mt-1">{profileUser.location}</p>
                )}
                
                {isOwnProfile && (
                  <div className="flex gap-2 mt-3">
                    <Button 
                      size="sm" 
                      variant="outline"
                      onClick={() => setShowEditProfile(true)}
                    >
                      <Edit className="w-4 h-4 mr-1" />
                      Edit Profile
                    </Button>
                    <Button 
                      size="sm" 
                      variant="outline"
                      onClick={() => setLocation('/personal-shop')}
                    >
                      <Store className="w-4 h-4 mr-1" />
                      Shop
                    </Button>
                  </div>
                )}
              </div>
            </div>

            {/* Social Media Links */}
            <div className="mt-4">
              <SocialMediaLinks userId={profileUser.id} isOwnProfile={isOwnProfile} />
            </div>
          </CardContent>
        </Card>

        {/* Create Post (Own Profile Only) */}
        {isOwnProfile && (
          <Card className="mb-6">
            <CardContent className="p-4">
              <div className="space-y-3">
                <Textarea
                  placeholder="What's on your mind?"
                  value={newPost}
                  onChange={(e) => setNewPost(e.target.value)}
                  className="min-h-[80px]"
                />
                <div className="flex justify-between items-center">
                  <div className="flex gap-2">
                    <Button 
                      size="sm" 
                      variant="outline"
                      onClick={handleMediaUpload}
                    >
                      <Upload className="w-4 h-4 mr-1" />
                      Add Photos/Videos
                    </Button>
                  </div>
                  <Button 
                    onClick={() => createPostMutation.mutate(newPost)}
                    disabled={!newPost.trim() || createPostMutation.isPending}
                    className="bg-pink-600 text-white"
                  >
                    {createPostMutation.isPending ? 'Posting...' : 'Post'}
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Posts Feed */}
        <div className="space-y-4 mb-6">
          {Array.isArray(posts) && posts.length > 0 ? (
            posts.map((post: ProfilePost) => (
              <Card key={post.id}>
                <CardContent className="p-4">
                  <div className="flex items-start space-x-3 mb-3">
                    <div className="w-10 h-10 rounded-full overflow-hidden bg-gray-100">
                      {profileUser.profileImageUrl ? (
                        <img 
                          src={profileUser.profileImageUrl} 
                          alt={profileUser.name}
                          className="w-full h-full object-cover"
                        />
                      ) : (
                        <div className="w-full h-full bg-gradient-to-br from-blue-400 to-purple-500 flex items-center justify-center">
                          <span className="text-white font-bold text-sm">
                            {profileUser.name.charAt(0).toUpperCase()}
                          </span>
                        </div>
                      )}
                    </div>
                    <div>
                      <h3 className="font-semibold">{profileUser.name}</h3>
                      <p className="text-sm text-gray-500">
                        {new Date(post.createdAt).toLocaleDateString()}
                      </p>
                    </div>
                  </div>
                  
                  <p className="text-gray-900 mb-3">{post.content}</p>
                  
                  {/* Media display */}
                  {post.mediaUrl && (
                    <div className="mb-3 rounded-lg overflow-hidden">
                      {post.mediaType === 'video' ? (
                        <video controls className="w-full max-h-96 object-cover">
                          <source src={post.mediaUrl} type="video/mp4" />
                        </video>
                      ) : (
                        <img src={post.mediaUrl} alt="Post media" className="w-full max-h-96 object-cover" />
                      )}
                    </div>
                  )}
                  
                  <div className="flex items-center space-x-4 pt-2 border-t">
                    <Button variant="ghost" size="sm">
                      <Heart className="w-4 h-4 mr-1" />
                      {post.likes || 0}
                    </Button>
                    <Button variant="ghost" size="sm">
                      <MessageCircle className="w-4 h-4 mr-1" />
                      {post.comments || 0}
                    </Button>
                    <Button variant="ghost" size="sm">
                      <Share2 className="w-4 h-4 mr-1" />
                      Share
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))
          ) : (
            <Card>
              <CardContent className="p-6 text-center text-gray-500">
                {isOwnProfile ? "You haven't posted anything yet." : "No posts yet."}
              </CardContent>
            </Card>
          )}
        </div>

        {/* Single Unified Gallery Section */}
        <Card className="mb-6">
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-xl font-bold text-black">Photos & Videos</h2>
              {isOwnProfile && (
                <Button 
                  size="sm" 
                  onClick={handleMediaUpload}
                  className="bg-blue-600 text-white"
                >
                  <Plus className="w-4 h-4 mr-1" />
                  Add Media
                </Button>
              )}
            </div>

            {/* Gallery Grid */}
            {Array.isArray(galleryItems) && galleryItems.length > 0 ? (
              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
                {galleryItems.map((item: GalleryItem) => {
                  const isVideo = item.fileType.startsWith('video/');
                  const mediaUrl = `data:${item.fileType};base64,${item.fileData}`;

                  return (
                    <div
                      key={item.id}
                      className="relative aspect-square bg-gray-100 rounded-lg overflow-hidden group hover:shadow-lg transition-all cursor-pointer"
                    >
                      {isVideo ? (
                        <div className="relative w-full h-full">
                          <video
                            src={mediaUrl}
                            className="w-full h-full object-cover"
                            muted
                          />
                          <div className="absolute inset-0 bg-black/20 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                            <Video className="h-8 w-8 text-white" />
                          </div>
                          <div className="absolute top-2 right-2">
                            <Video className="h-4 w-4 text-white drop-shadow-lg" />
                          </div>
                        </div>
                      ) : (
                        <div className="relative w-full h-full">
                          <img
                            src={mediaUrl}
                            alt={item.caption || item.fileName}
                            className="w-full h-full object-cover"
                            loading="lazy"
                          />
                          <div className="absolute top-2 right-2">
                            <ImageIcon className="h-4 w-4 text-white drop-shadow-lg" />
                          </div>
                        </div>
                      )}

                      {/* Caption overlay */}
                      {item.caption && (
                        <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/70 to-transparent p-2">
                          <p className="text-white text-xs truncate">{item.caption}</p>
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            ) : (
              <div className="text-center py-12">
                <div className="text-gray-400 mb-4">
                  <ImageIcon className="h-16 w-16 mx-auto" />
                </div>
                <h3 className="text-lg font-medium text-gray-600 mb-2">No media yet</h3>
                <p className="text-gray-500">
                  {isOwnProfile 
                    ? "Upload your first photo or video to get started" 
                    : "This user hasn't shared any media yet"
                  }
                </p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Edit Profile Dialog */}
      <Dialog open={showEditProfile} onOpenChange={setShowEditProfile}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Edit Profile</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label htmlFor="name">Name</Label>
              <Input
                id="name"
                value={profileEditData.name}
                onChange={(e) => setProfileEditData(prev => ({ ...prev, name: e.target.value }))}
              />
            </div>
            <div>
              <Label htmlFor="bio">Bio</Label>
              <Textarea
                id="bio"
                value={profileEditData.bio}
                onChange={(e) => setProfileEditData(prev => ({ ...prev, bio: e.target.value }))}
              />
            </div>
            <div>
              <Label htmlFor="location">Location</Label>
              <Input
                id="location"
                value={profileEditData.location}
                onChange={(e) => setProfileEditData(prev => ({ ...prev, location: e.target.value }))}
              />
            </div>
            <div className="flex gap-2">
              <Button 
                onClick={() => updateProfileMutation.mutate(profileEditData)}
                disabled={updateProfileMutation.isPending}
              >
                {updateProfileMutation.isPending ? 'Saving...' : 'Save Changes'}
              </Button>
              <Button variant="outline" onClick={() => setShowEditProfile(false)}>
                Cancel
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Image Upload Dialog */}
      <Dialog open={showImageUpload} onOpenChange={setShowImageUpload}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Upload Profile Image</DialogTitle>
          </DialogHeader>
          <SimpleImageUpload
            onImageUploaded={handleImageUploaded}
            accept="image/*"
            className="w-full"
          />
        </DialogContent>
      </Dialog>
    </div>
  );
}