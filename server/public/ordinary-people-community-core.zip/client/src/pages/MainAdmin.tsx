import React, { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/useAuth";
import { 
  Shield, 
  Users, 
  FileText, 
  ShoppingBag, 
  AlertTriangle,
  Eye,
  Settings,
  Ban,
  CheckCircle,
  Trash2,
  Search
} from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { PageHeader } from "@/components/PageHeader";
import { User } from "@shared/schema";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";

function UserEditForm({ user }: { user: User }) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [formData, setFormData] = useState({
    name: user.name || "",
    email: user.email || "",
    bio: user.bio || "",
    location: user.location || "",
    isAdmin: user.isAdmin || false,
    isBlocked: user.isBlocked || false
  });

  const updateUserMutation = useMutation({
    mutationFn: async (data: any) => {
      const response = await apiRequest("PUT", `/api/admin/users/${user.id}`, data);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "User updated successfully",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/users"] });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to update user",
        variant: "destructive",
      });
    },
  });

  const handleSave = () => {
    updateUserMutation.mutate(formData);
  };

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <Label htmlFor="name">Name</Label>
          <Input
            id="name"
            value={formData.name}
            onChange={(e) => setFormData({ ...formData, name: e.target.value })}
            className="mt-1"
          />
        </div>
        <div>
          <Label htmlFor="email">Email</Label>
          <Input
            id="email"
            value={formData.email}
            onChange={(e) => setFormData({ ...formData, email: e.target.value })}
            className="mt-1"
          />
        </div>

      </div>

      <div>
        <Label htmlFor="bio">Bio</Label>
        <Textarea
          id="bio"
          value={formData.bio}
          onChange={(e) => setFormData({ ...formData, bio: e.target.value })}
          className="mt-1"
          rows={3}
        />
      </div>

      <div>
        <Label htmlFor="location">Location</Label>
        <Input
          id="location"
          value={formData.location}
          onChange={(e) => setFormData({ ...formData, location: e.target.value })}
          className="mt-1"
        />
      </div>

      <div className="flex items-center space-x-4">
        <label className="flex items-center space-x-2">
          <input
            type="checkbox"
            checked={formData.isAdmin}
            onChange={(e) => setFormData({ ...formData, isAdmin: e.target.checked })}
          />
          <span>Admin Access</span>
        </label>
        <label className="flex items-center space-x-2">
          <input
            type="checkbox"
            checked={formData.isBlocked}
            onChange={(e) => setFormData({ ...formData, isBlocked: e.target.checked })}
          />
          <span>Blocked</span>
        </label>
      </div>

      <div className="flex justify-end space-x-3 border-t pt-4">
        <Button variant="outline" onClick={() => window.location.reload()}>
          Cancel
        </Button>
        <Button 
          onClick={handleSave}
          disabled={updateUserMutation.isPending}
          className="bg-blue-600 hover:bg-blue-700"
        >
          {updateUserMutation.isPending ? "Saving..." : "Save Changes"}
        </Button>
      </div>
    </div>
  );
}

function UserManagementRow({ user }: { user: User }) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [blockReason, setBlockReason] = useState("");
  const [deleteReason, setDeleteReason] = useState("");

  const blockUserMutation = useMutation({
    mutationFn: async (data: { userId: number; reason: string }) => {
      const response = await apiRequest("POST", `/api/admin/users/${data.userId}/block`, { reason: data.reason });
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "User blocked successfully",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/users"] });
      setBlockReason("");
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to block user",
        variant: "destructive",
      });
    },
  });

  const unblockUserMutation = useMutation({
    mutationFn: async (userId: number) => {
      const response = await apiRequest("POST", `/api/admin/users/${userId}/unblock`, {});
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "User unblocked successfully",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/users"] });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to unblock user",
        variant: "destructive",
      });
    },
  });

  const deleteUserMutation = useMutation({
    mutationFn: async (data: { userId: number; reason: string }) => {
      const response = await apiRequest("DELETE", `/api/admin/users/${data.userId}`, { reason: data.reason });
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "User deleted successfully",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/users"] });
      setDeleteReason("");
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to delete user",
        variant: "destructive",
      });
    },
  });

  const handleBlockUser = () => {
    if (!blockReason.trim()) {
      toast({
        title: "Error",
        description: "Please provide a reason for blocking",
        variant: "destructive",
      });
      return;
    }
    blockUserMutation.mutate({ userId: user.id, reason: blockReason.trim() });
  };

  const handleUnblockUser = () => {
    unblockUserMutation.mutate(user.id);
  };

  const handleDeleteUser = () => {
    if (!deleteReason.trim()) {
      toast({
        title: "Error",
        description: "Please provide a reason for deletion",
        variant: "destructive",
      });
      return;
    }
    deleteUserMutation.mutate({ userId: user.id, reason: deleteReason.trim() });
  };

  return (
    <div className="p-4 border rounded-lg bg-white max-w-full">
      <div className="flex flex-col space-y-3 md:flex-row md:items-center md:justify-between md:space-y-0">
        <div className="flex items-center space-x-3 min-w-0 flex-1">
          <div className="w-12 h-12 bg-primary rounded-full flex items-center justify-center flex-shrink-0">
            <span className="text-white font-semibold text-sm">
              {user.name?.charAt(0) || user.email?.charAt(0) || "U"}
            </span>
          </div>
          <div className="min-w-0 flex-1">
            <div className="font-medium text-gray-900 truncate">{user.name || "Unnamed User"}</div>
            <div className="text-sm text-gray-500 truncate">{user.email}</div>
            <div className="text-xs text-gray-400">ID: {user.id}</div>
            <div className="flex gap-1 mt-1 md:hidden">
              {user.isAdmin && (
                <Badge variant="destructive" className="bg-red-100 text-red-800 text-xs">Admin</Badge>
              )}
              {user.isBlocked && (
                <Badge variant="secondary" className="bg-gray-100 text-gray-800 text-xs">Blocked</Badge>
              )}
            </div>
          </div>
        </div>
        
        <div className="flex flex-col space-y-2 md:flex-row md:items-center md:space-y-0 md:space-x-2">
          <div className="hidden md:flex items-center space-x-2">
            {user.isAdmin && (
              <Badge variant="destructive" className="bg-red-100 text-red-800">Admin</Badge>
            )}
            {user.isBlocked && (
              <Badge variant="secondary" className="bg-gray-100 text-gray-800">Blocked</Badge>
            )}
          </div>
          
          <div className="flex flex-wrap gap-2">
            <Button 
              variant="outline" 
              size="sm"
              onClick={() => window.open(`/users/${user.id}`, '_blank')}
              className="flex items-center gap-1 text-xs px-2 py-1"
            >
              <Eye className="w-3 h-3" />
              View
            </Button>

            <Button 
              variant="outline" 
              size="sm"
              onClick={() => window.open(`/profile-wall/${user.id}`, '_blank')}
              className="flex items-center gap-1 text-xs px-2 py-1"
            >
              <FileText className="w-3 h-3" />
              Posts
            </Button>

            <Dialog>
              <DialogTrigger asChild>
                <Button variant="outline" size="sm" className="text-blue-600 hover:bg-blue-50 text-xs px-2 py-1">
                  <Settings className="w-3 h-3 mr-1" />
                  Edit
                </Button>
              </DialogTrigger>
              <DialogContent className="max-w-2xl">
                <DialogHeader>
                  <DialogTitle>Edit User: {user.name || user.email}</DialogTitle>
                </DialogHeader>
                <UserEditForm user={user} />
              </DialogContent>
            </Dialog>

            {!user.isBlocked ? (
              <Dialog>
                <DialogTrigger asChild>
                  <Button variant="outline" size="sm" className="text-orange-600 hover:bg-orange-50 text-xs px-2 py-1">
                    <Ban className="w-3 h-3 mr-1" />
                    Block
                  </Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>Block User: {user.name || user.email}</DialogTitle>
                  </DialogHeader>
                  <div className="space-y-4">
                    <div>
                      <Label htmlFor="blockReason">Reason for blocking</Label>
                      <Textarea
                        id="blockReason"
                        value={blockReason}
                        onChange={(e) => setBlockReason(e.target.value)}
                        placeholder="Enter reason for blocking this user..."
                        rows={3}
                        className="mt-2"
                      />
                    </div>
                    <div className="flex justify-end space-x-2">
                      <Button variant="outline">Cancel</Button>
                      <Button 
                        onClick={handleBlockUser}
                        disabled={blockUserMutation.isPending || !blockReason.trim()}
                        className="bg-orange-600 hover:bg-orange-700"
                      >
                        {blockUserMutation.isPending ? "Blocking..." : "Block User"}
                      </Button>
                    </div>
                  </div>
                </DialogContent>
              </Dialog>
            ) : (
              <Button 
                variant="outline" 
                size="sm" 
                onClick={handleUnblockUser}
                disabled={unblockUserMutation.isPending}
                className="text-green-600 hover:bg-green-50 text-xs px-2 py-1"
              >
                <CheckCircle className="w-3 h-3 mr-1" />
                {unblockUserMutation.isPending ? "Unblocking..." : "Unblock"}
              </Button>
            )}

            <AlertDialog>
              <AlertDialogTrigger asChild>
                <Button variant="outline" size="sm" className="text-red-600 hover:bg-red-50 text-xs px-2 py-1">
                  <Trash2 className="w-3 h-3 mr-1" />
                  Delete
                </Button>
              </AlertDialogTrigger>
              <AlertDialogContent>
                <AlertDialogHeader>
                  <AlertDialogTitle>Delete User: {user.name || user.email}</AlertDialogTitle>
                  <AlertDialogDescription>
                    This action will permanently delete the user and all their content. This cannot be undone.
                  </AlertDialogDescription>
                </AlertDialogHeader>
                <div className="my-4">
                  <Label htmlFor="deleteReason">Reason for deletion (required)</Label>
                  <Textarea
                    id="deleteReason"
                    value={deleteReason}
                    onChange={(e) => setDeleteReason(e.target.value)}
                    placeholder="Enter reason for deleting this user..."
                    rows={3}
                    className="mt-2"
                  />
                </div>
                <AlertDialogFooter>
                  <AlertDialogCancel onClick={() => setDeleteReason("")}>Cancel</AlertDialogCancel>
                  <AlertDialogAction 
                    onClick={handleDeleteUser}
                    disabled={deleteUserMutation.isPending || !deleteReason.trim()}
                    className="bg-red-600 hover:bg-red-700"
                  >
                    {deleteUserMutation.isPending ? "Deleting..." : "Delete User"}
                  </AlertDialogAction>
                </AlertDialogFooter>
              </AlertDialogContent>
            </AlertDialog>
          </div>
        </div>
      </div>
    </div>
  );
}

export default function MainAdmin() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const { appUser, loading } = useAuth();
  const [searchQuery, setSearchQuery] = useState("");

  // Check for development blocking on component mount and periodically
  React.useEffect(() => {
    const checkDevelopmentBlock = () => {
      const blockData = localStorage.getItem('developmentBlocked');
      if (blockData) {
        const { blocked } = JSON.parse(blockData);
        if (blocked) {
          window.location.href = '/development-gate.html';
          return true;
        }
      }
      return false;
    };

    // Check immediately
    checkDevelopmentBlock();

    // Check every 5 seconds during development session
    const interval = setInterval(checkDevelopmentBlock, 5000);

    return () => clearInterval(interval);
  }, []);

  const { data: users = [] } = useQuery<User[]>({
    queryKey: ["/api/admin/users"],
  });

  const { data: posts = [] } = useQuery<any[]>({
    queryKey: ["/api/admin/posts"],
  });

  const { data: products = [] } = useQuery<any[]>({
    queryKey: ["/api/admin/products"],
  });

  const { data: blogs = [] } = useQuery<any[]>({
    queryKey: ["/api/admin/blogs"],
  });

  const { data: reports = [] } = useQuery<any[]>({
    queryKey: ["/api/admin/reports"],
  });

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="w-16 h-16 bg-primary rounded-xl flex items-center justify-center mx-auto mb-4">
            <Shield className="w-8 h-8 text-white" />
          </div>
          <h2 className="text-xl font-semibold text-gray-900 mb-2">Verifying Admin Access</h2>
          <div className="animate-spin w-6 h-6 border-2 border-primary border-t-transparent rounded-full mx-auto"></div>
        </div>
      </div>
    );
  }

  if (!appUser) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="w-16 h-16 bg-red-100 rounded-xl flex items-center justify-center mx-auto mb-4">
            <Shield className="w-8 h-8 text-red-600" />
          </div>
          <h2 className="text-xl font-semibold text-gray-900 mb-2">Access Denied</h2>
          <p className="text-gray-600 mb-4">Please sign in to continue</p>
          <a href="/login" className="text-primary hover:text-primary/80">
            Go to login page
          </a>
        </div>
      </div>
    );
  }

  if (!appUser.isAdmin) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="w-16 h-16 bg-red-100 rounded-xl flex items-center justify-center mx-auto mb-4">
            <Shield className="w-8 h-8 text-red-600" />
          </div>
          <h2 className="text-xl font-semibold text-gray-900 mb-2">Admin Access Required</h2>
          <p className="text-gray-600 mb-4">You need administrator privileges to access this page</p>
          <a href="/" className="text-primary hover:text-primary/80">
            Return to dashboard
          </a>
        </div>
      </div>
    );
  }

  const filteredUsers = users.filter(user =>
    user.name?.toLowerCase().includes(searchQuery.toLowerCase()) ||
    user.email?.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="min-h-screen bg-gray-50">
      <PageHeader title="Administrator Panel" />
      
      <div className="max-w-7xl mx-auto px-4 py-8 space-y-6">
        <div className="bg-gradient-to-r from-blue-100 to-purple-100 border border-blue-200 rounded-lg p-4">
          <div className="flex items-center gap-2 mb-2">
            <Shield className="w-5 h-5 text-blue-600" />
            <h3 className="font-semibold text-blue-800">Administrator Panel</h3>
          </div>
          <p className="text-blue-700 text-sm">
            You have administrative access to manage the Ordinary People Community platform.
            Use these tools responsibly to maintain community standards.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          <Card>
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <CardTitle className="text-sm font-medium text-gray-600">Daily Spending</CardTitle>
                <Users className="w-4 h-4 text-green-600" />
              </div>
            </CardHeader>
            <CardContent>
              <div className="mb-3">
                <Button 
                  className="w-full bg-green-600 hover:bg-green-700 text-white"
                  onClick={() => window.open('/daily-spending-tracker.html', '_blank')}
                >
                  Today's Total Spending
                </Button>
              </div>
              <p className="text-xs text-gray-500">Monitor development costs at £0.10/min</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <CardTitle className="text-sm font-medium text-gray-600">Total Users</CardTitle>
                <Users className="w-4 h-4 text-blue-600" />
              </div>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-gray-900">{users.length}</div>
              <p className="text-xs text-gray-500">Registered community members</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <CardTitle className="text-sm font-medium text-gray-600">Profile Posts</CardTitle>
                <FileText className="w-4 h-4 text-green-600" />
              </div>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-gray-900">{posts.length}</div>
              <p className="text-xs text-gray-500">User profile wall posts</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <CardTitle className="text-sm font-medium text-gray-600">Shop Products</CardTitle>
                <ShoppingBag className="w-4 h-4 text-purple-600" />
              </div>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-gray-900">{products.length}</div>
              <p className="text-xs text-gray-500">Active supplement products</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <CardTitle className="text-sm font-medium text-gray-600">Reports</CardTitle>
                <AlertTriangle className="w-4 h-4 text-red-600" />
              </div>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-gray-900">{reports.length}</div>
              <p className="text-xs text-gray-500">Community reports pending</p>
            </CardContent>
          </Card>
        </div>

        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <div>
                <CardTitle>User Management</CardTitle>
                <CardDescription>Manage community members and their content</CardDescription>
              </div>
              <div className="flex items-center space-x-2">
                <Search className="w-4 h-4 text-gray-400" />
                <Input
                  placeholder="Search users..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-64 bg-white border-gray-300 focus:border-blue-500 focus:ring-blue-500"
                  autoComplete="off"
                />
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {searchQuery && (
                <div className="text-sm text-gray-600 mb-4">
                  Found {filteredUsers.length} user{filteredUsers.length !== 1 ? 's' : ''} matching "{searchQuery}"
                </div>
              )}
              {filteredUsers.slice(0, 10).map((user) => (
                <UserManagementRow key={user.id} user={user} />
              ))}
              {filteredUsers.length === 0 && searchQuery && (
                <div className="text-center py-8">
                  <div className="text-gray-400 mb-2">No users found</div>
                  <div className="text-sm text-gray-500">Try adjusting your search terms</div>
                </div>
              )}
              {filteredUsers.length > 10 && (
                <div className="text-sm text-gray-500 text-center pt-4">
                  Showing first 10 of {filteredUsers.length} results
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}