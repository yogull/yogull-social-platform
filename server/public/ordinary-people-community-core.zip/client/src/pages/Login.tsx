import { useLocation } from "wouter";
import { LoginForm } from "@/components/LoginForm";
import { Card, CardContent } from "@/components/ui/card";
import { SupportBanner } from "@/components/SupportBanner";
import { LanguageSelector } from "@/components/LanguageSelector";
import { PageHelpSystem } from "@/components/PageHelpSystem";
import { useTranslation } from "@/hooks/useTranslation";
import { SEO } from "@/components/SEO";
import { StructuredData, organizationSchema, healthPlatformSchema } from "@/components/StructuredData";
import { Heart, Users, MessageCircle, Shield, Globe, Lightbulb } from "lucide-react";

export default function Login() {
  const [, setLocation] = useLocation();
  const { t } = useTranslation();

  const handleSuccess = () => {
    setLocation("/dashboard");
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 to-blue-50 mobile-safe p-2 sm:p-4 overflow-x-hidden">
      {/* Page Help System */}
      <PageHelpSystem currentPage="login" />
      
      {/* Language Selector in top-right */}
      <div className="absolute top-4 right-4 z-10">
        <LanguageSelector />
      </div>
      
      <SEO 
        title="Login to GoHealMe - The People's Health Community"
        description="Access your personal health dashboard on GoHealMe. Track supplements, monitor biometrics, and connect with a community that puts your wellbeing first - away from healthcare elites."
        keywords={[
          'gohealme login', 'health tracking login', 'supplement tracker signin',
          'wellness community access', 'health dashboard login', 'peoples health platform',
          'alternative healthcare login', 'health freedom community', 'holistic wellness access'
        ]}
        type="website"
        url="https://gohealme.org/login"
      />
      <StructuredData data={organizationSchema} />
      <StructuredData data={healthPlatformSchema} />
      
      {/* Mobile Header - Only visible on mobile */}
      <div className="lg:hidden text-center mb-6 pt-4">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">
          {t('login.welcomeTo')} <span className="text-green-600">{t('login.communityName')}</span>
        </h1>
        <p className="text-lg text-gray-600">
          {t('login.awayFromElites')}
        </p>
      </div>

      <div className="max-w-6xl w-full ml-auto mr-4 grid lg:grid-cols-2 gap-8 items-start lg:items-center min-h-0">
        {/* Platform Description */}
        <div className="space-y-6 hidden lg:block">
          <div className="text-center lg:text-left">
            <h1 className="text-4xl lg:text-5xl font-bold text-gray-900 mb-4">
              {t('login.welcomeTo')} <span className="text-green-600">{t('login.communityName')}</span>
            </h1>
            <p className="text-xl text-gray-600 mb-6">
              {t('login.awayFromElites')}
            </p>
          </div>

          <Card className="bg-white/80 backdrop-blur-sm border-green-200">
            <CardContent className="p-6">
              <h2 className="text-2xl font-semibold text-gray-900 mb-4">
                Connect. Share. Heal Together.
              </h2>
              <p className="text-gray-700 mb-4">
                Join thousands of health-conscious individuals who believe in the power of community healing. 
                The People's Health Community is where real people share real experiences about supplements, natural remedies, 
                exercise routines, and wellness journeys - without corporate influence or elite gatekeeping.
              </p>
              
              <div className="grid md:grid-cols-2 gap-4 mt-6">
                <div className="flex items-start space-x-3">
                  <Heart className="w-6 h-6 text-red-500 mt-1" />
                  <div>
                    <h3 className="font-semibold text-gray-900">Share Your Journey</h3>
                    <p className="text-sm text-gray-600">Document your supplement regimens, track your energy levels, and share what works for your body.</p>
                  </div>
                </div>
                
                <div className="flex items-start space-x-3">
                  <Users className="w-6 h-6 text-blue-500 mt-1" />
                  <div>
                    <h3 className="font-semibold text-gray-900">Connect with Others</h3>
                    <p className="text-sm text-gray-600">Find people with similar health challenges and learn from their experiences and solutions.</p>
                  </div>
                </div>
                
                <div className="flex items-start space-x-3">
                  <MessageCircle className="w-6 h-6 text-green-500 mt-1" />
                  <div>
                    <h3 className="font-semibold text-gray-900">Real Advice</h3>
                    <p className="text-sm text-gray-600">Get honest feedback about supplements, rest patterns, and exercise routines from people who've tried them.</p>
                  </div>
                </div>
                
                <div className="flex items-start space-x-3">
                  <Shield className="w-6 h-6 text-purple-500 mt-1" />
                  <div>
                    <h3 className="font-semibold text-gray-900">Safe Space</h3>
                    <p className="text-sm text-gray-600">Discuss health topics freely, including sensitive issues like EMF illness, brain injuries, and alternative treatments.</p>
                  </div>
                </div>
                
                <div className="flex items-start space-x-3">
                  <Globe className="w-6 h-6 text-indigo-500 mt-1" />
                  <div>
                    <h3 className="font-semibold text-gray-900">Global Community</h3>
                    <p className="text-sm text-gray-600">Connect with like-minded people worldwide who prioritize natural health and wellness solutions.</p>
                  </div>
                </div>
                
                <div className="flex items-start space-x-3">
                  <Lightbulb className="w-6 h-6 text-yellow-500 mt-1" />
                  <div>
                    <h3 className="font-semibold text-gray-900">Discover Solutions</h3>
                    <p className="text-sm text-gray-600">Learn about innovative approaches to health that you won't find in mainstream medical advice.</p>
                  </div>
                </div>
              </div>

              <div className="mt-6 p-4 bg-green-50 rounded-lg border border-green-200">
                <h3 className="font-semibold text-green-800 mb-2">Why GoHealMe?</h3>
                <ul className="text-sm text-green-700 space-y-1">
                  <li>• No pharmaceutical influence or corporate agenda</li>
                  <li>• Share experiences with supplements, dosages, and timing</li>
                  <li>• Track your rest patterns and energy levels</li>
                  <li>• Connect with people facing similar health challenges</li>
                  <li>• Access comprehensive illness information and support</li>
                  <li>• Build meaningful relationships around wellness</li>
                </ul>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Login Form */}
        <div className="lg:pl-8">
          {/* Support Banner above sign-in */}
          <div className="mb-6">
            <SupportBanner />
          </div>
          
          <LoginForm onSuccess={handleSuccess} />
        </div>
      </div>
    </div>
  );
}
