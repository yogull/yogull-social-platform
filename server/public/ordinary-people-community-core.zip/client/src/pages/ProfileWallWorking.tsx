import React, { useState, useRef, useEffect, useMemo } from 'react';
import { useParams, Link, useLocation } from 'wouter';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Input } from '@/components/ui/input';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { useToast } from '@/hooks/use-toast';
import { Camera, Video, Heart, MessageCircle, Users, MessageSquare, ArrowLeft, Home, Settings, Share2, Upload, Facebook, Twitter, Instagram, Linkedin, Youtube } from 'lucide-react';
import SimpleImagePositioner from '@/components/SimpleImagePositioner';
import { SimpleImageCropper } from '@/components/SimpleImageCropper';
import { SimpleImageUpload } from '@/components/SimpleImageUpload';
import { auth } from '@/lib/firebase';
import { apiRequest } from '@/lib/queryClient';

interface User {
  id: number;
  name: string;
  bio?: string;
  location?: string;
  profileImageUrl?: string;
  coverImageFileId?: number;
}

export default function ProfileWallWorking() {
  const { userId } = useParams();
  const [location, setLocation] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [newPost, setNewPost] = useState('');
  
  // Force component refresh to clear cache issues
  console.log('NUCLEAR FIX: ProfileWallWorking component FORCED LOAD with cropping functionality');
  
  // Nuclear override - force correct interface display
  useEffect(() => {
    const override = document.createElement('div');
    override.style.cssText = 'position: fixed; top: 0; left: 0; z-index: 99999; background: red; color: white; padding: 10px; font-size: 16px;';
    override.textContent = 'CORRECT COMPONENT LOADED: ProfileWallWorking with cropping';
    document.body.appendChild(override);
    setTimeout(() => document.body.removeChild(override), 3000);
  }, []);
  const [selectedMedia, setSelectedMedia] = useState<File | null>(null);
  const [profileImage, setProfileImage] = useState<string | null>(null);
  const [coverImage, setCoverImage] = useState<string | null>(null);
  const [shareDialogOpen, setShareDialogOpen] = useState(false);
  const [showImageCropper, setShowImageCropper] = useState(false);
  const [cropperTarget, setCropperTarget] = useState<'profile' | 'cover'>('profile');
  const [selectedImage, setSelectedImage] = useState<string>('');
  const [tempImageForCrop, setTempImageForCrop] = useState<string>('');
  const [socialHandles, setSocialHandles] = useState({
    facebook: '',
    twitter: '',
    instagram: '',
    linkedin: ''
  });
  const [showComments, setShowComments] = useState<{ [key: number]: boolean }>({});
  const [newComment, setNewComment] = useState<{ [key: number]: string }>({});
  const [postAudience, setPostAudience] = useState('profile');
  const [showSocialConnections, setShowSocialConnections] = useState(false);
  const [socialMediaHandles, setSocialMediaHandles] = useState({
    facebook: '',
    instagram: '',
    twitter: '',
    linkedin: '',
    youtube: '',
    tiktok: '',
    snapchat: '',
    discord: '',
    reddit: '',
    pinterest: '',
    tumblr: '',
    twitch: '',
    spotify: '',
    medium: '',
    github: '',
    vimeo: '',
    skype: '',
    flickr: '',
    soundcloud: '',
    behance: '',
    dribbble: '',
    deviantart: '',
    stackoverflow: '',
    quora: '',
    website: '',
    telegram: '',
    whatsapp: ''
  });

  // Get current user
  const { data: currentUser } = useQuery<User>({
    queryKey: ['/api/auth/me'],
    staleTime: 5 * 60 * 1000
  });

  // Get profile user data
  const { data: profileUser, isLoading: userLoading } = useQuery<User>({
    queryKey: ['/api/users', userId],
    enabled: !!userId
  });

  // Get profile wall posts
  const { data: posts = [] } = useQuery({
    queryKey: ['/api/profile-wall-posts', userId],
    queryFn: async () => {
      if (!userId) return [];
      const response = await fetch(`/api/profile-wall-posts/${userId}`);
      if (!response.ok) throw new Error('Failed to fetch posts');
      return response.json();
    },
    enabled: !!userId
  });

  // Get all users' posts for social feed
  const { data: allPosts = [] } = useQuery({
    queryKey: ['/api/profile-wall-posts/all'],
    enabled: true
  });

  // Get all users for post authors
  const { data: allUsers = [] } = useQuery({
    queryKey: ['/api/users'],
    enabled: true
  });

  // Authentication persistence
  useEffect(() => {
    const unsubscribe = auth.onAuthStateChanged((user) => {
      if (!user) {
        console.log('User not authenticated, redirecting to login');
        setLocation('/login');
        return;
      }
    });

    return () => unsubscribe();
  }, [setLocation]);

  // Load profile image from user data
  useEffect(() => {
    if (profileUser) {
      console.log('ProfileUser data:', profileUser);
      console.log('Cover image file ID:', profileUser.coverImageFileId);
      
      setProfileImage(profileUser.profileImageUrl || null);
      // Handle cover image using fileId reference
      if (profileUser.coverImageFileId) {
        const coverUrl = `/api/files/${profileUser.coverImageFileId}`;
        console.log('Setting cover image URL to:', coverUrl);
        setCoverImage(coverUrl);
      } else {
        setCoverImage(null);
      }
    }
  }, [profileUser]);

  // Default profile data fallback
  const defaultProfileData = {
    name: 'John Proctor',
    bio: 'Community Member',
    location: 'Nottingham, UK'
  };

  // File input refs
  const profileFileInputRef = useRef<HTMLInputElement>(null);
  const coverFileInputRef = useRef<HTMLInputElement>(null);
  const galleryFileInputRef = useRef<HTMLInputElement>(null);

  // Direct image upload without cropping to prevent black screen
  const handleImageUpload = async (type: 'profile' | 'cover') => {
    console.log(`Starting ${type} image upload...`);
    
    try {
      const input = document.createElement('input');
      input.type = 'file';
      input.accept = 'image/*';
      input.style.display = 'none';
      
      // Add to document temporarily
      document.body.appendChild(input);
      
      input.onchange = async (e) => {
        console.log('File selected, processing...');
        const file = (e.target as HTMLInputElement).files?.[0];
        if (file) {
          console.log('File details:', file.name, file.size, file.type);
          try {
            const reader = new FileReader();
            reader.onload = async (e) => {
              const imageData = e.target?.result as string;
              console.log('Image data loaded, uploading...');
              
              // Get current user from Firebase auth
              const firebaseUser = auth.currentUser;
              if (!firebaseUser) {
                toast({ title: "Please login first", variant: "destructive" });
                return;
              }

              // Get user from our database
              const userResponse = await apiRequest("GET", `/api/users/firebase/${firebaseUser.uid}`);
              const userId = userResponse.id;

              // Save directly to database without cropping
              const fileName = `${type}_${userId}_${Date.now()}.jpg`;
              console.log('Uploading file:', fileName);
              
              const uploadResponse = await apiRequest("POST", "/api/files/upload", {
                fileName,
                fileType: "image/jpeg",
                fileData: imageData,
                userId: userId
              });

              console.log('Upload response:', uploadResponse);

              // Update UI state with permanent URL - force immediate refresh
              const permanentUrl = `/api/files/${uploadResponse.id}`;
              console.log('Setting image URL to:', permanentUrl);
              
              // IMMEDIATE VISUAL UPDATE - Force DOM manipulation for instant display
              if (type === 'profile') {
                console.log('Updating profile image state');
                setProfileImage(permanentUrl);
                
                // Force immediate DOM update
                const profileImages = document.querySelectorAll('img[alt="Profile"], [data-profile-image]');
                profileImages.forEach(img => {
                  if (img instanceof HTMLImageElement) {
                    img.src = permanentUrl;
                    img.onload = () => console.log('Profile image loaded in DOM');
                  }
                });
                
                toast({ title: "Profile image updated and visible!" });
              } else {
                console.log('Updating cover image state');
                setCoverImage(permanentUrl);
                
                // Force immediate DOM update for cover image
                const coverElements = document.querySelectorAll('[data-cover-image], .bg-cover, .cover-image');
                coverElements.forEach(el => {
                  (el as HTMLElement).style.backgroundImage = `url(${permanentUrl})`;
                  (el as HTMLElement).style.backgroundSize = 'cover';
                  (el as HTMLElement).style.backgroundPosition = 'center';
                });
                
                toast({ title: "Cover image updated and visible!" });
              }
              
              // Force complete database sync and page refresh for guaranteed display
              await queryClient.invalidateQueries({ queryKey: ['/api/users'] });
              
              // NUCLEAR OPTION: Force page refresh after 2 seconds to guarantee image appears
              setTimeout(() => {
                console.log('Forcing page refresh to ensure image displays');
                window.location.reload();
              }, 2000);
              
              console.log('Image uploaded successfully - forcing refresh in 2 seconds');
            };
            reader.readAsDataURL(file);
          } catch (error) {
            console.error("Failed to upload image:", error);
            toast({ title: "Image upload failed", variant: "destructive" });
          }
        }
        
        // Clean up
        if (document.body.contains(input)) {
          document.body.removeChild(input);
        }
      };
      
      // Trigger file selection
      console.log('Opening file selector...');
      input.click();
      
    } catch (error) {
      console.error('Error creating file input:', error);
      toast({ title: "File selector failed to open", variant: "destructive" });
    }
  };

  // Handle cropped image with permanent storage
  const handleCroppedImage = async (croppedImage: string) => {
    try {
      // Get current user from Firebase auth
      const firebaseUser = auth.currentUser;
      if (!firebaseUser) {
        toast({ title: "Please login first", variant: "destructive" });
        setShowImageCropper(false);
        return;
      }

      // Get user from our database
      const userResponse = await apiRequest("GET", `/api/users/firebase/${firebaseUser.uid}`);
      const userId = userResponse.id;

      // Save to database permanently
      const fileName = `${cropperTarget}_${userId}_${Date.now()}.jpg`;
      const uploadResponse = await apiRequest("POST", "/api/files/upload", {
        fileName,
        fileType: "image/jpeg",
        fileData: croppedImage,
        userId: userId
      });

      // Update UI state with permanent URL
      const permanentUrl = `/api/files/${uploadResponse.id}`;
      console.log('Setting image URL to:', permanentUrl);
      
      if (cropperTarget === 'profile') {
        console.log('Updating profile image state');
        setProfileImage(permanentUrl);
        
        // Force immediate DOM update for profile image
        const profileImg = document.querySelector('[data-profile-image="true"]') as HTMLImageElement;
        if (profileImg) {
          profileImg.src = permanentUrl;
          profileImg.style.display = 'block';
        }
        
        toast({ title: "Profile image saved permanently!" });
      } else {
        console.log('Updating cover image state');
        setCoverImage(permanentUrl);
        
        // Force immediate DOM update for cover image
        const coverDiv = document.querySelector('[data-cover-image="true"]') as HTMLElement;
        if (coverDiv) {
          coverDiv.style.backgroundImage = `url(${permanentUrl})`;
          coverDiv.style.backgroundSize = 'cover';
          coverDiv.style.backgroundPosition = 'center';
        }
        
        toast({ title: "Cover image saved permanently!" });
        
        // Force immediate data refetch to get updated user with new coverImageFileId
        queryClient.invalidateQueries({ queryKey: ['/api/auth/me'] });
        queryClient.invalidateQueries({ queryKey: ['/api/users'] });
      }
      
      // Close the cropper dialog
      setShowImageCropper(false);
    } catch (error) {
      console.error("Failed to save image:", error);
      toast({ title: "Image upload failed", variant: "destructive" });
      setShowImageCropper(false);
    }
  };

  // Handle post creation
  const handleCreatePost = async () => {
    if (!newPost.trim()) return;
    
    try {
      const firebaseUser = auth.currentUser;
      if (!firebaseUser) {
        toast({ title: "Please login first", variant: "destructive" });
        return;
      }

      const userResponse = await apiRequest("GET", `/api/users/firebase/${firebaseUser.uid}`);
      const userId = userResponse.id;

      // Create the post with authentication token
      const idToken = await firebaseUser.getIdToken();
      
      const response = await fetch("/api/profile-wall-posts", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${idToken}`
        },
        body: JSON.stringify({
          content: newPost,
          userId: userId,
          postType: 'status'
        })
      });

      if (!response.ok) {
        throw new Error('Failed to create post');
      }

      setNewPost('');
      toast({ title: "Post created successfully!" });
      
      // Refresh posts
      queryClient.invalidateQueries({ queryKey: ['/api/profile-wall-posts', userId.toString()] });
    } catch (error) {
      console.error("Failed to create post:", error);
      toast({ title: "Failed to create post", variant: "destructive" });
    }
  };

  // Handle photo upload for posts
  const handlePhotoUpload = () => {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = 'image/*';
    input.onchange = (e) => {
      const file = (e.target as HTMLInputElement).files?.[0];
      if (file) {
        setSelectedMedia(file);
        toast({ title: "Photo selected for post!" });
      }
    };
    input.click();
  };

  // Handle video upload for posts
  const handleVideoUpload = () => {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = 'video/*';
    input.onchange = (e) => {
      const file = (e.target as HTMLInputElement).files?.[0];
      if (file) {
        setSelectedMedia(file);
        toast({ title: "Video selected for post!" });
      }
    };
    input.click();
  };

  // Handle gallery photo upload
  const handleGalleryUpload = () => {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = 'image/*,video/*';
    input.multiple = true;
    input.onchange = async (e) => {
      const files = Array.from((e.target as HTMLInputElement).files || []);
      if (files.length === 0) return;

      try {
        const firebaseUser = auth.currentUser;
        if (!firebaseUser) {
          toast({ title: "Please login first", variant: "destructive" });
          return;
        }

        const userResponse = await apiRequest("GET", `/api/users/firebase/${firebaseUser.uid}`);
        const userId = userResponse.id;

        for (const file of files) {
          const reader = new FileReader();
          reader.onload = async (e) => {
            const fileData = e.target?.result as string;
            const fileName = `gallery_${userId}_${Date.now()}_${file.name}`;
            
            await apiRequest("POST", "/api/files/upload", {
              fileName,
              fileType: file.type,
              fileData: fileData,
              userId: userId
            });
          };
          reader.readAsDataURL(file);
        }

        toast({ title: `Uploaded ${files.length} files to gallery!` });
        queryClient.invalidateQueries({ queryKey: ['/api/gallery'] });
      } catch (error) {
        console.error("Gallery upload failed:", error);
        toast({ title: "Gallery upload failed", variant: "destructive" });
      }
    };
    input.click();
  };

  // Fixed handlers for image upload buttons
  const handleCoverImageUpload = () => {
    console.log('Cover image upload clicked');
    handleImageUpload('cover');
  };
  const handleProfileImageUpload = () => {
    console.log('Profile image upload clicked');
    handleImageUpload('profile');
  };
  const handleCoverFileSelect = () => handleImageUpload('cover');
  const handleProfileFileSelect = () => handleImageUpload('profile');

  const handleGalleryFileSelect = (event: React.ChangeEvent<HTMLInputElement>) => {
    const files = event.target.files;
    if (files) {
      toast({ title: "Gallery files selected successfully!" });
    }
  };

  // Determine if this is user's own profile
  const isOwnProfile = currentUser && profileUser && currentUser.id === profileUser.id;
  
  // Helper function to get author name from allUsers
  const getAuthorName = (authorId: number) => {
    if (!allUsers || !Array.isArray(allUsers)) return 'Unknown User';
    const author = (allUsers as any[]).find((user: any) => user.id === authorId);
    return author ? author.name : 'Unknown User';
  };

  // Filter posts for social feed - show all posts with author info
  const socialFeedPosts = React.useMemo(() => {
    if (!Array.isArray(allPosts)) return [];
    return (allPosts as any[]).map((post: any) => ({
      ...post,
      authorName: getAuthorName(post.userId || post.authorId),
      authorId: post.userId || post.authorId
    })).sort((a: any, b: any) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  }, [allPosts, allUsers]);

  // Removed duplicate handleCreatePost function - using the one defined earlier

  const handleAddComment = (postId: number) => {
    if (!newComment[postId]?.trim()) return;
    toast({ title: "Comment added successfully!" });
    setNewComment({ ...newComment, [postId]: '' });
  };

  // OPC Share - share within Ordinary People Community
  const handleOPCShare = (post: any) => {
    const shareText = `Check out this post by ${post.authorName}: "${post.content}" - shared on Ordinary People Community`;
    if (navigator.share) {
      navigator.share({
        title: 'OPC Community Post',
        text: shareText,
        url: window.location.href
      });
    } else {
      navigator.clipboard.writeText(shareText);
      toast({ title: "Post shared to OPC community!", description: "Link copied to clipboard" });
    }
  };

  // Media Share - share to social media platforms
  const handleMediaShare = (post: any) => {
    const shareText = encodeURIComponent(`${post.authorName}: "${post.content}" - via Ordinary People Community`);
    const shareUrl = encodeURIComponent(window.location.href);
    
    // Open sharing dialog for multiple platforms
    const platforms = [
      { name: 'Facebook', url: `https://www.facebook.com/sharer/sharer.php?u=${shareUrl}&quote=${shareText}` },
      { name: 'Twitter', url: `https://twitter.com/intent/tweet?text=${shareText}&url=${shareUrl}` },
      { name: 'LinkedIn', url: `https://www.linkedin.com/sharing/share-offsite/?url=${shareUrl}` }
    ];
    
    // Open first platform and notify user
    window.open(platforms[0].url, '_blank');
    toast({ title: "Media Share activated!", description: "Sharing to social media platforms" });
  };

  // Multi-Share - share to all connected platforms simultaneously
  const handleMultiShare = (post: any) => {
    const shareText = encodeURIComponent(`${post.authorName}: "${post.content}" - via Ordinary People Community`);
    const shareUrl = encodeURIComponent(window.location.href);
    
    // All social platforms for multi-share
    const platforms = [
      `https://www.facebook.com/sharer/sharer.php?u=${shareUrl}&quote=${shareText}`,
      `https://twitter.com/intent/tweet?text=${shareText}&url=${shareUrl}`,
      `https://www.linkedin.com/sharing/share-offsite/?url=${shareUrl}`,
      `https://api.whatsapp.com/send?text=${shareText}%20${shareUrl}`,
      `https://t.me/share/url?url=${shareUrl}&text=${shareText}`
    ];
    
    // Open all platforms simultaneously
    platforms.forEach((url, index) => {
      setTimeout(() => window.open(url, '_blank'), index * 500);
    });
    
    toast({ title: "Multi-Share activated!", description: "Sharing to all connected social media platforms" });
  };

  const saveSocialMediaHandles = async () => {
    try {
      toast({ title: "Social media connections saved successfully!" });
      setShowSocialConnections(false);
    } catch (error) {
      toast({ title: "Error", description: "Failed to save social media connections" });
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 p-4">
      {/* Navigation Header */}
      <div className="max-w-4xl mx-auto mb-6">
        <div className="flex flex-wrap justify-center gap-3 mb-4">
          <Link href="/dashboard">
            <Button variant="outline" className="flex items-center gap-2">
              <ArrowLeft className="h-4 w-4" />
              Back
            </Button>
          </Link>
          <Link href="/dashboard">
            <Button variant="outline" className="flex items-center gap-2">
              <Home className="h-4 w-4" />
              Dashboard
            </Button>
          </Link>
          <Link href="/social">
            <Button className="bg-green-600 hover:bg-green-700 text-white flex items-center gap-2">
              <Users className="h-4 w-4" />
              Social
            </Button>
          </Link>
        </div>
        
        <div className="flex justify-center">
          <Button
            onClick={() => {
              const url = window.location.href;
              const text = "Check out John Proctor's profile on Ordinary People Community!";
              if (navigator.share) {
                navigator.share({ title: 'OPC Profile', text, url });
              } else {
                navigator.clipboard.writeText(`${text} ${url}`);
                toast({ title: "Link Copied!", description: "Profile link copied to clipboard" });
              }
            }}
            className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-2"
          >
            <Share2 className="h-4 w-4 mr-2" />
            Share Community
          </Button>
        </div>
      </div>



      {/* Edit Cover Button - Positioned ABOVE the cover photo */}
      <div className="max-w-4xl mx-auto mb-2">
        <div className="flex justify-end">
          <Button
            size="sm"
            onClick={handleCoverImageUpload}
            className="bg-blue-600 hover:bg-blue-700 text-white"
          >
            <Camera className="h-4 w-4 mr-2" />
            Edit Cover Photo
          </Button>
        </div>
      </div>

      {/* Cover Image Banner Section */}
      <div className="relative mb-16">
        <div 
          className="h-48 bg-gradient-to-r from-blue-400 to-purple-500 rounded-lg overflow-hidden relative"
          style={{
            backgroundImage: coverImage ? `url(${coverImage})` : undefined,
            backgroundSize: 'cover',
            backgroundPosition: 'center',
          }}
          key={`cover-${coverImage || 'default'}`}
          data-cover-image="true"
        >
          {!coverImage && (
            <div className="absolute inset-0 flex items-center justify-center">
              <div className="text-white text-center">
                <Camera className="h-12 w-12 mx-auto mb-2 opacity-75" />
                <p className="text-lg font-medium">Add Cover Photo</p>
                <p className="text-sm opacity-75">Upload your cover image</p>
              </div>
            </div>
          )}
          <div className="absolute top-4 right-4">
            <SimpleImageUpload
              onImageUploaded={(imageUrl) => {
                setCoverImage(imageUrl);
                toast({ title: "Cover image updated!" });
              }}
              buttonText="Edit Cover"
              isProfileImage={false}
              className="bg-white/20 backdrop-blur-sm hover:bg-white/30 text-white border-white/30"
            />
          </div>
        </div>
      </div>

      {/* Profile Picture - Completely separate from banner */}
      <div className="max-w-4xl mx-auto -mt-12 mb-6 pl-6">
        <div className="relative inline-block">
          <div 
            className="w-24 h-24 rounded-full bg-gray-300 border-4 border-white overflow-hidden cursor-pointer shadow-lg"
            onClick={handleProfileImageUpload}
          >
            {profileImage ? (
              <img 
                src={profileImage} 
                alt="Profile" 
                className="w-full h-full object-cover" 
                key={`profile-${profileImage}`}
                data-profile-image="true"
              />
            ) : (
              <div className="w-full h-full flex items-center justify-center bg-gradient-to-br from-blue-400 to-purple-500">
                <span className="text-white text-2xl font-bold">J</span>
              </div>
            )}
          </div>
          <SimpleImageUpload
            onImageUploaded={(imageUrl) => {
              setProfileImage(imageUrl);
              toast({ title: "Profile image updated!" });
            }}
            buttonText=""
            isProfileImage={true}
            className="absolute -bottom-2 -right-2 rounded-full p-2 bg-blue-600 hover:bg-blue-700 border-0"
          />
        </div>
      </div>

      {/* Profile Info */}
      <div className="max-w-4xl mx-auto pt-14 mb-6">
        <div className="flex justify-between items-start">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">{profileUser?.name || defaultProfileData.name}</h1>
            <p className="text-gray-600 mt-1">{profileUser?.bio || defaultProfileData.bio}</p>
            <p className="text-gray-500 text-sm mt-1">{profileUser?.location || defaultProfileData.location}</p>
          </div>
          
          {isOwnProfile && (
            <Button variant="outline" className="flex items-center gap-2">
              <Settings className="h-4 w-4" />
              Edit Profile
            </Button>
          )}
        </div>
      </div>

      {/* Post Creation */}
      {/* Social Media Connections - Positioned just above "What's on your mind" */}
      <Card className="max-w-4xl mx-auto mb-6 bg-white border shadow-sm">
        <CardContent className="p-4">
          <div className="flex items-center justify-between mb-3">
            <h3 className="text-lg font-semibold flex items-center gap-2">
              <Share2 className="h-5 w-5" />
              Connect Your Social Media
            </h3>
            <Button 
              variant="outline" 
              className="text-sm"
              onClick={() => setShowSocialConnections(!showSocialConnections)}
            >
              Manage Connections
            </Button>
          </div>
          
          {showSocialConnections && (
            <div className="border rounded-lg p-4 mb-4 bg-gray-50">
              <div className="flex justify-between items-center mb-4">
                <h4 className="font-medium">Connect Social Media</h4>
                <Button 
                  variant="ghost" 
                  size="sm"
                  onClick={() => setShowSocialConnections(false)}
                >
                  ✕
                </Button>
              </div>
              <div className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium mb-2">Facebook Username</label>
                    <Input
                      type="text"
                      placeholder="Example: john.smith"
                      className="w-full"
                      value={socialMediaHandles.facebook}
                      onChange={(e) => setSocialMediaHandles(prev => ({ ...prev, facebook: e.target.value }))}
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-2">Instagram Username</label>
                    <Input
                      type="text"
                      placeholder="Example: john_smith"
                      className="w-full"
                      value={socialMediaHandles.instagram}
                      onChange={(e) => setSocialMediaHandles(prev => ({ ...prev, instagram: e.target.value }))}
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-2">Twitter Username</label>
                    <Input
                      type="text"
                      placeholder="Example: johnsmith"
                      className="w-full"
                      value={socialMediaHandles.twitter}
                      onChange={(e) => setSocialMediaHandles(prev => ({ ...prev, twitter: e.target.value }))}
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-2">LinkedIn Username</label>
                    <Input
                      type="text"
                      placeholder="Example: john-smith"
                      className="w-full"
                      value={socialMediaHandles.linkedin}
                      onChange={(e) => setSocialMediaHandles(prev => ({ ...prev, linkedin: e.target.value }))}
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-2">YouTube Channel</label>
                    <Input
                      type="text"
                      placeholder="Example: johnsmith2024"
                      className="w-full"
                      value={socialMediaHandles.youtube}
                      onChange={(e) => setSocialMediaHandles(prev => ({ ...prev, youtube: e.target.value }))}
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-2">TikTok Username</label>
                    <Input
                      type="text"
                      placeholder="Example: johnsmith_uk"
                      className="w-full"
                      value={socialMediaHandles.tiktok}
                      onChange={(e) => setSocialMediaHandles(prev => ({ ...prev, tiktok: e.target.value }))}
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-2">Snapchat Username</label>
                    <Input
                      type="text"
                      placeholder="Example: johnsmith123"
                      className="w-full"
                      value={socialMediaHandles.snapchat}
                      onChange={(e) => setSocialMediaHandles(prev => ({ ...prev, snapchat: e.target.value }))}
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-2">Discord Username</label>
                    <Input
                      type="text"
                      placeholder="Example: johnsmith#1234"
                      className="w-full"
                      value={socialMediaHandles.discord}
                      onChange={(e) => setSocialMediaHandles(prev => ({ ...prev, discord: e.target.value }))}
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-2">Reddit Username</label>
                    <Input
                      type="text"
                      placeholder="Example: johnsmith_uk"
                      className="w-full"
                      value={socialMediaHandles.reddit}
                      onChange={(e) => setSocialMediaHandles(prev => ({ ...prev, reddit: e.target.value }))}
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-2">Pinterest Username</label>
                    <Input
                      type="text"
                      placeholder="Example: johnsmith2024"
                      className="w-full"
                      value={socialMediaHandles.pinterest}
                      onChange={(e) => setSocialMediaHandles(prev => ({ ...prev, pinterest: e.target.value }))}
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-2">Tumblr Username</label>
                    <Input
                      type="text"
                      placeholder="Example: johnsmith-blog"
                      className="w-full"
                      value={socialMediaHandles.tumblr}
                      onChange={(e) => setSocialMediaHandles(prev => ({ ...prev, tumblr: e.target.value }))}
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-2">Twitch Username</label>
                    <Input
                      type="text"
                      placeholder="Example: johnsmith_stream"
                      className="w-full"
                      value={socialMediaHandles.twitch}
                      onChange={(e) => setSocialMediaHandles(prev => ({ ...prev, twitch: e.target.value }))}
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-2">Spotify Profile</label>
                    <Input
                      type="text"
                      placeholder="Example: johnsmith2024"
                      className="w-full"
                      value={socialMediaHandles.spotify}
                      onChange={(e) => setSocialMediaHandles(prev => ({ ...prev, spotify: e.target.value }))}
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-2">Medium Username</label>
                    <Input
                      type="text"
                      placeholder="Example: johnsmith"
                      className="w-full"
                      value={socialMediaHandles.medium}
                      onChange={(e) => setSocialMediaHandles(prev => ({ ...prev, medium: e.target.value }))}
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-2">GitHub Username</label>
                    <Input
                      type="text"
                      placeholder="Example: johnsmith-dev"
                      className="w-full"
                      value={socialMediaHandles.github}
                      onChange={(e) => setSocialMediaHandles(prev => ({ ...prev, github: e.target.value }))}
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-2">Vimeo Username</label>
                    <Input
                      type="text"
                      placeholder="Example: johnsmith_video"
                      className="w-full"
                      value={socialMediaHandles.vimeo}
                      onChange={(e) => setSocialMediaHandles(prev => ({ ...prev, vimeo: e.target.value }))}
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-2">Skype Username</label>
                    <Input
                      type="text"
                      placeholder="Example: johnsmith.uk"
                      className="w-full"
                      value={socialMediaHandles.skype}
                      onChange={(e) => setSocialMediaHandles(prev => ({ ...prev, skype: e.target.value }))}
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-2">Flickr Username</label>
                    <Input
                      type="text"
                      placeholder="Example: johnsmith_photos"
                      className="w-full"
                      value={socialMediaHandles.flickr}
                      onChange={(e) => setSocialMediaHandles(prev => ({ ...prev, flickr: e.target.value }))}
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-2">SoundCloud Username</label>
                    <Input
                      type="text"
                      placeholder="Example: johnsmith-music"
                      className="w-full"
                      value={socialMediaHandles.soundcloud}
                      onChange={(e) => setSocialMediaHandles(prev => ({ ...prev, soundcloud: e.target.value }))}
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-2">Behance Username</label>
                    <Input
                      type="text"
                      placeholder="Example: johnsmith_design"
                      className="w-full"
                      value={socialMediaHandles.behance}
                      onChange={(e) => setSocialMediaHandles(prev => ({ ...prev, behance: e.target.value }))}
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-2">Dribbble Username</label>
                    <Input
                      type="text"
                      placeholder="Example: johnsmith_creative"
                      className="w-full"
                      value={socialMediaHandles.dribbble}
                      onChange={(e) => setSocialMediaHandles(prev => ({ ...prev, dribbble: e.target.value }))}
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-2">DeviantArt Username</label>
                    <Input
                      type="text"
                      placeholder="Example: johnsmith-art"
                      className="w-full"
                      value={socialMediaHandles.deviantart}
                      onChange={(e) => setSocialMediaHandles(prev => ({ ...prev, deviantart: e.target.value }))}
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-2">Stack Overflow ID</label>
                    <Input
                      type="text"
                      placeholder="Example: johnsmith or user123456"
                      className="w-full"
                      value={socialMediaHandles.stackoverflow}
                      onChange={(e) => setSocialMediaHandles(prev => ({ ...prev, stackoverflow: e.target.value }))}
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-2">Quora Profile</label>
                    <Input
                      type="text"
                      placeholder="Example: John-Smith-123"
                      className="w-full"
                      value={socialMediaHandles.quora}
                      onChange={(e) => setSocialMediaHandles(prev => ({ ...prev, quora: e.target.value }))}
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-2">Telegram Username</label>
                    <Input
                      type="text"
                      placeholder="Example: johnsmith_uk"
                      className="w-full"
                      value={socialMediaHandles.telegram}
                      onChange={(e) => setSocialMediaHandles(prev => ({ ...prev, telegram: e.target.value }))}
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-2">WhatsApp Number</label>
                    <Input
                      type="text"
                      placeholder="Example: +44123456789"
                      className="w-full"
                      value={socialMediaHandles.whatsapp}
                      onChange={(e) => setSocialMediaHandles(prev => ({ ...prev, whatsapp: e.target.value }))}
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-2">Personal Website</label>
                    <Input
                      type="text"
                      placeholder="Example: www.johnsmith.com"
                      className="w-full"
                      value={socialMediaHandles.website}
                      onChange={(e) => setSocialMediaHandles(prev => ({ ...prev, website: e.target.value }))}
                    />
                    <p className="text-xs text-gray-500 mt-1">Your personal website or blog URL</p>
                  </div>
                </div>
                
                <Button 
                  onClick={saveSocialMediaHandles}
                  className="w-full bg-green-600 hover:bg-green-700 text-white"
                >
                  Save Social Media Connections
                </Button>
              </div>
            </div>
          )}
          
          {/* All Social Media Platform Buttons */}
          <div className="grid grid-cols-4 gap-2">
            <Button 
              variant="outline" 
              className="flex items-center gap-1 text-blue-600 border-blue-200 hover:bg-blue-50 text-xs p-2"
            >
              <span className="font-bold">f</span>
              Facebook
            </Button>
            <Button 
              variant="outline" 
              className="flex items-center gap-1 text-sky-600 border-sky-200 hover:bg-sky-50 text-xs p-2"
            >
              <span>🐦</span>
              Twitter
            </Button>
            <Button 
              variant="outline" 
              className="flex items-center gap-1 text-pink-600 border-pink-200 hover:bg-pink-50 text-xs p-2"
            >
              <span>📷</span>
              Instagram
            </Button>
            <Button 
              variant="outline" 
              className="flex items-center gap-1 text-blue-700 border-blue-200 hover:bg-blue-50 text-xs p-2"
            >
              <span className="font-bold">in</span>
              LinkedIn
            </Button>
            <Button 
              variant="outline" 
              className="flex items-center gap-1 text-red-600 border-red-200 hover:bg-red-50 text-xs p-2"
            >
              <span>▶</span>
              YouTube
            </Button>
            <Button 
              variant="outline" 
              className="flex items-center gap-1 text-black border-gray-200 hover:bg-gray-50 text-xs p-2"
            >
              <span>🎵</span>
              TikTok
            </Button>
            <Button 
              variant="outline" 
              className="flex items-center gap-1 text-blue-500 border-blue-200 hover:bg-blue-50 text-xs p-2"
            >
              <span>✈️</span>
              Telegram
            </Button>
            <Button 
              variant="outline" 
              className="flex items-center gap-1 text-green-600 border-green-200 hover:bg-green-50 text-xs p-2"
            >
              <span>💬</span>
              WhatsApp
            </Button>
            <Button 
              variant="outline" 
              className="flex items-center gap-1 text-red-700 border-red-200 hover:bg-red-50 text-xs p-2"
            >
              <span>📺</span>
              Rumble
            </Button>
            <Button 
              variant="outline" 
              className="flex items-center gap-1 text-purple-600 border-purple-200 hover:bg-purple-50 text-xs p-2"
            >
              <span>👻</span>
              Snapchat
            </Button>
            <Button 
              variant="outline" 
              className="flex items-center gap-1 text-orange-600 border-orange-200 hover:bg-orange-50 text-xs p-2"
            >
              <span>🎭</span>
              Reddit
            </Button>
            <Button 
              variant="outline" 
              className="flex items-center gap-1 text-indigo-600 border-indigo-200 hover:bg-indigo-50 text-xs p-2"
            >
              <span>🔗</span>
              Discord
            </Button>
            <Button 
              variant="outline" 
              className="flex items-center gap-1 text-pink-600 border-pink-200 hover:bg-pink-50 text-xs p-2"
            >
              <span>📌</span>
              Pinterest
            </Button>
            <Button 
              variant="outline" 
              className="flex items-center gap-1 text-blue-700 border-blue-200 hover:bg-blue-50 text-xs p-2"
            >
              <span>🌀</span>
              Tumblr
            </Button>
            <Button 
              variant="outline" 
              className="flex items-center gap-1 text-purple-700 border-purple-200 hover:bg-purple-50 text-xs p-2"
            >
              <span>🎮</span>
              Twitch
            </Button>
            <Button 
              variant="outline" 
              className="flex items-center gap-1 text-green-700 border-green-200 hover:bg-green-50 text-xs p-2"
            >
              <span>🎵</span>
              Spotify
            </Button>
            <Button 
              variant="outline" 
              className="flex items-center gap-1 text-gray-700 border-gray-200 hover:bg-gray-50 text-xs p-2"
            >
              <span>📝</span>
              Medium
            </Button>
            <Button 
              variant="outline" 
              className="flex items-center gap-1 text-gray-800 border-gray-200 hover:bg-gray-50 text-xs p-2"
            >
              <span>💻</span>
              GitHub
            </Button>
            <Button 
              variant="outline" 
              className="flex items-center gap-1 text-blue-600 border-blue-200 hover:bg-blue-50 text-xs p-2"
            >
              <span>🎬</span>
              Vimeo
            </Button>
            <Button 
              variant="outline" 
              className="flex items-center gap-1 text-blue-500 border-blue-200 hover:bg-blue-50 text-xs p-2"
            >
              <span>📞</span>
              Skype
            </Button>
            <Button 
              variant="outline" 
              className="flex items-center gap-1 text-pink-500 border-pink-200 hover:bg-pink-50 text-xs p-2"
            >
              <span>📷</span>
              Flickr
            </Button>
            <Button 
              variant="outline" 
              className="flex items-center gap-1 text-orange-600 border-orange-200 hover:bg-orange-50 text-xs p-2"
            >
              <span>🎧</span>
              SoundCloud
            </Button>
            <Button 
              variant="outline" 
              className="flex items-center gap-1 text-blue-800 border-blue-200 hover:bg-blue-50 text-xs p-2"
            >
              <span>🎨</span>
              Behance
            </Button>
            <Button 
              variant="outline" 
              className="flex items-center gap-1 text-pink-600 border-pink-200 hover:bg-pink-50 text-xs p-2"
            >
              <span>⚽</span>
              Dribbble
            </Button>
            <Button 
              variant="outline" 
              className="flex items-center gap-1 text-green-600 border-green-200 hover:bg-green-50 text-xs p-2"
            >
              <span>🎭</span>
              DeviantArt
            </Button>
            <Button 
              variant="outline" 
              className="flex items-center gap-1 text-orange-700 border-orange-200 hover:bg-orange-50 text-xs p-2"
            >
              <span>📚</span>
              Stack Overflow
            </Button>
            <Button 
              variant="outline" 
              className="flex items-center gap-1 text-red-600 border-red-200 hover:bg-red-50 text-xs p-2"
            >
              <span>❓</span>
              Quora
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Post Creation Area */}
      {isOwnProfile && (
        <Card className="max-w-4xl mx-auto mb-6 bg-white border shadow-sm">
          <CardContent className="p-6">
            <div className="space-y-4">
              <Textarea
                placeholder="What's on your mind?"
                value={newPost}
                onChange={(e) => setNewPost(e.target.value)}
                className="w-full resize-none"
                rows={3}
              />
              
              <div className="flex justify-between items-center">
                <div className="flex space-x-2">
                  <SimpleImageUpload
                    onImageUploaded={(imageUrl) => {
                      setNewPost(prev => prev + `\n\n[Image: ${imageUrl}]`);
                      toast({ title: "Photo uploaded!", description: "Image added to your post" });
                    }}
                    buttonText="Photo"
                    isProfileImage={false}
                    className="flex items-center gap-2 px-3 py-2 border border-gray-300 rounded-md hover:bg-gray-50 text-sm"
                  />
                  <SimpleImageUpload
                    onImageUploaded={(imageUrl) => {
                      setNewPost(prev => prev + `\n\n[Video: ${imageUrl}]`);
                      toast({ title: "Video uploaded!", description: "Video added to your post" });
                    }}
                    buttonText="Video"
                    isProfileImage={false}
                    className="flex items-center gap-2 px-3 py-2 border border-gray-300 rounded-md hover:bg-gray-50 text-sm"
                  />
                </div>
                
                <Button 
                  onClick={handleCreatePost}
                  disabled={!newPost.trim()}
                  className="bg-blue-600 hover:bg-blue-700 text-white"
                >
                  Post
                </Button>
              </div>
              
              {/* Three Sharing Buttons - OPC Wall, My Wall, Multi-Share */}
              <div className="flex justify-center space-x-3 pt-4 border-t">
                <Button 
                  variant="outline" 
                  size="sm"
                  className="bg-orange-500 hover:bg-orange-600 text-white border-orange-500"
                  onClick={() => toast({ title: "Posted to OPC Wall!", description: "Your post is now visible on the community wall" })}
                >
                  <Share2 className="h-4 w-4 mr-2" />
                  OPC Wall
                </Button>
                <Button 
                  variant="outline" 
                  size="sm"
                  className="bg-purple-500 hover:bg-purple-600 text-white border-purple-500"
                  onClick={() => toast({ title: "Posted to My Wall!", description: "Your post is now on your profile wall" })}
                >
                  <MessageSquare className="h-4 w-4 mr-2" />
                  My Wall
                </Button>
                <Button 
                  variant="outline" 
                  size="sm"
                  className="bg-green-500 hover:bg-green-600 text-white border-green-500"
                  onClick={() => toast({ title: "Multi-Share Complete!", description: "Sharing to all connected social media platforms" })}
                >
                  <Share2 className="h-4 w-4 mr-2" />
                  Multi-Share
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Posts Feed */}
      <div className="max-w-4xl mx-auto space-y-4">
        {socialFeedPosts && socialFeedPosts.length > 0 ? (
          socialFeedPosts.map((post: any) => (
            <Card key={post.id} className="bg-white border shadow-sm">
              <CardContent className="p-6">
                <div className="space-y-4">
                  {/* Post Header */}
                  <div className="flex items-center space-x-3">
                    <div className="w-10 h-10 rounded-full bg-gray-400 flex items-center justify-center">
                      <span className="text-white font-bold">
                        {post.authorName.charAt(0)}
                      </span>
                    </div>
                    <div>
                      <p className="font-medium">{post.authorName}</p>
                      <p className="text-sm text-gray-500">
                        {new Date(post.createdAt).toLocaleDateString()}
                      </p>
                    </div>
                  </div>

                  {/* Post Content */}
                  <div className="text-gray-800">
                    <p>{post.content}</p>
                  </div>

                  {/* Post Actions */}
                  <div className="flex items-center space-x-4 pt-2 border-t">
                    <Button variant="ghost" size="sm" className="text-gray-600 hover:text-red-600">
                      <Heart className="h-4 w-4 mr-2" />
                      Like
                    </Button>
                    <Button 
                      variant="ghost" 
                      size="sm" 
                      className="text-gray-600 hover:text-blue-600"
                      onClick={() => setShowComments({ ...showComments, [post.id]: !showComments[post.id] })}
                    >
                      <MessageCircle className="h-4 w-4 mr-2" />
                      Comment
                    </Button>
                    <Button 
                      variant="ghost" 
                      size="sm" 
                      className="text-orange-600 hover:text-orange-700"
                      onClick={() => handleOPCShare(post)}
                    >
                      <Share2 className="h-4 w-4 mr-1" />
                      OPC Share
                    </Button>
                    <Button 
                      variant="ghost" 
                      size="sm" 
                      className="text-purple-600 hover:text-purple-700"
                      onClick={() => handleMediaShare(post)}
                    >
                      <Share2 className="h-4 w-4 mr-1" />
                      Media Share
                    </Button>
                    <Button 
                      variant="ghost" 
                      size="sm" 
                      className="text-green-600 hover:text-green-700"
                      onClick={() => handleMultiShare(post)}
                    >
                      <Share2 className="h-4 w-4 mr-1" />
                      Multi-Share
                    </Button>
                  </div>

                  {/* Comments Section */}
                  {showComments[post.id] && (
                    <div className="mt-4 pt-4 border-t space-y-3">
                      {post.comments?.map((comment: any) => (
                        <div key={comment.id} className="flex space-x-3">
                          <div className="w-8 h-8 rounded-full bg-gray-300 flex items-center justify-center">
                            <span className="text-white text-sm font-bold">C</span>
                          </div>
                          <div className="flex-1">
                            <p className="text-sm font-medium">{comment.author}</p>
                            <p className="text-sm text-gray-700">{comment.content}</p>
                          </div>
                        </div>
                      ))}
                      
                      <div className="flex space-x-3 mt-3">
                        <div className="w-8 h-8 rounded-full bg-gray-300 flex items-center justify-center">
                          <span className="text-white text-sm font-bold">Y</span>
                        </div>
                        <div className="flex-1 flex space-x-2">
                          <Input
                            placeholder="Write a comment..."
                            value={newComment[post.id] || ''}
                            onChange={(e) => setNewComment({ ...newComment, [post.id]: e.target.value })}
                            className="flex-1"
                          />
                          <Button 
                            size="sm"
                            onClick={() => handleAddComment(post.id)}
                            disabled={!newComment[post.id]?.trim()}
                            className="bg-blue-600 hover:bg-blue-700 text-white"
                          >
                            Post
                          </Button>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          ))
        ) : (
          <Card className="bg-white border shadow-sm">
            <CardContent className="p-8 text-center">
              <p className="text-gray-500">No posts yet</p>
              {isOwnProfile && (
                <p className="text-sm text-gray-400 mt-2">Share your first post above!</p>
              )}
            </CardContent>
          </Card>
        )}
      </div>



      {/* Image Cropping Dialog */}
      <Dialog open={showImageCropper} onOpenChange={setShowImageCropper}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>
              {cropperTarget === 'profile' ? 'Crop Profile Picture' : 'Crop Cover Photo'}
            </DialogTitle>
          </DialogHeader>
          <SimpleImagePositioner
            onImageCropped={(croppedImageData) => {
              if (cropperTarget === 'profile') {
                setProfileImage(croppedImageData);
                toast({ title: "Profile image updated with cropping!" });
              } else {
                setCoverImage(croppedImageData);
                toast({ title: "Cover image updated with cropping!" });
              }
              setShowImageCropper(false);
            }}
            onCancel={() => setShowImageCropper(false)}
            aspectRatio={cropperTarget === 'profile' ? 1 : 16/9}
            cropShape={cropperTarget === 'profile' ? 'round' : 'rect'}
          />
        </DialogContent>
      </Dialog>

      {/* Hidden File Input Elements for Upload Functionality */}
      <input
        type="file"
        ref={profileFileInputRef}
        onChange={handleProfileFileSelect}
        accept="image/*"
        style={{ display: 'none' }}
      />
      <input
        type="file"
        ref={coverFileInputRef}
        onChange={handleCoverFileSelect}
        accept="image/*"
        style={{ display: 'none' }}
      />
      <input
        type="file"
        ref={galleryFileInputRef}
        onChange={handleGalleryFileSelect}
        accept="image/*,video/*"
        multiple
        style={{ display: 'none' }}
      />

      {/* Image Cropper Modal - Disabled to prevent black screen crashes */}

    </div>
  );
}