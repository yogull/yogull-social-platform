import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { PageHeader } from "@/components/PageHeader";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { FileText, Trash2, Eye, MessageSquare, Image, Shield } from "lucide-react";
import type { ProfileWallPost, BlogPost, CommunityDiscussion } from "@shared/schema";
import { useAuth } from "@/hooks/useAuth";

export default function AdminContent() {
  const { appUser } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  const [searchQuery, setSearchQuery] = useState("");
  const [activeTab, setActiveTab] = useState("posts");

  // Fetch profile wall posts
  const { data: profilePosts = [] } = useQuery<ProfileWallPost[]>({
    queryKey: ["/api/admin/profile-posts"],
    queryFn: async () => {
      const response = await fetch("/api/admin/profile-posts");
      if (!response.ok) throw new Error('Failed to fetch profile posts');
      return response.json();
    },
  });

  // Fetch blog posts
  const { data: blogPosts = [] } = useQuery<BlogPost[]>({
    queryKey: ["/api/admin/blog-posts"],
    queryFn: async () => {
      const response = await fetch("/api/admin/blog-posts");
      if (!response.ok) throw new Error('Failed to fetch blog posts');
      return response.json();
    },
  });

  // Fetch discussions
  const { data: discussions = [] } = useQuery<CommunityDiscussion[]>({
    queryKey: ["/api/admin/discussions"],
    queryFn: async () => {
      const response = await fetch("/api/admin/discussions");
      if (!response.ok) throw new Error('Failed to fetch discussions');
      return response.json();
    },
  });

  // Delete content mutation
  const deleteContentMutation = useMutation({
    mutationFn: async ({ type, id, reason }: { type: string; id: number; reason: string }) => {
      const response = await fetch(`/api/admin/${type}/${id}`, {
        method: 'DELETE',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ reason }),
      });
      if (!response.ok) throw new Error('Failed to delete content');
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/profile-posts"] });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/blog-posts"] });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/discussions"] });
      toast({ title: "Content deleted successfully" });
    },
    onError: () => {
      toast({ title: "Failed to delete content", variant: "destructive" });
    },
  });

  const handleDeleteContent = (type: string, id: number, reason: string) => {
    deleteContentMutation.mutate({ type, id, reason });
  };

  if (!appUser?.isAdmin) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Card className="p-8 text-center">
          <Shield className="w-16 h-16 mx-auto mb-4 text-red-500" />
          <h2 className="text-2xl font-bold mb-2">Access Denied</h2>
          <p className="text-muted-foreground">You don't have administrator privileges.</p>
        </Card>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 py-6">
      <PageHeader title="Content Management" />
      
      <div className="mb-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <FileText className="w-5 h-5" />
              Content Statistics
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div className="text-center">
                <div className="text-2xl font-bold text-blue-600">{profilePosts.length}</div>
                <div className="text-sm text-muted-foreground">Profile Posts</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-green-600">{blogPosts.length}</div>
                <div className="text-sm text-muted-foreground">Blog Posts</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-purple-600">{discussions.length}</div>
                <div className="text-sm text-muted-foreground">Discussions</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-orange-600">
                  {profilePosts.length + blogPosts.length + discussions.length}
                </div>
                <div className="text-sm text-muted-foreground">Total Content</div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="mb-6">
        <Input
          placeholder="Search content..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="max-w-md"
        />
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="posts">Profile Posts ({profilePosts.length})</TabsTrigger>
          <TabsTrigger value="blogs">Blog Posts ({blogPosts.length})</TabsTrigger>
          <TabsTrigger value="discussions">Discussions ({discussions.length})</TabsTrigger>
        </TabsList>

        {/* Profile Posts */}
        <TabsContent value="posts" className="space-y-4">
          {profilePosts
            .filter(post => 
              post.content.toLowerCase().includes(searchQuery.toLowerCase())
            )
            .map((post) => (
            <Card key={post.id}>
              <CardContent className="p-4">
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-2">
                      <Badge variant="outline">Profile Post</Badge>
                      <Badge variant="outline">ID: {post.id}</Badge>
                      <Badge variant="outline">User: {post.userId}</Badge>
                    </div>
                    <p className="text-sm mb-2 line-clamp-3">{post.content}</p>
                    {post.mediaUrl && (
                      <div className="flex items-center gap-1 text-xs text-muted-foreground mb-2">
                        <Image className="w-3 h-3" />
                        Media attached
                      </div>
                    )}
                    <div className="flex items-center gap-4 text-xs text-muted-foreground">
                      <span>❤️ {post.likes} likes</span>
                      <span>📤 {post.shares} shares</span>
                      <span>📅 {new Date(post.createdAt).toLocaleDateString()}</span>
                    </div>
                  </div>
                  <div className="flex gap-2">
                    <Dialog>
                      <DialogTrigger asChild>
                        <Button size="sm" variant="outline">
                          <Eye className="w-4 h-4 mr-1" />
                          View
                        </Button>
                      </DialogTrigger>
                      <DialogContent className="max-w-2xl">
                        <DialogHeader>
                          <DialogTitle>Profile Post Details</DialogTitle>
                        </DialogHeader>
                        <div className="space-y-4">
                          <div>
                            <strong>Content:</strong>
                            <p className="mt-1 text-sm">{post.content}</p>
                          </div>
                          <div className="grid grid-cols-2 gap-4 text-sm">
                            <div><strong>Likes:</strong> {post.likes}</div>
                            <div><strong>Shares:</strong> {post.shares}</div>
                            <div><strong>Privacy:</strong> {post.privacy}</div>
                            <div><strong>Created:</strong> {new Date(post.createdAt).toLocaleString()}</div>
                          </div>
                        </div>
                      </DialogContent>
                    </Dialog>
                    <Dialog>
                      <DialogTrigger asChild>
                        <Button size="sm" variant="destructive">
                          <Trash2 className="w-4 h-4 mr-1" />
                          Delete
                        </Button>
                      </DialogTrigger>
                      <DialogContent>
                        <DialogHeader>
                          <DialogTitle>Delete Profile Post</DialogTitle>
                        </DialogHeader>
                        <p className="text-sm text-muted-foreground mb-4">
                          Are you sure you want to delete this post? This action cannot be undone.
                        </p>
                        <div className="flex gap-2 justify-end">
                          <Button variant="outline">Cancel</Button>
                          <Button 
                            variant="destructive"
                            onClick={() => handleDeleteContent('profile-posts', post.id, 'Admin deletion')}
                          >
                            Delete Post
                          </Button>
                        </div>
                      </DialogContent>
                    </Dialog>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </TabsContent>

        {/* Blog Posts */}
        <TabsContent value="blogs" className="space-y-4">
          {blogPosts
            .filter(post => 
              post.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
              post.content.toLowerCase().includes(searchQuery.toLowerCase())
            )
            .map((post) => (
            <Card key={post.id}>
              <CardContent className="p-4">
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-2">
                      <Badge variant="outline">Blog Post</Badge>
                      <Badge variant="outline">ID: {post.id}</Badge>
                      <Badge variant="outline">User: {post.userId}</Badge>
                    </div>
                    <h3 className="font-semibold mb-1">{post.title}</h3>
                    <p className="text-sm text-muted-foreground mb-2 line-clamp-2">{post.content}</p>
                    <div className="flex items-center gap-4 text-xs text-muted-foreground">
                      <span>❤️ {post.likes} likes</span>
                      <span>📋 {post.category}</span>
                      <span>📅 {new Date(post.createdAt).toLocaleDateString()}</span>
                    </div>
                  </div>
                  <div className="flex gap-2">
                    <Dialog>
                      <DialogTrigger asChild>
                        <Button size="sm" variant="outline">
                          <Eye className="w-4 h-4 mr-1" />
                          View
                        </Button>
                      </DialogTrigger>
                      <DialogContent className="max-w-4xl max-h-[80vh] overflow-y-auto">
                        <DialogHeader>
                          <DialogTitle>{post.title}</DialogTitle>
                        </DialogHeader>
                        <div className="space-y-4">
                          <div className="prose max-w-none">
                            <p className="whitespace-pre-wrap">{post.content}</p>
                          </div>
                          <div className="grid grid-cols-3 gap-4 text-sm border-t pt-4">
                            <div><strong>Likes:</strong> {post.likes}</div>
                            <div><strong>Category:</strong> {post.category}</div>
                            <div><strong>Created:</strong> {new Date(post.createdAt).toLocaleString()}</div>
                          </div>
                        </div>
                      </DialogContent>
                    </Dialog>
                    <Dialog>
                      <DialogTrigger asChild>
                        <Button size="sm" variant="destructive">
                          <Trash2 className="w-4 h-4 mr-1" />
                          Delete
                        </Button>
                      </DialogTrigger>
                      <DialogContent>
                        <DialogHeader>
                          <DialogTitle>Delete Blog Post</DialogTitle>
                        </DialogHeader>
                        <p className="text-sm text-muted-foreground mb-4">
                          Are you sure you want to delete "{post.title}"? This action cannot be undone.
                        </p>
                        <div className="flex gap-2 justify-end">
                          <Button variant="outline">Cancel</Button>
                          <Button 
                            variant="destructive"
                            onClick={() => handleDeleteContent('blog-posts', post.id, 'Admin deletion')}
                          >
                            Delete Post
                          </Button>
                        </div>
                      </DialogContent>
                    </Dialog>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </TabsContent>

        {/* Discussions */}
        <TabsContent value="discussions" className="space-y-4">
          {discussions
            .filter(discussion => 
              discussion.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
              discussion.description.toLowerCase().includes(searchQuery.toLowerCase())
            )
            .map((discussion) => (
            <Card key={discussion.id}>
              <CardContent className="p-4">
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-2">
                      <Badge variant="outline">Discussion</Badge>
                      <Badge variant="outline">ID: {discussion.id}</Badge>
                      <Badge variant="outline">Category: {discussion.categoryId}</Badge>
                    </div>
                    <h3 className="font-semibold mb-1">{discussion.title}</h3>
                    <p className="text-sm text-muted-foreground mb-2 line-clamp-2">{discussion.description}</p>
                    <div className="flex items-center gap-4 text-xs text-muted-foreground">
                      <span>💬 Messages</span>
                      <span>📍 {discussion.location || 'Global'}</span>
                      <span>📅 {new Date(discussion.createdAt).toLocaleDateString()}</span>
                    </div>
                  </div>
                  <div className="flex gap-2">
                    <Dialog>
                      <DialogTrigger asChild>
                        <Button size="sm" variant="outline">
                          <MessageSquare className="w-4 h-4 mr-1" />
                          View
                        </Button>
                      </DialogTrigger>
                      <DialogContent className="max-w-2xl">
                        <DialogHeader>
                          <DialogTitle>{discussion.title}</DialogTitle>
                        </DialogHeader>
                        <div className="space-y-4">
                          <div>
                            <strong>Description:</strong>
                            <p className="mt-1 text-sm">{discussion.description}</p>
                          </div>
                          <div className="grid grid-cols-2 gap-4 text-sm">
                            <div><strong>Location:</strong> {discussion.location || 'Global'}</div>
                            <div><strong>Category:</strong> {discussion.categoryId}</div>
                            <div><strong>Active:</strong> {discussion.isActive ? 'Yes' : 'No'}</div>
                            <div><strong>Created:</strong> {new Date(discussion.createdAt).toLocaleString()}</div>
                          </div>
                        </div>
                      </DialogContent>
                    </Dialog>
                    <Dialog>
                      <DialogTrigger asChild>
                        <Button size="sm" variant="destructive">
                          <Trash2 className="w-4 h-4 mr-1" />
                          Delete
                        </Button>
                      </DialogTrigger>
                      <DialogContent>
                        <DialogHeader>
                          <DialogTitle>Delete Discussion</DialogTitle>
                        </DialogHeader>
                        <p className="text-sm text-muted-foreground mb-4">
                          Are you sure you want to delete "{discussion.title}"? This action cannot be undone.
                        </p>
                        <div className="flex gap-2 justify-end">
                          <Button variant="outline">Cancel</Button>
                          <Button 
                            variant="destructive"
                            onClick={() => handleDeleteContent('discussions', discussion.id, 'Admin deletion')}
                          >
                            Delete Discussion
                          </Button>
                        </div>
                      </DialogContent>
                    </Dialog>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </TabsContent>
      </Tabs>
    </div>
  );
}