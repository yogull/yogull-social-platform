import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useParams } from "wouter";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/useAuth";
import { PageHeader } from "@/components/PageHeader";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { loadStripe } from "@stripe/stripe-js";
import { Elements, PaymentElement, useStripe, useElements } from "@stripe/react-stripe-js";
import { useState } from "react";
import { 
  Building2, 
  ShoppingCart, 
  Star, 
  Globe, 
  Phone, 
  Mail,
  MapPin,
  Package,
  CreditCard,
  Minus,
  Plus
} from "lucide-react";

const stripePromise = loadStripe(import.meta.env.VITE_STRIPE_PUBLIC_KEY);

function ProductPurchaseForm({ product, quantity, onSuccess }: { 
  product: any; 
  quantity: number;
  onSuccess: () => void; 
}) {
  const stripe = useStripe();
  const elements = useElements();
  const { toast } = useToast();
  const { appUser } = useAuth();
  const [isProcessing, setIsProcessing] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!stripe || !elements) return;

    setIsProcessing(true);

    const { error } = await stripe.confirmPayment({
      elements,
      confirmParams: {
        return_url: `${window.location.origin}/company/${product.companyId}/purchase-success`,
      },
    });

    if (error) {
      toast({
        title: "Payment Failed",
        description: error.message,
        variant: "destructive",
      });
    } else {
      toast({
        title: "Purchase Successful",
        description: "Thank you for your purchase!",
      });
      onSuccess();
    }

    setIsProcessing(false);
  };

  const totalAmount = (product.price * quantity) / 100; // Convert from pence

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="bg-gray-50 rounded-lg p-4">
        <div className="flex justify-between items-center">
          <span className="font-medium">{product.name}</span>
          <span className="font-bold">£{(product.price / 100).toFixed(2)}</span>
        </div>
        <div className="flex justify-between items-center mt-2">
          <span className="text-sm text-gray-600">Quantity: {quantity}</span>
          <span className="font-bold text-lg">£{totalAmount.toFixed(2)}</span>
        </div>
      </div>
      <PaymentElement />
      <Button type="submit" disabled={!stripe || isProcessing} className="w-full">
        {isProcessing ? "Processing..." : `Pay £${totalAmount.toFixed(2)}`}
      </Button>
    </form>
  );
}

export default function CompanyStorefront() {
  const { companyId } = useParams();
  const { toast } = useToast();
  const { appUser } = useAuth();
  const [selectedProduct, setSelectedProduct] = useState<any>(null);
  const [quantity, setQuantity] = useState(1);
  const [showPayment, setShowPayment] = useState(false);
  const [clientSecret, setClientSecret] = useState("");

  const { data: storefront, isLoading } = useQuery({
    queryKey: [`/api/companies/${companyId}/storefront`],
    queryFn: () => apiRequest("GET", `/api/companies/${companyId}/storefront`).then(res => res.json()),
    enabled: !!companyId
  });

  const purchaseMutation = useMutation({
    mutationFn: async ({ productId, quantity }: { productId: number; quantity: number }) => {
      const response = await apiRequest("POST", `/api/company-products/${productId}/purchase`, {
        quantity,
        customerId: appUser?.id
      });
      const data = await response.json();
      setClientSecret(data.clientSecret);
      setShowPayment(true);
      return data;
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    }
  });

  const handlePurchase = (product: any) => {
    if (!appUser) {
      toast({
        title: "Sign In Required",
        description: "Please sign in to purchase products",
        variant: "destructive",
      });
      return;
    }

    setSelectedProduct(product);
    purchaseMutation.mutate({ productId: product.id, quantity });
  };

  if (isLoading) {
    return (
      <div className="mobile-safe w-full max-w-[65vw] mx-auto px-2 sm:px-4 py-4 overflow-x-hidden">
        <div className="animate-pulse space-y-4">
          <div className="h-8 bg-gray-200 rounded w-1/3"></div>
          <div className="h-4 bg-gray-200 rounded w-2/3"></div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {[1, 2, 3].map(i => (
              <div key={i} className="h-64 bg-gray-200 rounded"></div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  if (!storefront?.company) {
    return (
      <div className="mobile-safe w-full max-w-[65vw] mx-auto px-2 sm:px-4 py-4 overflow-x-hidden">
        <Card className="max-w-md mx-auto">
          <CardContent className="p-6 text-center">
            <h2 className="text-xl font-semibold mb-2">Company Not Found</h2>
            <p className="text-gray-600">This company storefront is not available.</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  const { company, products } = storefront;

  return (
    <div className="mobile-safe w-full max-w-[65vw] mx-auto px-2 sm:px-4 py-4 overflow-x-hidden">
      {/* Company Header */}
      <div className="bg-gradient-to-r from-blue-50 to-purple-50 rounded-xl p-8 mb-8">
        <div className="flex items-start gap-6">
          {company.logo && (
            <img 
              src={company.logo} 
              alt={`${company.name} logo`}
              className="w-20 h-20 object-cover rounded-lg border border-gray-200"
            />
          )}
          <div className="flex-1">
            <div className="flex items-center gap-3 mb-3">
              <Building2 className="h-6 w-6 text-blue-600" />
              <h1 className="text-3xl font-bold text-gray-900">{company.name}</h1>
            </div>
            {company.description && (
              <p className="text-gray-700 text-lg mb-4">{company.description}</p>
            )}
            <div className="flex flex-wrap gap-4 text-sm text-gray-600">
              {company.website && (
                <div className="flex items-center gap-2">
                  <Globe className="h-4 w-4" />
                  <a 
                    href={company.website} 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="text-blue-600 hover:underline"
                  >
                    {company.website}
                  </a>
                </div>
              )}
              {company.email && (
                <div className="flex items-center gap-2">
                  <Mail className="h-4 w-4" />
                  <a href={`mailto:${company.email}`} className="text-blue-600 hover:underline">
                    {company.email}
                  </a>
                </div>
              )}
              {company.phone && (
                <div className="flex items-center gap-2">
                  <Phone className="h-4 w-4" />
                  <a href={`tel:${company.phone}`} className="text-blue-600 hover:underline">
                    {company.phone}
                  </a>
                </div>
              )}
              {company.address && (
                <div className="flex items-center gap-2">
                  <MapPin className="h-4 w-4" />
                  <span>{company.address}</span>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Products Section */}
      <div className="mb-8">
        <h2 className="text-2xl font-bold mb-6">Our Products</h2>
        
        {products.length === 0 ? (
          <Card>
            <CardContent className="p-8 text-center">
              <Package className="h-12 w-12 text-gray-400 mx-auto mb-4" />
              <h3 className="text-lg font-semibold text-gray-900 mb-2">No Products Available</h3>
              <p className="text-gray-600">This company hasn't added any products yet.</p>
            </CardContent>
          </Card>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {products.map((product: any) => (
              <Card key={product.id} className="overflow-hidden hover:shadow-lg transition-shadow">
                {product.imageUrl && (
                  <div className="aspect-video bg-gray-100">
                    <img 
                      src={product.imageUrl} 
                      alt={product.name}
                      className="w-full h-full object-cover"
                    />
                  </div>
                )}
                
                <CardHeader>
                  <div className="flex justify-between items-start">
                    <CardTitle className="text-lg">{product.name}</CardTitle>
                    <Badge variant="outline">
                      <Package className="h-3 w-3 mr-1" />
                      {product.stock} left
                    </Badge>
                  </div>
                  {product.category && (
                    <Badge variant="secondary" className="w-fit">
                      {product.category}
                    </Badge>
                  )}
                </CardHeader>
                
                <CardContent>
                  <p className="text-gray-600 text-sm mb-4">{product.description}</p>
                  
                  <div className="flex items-center justify-between">
                    <span className="text-2xl font-bold text-primary">
                      £{(product.price / 100).toFixed(2)}
                    </span>
                    
                    <div className="flex items-center gap-2">
                      <div className="flex items-center border rounded-lg">
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => setQuantity(Math.max(1, quantity - 1))}
                          className="h-8 w-8 p-0"
                        >
                          <Minus className="h-4 w-4" />
                        </Button>
                        <span className="px-3 py-1 text-sm font-medium">{quantity}</span>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => setQuantity(Math.min(product.stock, quantity + 1))}
                          className="h-8 w-8 p-0"
                        >
                          <Plus className="h-4 w-4" />
                        </Button>
                      </div>
                      
                      <Button 
                        onClick={() => handlePurchase(product)}
                        disabled={product.stock === 0 || purchaseMutation.isPending}
                        className="flex items-center gap-2"
                      >
                        <ShoppingCart className="h-4 w-4" />
                        {product.stock === 0 ? "Out of Stock" : "Buy Now"}
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>

      {/* Payment Modal */}
      {showPayment && selectedProduct && clientSecret && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl p-6 max-w-md w-full">
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-lg font-semibold">Complete Purchase</h3>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setShowPayment(false)}
                className="h-8 w-8 p-0"
              >
                ×
              </Button>
            </div>
            
            <Elements stripe={stripePromise} options={{ clientSecret }}>
              <ProductPurchaseForm 
                product={selectedProduct}
                quantity={quantity}
                onSuccess={() => {
                  setShowPayment(false);
                  setSelectedProduct(null);
                  setQuantity(1);
                }}
              />
            </Elements>
          </div>
        </div>
      )}

      {/* Company Information Footer */}
      <Card className="bg-gray-50">
        <CardContent className="p-6">
          <h3 className="text-lg font-semibold mb-3">About {company.name}</h3>
          <p className="text-gray-700 mb-4">
            {company.description || `${company.name} is a trusted business offering quality products and services.`}
          </p>
          <div className="text-sm text-gray-600">
            <p>This is an isolated company storefront - no competitor advertisements are displayed on this page.</p>
            <p className="mt-1">All payments are processed securely through Stripe.</p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}