import { useState, useEffect } from "react";
import { User } from "@shared/schema";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/useAuth";

interface DailyMetrics {
  date: string;
  newMembers: number;
  totalMembers: number;
  socialInvitesSent: number;
  businessEmailsSent: number;
  newBusinessSignups: number;
  totalBusinesses: number;
  paymentsReceived: number;
  totalRevenue: number;
  newDiscussions: number;
  newChatMessages: number;
  newProfilePosts: number;
  activeUsers: number;
  platformGrowth: number;
}

interface BusinessMetrics {
  businessName: string;
  signupDate: string;
  paymentStatus: string;
  adsRunning: number;
  location: string;
  contactAttempts: number;
}

export default function AdminDashboard() {
  const [selectedReport, setSelectedReport] = useState<string>("");
  const [systemStatus, setSystemStatus] = useState("Checking...");
  const { toast } = useToast();
  const { appUser: user, loading } = useAuth();

  // Fetch daily metrics
  const { data: dailyMetrics, isLoading: metricsLoading, refetch: refetchMetrics } = useQuery<DailyMetrics>({
    queryKey: ['/api/admin/daily-metrics'],
    enabled: false
  });

  // Fetch business metrics
  const { data: businessMetrics, isLoading: businessLoading, refetch: refetchBusiness } = useQuery<BusinessMetrics[]>({
    queryKey: ['/api/admin/business-metrics'],
    enabled: false
  });

  // Check system status
  useEffect(() => {
    checkSystemStatus();
  }, []);

  const checkSystemStatus = async () => {
    try {
      const response = await fetch('/api/admin/system-status');
      const data = await response.json();
      setSystemStatus(data.status);
    } catch (error) {
      setSystemStatus('Error');
    }
  };

  const runDailyReport = async () => {
    toast({ title: "Generating Report", description: "Fetching today's metrics..." });
    await refetchMetrics();
    setSelectedReport("daily");
    toast({ title: "Success", description: "Daily report generated successfully" });
  };

  const runBusinessReport = async () => {
    toast({ title: "Generating Report", description: "Fetching business data..." });
    await refetchBusiness();
    setSelectedReport("business");
    toast({ title: "Success", description: "Business report generated successfully" });
  };

  const runWeeklyReport = async () => {
    toast({ title: "Generating Report", description: "Compiling weekly statistics..." });
    try {
      const response = await fetch('/api/admin/weekly-metrics');
      const data = await response.json();
      setSelectedReport("weekly");
      toast({ title: "Success", description: "Weekly report generated successfully" });
    } catch (error) {
      toast({ title: "Error", description: "Failed to generate weekly report" });
    }
  };

  const fixSystemIssues = async () => {
    toast({ title: "System Fix", description: "Running automatic system repair..." });
    try {
      const response = await fetch('/api/admin/fix-system', { method: 'POST' });
      const data = await response.json();
      
      if (data.success) {
        toast({ title: "Success", description: "System issues fixed automatically" });
        checkSystemStatus();
      } else {
        toast({ title: "Warning", description: data.message || "Some issues require manual attention" });
      }
    } catch (error) {
      toast({ title: "Error", description: "Failed to run system fix" });
    }
  };

  const triggerDailyTasks = async () => {
    toast({ title: "Running Tasks", description: "Triggering daily automated tasks..." });
    try {
      const response = await fetch('/api/admin/trigger-daily-tasks', { method: 'POST' });
      const data = await response.json();
      toast({ title: "Success", description: "Daily tasks completed successfully" });
    } catch (error) {
      toast({ title: "Error", description: "Failed to trigger daily tasks" });
    }
  };

  const createSnapshot = async () => {
    toast({ title: "Creating Snapshot", description: "Saving current working state..." });
    try {
      const response = await fetch('/api/admin/create-snapshot', { method: 'POST' });
      const data = await response.json();
      toast({ title: "Success", description: "Deployment snapshot created successfully" });
    } catch (error) {
      toast({ title: "Error", description: "Failed to create snapshot" });
    }
  };

  const restoreSnapshot = async () => {
    toast({ title: "Restoring System", description: "Restoring from last working snapshot..." });
    try {
      const response = await fetch('/api/admin/restore-snapshot', { method: 'POST' });
      const data = await response.json();
      toast({ title: "Success", description: "System restored successfully" });
      checkSystemStatus();
    } catch (error) {
      toast({ title: "Error", description: "Failed to restore snapshot" });
    }
  };

  const restartService = async (serviceName: string) => {
    const serviceNames: Record<string, string> = {
      rss: "RSS Feeds",
      email: "Email Service", 
      social: "Social Invites",
      database: "Database",
      api: "API Routes",
      business: "Business System"
    };

    toast({ title: "Restarting Service", description: `Restarting ${serviceNames[serviceName]}...` });
    
    try {
      const response = await fetch(`/api/admin/restart-service/${serviceName}`, { method: 'POST' });
      const data = await response.json();
      
      if (data.success) {
        toast({ title: "Success", description: `${serviceNames[serviceName]} restarted successfully` });
      } else {
        toast({ title: "Warning", description: data.message || "Service restart may require manual attention" });
      }
    } catch (error) {
      toast({ title: "Error", description: `Failed to restart ${serviceNames[serviceName]}` });
    }
  };

  if (!user.isAdmin) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Card>
          <CardHeader>
            <CardTitle>Access Denied</CardTitle>
            <CardDescription>You don't have admin privileges</CardDescription>
          </CardHeader>
        </Card>
      </div>
    );
  }

  return (
    <main className="max-w-7xl mx-auto p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Admin Control Panel</h1>
          <p className="text-muted-foreground">Complete platform management and reporting</p>
        </div>
        <div className="flex items-center space-x-2">
          <Badge variant={systemStatus === 'healthy' ? 'default' : 'destructive'}>
            System: {systemStatus}
          </Badge>
          <Button onClick={checkSystemStatus} variant="outline" size="sm">
            Refresh Status
          </Button>
        </div>
      </div>

      <Tabs defaultValue="reports" className="space-y-6">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="reports">Reports</TabsTrigger>
          <TabsTrigger value="system">System Control</TabsTrigger>
          <TabsTrigger value="automation">Automation</TabsTrigger>
          <TabsTrigger value="monitoring">Monitoring</TabsTrigger>
        </TabsList>

        <TabsContent value="reports" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Platform Reports</CardTitle>
              <CardDescription>Generate comprehensive reports on platform performance</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
                <Button onClick={runDailyReport} size="lg" className="h-20 flex-col">
                  <span className="text-lg font-semibold">Daily Report</span>
                  <span className="text-sm opacity-75">Today's metrics</span>
                </Button>
                <Button onClick={runBusinessReport} size="lg" className="h-20 flex-col" variant="outline">
                  <span className="text-lg font-semibold">Business Report</span>
                  <span className="text-sm opacity-75">All businesses</span>
                </Button>
                <Button onClick={runWeeklyReport} size="lg" className="h-20 flex-col" variant="outline">
                  <span className="text-lg font-semibold">Weekly Report</span>
                  <span className="text-sm opacity-75">7-day summary</span>
                </Button>
              </div>

              {selectedReport === "daily" && dailyMetrics && (
                <Card>
                  <CardHeader>
                    <CardTitle>Today's Platform Metrics</CardTitle>
                    <CardDescription>Real-time statistics for {dailyMetrics.date}</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                      <div className="text-center p-4 bg-blue-50 rounded-lg">
                        <div className="text-2xl font-bold text-blue-600">{dailyMetrics.newMembers}</div>
                        <div className="text-sm text-blue-800">New Members</div>
                        <div className="text-xs text-blue-600">Total: {dailyMetrics.totalMembers}</div>
                      </div>
                      <div className="text-center p-4 bg-green-50 rounded-lg">
                        <div className="text-2xl font-bold text-green-600">£{dailyMetrics.totalRevenue}</div>
                        <div className="text-sm text-green-800">Total Revenue</div>
                        <div className="text-xs text-green-600">Today: £{dailyMetrics.paymentsReceived * 24}</div>
                      </div>
                      <div className="text-center p-4 bg-purple-50 rounded-lg">
                        <div className="text-2xl font-bold text-purple-600">{dailyMetrics.socialInvitesSent}</div>
                        <div className="text-sm text-purple-800">Social Invites</div>
                        <div className="text-xs text-purple-600">Today</div>
                      </div>
                      <div className="text-center p-4 bg-orange-50 rounded-lg">
                        <div className="text-2xl font-bold text-orange-600">{dailyMetrics.businessEmailsSent}</div>
                        <div className="text-sm text-orange-800">Business Emails</div>
                        <div className="text-xs text-orange-600">Today</div>
                      </div>
                      <div className="text-center p-4 bg-red-50 rounded-lg">
                        <div className="text-2xl font-bold text-red-600">{dailyMetrics.newBusinessSignups}</div>
                        <div className="text-sm text-red-800">New Businesses</div>
                        <div className="text-xs text-red-600">Total: {dailyMetrics.totalBusinesses}</div>
                      </div>
                      <div className="text-center p-4 bg-indigo-50 rounded-lg">
                        <div className="text-2xl font-bold text-indigo-600">{dailyMetrics.activeUsers}</div>
                        <div className="text-sm text-indigo-800">Active Users</div>
                        <div className="text-xs text-indigo-600">Today</div>
                      </div>
                      <div className="text-center p-4 bg-pink-50 rounded-lg">
                        <div className="text-2xl font-bold text-pink-600">{dailyMetrics.newDiscussions}</div>
                        <div className="text-sm text-pink-800">New Discussions</div>
                        <div className="text-xs text-pink-600">Today</div>
                      </div>
                      <div className="text-center p-4 bg-cyan-50 rounded-lg">
                        <div className="text-2xl font-bold text-cyan-600">{dailyMetrics.platformGrowth.toFixed(1)}%</div>
                        <div className="text-sm text-cyan-800">Growth Rate</div>
                        <div className="text-xs text-cyan-600">Daily</div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              )}

              {selectedReport === "business" && businessMetrics && (
                <Card>
                  <CardHeader>
                    <CardTitle>Business Directory Report</CardTitle>
                    <CardDescription>All registered businesses and their status</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {businessMetrics.map((business, index) => (
                        <div key={index} className="flex items-center justify-between p-4 border rounded-lg">
                          <div>
                            <div className="font-semibold">{business.businessName}</div>
                            <div className="text-sm text-muted-foreground">{business.location}</div>
                            <div className="text-xs text-muted-foreground">Joined: {business.signupDate}</div>
                          </div>
                          <div className="text-right">
                            <Badge variant={business.paymentStatus === 'Active' ? 'default' : 'secondary'}>
                              {business.paymentStatus}
                            </Badge>
                            <div className="text-sm mt-1">{business.adsRunning} ads running</div>
                            <div className="text-xs text-muted-foreground">{business.contactAttempts} contacts</div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="system" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>System Control</CardTitle>
              <CardDescription>Manual control over platform systems and fixes</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                <Button onClick={() => restartService('rss')} size="lg" className="h-20 flex-col bg-orange-600 hover:bg-orange-700">
                  <span className="text-lg font-semibold">📰 Restart RSS Feeds</span>
                  <span className="text-sm opacity-75">News posting system</span>
                </Button>
                <Button onClick={() => restartService('email')} size="lg" className="h-20 flex-col bg-yellow-600 hover:bg-yellow-700">
                  <span className="text-lg font-semibold">📧 Restart Email Service</span>
                  <span className="text-sm opacity-75">SendGrid system</span>
                </Button>
                <Button onClick={() => restartService('social')} size="lg" className="h-20 flex-col bg-pink-600 hover:bg-pink-700">
                  <span className="text-lg font-semibold">🤝 Restart Social Invites</span>
                  <span className="text-sm opacity-75">Friend invitations</span>
                </Button>
                <Button onClick={() => restartService('database')} size="lg" className="h-20 flex-col bg-indigo-600 hover:bg-indigo-700">
                  <span className="text-lg font-semibold">🗄️ Restart Database</span>
                  <span className="text-sm opacity-75">PostgreSQL connection</span>
                </Button>
                <Button onClick={() => restartService('api')} size="lg" className="h-20 flex-col bg-teal-600 hover:bg-teal-700">
                  <span className="text-lg font-semibold">⚡ Restart API Routes</span>
                  <span className="text-sm opacity-75">All endpoints</span>
                </Button>
                <Button onClick={() => restartService('business')} size="lg" className="h-20 flex-col bg-purple-600 hover:bg-purple-700">
                  <span className="text-lg font-semibold">💼 Restart Business System</span>
                  <span className="text-sm opacity-75">Ad campaigns</span>
                </Button>
                <Button onClick={fixSystemIssues} size="lg" className="h-20 flex-col bg-red-600 hover:bg-red-700">
                  <span className="text-lg font-semibold">🔧 Fix All Issues</span>
                  <span className="text-sm opacity-75">Complete system repair</span>
                </Button>
                <Button onClick={createSnapshot} size="lg" className="h-20 flex-col bg-blue-600 hover:bg-blue-700">
                  <span className="text-lg font-semibold">📸 Create Snapshot</span>
                  <span className="text-sm opacity-75">Save current state</span>
                </Button>
                <Button onClick={restoreSnapshot} size="lg" className="h-20 flex-col bg-gray-600 hover:bg-gray-700">
                  <span className="text-lg font-semibold">🔄 Restore Snapshot</span>
                  <span className="text-sm opacity-75">Restore working state</span>
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="automation" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Automation Status</CardTitle>
              <CardDescription>Monitor and control automated systems</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex items-center justify-between p-4 border rounded-lg">
                  <div>
                    <div className="font-semibold">📰 RSS Feed Service</div>
                    <div className="text-sm text-muted-foreground">Daily news posting to discussions</div>
                  </div>
                  <div className="flex items-center gap-2">
                    <Badge variant="default">Active</Badge>
                    <Button onClick={() => restartService('rss')} size="sm" variant="outline">
                      Restart
                    </Button>
                  </div>
                </div>
                <div className="flex items-center justify-between p-4 border rounded-lg">
                  <div>
                    <div className="font-semibold">📧 Email Service</div>
                    <div className="text-sm text-muted-foreground">SendGrid notifications and reports</div>
                  </div>
                  <div className="flex items-center gap-2">
                    <Badge variant="destructive">Needs Setup</Badge>
                    <Button onClick={() => restartService('email')} size="sm" variant="outline">
                      Restart
                    </Button>
                  </div>
                </div>
                <div className="flex items-center justify-between p-4 border rounded-lg">
                  <div>
                    <div className="font-semibold">🤝 Social Media Invites</div>
                    <div className="text-sm text-muted-foreground">Automatic friend invitations</div>
                  </div>
                  <div className="flex items-center gap-2">
                    <Badge variant="default">Active</Badge>
                    <Button onClick={() => restartService('social')} size="sm" variant="outline">
                      Restart
                    </Button>
                  </div>
                </div>
                <div className="flex items-center justify-between p-4 border rounded-lg">
                  <div>
                    <div className="font-semibold">🗄️ Database Connection</div>
                    <div className="text-sm text-muted-foreground">PostgreSQL data storage</div>
                  </div>
                  <div className="flex items-center gap-2">
                    <Badge variant="default">Connected</Badge>
                    <Button onClick={() => restartService('database')} size="sm" variant="outline">
                      Restart
                    </Button>
                  </div>
                </div>
                <div className="flex items-center justify-between p-4 border rounded-lg">
                  <div>
                    <div className="font-semibold">⚡ API Routes</div>
                    <div className="text-sm text-muted-foreground">All backend endpoints</div>
                  </div>
                  <div className="flex items-center gap-2">
                    <Badge variant="default">Responsive</Badge>
                    <Button onClick={() => restartService('api')} size="sm" variant="outline">
                      Restart
                    </Button>
                  </div>
                </div>
                <div className="flex items-center justify-between p-4 border rounded-lg">
                  <div>
                    <div className="font-semibold">💼 Business Campaign Service</div>
                    <div className="text-sm text-muted-foreground">£24/year advertising outreach</div>
                  </div>
                  <div className="flex items-center gap-2">
                    <Badge variant="default">Active</Badge>
                    <Button onClick={() => restartService('business')} size="sm" variant="outline">
                      Restart
                    </Button>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="monitoring" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Real-Time Monitoring</CardTitle>
              <CardDescription>Live platform statistics and alerts</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="text-center p-6 bg-green-50 rounded-lg">
                  <div className="text-3xl font-bold text-green-600">✓</div>
                  <div className="text-lg font-semibold">Database</div>
                  <div className="text-sm text-green-700">Operational</div>
                </div>
                <div className="text-center p-6 bg-green-50 rounded-lg">
                  <div className="text-3xl font-bold text-green-600">✓</div>
                  <div className="text-lg font-semibold">API Endpoints</div>
                  <div className="text-sm text-green-700">Responsive</div>
                </div>
                <div className="text-center p-6 bg-green-50 rounded-lg">
                  <div className="text-3xl font-bold text-green-600">✓</div>
                  <div className="text-lg font-semibold">User Sessions</div>
                  <div className="text-sm text-green-700">Active</div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </main>
  );
}