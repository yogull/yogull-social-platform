import { useState } from "react";
import { useAuth } from "@/hooks/useAuth";
import { resetPassword, changePassword } from "@/lib/auth";
import { Sidebar } from "@/components/Sidebar";
import { MobileNav } from "@/components/MobileNav";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { PageHeader } from "@/components/PageHeader";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useToast } from "@/hooks/use-toast";
import { Key, Shield } from "lucide-react";

const passwordChangeSchema = z.object({
  currentPassword: z.string().min(1, "Current password is required"),
  newPassword: z.string().min(6, "New password must be at least 6 characters"),
  confirmPassword: z.string().min(1, "Please confirm your new password")
}).refine((data) => data.newPassword === data.confirmPassword, {
  message: "Passwords don't match",
  path: ["confirmPassword"]
});

export default function ProfileSettings() {
  const { appUser } = useAuth();
  const { toast } = useToast();
  const [showPasswordDialog, setShowPasswordDialog] = useState(false);
  const [isChangingPassword, setIsChangingPassword] = useState(false);

  const passwordForm = useForm<z.infer<typeof passwordChangeSchema>>({
    resolver: zodResolver(passwordChangeSchema),
    defaultValues: {
      currentPassword: "",
      newPassword: "",
      confirmPassword: ""
    }
  });

  const handlePasswordChange = async (values: z.infer<typeof passwordChangeSchema>) => {
    setIsChangingPassword(true);
    try {
      await changePassword(values.currentPassword, values.newPassword);
      toast({
        title: "Password Changed",
        description: "Your password has been successfully updated.",
      });
      setShowPasswordDialog(false);
      passwordForm.reset();
    } catch (error: any) {
      console.error("Password change error:", error);
      let errorMessage = "Failed to change password. Please try again.";
      
      if (error.code === 'auth/wrong-password') {
        errorMessage = "Current password is incorrect.";
      } else if (error.code === 'auth/weak-password') {
        errorMessage = "New password is too weak. Please use at least 6 characters.";
      } else if (error.code === 'auth/requires-recent-login') {
        errorMessage = "For security reasons, please sign out and sign back in before changing your password.";
      }
      
      toast({
        title: "Password Change Failed",
        description: errorMessage,
        variant: "destructive"
      });
    } finally {
      setIsChangingPassword(false);
    }
  };

  const handlePasswordReset = async () => {
    if (!appUser?.email) {
      toast({
        title: "Error",
        description: "No email address found for password reset.",
        variant: "destructive"
      });
      return;
    }

    try {
      await resetPassword(appUser.email);
      toast({
        title: "Password Reset Email Sent",
        description: "Check your email for password reset instructions.",
      });
    } catch (error) {
      toast({
        title: "Password Reset Failed",
        description: "Failed to send password reset email. Please try again.",
        variant: "destructive"
      });
    }
  };

  if (!appUser) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-xl font-semibold text-gray-900 mb-2">Please sign in</h2>
          <a href="/login" className="text-primary hover:text-primary/80">
            Go to login page
          </a>
        </div>
      </div>
    );
  }

  const memberSince = new Date(appUser.createdAt).toLocaleDateString('en-US', {
    year: 'numeric',
    month: 'long',
    day: 'numeric'
  });

  return (
    <div className="lg:flex lg:h-screen">
      <Sidebar user={appUser} />
      <MobileNav user={appUser} />
      
      <main className="flex-1 overflow-auto bg-gray-50">
        <div className="bg-white border-b border-gray-200 px-4 lg:px-8 py-6">
          <PageHeader 
            title="Account Settings" 
            subtitle="Manage your password and security settings"
          />
        </div>

        <div className="container mx-auto max-w-4xl p-4 lg:p-8 space-y-6 pb-20 lg:pb-8">
          {/* Profile Overview */}
          <Card className="shadow-sm">
            <CardHeader className="pb-4">
              <CardTitle className="text-lg text-gray-900">Profile Overview</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center space-x-4">
                <div className="w-16 h-16 bg-primary rounded-full flex items-center justify-center flex-shrink-0">
                  <span className="text-white font-bold text-xl">
                    {appUser.name.charAt(0).toUpperCase()}
                  </span>
                </div>
                <div className="flex-1 min-w-0">
                  <h3 className="text-xl font-semibold text-gray-900 truncate">{appUser.name}</h3>
                  <p className="text-gray-600 truncate">{appUser.email}</p>
                  <div className="flex flex-wrap items-center gap-2 mt-3">
                    <Badge variant="secondary" className="text-xs">
                      Member since {memberSince}
                    </Badge>
                    <Badge variant="outline" className="text-xs">
                      Verified Account
                    </Badge>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Account Security */}
          <Card className="shadow-sm">
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Shield className="w-5 h-5 text-primary" />
                <span>Account Security</span>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="p-6 border border-gray-200 rounded-lg bg-gray-50">
                <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
                  <div className="flex-1">
                    <h4 className="font-medium text-gray-900 text-base">Password Management</h4>
                    <p className="text-sm text-gray-600 mt-1">Change your password or request a reset email</p>
                  </div>
                  <div className="flex flex-col sm:flex-row gap-3">
                    <Dialog open={showPasswordDialog} onOpenChange={setShowPasswordDialog}>
                      <DialogTrigger asChild>
                        <Button variant="outline" size="sm">
                          <Key className="w-4 h-4 mr-2" />
                          Change Password
                        </Button>
                      </DialogTrigger>
                      <DialogContent className="sm:max-w-md">
                        <DialogHeader>
                          <DialogTitle className="flex items-center gap-2">
                            <Shield className="w-5 h-5" />
                            Change Password
                          </DialogTitle>
                        </DialogHeader>
                        <Form {...passwordForm}>
                          <form onSubmit={passwordForm.handleSubmit(handlePasswordChange)} className="space-y-4">
                            <FormField
                              control={passwordForm.control}
                              name="currentPassword"
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel>Current Password</FormLabel>
                                  <FormControl>
                                    <Input 
                                      type="password" 
                                      placeholder="Enter your current password"
                                      {...field} 
                                    />
                                  </FormControl>
                                  <FormMessage />
                                </FormItem>
                              )}
                            />
                            <FormField
                              control={passwordForm.control}
                              name="newPassword"
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel>New Password</FormLabel>
                                  <FormControl>
                                    <Input 
                                      type="password" 
                                      placeholder="Enter your new password (min 6 characters)"
                                      {...field} 
                                    />
                                  </FormControl>
                                  <FormMessage />
                                </FormItem>
                              )}
                            />
                            <FormField
                              control={passwordForm.control}
                              name="confirmPassword"
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel>Confirm New Password</FormLabel>
                                  <FormControl>
                                    <Input 
                                      type="password" 
                                      placeholder="Confirm your new password"
                                      {...field} 
                                    />
                                  </FormControl>
                                  <FormMessage />
                                </FormItem>
                              )}
                            />
                            <div className="flex gap-2 pt-4">
                              <Button 
                                type="submit" 
                                disabled={isChangingPassword}
                                className="flex-1"
                              >
                                {isChangingPassword ? "Changing..." : "Change Password"}
                              </Button>
                              <Button 
                                type="button" 
                                variant="outline" 
                                onClick={() => setShowPasswordDialog(false)}
                              >
                                Cancel
                              </Button>
                            </div>
                          </form>
                        </Form>
                      </DialogContent>
                    </Dialog>
                    <Button variant="outline" size="sm" onClick={handlePasswordReset}>
                      <Key className="w-4 h-4 mr-2" />
                      Reset Password
                    </Button>
                  </div>
                </div>
              </div>

              <div className="p-6 border border-gray-200 rounded-lg bg-white">
                <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
                  <div className="flex-1">
                    <h4 className="font-medium text-gray-900 text-base">Two-Factor Authentication</h4>
                    <p className="text-sm text-gray-600 mt-1">Add an extra layer of security to your account</p>
                  </div>
                  <Button variant="outline" size="sm" disabled>
                    <Shield className="w-4 h-4 mr-2" />
                    Coming Soon
                  </Button>
                </div>
              </div>

              <div className="p-6 border border-gray-200 rounded-lg bg-white">
                <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
                  <div className="flex-1">
                    <h4 className="font-medium text-gray-900 text-base">Login Sessions</h4>
                    <p className="text-sm text-gray-600 mt-1">Manage devices that have access to your account</p>
                  </div>
                  <Button variant="outline" size="sm" disabled>
                    <Shield className="w-4 h-4 mr-2" />
                    Coming Soon
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Quick Navigation */}
          <Card className="shadow-sm">
            <CardHeader>
              <CardTitle className="text-lg text-gray-900">Quick Navigation</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                <Button 
                  variant="outline" 
                  className="h-12 justify-start text-left"
                  onClick={() => window.location.href = '/dashboard'}
                >
                  Dashboard
                </Button>
                <Button 
                  variant="outline" 
                  className="h-12 justify-start text-left"
                  onClick={() => window.location.href = '/profile'}
                >
                  Profile Information
                </Button>
                <Button 
                  variant="outline" 
                  className="h-12 justify-start text-left"
                  onClick={() => window.location.href = `/profile-wall/${appUser.id}`}
                >
                  Profile Wall
                </Button>
                <Button 
                  variant="outline" 
                  className="h-12 justify-start text-left"
                  onClick={() => window.location.href = '/community'}
                >
                  Community
                </Button>
                <Button 
                  variant="outline" 
                  className="h-12 justify-start text-left"
                  onClick={() => window.location.href = '/chat'}
                >
                  Chat & Messaging
                </Button>
                <Button 
                  variant="outline" 
                  className="h-12 justify-start text-left"
                  onClick={() => window.location.href = '/shop'}
                >
                  Shop
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  );
}