import React from 'react';

const DirectProfileWall = () => {
  return (
    <div style={{ padding: '20px', fontFamily: 'Arial, sans-serif' }}>
      <h1>Profile Wall - WORKING</h1>
      <p>This is the working profile wall component.</p>
      <button onClick={() => window.location.href = '/dashboard'}>
        Back to Dashboard
      </button>
    </div>
  );
};

export default DirectProfileWall;