import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertUserSchema } from "@shared/schema";
import { z } from "zod";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/useAuth";
import { useTutorial } from "@/hooks/useTutorial";
import { useLocation } from "wouter";
import { signOut } from "@/lib/auth";
import { Sidebar } from "@/components/Sidebar";
import { MobileNav } from "@/components/MobileNav";
import { PageHeader } from "@/components/PageHeader";
import { TutorialPopup } from "@/components/TutorialPopup";
import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import SocialActions from "@/components/SocialActions";
import { Separator } from "@/components/ui/separator";
import { Badge } from "@/components/ui/badge";

const profileFormSchema = insertUserSchema.pick({
  name: true,
  email: true,
}).extend({
  name: z.string().min(2, "Name must be at least 2 characters"),
  email: z.string().email("Please enter a valid email address"),
});

type ProfileFormData = z.infer<typeof profileFormSchema>;

export default function Profile() {
  const { appUser, loading } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [location, setLocation] = useLocation();
  const { shouldShowTutorial, getTutorialSteps, markTutorialComplete } = useTutorial();

  const form = useForm<ProfileFormData>({
    resolver: zodResolver(profileFormSchema),
    defaultValues: {
      name: "",
      email: "",
    },
  });

  // Update form when user data loads
  useEffect(() => {
    if (appUser) {
      form.reset({
        name: appUser.name,
        email: appUser.email,
      });
    }
  }, [appUser, form]);

  const updateProfileMutation = useMutation({
    mutationFn: async (data: ProfileFormData) => {
      if (!appUser) throw new Error("User not found");
      return apiRequest("PUT", `/api/users/${appUser.id}`, data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/users/firebase/${appUser?.firebaseUid}`] });
      toast({
        title: "Profile updated!",
        description: "Your profile information has been saved successfully.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to update profile. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleSignOut = async () => {
    try {
      await signOut();
      setLocation("/login");
      toast({
        title: "Signed out",
        description: "You have been successfully signed out.",
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to sign out. Please try again.",
        variant: "destructive",
      });
    }
  };

  const onSubmit = (data: ProfileFormData) => {
    updateProfileMutation.mutate(data);
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="animate-pulse text-center">
          <div className="w-16 h-16 bg-gray-200 rounded-xl mx-auto mb-4"></div>
          <div className="h-4 bg-gray-200 rounded w-32 mx-auto"></div>
        </div>
      </div>
    );
  }

  if (!appUser) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-xl font-semibold text-gray-900 mb-2">Please sign in</h2>
          <a href="/login" className="text-primary hover:text-primary/80">
            Go to login page
          </a>
        </div>
      </div>
    );
  }

  const memberSince = new Date(appUser.createdAt).toLocaleDateString('en-US', {
    year: 'numeric',
    month: 'long',
    day: 'numeric'
  });

  return (
    <div className="lg:flex lg:h-screen">
      <Sidebar user={appUser} />
      <MobileNav user={appUser} />
      
      <main className="flex-1 overflow-auto">
        <div className="bg-white border-b border-gray-200 px-4 lg:px-8 py-6">
          <PageHeader 
            title="Profile Settings" 
            subtitle="Manage your account information and preferences"
          />
        </div>

        <div className="p-4 lg:p-8 space-y-8 pb-20 lg:pb-8">
          {/* Profile Overview */}
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center space-x-4">
                <div className="w-16 h-16 bg-primary rounded-full flex items-center justify-center">
                  <span className="text-white font-bold text-sm">
                    {appUser.name.charAt(0).toUpperCase()}
                  </span>
                </div>
                <div className="flex-1">
                  <h3 className="text-xl font-semibold text-gray-900">{appUser.name}</h3>
                  <p className="text-gray-600">{appUser.email}</p>
                  <div className="flex items-center space-x-4 mt-2">
                    <Badge variant="secondary" className="text-xs">
                      <i className="fas fa-calendar-alt mr-1"></i>
                      Member since {memberSince}
                    </Badge>
                    <Badge variant="outline" className="text-xs">
                      <i className="fas fa-shield-alt mr-1"></i>
                      Verified Account
                    </Badge>
                  </div>
                  
                  {/* Photo Album Button under bio */}
                  <div className="mt-4">
                    <Button 
                      onClick={() => setLocation('/gallery')}
                      className="bg-purple-600 hover:bg-purple-700 text-white px-6 py-3 text-lg font-bold rounded-lg shadow-lg border-2 border-purple-800 min-h-[50px] touch-manipulation w-full"
                    >
                      📸 Photo Album
                    </Button>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Account Information */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <i className="fas fa-user-edit text-primary"></i>
                <span>Account Information</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="name">Full Name</Label>
                    <Input
                      id="name"
                      placeholder="Enter your full name"
                      {...form.register("name")}
                    />
                    {form.formState.errors.name && (
                      <p className="text-sm text-red-600">{form.formState.errors.name.message}</p>
                    )}
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="email">Email Address</Label>
                    <Input
                      id="email"
                      type="email"
                      placeholder="Enter your email"
                      {...form.register("email")}
                    />
                    {form.formState.errors.email && (
                      <p className="text-sm text-red-600">{form.formState.errors.email.message}</p>
                    )}
                  </div>
                </div>

                <div className="flex space-x-4">
                  <Button 
                    type="submit" 
                    className="bg-primary hover:bg-primary/90"
                    disabled={updateProfileMutation.isPending}
                  >
                    {updateProfileMutation.isPending ? (
                      <>
                        <i className="fas fa-spinner fa-spin mr-2"></i>
                        Updating...
                      </>
                    ) : (
                      <>
                        <i className="fas fa-save mr-2"></i>
                        Save Changes
                      </>
                    )}
                  </Button>
                  
                  <Button 
                    type="button" 
                    variant="outline"
                    onClick={() => form.reset()}
                    disabled={updateProfileMutation.isPending}
                  >
                    Cancel
                  </Button>
                </div>
              </form>
            </CardContent>
          </Card>

          {/* Preferences */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <i className="fas fa-cog text-primary"></i>
                <span>Preferences</span>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="flex items-center justify-between p-4 border border-gray-200 rounded-lg">
                <div>
                  <h4 className="font-medium text-gray-900">Email Notifications</h4>
                  <p className="text-sm text-gray-600">Receive weekly health summaries and reminders</p>
                </div>
                <div className="text-primary">
                  <i className="fas fa-toggle-on text-2xl"></i>
                </div>
              </div>

              <div className="flex items-center justify-between p-4 border border-gray-200 rounded-lg">
                <div>
                  <h4 className="font-medium text-gray-900">Supplement Reminders</h4>
                  <p className="text-sm text-gray-600">Get notified when it's time to take supplements</p>
                </div>
                <div className="text-primary">
                  <i className="fas fa-toggle-on text-2xl"></i>
                </div>
              </div>

              <div className="flex items-center justify-between p-4 border border-gray-200 rounded-lg">
                <div>
                  <h4 className="font-medium text-gray-900">Data Sync</h4>
                  <p className="text-sm text-gray-600">Automatically sync data across devices</p>
                </div>
                <div className="text-primary">
                  <i className="fas fa-toggle-on text-2xl"></i>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Health Goals */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <i className="fas fa-target text-primary"></i>
                <span>Health Goals</span>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="p-4 bg-blue-50 rounded-lg">
                  <div className="flex items-center space-x-3">
                    <div className="w-10 h-10 bg-blue-500 rounded-lg flex items-center justify-center">
                      <i className="fas fa-walking text-white"></i>
                    </div>
                    <div>
                      <h4 className="font-medium text-gray-900">Daily Steps</h4>
                      <p className="text-sm text-gray-600">Goal: 10,000 steps</p>
                    </div>
                  </div>
                </div>

                <div className="p-4 bg-purple-50 rounded-lg">
                  <div className="flex items-center space-x-3">
                    <div className="w-10 h-10 bg-purple-500 rounded-lg flex items-center justify-center">
                      <i className="fas fa-moon text-white"></i>
                    </div>
                    <div>
                      <h4 className="font-medium text-gray-900">Sleep Duration</h4>
                      <p className="text-sm text-gray-600">Goal: 8 hours</p>
                    </div>
                  </div>
                </div>

                <div className="p-4 bg-green-50 rounded-lg">
                  <div className="flex items-center space-x-3">
                    <div className="w-10 h-10 bg-primary rounded-lg flex items-center justify-center">
                      <i className="fas fa-pills text-white"></i>
                    </div>
                    <div>
                      <h4 className="font-medium text-gray-900">Supplement Adherence</h4>
                      <p className="text-sm text-gray-600">Goal: 95% compliance</p>
                    </div>
                  </div>
                </div>

                <div className="p-4 bg-orange-50 rounded-lg">
                  <div className="flex items-center space-x-3">
                    <div className="w-10 h-10 bg-orange-500 rounded-lg flex items-center justify-center">
                      <i className="fas fa-fire text-white"></i>
                    </div>
                    <div>
                      <h4 className="font-medium text-gray-900">Streak Goal</h4>
                      <p className="text-sm text-gray-600">Goal: 30 days</p>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Account Actions */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <i className="fas fa-shield-alt text-primary"></i>
                <span>Account Security</span>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between p-4 border border-gray-200 rounded-lg">
                <div>
                  <h4 className="font-medium text-gray-900">Password</h4>
                  <p className="text-sm text-gray-600">Last updated: Managed by Firebase</p>
                </div>
                <div className="flex gap-2">
                  <Button variant="outline" size="sm" onClick={() => window.location.href = '/profile-settings'}>
                    <i className="fas fa-key mr-2"></i>
                    Change Password
                  </Button>
                  <Button variant="outline" size="sm">
                    <i className="fas fa-key mr-2"></i>
                    Reset Password
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  );
}
