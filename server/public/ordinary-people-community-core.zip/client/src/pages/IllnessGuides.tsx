import { useState, useMemo } from "react";
import { Link } from "wouter";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { PageHelpSystem } from "@/components/PageHelpSystem";
import { useTranslation } from "@/hooks/useTranslation";
import { UniversalInstructionsButton } from "@/components/UniversalInstructionsButton";
import { Search, Brain, Zap, Heart, Users, MessageCircle, BookOpen, AlertTriangle, Filter } from "lucide-react";

interface IllnessGuide {
  id: string;
  title: string;
  description: string;
  category: string;
  severity: 'mild' | 'moderate' | 'severe';
  prevalence: string;
  icon: string;
  color: string;
}

// Optimized illness guides data
const illnessGuides: IllnessGuide[] = [
  {
    id: "brain-injury",
    title: "Traumatic Brain Injury (TBI)",
    description: "Understanding brain injuries, symptoms, recovery strategies, and how to support those affected.",
    category: "Neurological",
    severity: "severe",
    prevalence: "700,000 annually in UK",
    icon: "brain",
    color: "red"
  },
  {
    id: "dementia",
    title: "Dementia & Alzheimer's",
    description: "Comprehensive guide to dementia types, early signs, caregiving tips, and community support.",
    category: "Neurological",
    severity: "severe",
    prevalence: "944,000 people in UK",
    icon: "brain",
    color: "purple"
  },
  {
    id: "diabetes-1",
    title: "Diabetes Type 1",
    description: "Understanding Type 1 diabetes, insulin management, blood sugar monitoring, and lifestyle adaptations.",
    category: "Endocrine",
    severity: "severe",
    prevalence: "400,000 people in UK",
    icon: "heart",
    color: "blue"
  },
  {
    id: "diabetes-2",
    title: "Diabetes Type 2",
    description: "Managing Type 2 diabetes through diet, exercise, medication, and preventing complications.",
    category: "Endocrine",
    severity: "moderate",
    prevalence: "4.9 million people in UK",
    icon: "heart",
    color: "green"
  },
  {
    id: "depression",
    title: "Depression",
    description: "Understanding depression symptoms, treatment options, support systems, and recovery approaches.",
    category: "Mental Health",
    severity: "moderate",
    prevalence: "4.5 million adults in UK",
    icon: "brain",
    color: "blue"
  },
  {
    id: "anxiety",
    title: "Anxiety Disorders",
    description: "Managing anxiety, panic attacks, social anxiety, and developing coping strategies for daily life.",
    category: "Mental Health",
    severity: "moderate",
    prevalence: "8.2 million people in UK",
    icon: "brain",
    color: "yellow"
  },
  {
    id: "arthritis",
    title: "Arthritis",
    description: "Understanding arthritis types, joint pain management, mobility support, and treatment options.",
    category: "Musculoskeletal",
    severity: "moderate",
    prevalence: "10 million people in UK",
    icon: "users",
    color: "orange"
  },
  {
    id: "ibs",
    title: "Irritable Bowel Syndrome (IBS)",
    description: "Managing IBS symptoms, dietary approaches, stress reduction, and improving digestive health.",
    category: "Gastrointestinal",
    severity: "moderate",
    prevalence: "13 million people in UK",
    icon: "heart",
    color: "green"
  },
  {
    id: "bipolar-disorder",
    title: "Bipolar Disorder",
    description: "Understanding mood swings, manic and depressive episodes, treatment options, and lifestyle management.",
    category: "Mental Health",
    severity: "severe",
    prevalence: "1.3 million people in UK",
    icon: "brain",
    color: "orange"
  },
  {
    id: "adhd",
    title: "ADHD",
    description: "Managing attention, hyperactivity, impulsivity, and developing coping strategies for daily life.",
    category: "Mental Health",
    severity: "moderate",
    prevalence: "2.6 million adults in UK",
    icon: "brain",
    color: "yellow"
  },
  {
    id: "autism",
    title: "Autism Spectrum Disorder",
    description: "Understanding autism, sensory needs, communication support, and creating inclusive environments.",
    category: "Mental Health",
    severity: "moderate",
    prevalence: "700,000 people in UK",
    icon: "brain",
    color: "blue"
  },
  {
    id: "sleep-disorders",
    title: "Sleep Disorders",
    description: "Understanding insomnia, sleep apnea, restless leg syndrome, sleep hygiene, and effective treatment options.",
    category: "Sleep Health",
    severity: "moderate",
    prevalence: "16 million adults in UK",
    icon: "brain",
    color: "purple"
  }
];

export default function IllnessGuides() {
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("all");
  const { t } = useTranslation();

  // Memoized calculations for performance
  const categories = useMemo(() => 
    ["all", ...Array.from(new Set(illnessGuides.map(guide => guide.category)))], 
    []
  );

  const filteredGuides = useMemo(() => {
    if (searchTerm === "" && selectedCategory === "all") return illnessGuides;
    
    return illnessGuides.filter(guide => {
      const matchesSearch = searchTerm === "" || 
        guide.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
        guide.description.toLowerCase().includes(searchTerm.toLowerCase());
      
      const matchesCategory = selectedCategory === "all" || guide.category === selectedCategory;
      
      return matchesSearch && matchesCategory;
    });
  }, [searchTerm, selectedCategory]);

  const getIcon = (iconName: string) => {
    const iconProps = { className: "w-6 h-6" };
    switch (iconName) {
      case "brain": return <Brain {...iconProps} />;
      case "zap": return <Zap {...iconProps} />;
      case "heart": return <Heart {...iconProps} />;
      case "users": return <Users {...iconProps} />;
      case "alert-triangle": return <AlertTriangle {...iconProps} />;
      case "book-open": return <BookOpen {...iconProps} />;
      default: return <MessageCircle {...iconProps} />;
    }
  };

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case "mild": return "bg-green-100 text-green-800";
      case "moderate": return "bg-yellow-100 text-yellow-800";
      case "severe": return "bg-red-100 text-red-800";
      default: return "bg-gray-100 text-gray-800";
    }
  };

  const getColorClasses = (color: string) => {
    switch (color) {
      case "red": return "text-red-600 bg-red-50 hover:bg-red-100";
      case "purple": return "text-purple-600 bg-purple-50 hover:bg-purple-100";
      case "yellow": return "text-yellow-600 bg-yellow-50 hover:bg-yellow-100";
      case "blue": return "text-blue-600 bg-blue-50 hover:bg-blue-100";
      case "green": return "text-green-600 bg-green-50 hover:bg-green-100";
      case "orange": return "text-orange-600 bg-orange-50 hover:bg-orange-100";
      default: return "text-gray-600 bg-gray-50 hover:bg-gray-100";
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 p-4">
      {/* Instructions Button */}
      <UniversalInstructionsButton currentPage="illness-guides" position="top" />
      

      
      <div className="mobile-safe w-full max-w-7xl mx-auto px-4 sm:px-6 py-4 overflow-x-hidden">
        {/* Back Button */}
        <div className="mb-6">
          <Link href="/">
            <Button variant="outline" className="flex items-center gap-2">
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
              </svg>
{t('common.back')} to {t('nav.dashboard')}
            </Button>
          </Link>
        </div>

        {/* Header with Search */}
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">{t('health.title')}</h1>
          <p className="text-xl text-gray-600 mb-6">
            {t('health.subtitle')}
          </p>
          
          {/* Search Controls */}
          <div className="max-w-4xl mx-auto space-y-4">
            {/* Search Bar */}
            <div className="relative">
              <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-400 w-6 h-6" />
              <Input
                type="text"
                placeholder={t('health.searchPlaceholder')}
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-12 py-4 text-lg border-2 border-blue-200 focus:border-blue-400 rounded-lg shadow-sm"
              />
            </div>

            {/* Category Buttons */}
            <div className="max-w-5xl mx-auto">
              <h3 className="text-center text-lg font-medium text-gray-700 mb-4">{t('health.browseCategories')}</h3>
              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-3">
                {categories.map((category) => {
                  const categoryGuides = category === "all" ? illnessGuides : illnessGuides.filter(g => g.category === category);
                  const isSelected = selectedCategory === category;
                  
                  return (
                    <button
                      key={category}
                      onClick={() => setSelectedCategory(category)}
                      className={`p-3 rounded-lg border-2 text-center transition-all duration-200 ${
                        isSelected 
                          ? 'bg-blue-500 text-white border-blue-500 shadow-md' 
                          : 'bg-white text-gray-700 border-gray-200 hover:border-blue-300 hover:bg-blue-50'
                      }`}
                    >
                      <div className="font-medium text-sm">
                        {category === "all" ? "All Conditions" : category}
                      </div>
                      <div className="text-xs mt-1 opacity-75">
                        {categoryGuides.length} conditions
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>
            
            {/* Quick Browse Dropdown */}
            <div className="max-w-md mx-auto">
              <Select onValueChange={(value) => {
                const guide = illnessGuides.find(g => g.id === value);
                if (guide) {
                  setSearchTerm(guide.title);
                }
              }}>
                <SelectTrigger className="w-full py-3 border-2 border-green-200 bg-green-50">
                  <div className="flex items-center">
                    <span className="mr-2">📋</span>
                    <span>{t('health.quickBrowse')}</span>
                  </div>
                </SelectTrigger>
                <SelectContent className="max-h-64">
                  {illnessGuides
                    .sort((a, b) => a.title.localeCompare(b.title))
                    .map((guide) => (
                      <SelectItem key={guide.id} value={guide.id}>
                        <div className="flex items-center justify-between w-full">
                          <span>{guide.title}</span>
                          <Badge variant="outline" className="ml-2 text-xs">
                            {guide.category}
                          </Badge>
                        </div>
                      </SelectItem>
                    ))}
                </SelectContent>
              </Select>
            </div>

            {/* Search Results Info */}
            {searchTerm && (
              <div className="text-center text-sm text-gray-600">
                Showing {filteredGuides.length} results for "{searchTerm}"
              </div>
            )}
          </div>
        </div>

        {/* Illness Guides Grid */}
        <div className="illness-guide-grid grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
          {filteredGuides.map((guide) => (
            <Link key={guide.id} href={`/illness-guides/${guide.id}`}>
              <Card className={`illness-guide-card h-full cursor-pointer transition-all duration-200 hover:shadow-lg border-2 hover:border-opacity-50 ${getColorClasses(guide.color)} flex flex-col`}>
                <CardHeader className="pb-2 p-4">
                  <div className="flex items-center justify-between mb-2">
                    <div className={`p-2 rounded-lg ${getColorClasses(guide.color)}`}>
                      {getIcon(guide.icon)}
                    </div>
                    <Badge className={`text-xs ${getSeverityColor(guide.severity)}`}>
                      {guide.severity}
                    </Badge>
                  </div>
                  <CardTitle className="text-sm font-semibold text-gray-900 mt-2 line-clamp-2">
                    {guide.title}
                  </CardTitle>
                </CardHeader>
                <CardContent className="pt-0 p-4 flex-1 flex flex-col justify-between">
                  <div>
                    <p className="text-gray-600 text-sm mb-3 line-clamp-3">
                      {guide.description}
                    </p>
                    
                    <div className="text-xs text-gray-500 mb-4">
                      <div className="truncate">{guide.prevalence}</div>
                    </div>
                  </div>
                  
                  <Button 
                    className="w-full text-sm py-2 mt-auto" 
                    variant="outline"
                    size="sm"
                  >
                    Learn More
                  </Button>
                </CardContent>
              </Card>
            </Link>
          ))}
        </div>

        {filteredGuides.length === 0 && searchTerm && (
          <div className="text-center py-12">
            <Search className="w-16 h-16 text-gray-400 mx-auto mb-4" />
            <h3 className="text-lg font-semibold text-gray-900 mb-2">No guides found</h3>
            <p className="text-gray-600">
              No illness guides match your search term "{searchTerm}". Try different keywords or browse all guides.
            </p>
          </div>
        )}

        {/* Community Support CTA */}
        <Card className="mt-12 bg-gradient-to-r from-green-50 to-blue-50 border-green-200">
          <CardContent className="p-8 text-center">
            <h2 className="text-2xl font-bold text-gray-900 mb-4">Join Our Supportive Community</h2>
            <p className="text-gray-700 mb-6 max-w-2xl mx-auto">
              Connect with others who understand your journey. Share experiences, find support, 
              and help create a more compassionate community for people with all types of health conditions.
            </p>
            <div className="flex justify-center gap-4">
              <Link href="/community">
                <Button size="lg" className="bg-green-600 hover:bg-green-700">
                  Join Community Discussions
                </Button>
              </Link>
              <Link href="/chat">
                <Button variant="outline" size="lg">
                  Find Support Chat
                </Button>
              </Link>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}