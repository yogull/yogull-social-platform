import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { AlertTriangle, CheckCircle, Clock, Activity, Shield, Zap } from "lucide-react";
import { useState } from "react";

interface SystemAlert {
  level: string;
  component: string;
  message: string;
  autoFix: string;
}

interface SystemStatus {
  timestamp: string;
  platform: string;
  zeroDowntimeStatus: string;
  monitoring: {
    criticalAlerts: {
      status: string;
      interval: string;
      components: string[];
      alertCount: number;
      lastCheck: string;
    };
    autoReconciliation: {
      status: string;
      interval: string;
      lastRun: string;
      automatedFixes: string[];
    };
  };
  currentAlerts: SystemAlert[];
  systemHealth: {
    uptime: string;
    memory: {
      used: string;
      total: string;
    };
    environment: string;
  };
  reconciliationDetails: any;
}

export default function SystemMonitoring() {
  const [autoRefresh, setAutoRefresh] = useState(true);

  const { data: systemStatus, isLoading, refetch } = useQuery<SystemStatus>({
    queryKey: ['/api/admin/system-status'],
    refetchInterval: autoRefresh ? 5000 : false, // Refresh every 5 seconds
  });

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 dark:from-gray-900 dark:to-gray-800 p-6">
        <div className="flex items-center justify-center h-64">
          <div className="text-center">
            <Activity className="w-8 h-8 animate-spin mx-auto mb-4 text-blue-600" />
            <p className="text-lg font-medium">Loading System Status...</p>
          </div>
        </div>
      </div>
    );
  }

  if (!systemStatus) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-red-50 to-red-100 dark:from-gray-900 dark:to-gray-800 p-6">
        <Card className="max-w-2xl mx-auto">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-red-600">
              <AlertTriangle className="w-6 h-6" />
              System Status Unavailable
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p>Unable to retrieve system status. Check admin permissions.</p>
            <Button onClick={() => refetch()} className="mt-4">Retry</Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  const getStatusColor = (status: string) => {
    switch (status.toLowerCase()) {
      case 'active':
      case 'monitoring':
      case 'fixing_issues':
        return 'bg-green-100 text-green-800';
      case 'warning':
        return 'bg-yellow-100 text-yellow-800';
      case 'critical':
        return 'bg-red-100 text-red-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const getAlertIcon = (level: string) => {
    switch (level.toLowerCase()) {
      case 'critical':
        return <AlertTriangle className="w-4 h-4 text-red-600" />;
      case 'warning':
        return <AlertTriangle className="w-4 h-4 text-yellow-600" />;
      default:
        return <CheckCircle className="w-4 h-4 text-green-600" />;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 dark:from-gray-900 dark:to-gray-800 p-6">
      <div className="max-w-7xl mx-auto space-y-6">
        
        {/* Header */}
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold text-gray-900 dark:text-white mb-2">
            System Monitoring Dashboard
          </h1>
          <p className="text-lg text-gray-600 dark:text-gray-300">
            Real-time platform health and auto-reconciliation status
          </p>
          <div className="flex items-center justify-center gap-4 mt-4">
            <Badge className={getStatusColor(systemStatus.zeroDowntimeStatus)}>
              <Shield className="w-4 h-4 mr-1" />
              {systemStatus.zeroDowntimeStatus}
            </Badge>
            <Badge variant="outline">
              <Clock className="w-4 h-4 mr-1" />
              Last Updated: {new Date(systemStatus.timestamp).toLocaleTimeString()}
            </Badge>
          </div>
        </div>

        {/* Platform Overview */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium">Platform</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{systemStatus.platform}</div>
              <p className="text-xs text-muted-foreground">Environment: {systemStatus.systemHealth.environment}</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium">Uptime</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{systemStatus.systemHealth.uptime}</div>
              <p className="text-xs text-muted-foreground">Continuous operation</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium">Memory Usage</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">
                {systemStatus.systemHealth.memory.used} / {systemStatus.systemHealth.memory.total}
              </div>
              <p className="text-xs text-muted-foreground">Heap memory allocation</p>
            </CardContent>
          </Card>
        </div>

        {/* Monitoring Systems */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
          
          {/* Critical Alerts System */}
          <Card className="border-2 border-blue-200">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Activity className="w-5 h-5 text-blue-600" />
                Critical Alert System
              </CardTitle>
              <CardDescription>
                Monitoring {systemStatus.monitoring.criticalAlerts.components.length} components every {systemStatus.monitoring.criticalAlerts.interval}
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium">Status:</span>
                <Badge className={getStatusColor(systemStatus.monitoring.criticalAlerts.status)}>
                  {systemStatus.monitoring.criticalAlerts.status}
                </Badge>
              </div>
              
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium">Active Alerts:</span>
                <Badge variant="outline">{systemStatus.monitoring.criticalAlerts.alertCount}</Badge>
              </div>

              <div className="space-y-2">
                <span className="text-sm font-medium">Monitored Components:</span>
                <div className="flex flex-wrap gap-1">
                  {systemStatus.monitoring.criticalAlerts.components.map((component, index) => (
                    <Badge key={index} variant="secondary" className="text-xs">
                      {component}
                    </Badge>
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Auto-Reconciliation System */}
          <Card className="border-2 border-green-200">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Zap className="w-5 h-5 text-green-600" />
                Auto-Reconciliation System
              </CardTitle>
              <CardDescription>
                Automatic fixes applied every {systemStatus.monitoring.autoReconciliation.interval}
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium">Status:</span>
                <Badge className={getStatusColor(systemStatus.monitoring.autoReconciliation.status)}>
                  {systemStatus.monitoring.autoReconciliation.status}
                </Badge>
              </div>

              <div className="space-y-2">
                <span className="text-sm font-medium">Automated Fixes Available:</span>
                <div className="space-y-1 max-h-32 overflow-y-auto">
                  {systemStatus.monitoring.autoReconciliation.automatedFixes.map((fix, index) => (
                    <div key={index} className="flex items-center gap-2 text-xs">
                      <CheckCircle className="w-3 h-3 text-green-600" />
                      {fix}
                    </div>
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Current Alerts */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <AlertTriangle className="w-5 h-5" />
              Current System Alerts
            </CardTitle>
            <CardDescription>
              Real-time platform health status and automated resolutions
            </CardDescription>
          </CardHeader>
          <CardContent>
            {systemStatus.currentAlerts.length === 0 ? (
              <div className="text-center py-8">
                <CheckCircle className="w-12 h-12 text-green-600 mx-auto mb-4" />
                <h3 className="text-lg font-medium text-green-600">All Systems Operational</h3>
                <p className="text-gray-600">No alerts detected - platform running smoothly</p>
              </div>
            ) : (
              <div className="space-y-3">
                {systemStatus.currentAlerts.map((alert, index) => (
                  <div key={index} className="flex items-start gap-3 p-3 border rounded-lg">
                    {getAlertIcon(alert.level)}
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <Badge className={getStatusColor(alert.level)}>
                          {alert.level}
                        </Badge>
                        <span className="font-medium">{alert.component}</span>
                      </div>
                      <p className="text-sm text-gray-600 mb-2">{alert.message}</p>
                      <div className="flex items-center gap-2">
                        <span className="text-xs text-gray-500">Auto-fix status:</span>
                        <Badge variant="outline" className="text-xs">
                          {alert.autoFix}
                        </Badge>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        {/* Controls */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Button
              variant={autoRefresh ? "default" : "outline"}
              onClick={() => setAutoRefresh(!autoRefresh)}
              className="flex items-center gap-2"
            >
              <Activity className={`w-4 h-4 ${autoRefresh ? 'animate-spin' : ''}`} />
              {autoRefresh ? 'Auto-Refresh On' : 'Auto-Refresh Off'}
            </Button>
            
            <Button variant="outline" onClick={() => refetch()}>
              Refresh Now
            </Button>
          </div>

          <p className="text-sm text-gray-500">
            Monitoring active since server startup
          </p>
        </div>
      </div>
    </div>
  );
}