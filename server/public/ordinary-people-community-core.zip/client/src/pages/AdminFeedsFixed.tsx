import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { useToast } from '@/hooks/use-toast';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { Rss, Play, Settings, Edit, ExternalLink, Calendar, Clock, Users } from 'lucide-react';

export default function AdminFeedsFixed() {
  const { toast } = useToast();
  const [isProcessing, setIsProcessing] = useState(false);
  const queryClient = useQueryClient();

  // Demo data for RSS feed sources - in production this would come from API
  const feedSources = [
    {
      id: 1,
      name: "Government Health Updates",
      sourceType: "rss",
      sourceUrl: "https://www.gov.uk/government/news.rss",
      isActive: true,
      fetchFrequency: "daily",
      lastFetchedAt: new Date(),
      targetTopic: "government, health policy",
      itemsCount: 15
    },
    {
      id: 2,
      name: "NHS Community News",
      sourceType: "api", 
      sourceUrl: "https://www.nhs.uk/news/rss",
      isActive: true,
      fetchFrequency: "twice_daily",
      lastFetchedAt: new Date(Date.now() - 2 * 60 * 60 * 1000),
      targetTopic: "health, community support",
      itemsCount: 23
    },
    {
      id: 3,
      name: "Local Council Updates",
      sourceType: "rss",
      sourceUrl: "https://example-council.gov.uk/feed",
      isActive: false,
      fetchFrequency: "daily",
      lastFetchedAt: new Date(Date.now() - 24 * 60 * 60 * 1000),
      targetTopic: "local council, community",
      itemsCount: 8
    }
  ];

  const fetchFeedsMutation = useMutation({
    mutationFn: async (sourceId?: number) => {
      const url = sourceId ? `/api/admin/feeds/fetch/${sourceId}` : '/api/admin/feeds/fetch';
      const response = await fetch(url, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        }
      });
      if (!response.ok) {
        throw new Error('Failed to fetch feeds');
      }
      return await response.json();
    },
    onSuccess: (data) => {
      toast({
        title: "Feed Fetch Successful",
        description: `Fetched ${data.itemsCreated || 0} new items from ${data.sourcesProcessed || 0} source(s).`
      });
      queryClient.invalidateQueries({ queryKey: ['/api/admin/feeds'] });
    },
    onError: (error: any) => {
      toast({
        title: "Feed Fetch Failed",
        description: error.message || "Error occurred while fetching feeds. Please try again.",
        variant: "destructive"
      });
    }
  });

  const autoPostMutation = useMutation({
    mutationFn: async () => {
      const response = await fetch('/api/admin/feeds/auto-post', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        }
      });
      if (!response.ok) {
        throw new Error('Failed to auto-post content');
      }
      return await response.json();
    },
    onSuccess: (data) => {
      toast({
        title: "Auto-Post Successful",
        description: `Created ${data.postsCreated || 0} community discussion posts from ${data.itemsProcessed || 0} feed items.`
      });
      queryClient.invalidateQueries({ queryKey: ['/api/community-discussions'] });
    },
    onError: (error: any) => {
      toast({
        title: "Auto-Post Failed",
        description: error.message || "Error occurred during auto-posting. Please try again.",
        variant: "destructive"
      });
    }
  });

  const handleFetchFeeds = async (sourceId?: number) => {
    fetchFeedsMutation.mutate(sourceId);
  };

  const handleAutoPost = async () => {
    autoPostMutation.mutate();
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-6xl mx-auto px-4 py-8">
        {/* Header Section */}
        <div className="bg-white rounded-lg shadow-sm p-6 mb-8">
          <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-4">
            <div>
              <h1 className="text-3xl font-bold flex items-center gap-3 mb-2">
                <Rss className="h-8 w-8 text-blue-600" />
                RSS Feed Management System
              </h1>
              <p className="text-gray-600">
                Manage external content sources and automated posting to community discussions
              </p>
            </div>
            <div className="flex flex-col sm:flex-row gap-3 w-full lg:w-auto">
              <Button
                onClick={() => handleFetchFeeds()}
                disabled={fetchFeedsMutation.isPending || autoPostMutation.isPending}
                className="bg-green-600 hover:bg-green-700 text-white"
                size="lg"
              >
                <Play className="h-4 w-4 mr-2" />
                {fetchFeedsMutation.isPending ? "Fetching..." : "Fetch All Feeds"}
              </Button>
              <Button
                onClick={handleAutoPost}
                disabled={fetchFeedsMutation.isPending || autoPostMutation.isPending}
                className="bg-purple-600 hover:bg-purple-700 text-white"
                size="lg"
              >
                <Settings className="h-4 w-4 mr-2" />
                {autoPostMutation.isPending ? "Processing..." : "Auto-Post Content"}
              </Button>
            </div>
          </div>
        </div>

        {/* Main Content */}
        <Tabs defaultValue="sources" className="space-y-6">
          <TabsList className="grid w-full grid-cols-4 bg-white">
            <TabsTrigger value="sources">Feed Sources ({feedSources.length})</TabsTrigger>
            <TabsTrigger value="items">Content Items (5)</TabsTrigger>
            <TabsTrigger value="configs">Configurations (3)</TabsTrigger>
            <TabsTrigger value="overview">Overview</TabsTrigger>
          </TabsList>

          <TabsContent value="sources" className="space-y-4">
            <div className="flex justify-between items-center">
              <h2 className="text-xl font-semibold">RSS Feed Sources</h2>
              <Button variant="outline">
                <Settings className="h-4 w-4 mr-2" />
                Add New Source
              </Button>
            </div>
            
            <div className="grid gap-4">
              {feedSources.map((source) => (
                <Card key={source.id} className="bg-white">
                  <CardHeader>
                    <div className="flex justify-between items-start">
                      <div>
                        <CardTitle className="flex items-center gap-2">
                          {source.name}
                          <Badge variant={source.isActive ? "default" : "secondary"}>
                            {source.isActive ? "Active" : "Inactive"}
                          </Badge>
                        </CardTitle>
                        <p className="text-sm text-gray-600">{source.sourceType.toUpperCase()}</p>
                      </div>
                      <div className="flex gap-2">
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => handleFetchFeeds(source.id)}
                          disabled={isProcessing}
                        >
                          <Play className="h-4 w-4" />
                        </Button>
                        <Button size="sm" variant="outline">
                          <Edit className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-2">
                      <div className="flex items-center gap-2">
                        <ExternalLink className="h-4 w-4 text-gray-400" />
                        <span className="text-sm truncate">{source.sourceUrl}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Clock className="h-4 w-4 text-gray-400" />
                        <span className="text-sm">Fetch: {source.fetchFrequency}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Calendar className="h-4 w-4 text-gray-400" />
                        <span className="text-sm">Last: {source.lastFetchedAt.toLocaleString()}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Users className="h-4 w-4 text-gray-400" />
                        <span className="text-sm">Topics: {source.targetTopic}</span>
                      </div>
                      <div className="text-sm text-gray-600">
                        Total items: {source.itemsCount}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="items" className="space-y-4">
            <div className="text-center py-12">
              <Rss className="h-16 w-16 text-gray-300 mx-auto mb-4" />
              <h3 className="text-lg font-medium text-gray-600 mb-2">Content Items</h3>
              <p className="text-gray-500">Feed content items will appear here after fetching from sources</p>
            </div>
          </TabsContent>

          <TabsContent value="configs" className="space-y-4">
            <div className="text-center py-12">
              <Settings className="h-16 w-16 text-gray-300 mx-auto mb-4" />
              <h3 className="text-lg font-medium text-gray-600 mb-2">Auto-Post Configurations</h3>
              <p className="text-gray-500">Configure automated posting rules for different content categories</p>
            </div>
          </TabsContent>

          <TabsContent value="overview" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <Card className="bg-white">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Rss className="h-5 w-5 text-blue-600" />
                    Active Sources
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold text-blue-600">
                    {feedSources.filter(s => s.isActive).length}
                  </div>
                  <p className="text-sm text-gray-600">
                    of {feedSources.length} total sources
                  </p>
                </CardContent>
              </Card>

              <Card className="bg-white">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Settings className="h-5 w-5 text-purple-600" />
                    Pending Items
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold text-purple-600">12</div>
                  <p className="text-sm text-gray-600">ready for auto-posting</p>
                </CardContent>
              </Card>

              <Card className="bg-white">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Users className="h-5 w-5 text-green-600" />
                    Auto-Post Configs
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold text-green-600">2</div>
                  <p className="text-sm text-gray-600">active configurations</p>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}