import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useToast } from "@/hooks/use-toast";
import { Rss, Plus, Play, Settings, Edit, ExternalLink } from "lucide-react";

export default function AdminFeedsDemo() {
  const { toast } = useToast();
  const [showCreateDialog, setShowCreateDialog] = useState(false);
  const [showConfigDialog, setShowConfigDialog] = useState(false);

  // Demo data
  const feedSources = [
    {
      id: 1,
      name: "Health News RSS",
      sourceType: "rss",
      sourceUrl: "https://example.com/health-news/rss",
      isActive: true,
      fetchFrequency: "daily",
      lastFetchedAt: new Date(),
      targetTopic: "health, wellness"
    },
    {
      id: 2,
      name: "Government Updates API",
      sourceType: "api",
      sourceUrl: "https://example.com/api/government",
      isActive: true,
      fetchFrequency: "twice_daily",
      lastFetchedAt: new Date(),
      targetTopic: "government, policy"
    }
  ];

  const feedItems = [
    {
      id: 1,
      sourceId: 1,
      title: "New Health Guidelines Released",
      content: "The government has released new health guidelines for ordinary people focusing on preventive care and community wellness.",
      originalUrl: "https://example.com/health-guidelines",
      publishedAt: new Date(),
      isPosted: false
    },
    {
      id: 2,
      sourceId: 2,
      title: "Policy Update: Healthcare Access",
      content: "Important policy changes affecting healthcare access for ordinary people in local communities.",
      originalUrl: "https://example.com/policy-update",
      publishedAt: new Date(),
      isPosted: true
    }
  ];

  const feedConfigs = [
    {
      id: 1,
      categoryId: 1,
      autoPostEnabled: true,
      postsPerDay: 2,
      postingSchedule: "twice_daily",
      isActive: true,
      updatedAt: new Date()
    }
  ];

  const categories = [
    { id: 1, name: "Health & Wellness" },
    { id: 2, name: "Government Topics" },
    { id: 3, name: "Mental Health" },
    { id: 4, name: "Community Support" }
  ];

  const unpostedItems = feedItems.filter(item => !item.isPosted);

  const handleCreateSource = (e: React.FormEvent) => {
    e.preventDefault();
    toast({ title: "Demo: Feed source would be created in production system" });
    setShowCreateDialog(false);
  };

  const handleCreateConfig = (e: React.FormEvent) => {
    e.preventDefault();
    toast({ title: "Demo: Feed configuration would be created in production system" });
    setShowConfigDialog(false);
  };

  const handleFetchFeeds = (sourceId?: number) => {
    toast({ 
      title: "Demo: Content fetching triggered", 
      description: sourceId ? `Would fetch from source ${sourceId}` : "Would fetch from all active sources" 
    });
  };

  const handleAutoPost = () => {
    toast({ 
      title: "Demo: Auto-posting triggered", 
      description: `Would create posts from ${unpostedItems.length} pending items` 
    });
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="text-3xl font-bold flex items-center gap-2">
            <Rss className="h-8 w-8 text-blue-600" />
            Feed Management System (Demo)
          </h1>
          <p className="text-gray-600 mt-2">
            Manage external content sources and automated posting to community discussions
          </p>
        </div>
        <div className="flex gap-2">
          <Button
            onClick={() => handleFetchFeeds()}
            className="bg-green-600 hover:bg-green-700"
          >
            <Play className="h-4 w-4 mr-2" />
            Fetch All Feeds
          </Button>
          <Button
            onClick={handleAutoPost}
            className="bg-purple-600 hover:bg-purple-700"
          >
            <Settings className="h-4 w-4 mr-2" />
            Auto-Post Content
          </Button>
        </div>
      </div>

      <Tabs defaultValue="sources" className="space-y-6">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="sources">Feed Sources</TabsTrigger>
          <TabsTrigger value="items">Content Items</TabsTrigger>
          <TabsTrigger value="configs">Configurations</TabsTrigger>
          <TabsTrigger value="overview">Overview</TabsTrigger>
        </TabsList>

        <TabsContent value="sources" className="space-y-4">
          <div className="flex justify-between items-center">
            <h2 className="text-xl font-semibold">External Feed Sources</h2>
            <Dialog open={showCreateDialog} onOpenChange={setShowCreateDialog}>
              <DialogTrigger asChild>
                <Button>
                  <Plus className="h-4 w-4 mr-2" />
                  Add Feed Source
                </Button>
              </DialogTrigger>
              <DialogContent className="max-w-2xl">
                <DialogHeader>
                  <DialogTitle>Create New Feed Source</DialogTitle>
                </DialogHeader>
                <form onSubmit={handleCreateSource} className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="name">Source Name</Label>
                      <Input id="name" name="name" required placeholder="Health News RSS" />
                    </div>
                    <div>
                      <Label htmlFor="sourceType">Source Type</Label>
                      <Select name="sourceType" required>
                        <SelectTrigger>
                          <SelectValue placeholder="Select type" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="rss">RSS Feed</SelectItem>
                          <SelectItem value="api">API Endpoint</SelectItem>
                          <SelectItem value="json">JSON Feed</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                  <div>
                    <Label htmlFor="sourceUrl">Source URL</Label>
                    <Input id="sourceUrl" name="sourceUrl" required placeholder="https://example.com/rss" />
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="categoryId">Target Category</Label>
                      <Select name="categoryId">
                        <SelectTrigger>
                          <SelectValue placeholder="Select category" />
                        </SelectTrigger>
                        <SelectContent>
                          {categories.map((cat) => (
                            <SelectItem key={cat.id} value={cat.id.toString()}>
                              {cat.name}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <Label htmlFor="fetchFrequency">Fetch Frequency</Label>
                      <Select name="fetchFrequency" required>
                        <SelectTrigger>
                          <SelectValue placeholder="Select frequency" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="hourly">Every Hour</SelectItem>
                          <SelectItem value="daily">Daily</SelectItem>
                          <SelectItem value="weekly">Weekly</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                  <div>
                    <Label htmlFor="targetTopic">Target Topic/Keywords</Label>
                    <Input id="targetTopic" name="targetTopic" placeholder="health, government, etc." />
                  </div>
                  <div className="flex items-center space-x-2">
                    <Switch id="isActive" name="isActive" defaultChecked />
                    <Label htmlFor="isActive">Active</Label>
                  </div>
                  <div className="flex justify-end space-x-2">
                    <Button type="button" variant="outline" onClick={() => setShowCreateDialog(false)}>
                      Cancel
                    </Button>
                    <Button type="submit">
                      Create Source
                    </Button>
                  </div>
                </form>
              </DialogContent>
            </Dialog>
          </div>

          <div className="grid gap-4">
            {feedSources.map((source) => (
              <Card key={source.id}>
                <CardHeader>
                  <div className="flex justify-between items-start">
                    <div>
                      <CardTitle className="flex items-center gap-2">
                        {source.name}
                        <Badge variant={source.isActive ? "default" : "secondary"}>
                          {source.isActive ? "Active" : "Inactive"}
                        </Badge>
                      </CardTitle>
                      <p className="text-sm text-gray-600">{source.sourceType.toUpperCase()}</p>
                    </div>
                    <div className="flex gap-2">
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => handleFetchFeeds(source.id)}
                      >
                        <Play className="h-4 w-4" />
                      </Button>
                      <Button size="sm" variant="outline">
                        <Edit className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    <div className="flex items-center gap-2">
                      <ExternalLink className="h-4 w-4 text-gray-400" />
                      <a href={source.sourceUrl} target="_blank" rel="noopener noreferrer" 
                         className="text-blue-600 hover:underline text-sm">
                        {source.sourceUrl}
                      </a>
                    </div>
                    <div className="flex justify-between text-sm text-gray-600">
                      <span>Frequency: {source.fetchFrequency}</span>
                      <span>Last fetched: {source.lastFetchedAt.toLocaleDateString()}</span>
                    </div>
                    {source.targetTopic && (
                      <div className="text-sm">
                        <span className="font-medium">Target topics:</span> {source.targetTopic}
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="items" className="space-y-4">
          <div className="flex justify-between items-center">
            <h2 className="text-xl font-semibold">Content Items</h2>
            <Badge variant="outline" className="bg-yellow-50">
              {unpostedItems.length} Unposted Items
            </Badge>
          </div>

          <div className="grid gap-4">
            {feedItems.map((item) => (
              <Card key={item.id}>
                <CardHeader>
                  <div className="flex justify-between items-start">
                    <div className="flex-1">
                      <CardTitle className="text-lg">{item.title}</CardTitle>
                      <p className="text-sm text-gray-600 mt-1">
                        {item.publishedAt.toLocaleDateString()}
                      </p>
                    </div>
                    <Badge variant={item.isPosted ? "default" : "secondary"}>
                      {item.isPosted ? "Posted" : "Pending"}
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent>
                  <p className="text-sm mb-3">{item.content}</p>
                  <div className="flex justify-between items-center">
                    {item.originalUrl && (
                      <a href={item.originalUrl} target="_blank" rel="noopener noreferrer" 
                         className="text-blue-600 hover:underline text-sm flex items-center gap-1">
                        <ExternalLink className="h-3 w-3" />
                        View Original
                      </a>
                    )}
                    {item.isPosted && (
                      <span className="text-sm text-green-600">
                        Posted to community discussions
                      </span>
                    )}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="configs" className="space-y-4">
          <div className="flex justify-between items-center">
            <h2 className="text-xl font-semibold">Auto-Posting Configurations</h2>
            <Dialog open={showConfigDialog} onOpenChange={setShowConfigDialog}>
              <DialogTrigger asChild>
                <Button>
                  <Plus className="h-4 w-4 mr-2" />
                  Add Configuration
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Create Auto-Post Configuration</DialogTitle>
                </DialogHeader>
                <form onSubmit={handleCreateConfig} className="space-y-4">
                  <div>
                    <Label htmlFor="categoryId">Discussion Category</Label>
                    <Select name="categoryId" required>
                      <SelectTrigger>
                        <SelectValue placeholder="Select category" />
                      </SelectTrigger>
                      <SelectContent>
                        {categories.map((cat) => (
                          <SelectItem key={cat.id} value={cat.id.toString()}>
                            {cat.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label htmlFor="postsPerDay">Posts Per Day</Label>
                    <Input id="postsPerDay" name="postsPerDay" type="number" required min="1" max="10" defaultValue="2" />
                  </div>
                  <div>
                    <Label htmlFor="postingSchedule">Posting Schedule</Label>
                    <Select name="postingSchedule" required>
                      <SelectTrigger>
                        <SelectValue placeholder="Select schedule" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="morning">Morning (9 AM)</SelectItem>
                        <SelectItem value="afternoon">Afternoon (2 PM)</SelectItem>
                        <SelectItem value="evening">Evening (6 PM)</SelectItem>
                        <SelectItem value="twice_daily">Twice Daily (9 AM & 6 PM)</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Switch id="autoPostEnabled" name="autoPostEnabled" defaultChecked />
                    <Label htmlFor="autoPostEnabled">Auto-posting Enabled</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Switch id="isActive" name="isActive" defaultChecked />
                    <Label htmlFor="isActive">Active</Label>
                  </div>
                  <div className="flex justify-end space-x-2">
                    <Button type="button" variant="outline" onClick={() => setShowConfigDialog(false)}>
                      Cancel
                    </Button>
                    <Button type="submit">
                      Create Configuration
                    </Button>
                  </div>
                </form>
              </DialogContent>
            </Dialog>
          </div>

          <div className="grid gap-4">
            {feedConfigs.map((config) => (
              <Card key={config.id}>
                <CardHeader>
                  <div className="flex justify-between items-start">
                    <div>
                      <CardTitle>
                        {categories.find(c => c.id === config.categoryId)?.name || `Category ${config.categoryId}`}
                        <Badge variant={config.isActive ? "default" : "secondary"} className="ml-2">
                          {config.isActive ? "Active" : "Inactive"}
                        </Badge>
                      </CardTitle>
                    </div>
                    <Button size="sm" variant="outline">
                      <Edit className="h-4 w-4" />
                    </Button>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div>
                      <span className="font-medium">Posts per day:</span> {config.postsPerDay}
                    </div>
                    <div>
                      <span className="font-medium">Schedule:</span> {config.postingSchedule}
                    </div>
                    <div>
                      <span className="font-medium">Auto-posting:</span> {config.autoPostEnabled ? "Enabled" : "Disabled"}
                    </div>
                    <div>
                      <span className="font-medium">Updated:</span> {config.updatedAt.toLocaleDateString()}
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="overview" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium">Total Sources</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{feedSources.length}</div>
                <p className="text-xs text-gray-600">
                  {feedSources.filter(s => s.isActive).length} active
                </p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium">Total Items</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{feedItems.length}</div>
                <p className="text-xs text-gray-600">
                  {feedItems.filter(i => i.isPosted).length} posted
                </p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium">Pending Items</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-yellow-600">{unpostedItems.length}</div>
                <p className="text-xs text-gray-600">Ready to post</p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium">Configurations</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{feedConfigs.length}</div>
                <p className="text-xs text-gray-600">
                  {feedConfigs.filter(c => c.autoPostEnabled).length} auto-posting
                </p>
              </CardContent>
            </Card>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>System Status</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex justify-between items-center">
                  <span>Feed Fetching Status</span>
                  <Badge variant="default">Demo Mode</Badge>
                </div>
                <div className="flex justify-between items-center">
                  <span>Auto-posting System</span>
                  <Badge variant="default">Demo Mode</Badge>
                </div>
                <div className="flex justify-between items-center">
                  <span>Last System Check</span>
                  <span className="text-sm text-gray-600">{new Date().toLocaleString()}</span>
                </div>
                <div className="bg-blue-50 p-4 rounded-lg">
                  <p className="text-sm text-blue-800">
                    This is a demonstration of the feed management system. In production, this would:
                    <br />• Fetch content from external RSS feeds and APIs twice daily
                    <br />• Automatically post curated content to community discussions
                    <br />• Support health, government, and general topics for ordinary people
                    <br />• Include content filtering and moderation capabilities
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}