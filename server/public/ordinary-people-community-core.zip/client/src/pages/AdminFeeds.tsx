import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useToast } from "@/hooks/use-toast";
import { Rss, Plus, Play, Settings, Trash2, Edit, ExternalLink, ArrowLeft } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { BackButton } from "@/components/BackButton";
import { AdminHelpGuide } from "@/components/AdminHelpGuide";

interface FeedSource {
  id: number;
  name: string;
  sourceType: string;
  sourceUrl: string;
  categoryId: number | null;
  targetTopic: string | null;
  isActive: boolean;
  fetchFrequency: string;
  lastFetchedAt: Date | null;
  createdBy: number;
  createdAt: Date;
}

interface FeedItem {
  id: number;
  sourceId: number;
  title: string;
  content: string;
  originalUrl: string | null;
  authorName: string | null;
  publishedAt: Date | null;
  isPosted: boolean;
  postedToDiscussion: number | null;
}

interface FeedConfiguration {
  id: number;
  categoryId: number;
  autoPostEnabled: boolean;
  postsPerDay: number;
  postingSchedule: string;
  isActive: boolean;
  createdAt: Date;
  updatedAt: Date;
}

export default function AdminFeeds() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [selectedSource, setSelectedSource] = useState<FeedSource | null>(null);
  const [showCreateDialog, setShowCreateDialog] = useState(false);
  const [showConfigDialog, setShowConfigDialog] = useState(false);

  // Queries
  const { data: feedSources = [], isLoading: sourcesLoading } = useQuery({
    queryKey: ["/api/admin/feed-sources"],
  });

  const { data: feedItems = [], isLoading: itemsLoading } = useQuery({
    queryKey: ["/api/admin/feed-items"],
  });

  const { data: feedConfigs = [], isLoading: configsLoading } = useQuery({
    queryKey: ["/api/admin/feed-configurations"],
  });

  const { data: unpostedItems = [] } = useQuery({
    queryKey: ["/api/admin/feed-items/unposted"],
  });

  const { data: categories = [] } = useQuery<any[]>({
    queryKey: ["/api/discussion-categories"],
  });

  // Mutations
  const createSourceMutation = useMutation({
    mutationFn: async (data: any) => {
      const response = await fetch("/api/admin/feed-sources", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      if (!response.ok) throw new Error(await response.text());
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/feed-sources"] });
      setShowCreateDialog(false);
      toast({ 
        title: "Feed source created successfully",
        style: { 
          backgroundColor: 'white', 
          color: 'black', 
          border: '2px solid #22c55e',
          boxShadow: '0 4px 12px rgba(0,0,0,0.15)'
        }
      });
    },
    onError: (error: any) => {
      toast({ 
        title: "Failed to create feed source", 
        description: error.message, 
        variant: "destructive",
        style: { 
          backgroundColor: 'white', 
          color: 'black', 
          border: '2px solid #ef4444',
          boxShadow: '0 4px 12px rgba(0,0,0,0.15)'
        }
      });
    },
  });

  const fetchFeedsMutation = useMutation({
    mutationFn: async (sourceId?: number) => {
      const response = await fetch("/api/admin/fetch-feeds", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ sourceId }),
      });
      if (!response.ok) throw new Error(await response.text());
      return response.json();
    },
    onSuccess: (data: any) => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/feed-items"] });
      toast({ 
        title: "Content fetched successfully", 
        description: data.message,
        style: { 
          backgroundColor: 'white', 
          color: 'black', 
          border: '2px solid #22c55e',
          boxShadow: '0 4px 12px rgba(0,0,0,0.15)'
        }
      });
    },
    onError: (error: any) => {
      toast({ 
        title: "Failed to fetch content", 
        description: error.message, 
        variant: "destructive",
        style: { 
          backgroundColor: 'white', 
          color: 'black', 
          border: '2px solid #ef4444',
          boxShadow: '0 4px 12px rgba(0,0,0,0.15)'
        }
      });
    },
  });

  const autoPostMutation = useMutation({
    mutationFn: async () => {
      const response = await fetch("/api/admin/auto-post", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
      });
      if (!response.ok) throw new Error(await response.text());
      return response.json();
    },
    onSuccess: (data: any) => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/feed-items"] });
      queryClient.invalidateQueries({ queryKey: ["/api/community-discussions"] });
      toast({ 
        title: "Auto-posting completed", 
        description: data.message,
        style: { 
          backgroundColor: 'white', 
          color: 'black', 
          border: '2px solid #22c55e',
          boxShadow: '0 4px 12px rgba(0,0,0,0.15)'
        }
      });
    },
    onError: (error: any) => {
      toast({ 
        title: "Auto-posting failed", 
        description: error.message, 
        variant: "destructive",
        style: { 
          backgroundColor: 'white', 
          color: 'black', 
          border: '2px solid #ef4444',
          boxShadow: '0 4px 12px rgba(0,0,0,0.15)'
        }
      });
    },
  });

  const createConfigMutation = useMutation({
    mutationFn: async (data: any) => {
      const response = await fetch("/api/admin/feed-configurations", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      if (!response.ok) throw new Error(await response.text());
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/feed-configurations"] });
      setShowConfigDialog(false);
      toast({ 
        title: "Feed configuration created successfully",
        style: { 
          backgroundColor: 'white', 
          color: 'black', 
          border: '2px solid #22c55e',
          boxShadow: '0 4px 12px rgba(0,0,0,0.15)'
        }
      });
    },
    onError: (error: any) => {
      toast({ 
        title: "Failed to create configuration", 
        description: error.message, 
        variant: "destructive",
        style: { 
          backgroundColor: 'white', 
          color: 'black', 
          border: '2px solid #ef4444',
          boxShadow: '0 4px 12px rgba(0,0,0,0.15)'
        }
      });
    },
  });

  const handleCreateSource = (e: React.FormEvent) => {
    e.preventDefault();
    const formData = new FormData(e.target as HTMLFormElement);
    
    createSourceMutation.mutate({
      name: formData.get("name"),
      sourceType: formData.get("sourceType"),
      sourceUrl: formData.get("sourceUrl"),
      categoryId: formData.get("categoryId") ? parseInt(formData.get("categoryId") as string) : null,
      targetTopic: formData.get("targetTopic") || null,
      isActive: formData.get("isActive") === "on",
      fetchFrequency: formData.get("fetchFrequency"),
      createdBy: 5, // Admin user
    });
  };

  const handleCreateConfig = (e: React.FormEvent) => {
    e.preventDefault();
    const formData = new FormData(e.target as HTMLFormElement);
    
    createConfigMutation.mutate({
      categoryId: parseInt(formData.get("categoryId") as string),
      autoPostEnabled: formData.get("autoPostEnabled") === "on",
      postsPerDay: parseInt(formData.get("postsPerDay") as string),
      postingSchedule: formData.get("postingSchedule"),
      isActive: formData.get("isActive") === "on",
    });
  };

  if (sourcesLoading || itemsLoading || configsLoading) {
    return (
      <div className="container mx-auto px-4 py-8">
        <div className="flex items-center justify-center min-h-[400px]">
          <div className="text-center">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
            <p className="text-gray-600">Loading feed management system...</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-6">
        <BackButton />
      </div>
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="text-3xl font-bold flex items-center gap-2">
            <Rss className="h-8 w-8 text-blue-600" />
            Feed Management System
          </h1>
          <p className="text-gray-600 mt-2">
            Manage external content sources and automated posting to community discussions
          </p>
        </div>
        <div className="flex gap-2">
          <Button
            onClick={() => fetchFeedsMutation.mutate(undefined)}
            disabled={fetchFeedsMutation.isPending}
            className="bg-green-600 hover:bg-green-700"
          >
            <Play className="h-4 w-4 mr-2" />
            Fetch All Feeds
          </Button>
          <Button
            onClick={() => autoPostMutation.mutate()}
            disabled={autoPostMutation.isPending}
            className="bg-purple-600 hover:bg-purple-700"
          >
            <Settings className="h-4 w-4 mr-2" />
            Auto-Post Content
          </Button>
        </div>
      </div>

      <Tabs defaultValue="sources" className="space-y-6">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="sources">Feed Sources</TabsTrigger>
          <TabsTrigger value="items">Content Items</TabsTrigger>
          <TabsTrigger value="configs">Configurations</TabsTrigger>
          <TabsTrigger value="overview">Overview</TabsTrigger>
        </TabsList>

        <TabsContent value="sources" className="space-y-4">
          <div className="flex justify-between items-center">
            <h2 className="text-xl font-semibold">External Feed Sources</h2>
            <Dialog open={showCreateDialog} onOpenChange={setShowCreateDialog}>
              <DialogTrigger asChild>
                <Button>
                  <Plus className="h-4 w-4 mr-2" />
                  Add Feed Source
                </Button>
              </DialogTrigger>
              <DialogContent className="max-w-2xl">
                <DialogHeader>
                  <DialogTitle>Create New Feed Source</DialogTitle>
                </DialogHeader>
                <form onSubmit={handleCreateSource} className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="name">Source Name</Label>
                      <Input id="name" name="name" required placeholder="Health News RSS" />
                    </div>
                    <div>
                      <Label htmlFor="sourceType">Source Type</Label>
                      <Select name="sourceType" required>
                        <SelectTrigger>
                          <SelectValue placeholder="Select type" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="rss">RSS Feed</SelectItem>
                          <SelectItem value="api">API Endpoint</SelectItem>
                          <SelectItem value="json">JSON Feed</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                  <div>
                    <Label htmlFor="sourceUrl">Source URL</Label>
                    <Input id="sourceUrl" name="sourceUrl" required placeholder="https://example.com/rss" />
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="categoryId">Target Category</Label>
                      <Select name="categoryId">
                        <SelectTrigger>
                          <SelectValue placeholder="Select category" />
                        </SelectTrigger>
                        <SelectContent>
                          {categories.map((cat: any) => (
                            <SelectItem key={cat.id} value={cat.id.toString()}>
                              {cat.name}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <Label htmlFor="fetchFrequency">Fetch Frequency</Label>
                      <Select name="fetchFrequency" required>
                        <SelectTrigger>
                          <SelectValue placeholder="Select frequency" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="hourly">Every Hour</SelectItem>
                          <SelectItem value="daily">Daily</SelectItem>
                          <SelectItem value="weekly">Weekly</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                  <div>
                    <Label htmlFor="targetTopic">Target Topic/Keywords</Label>
                    <Input id="targetTopic" name="targetTopic" placeholder="health, government, etc." />
                  </div>
                  <div className="flex items-center space-x-2">
                    <Switch id="isActive" name="isActive" defaultChecked />
                    <Label htmlFor="isActive">Active</Label>
                  </div>
                  <div className="flex justify-end space-x-2">
                    <Button type="button" variant="outline" onClick={() => setShowCreateDialog(false)}>
                      Cancel
                    </Button>
                    <Button type="submit" disabled={createSourceMutation.isPending}>
                      Create Source
                    </Button>
                  </div>
                </form>
              </DialogContent>
            </Dialog>
          </div>

          <div className="grid gap-4">
            {Array.isArray(feedSources) && feedSources.map((source: FeedSource) => (
              <Card key={source.id}>
                <CardHeader>
                  <div className="flex justify-between items-start">
                    <div>
                      <CardTitle className="flex items-center gap-2">
                        {source.name}
                        <Badge variant={source.isActive ? "default" : "secondary"}>
                          {source.isActive ? "Active" : "Inactive"}
                        </Badge>
                      </CardTitle>
                      <p className="text-sm text-gray-600">{source.sourceType.toUpperCase()}</p>
                    </div>
                    <div className="flex gap-2">
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => fetchFeedsMutation.mutate(source.id)}
                        disabled={fetchFeedsMutation.isPending}
                      >
                        <Play className="h-4 w-4" />
                      </Button>
                      <Button size="sm" variant="outline">
                        <Edit className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    <div className="flex items-center gap-2">
                      <ExternalLink className="h-4 w-4 text-gray-400" />
                      <a href={source.sourceUrl} target="_blank" rel="noopener noreferrer" 
                         className="text-blue-600 hover:underline text-sm">
                        {source.sourceUrl}
                      </a>
                    </div>
                    <div className="flex justify-between text-sm text-gray-600">
                      <span>Frequency: {source.fetchFrequency}</span>
                      <span>Last fetched: {source.lastFetchedAt ? new Date(source.lastFetchedAt).toLocaleDateString() : 'Never'}</span>
                    </div>
                    {source.targetTopic && (
                      <div className="text-sm">
                        <span className="font-medium">Target topics:</span> {source.targetTopic}
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="items" className="space-y-4">
          <div className="flex justify-between items-center">
            <h2 className="text-xl font-semibold">Content Items</h2>
            <Badge variant="outline" className="bg-yellow-50">
              {Array.isArray(unpostedItems) ? unpostedItems.length : 0} Unposted Items
            </Badge>
          </div>

          <div className="grid gap-4">
            {Array.isArray(feedItems) && feedItems.slice(0, 20).map((item: FeedItem) => (
              <Card key={item.id}>
                <CardHeader>
                  <div className="flex justify-between items-start">
                    <div className="flex-1">
                      <CardTitle className="text-lg">{item.title}</CardTitle>
                      <p className="text-sm text-gray-600 mt-1">
                        {item.publishedAt ? new Date(item.publishedAt).toLocaleDateString() : 'No date'}
                      </p>
                    </div>
                    <Badge variant={item.isPosted ? "default" : "secondary"}>
                      {item.isPosted ? "Posted" : "Pending"}
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent>
                  <p className="text-sm mb-3 line-clamp-3">{item.content}</p>
                  <div className="flex justify-between items-center">
                    {item.originalUrl && (
                      <a href={item.originalUrl} target="_blank" rel="noopener noreferrer" 
                         className="text-blue-600 hover:underline text-sm flex items-center gap-1">
                        <ExternalLink className="h-3 w-3" />
                        View Original
                      </a>
                    )}
                    {item.isPosted && item.postedToDiscussion && (
                      <span className="text-sm text-green-600">
                        Posted to discussion #{item.postedToDiscussion}
                      </span>
                    )}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="configs" className="space-y-4">
          <div className="flex justify-between items-center">
            <h2 className="text-xl font-semibold">Auto-Posting Configurations</h2>
            <Dialog open={showConfigDialog} onOpenChange={setShowConfigDialog}>
              <DialogTrigger asChild>
                <Button>
                  <Plus className="h-4 w-4 mr-2" />
                  Add Configuration
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Create Auto-Post Configuration</DialogTitle>
                </DialogHeader>
                <form onSubmit={handleCreateConfig} className="space-y-4">
                  <div>
                    <Label htmlFor="categoryId">Discussion Category</Label>
                    <Select name="categoryId" required>
                      <SelectTrigger>
                        <SelectValue placeholder="Select category" />
                      </SelectTrigger>
                      <SelectContent>
                        {categories.map((cat: any) => (
                          <SelectItem key={cat.id} value={cat.id.toString()}>
                            {cat.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label htmlFor="postsPerDay">Posts Per Day</Label>
                    <Input id="postsPerDay" name="postsPerDay" type="number" required min="1" max="10" defaultValue="2" />
                  </div>
                  <div>
                    <Label htmlFor="postingSchedule">Posting Schedule</Label>
                    <Select name="postingSchedule" required>
                      <SelectTrigger>
                        <SelectValue placeholder="Select schedule" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="morning">Morning (9 AM)</SelectItem>
                        <SelectItem value="afternoon">Afternoon (2 PM)</SelectItem>
                        <SelectItem value="evening">Evening (6 PM)</SelectItem>
                        <SelectItem value="twice_daily">Twice Daily (9 AM & 6 PM)</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Switch id="autoPostEnabled" name="autoPostEnabled" defaultChecked />
                    <Label htmlFor="autoPostEnabled">Auto-posting Enabled</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Switch id="isActive" name="isActive" defaultChecked />
                    <Label htmlFor="isActive">Active</Label>
                  </div>
                  <div className="flex justify-end space-x-2">
                    <Button type="button" variant="outline" onClick={() => setShowConfigDialog(false)}>
                      Cancel
                    </Button>
                    <Button type="submit" disabled={createConfigMutation.isPending}>
                      Create Configuration
                    </Button>
                  </div>
                </form>
              </DialogContent>
            </Dialog>
          </div>

          <div className="grid gap-4">
            {Array.isArray(feedConfigs) && feedConfigs.map((config: FeedConfiguration) => (
              <Card key={config.id}>
                <CardHeader>
                  <div className="flex justify-between items-start">
                    <div>
                      <CardTitle>
                        Category {config.categoryId}
                        <Badge variant={config.isActive ? "default" : "secondary"} className="ml-2">
                          {config.isActive ? "Active" : "Inactive"}
                        </Badge>
                      </CardTitle>
                    </div>
                    <Button size="sm" variant="outline">
                      <Edit className="h-4 w-4" />
                    </Button>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div>
                      <span className="font-medium">Posts per day:</span> {config.postsPerDay}
                    </div>
                    <div>
                      <span className="font-medium">Schedule:</span> {config.postingSchedule}
                    </div>
                    <div>
                      <span className="font-medium">Auto-posting:</span> {config.autoPostEnabled ? "Enabled" : "Disabled"}
                    </div>
                    <div>
                      <span className="font-medium">Updated:</span> {new Date(config.updatedAt).toLocaleDateString()}
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="overview" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium">Total Sources</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{Array.isArray(feedSources) ? feedSources.length : 0}</div>
                <p className="text-xs text-gray-600">
                  {Array.isArray(feedSources) ? feedSources.filter((s: FeedSource) => s.isActive).length : 0} active
                </p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium">Total Items</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{Array.isArray(feedItems) ? feedItems.length : 0}</div>
                <p className="text-xs text-gray-600">
                  {Array.isArray(feedItems) ? feedItems.filter((i: FeedItem) => i.isPosted).length : 0} posted
                </p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium">Pending Items</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-yellow-600">{Array.isArray(unpostedItems) ? unpostedItems.length : 0}</div>
                <p className="text-xs text-gray-600">Ready to post</p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium">Configurations</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{Array.isArray(feedConfigs) ? feedConfigs.length : 0}</div>
                <p className="text-xs text-gray-600">
                  {Array.isArray(feedConfigs) ? feedConfigs.filter((c: FeedConfiguration) => c.autoPostEnabled).length : 0} auto-posting
                </p>
              </CardContent>
            </Card>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>System Status</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex justify-between items-center">
                  <span>Feed Fetching Status</span>
                  <Badge variant="default">Operational</Badge>
                </div>
                <div className="flex justify-between items-center">
                  <span>Auto-posting System</span>
                  <Badge variant="default">Operational</Badge>
                </div>
                <div className="flex justify-between items-center">
                  <span>Last System Check</span>
                  <span className="text-sm text-gray-600">{new Date().toLocaleString()}</span>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}