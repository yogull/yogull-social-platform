/**
 * Copyright (c) 2025 John Proctor. All rights reserved.
 * The People's Health Community Platform
 */

import { useParams, Link } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { 
  Facebook, 
  Twitter, 
  Instagram, 
  Linkedin, 
  Youtube, 
  MessageCircle,
  Send,
  Globe,
  ChevronLeft,
  ExternalLink,
  Share2
} from "lucide-react";

export default function SocialMediaView() {
  const { userId, platform } = useParams();
  
  const { data: user, isLoading } = useQuery({
    queryKey: [`/api/users/${userId}`],
    enabled: !!userId,
  });

  const platformConfigs = {
    facebookUrl: {
      name: 'Facebook',
      icon: Facebook,
      color: 'text-blue-600',
      description: 'Connect on Facebook within The People\'s Health Community',
      bgColor: 'bg-blue-50'
    },
    twitterUrl: {
      name: 'Twitter',
      icon: Twitter,
      color: 'text-blue-400',
      description: 'Follow on Twitter through our secure platform',
      bgColor: 'bg-blue-50'
    },
    instagramUrl: {
      name: 'Instagram',
      icon: Instagram,
      color: 'text-pink-600',
      description: 'View Instagram content safely within our community',
      bgColor: 'bg-pink-50'
    },
    linkedinUrl: {
      name: 'LinkedIn',
      icon: Linkedin,
      color: 'text-blue-700',
      description: 'Professional networking through The People\'s Health Community',
      bgColor: 'bg-blue-50'
    },
    youtubeUrl: {
      name: 'YouTube',
      icon: Youtube,
      color: 'text-red-600',
      description: 'Watch health content safely within our platform',
      bgColor: 'bg-red-50'
    },
    whatsappUrl: {
      name: 'WhatsApp',
      icon: MessageCircle,
      color: 'text-green-600',
      description: 'Connect via WhatsApp through our secure messaging',
      bgColor: 'bg-green-50'
    },
    telegramUrl: {
      name: 'Telegram',
      icon: Send,
      color: 'text-blue-500',
      description: 'Join Telegram discussions within our community',
      bgColor: 'bg-blue-50'
    },
    personalWebsite: {
      name: 'Personal Website',
      icon: Globe,
      color: 'text-purple-600',
      description: 'Visit personal website through our secure gateway',
      bgColor: 'bg-purple-50'
    }
  };

  const currentPlatform = platformConfigs[platform as keyof typeof platformConfigs];
  const IconComponent = currentPlatform?.icon || Globe;

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full mx-auto mb-4" />
          <p className="text-gray-600">Loading social media content...</p>
        </div>
      </div>
    );
  }

  if (!user || !currentPlatform) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <Card className="max-w-md">
          <CardContent className="p-6 text-center">
            <h2 className="text-xl font-semibold mb-2">Content Not Found</h2>
            <p className="text-gray-600 mb-4">The requested social media profile could not be found.</p>
            <Link href="/">
              <Button>Return to Dashboard</Button>
            </Link>
          </CardContent>
        </Card>
      </div>
    );
  }

  const socialUrl = user[platform as keyof typeof user] as string;

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="container mx-auto px-4 py-8 max-w-4xl">
        {/* Navigation */}
        <div className="mb-6">
          <Link href={`/profile-wall/${userId}`}>
            <Button variant="outline" className="flex items-center gap-2">
              <ChevronLeft className="w-4 h-4" />
              Back to Profile
            </Button>
          </Link>
        </div>

        {/* Header */}
        <Card className={`mb-6 ${currentPlatform.bgColor}`}>
          <CardHeader>
            <div className="flex items-center gap-4">
              <div className="p-3 bg-white rounded-full shadow-sm">
                <IconComponent className={`w-8 h-8 ${currentPlatform.color}`} />
              </div>
              <div>
                <CardTitle className="flex items-center gap-2">
                  {user.name}'s {currentPlatform.name}
                  <Badge variant="secondary" className="ml-2">Verified</Badge>
                </CardTitle>
                <p className="text-gray-600 mt-1">{currentPlatform.description}</p>
              </div>
            </div>
          </CardHeader>
        </Card>

        {/* Content Area */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Main Content */}
          <div className="lg:col-span-2">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <IconComponent className={`w-5 h-5 ${currentPlatform.color}`} />
                  {currentPlatform.name} Content
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="bg-gray-50 p-6 rounded-lg text-center">
                  <IconComponent className={`w-16 h-16 ${currentPlatform.color} mx-auto mb-4`} />
                  <h3 className="text-lg font-semibold mb-2">Secure Social Media Integration</h3>
                  <p className="text-gray-600 mb-4">
                    This is {user.name}'s {currentPlatform.name} profile displayed safely within The People's Health Community platform.
                  </p>
                  <div className="space-y-3">
                    <div className="p-3 bg-white rounded border-l-4 border-green-500">
                      <p className="text-sm text-green-700 font-medium">✓ Secure Connection</p>
                      <p className="text-xs text-green-600">All external links are processed through our secure gateway</p>
                    </div>
                    <div className="p-3 bg-white rounded border-l-4 border-blue-500">
                      <p className="text-sm text-blue-700 font-medium">✓ Community Privacy</p>
                      <p className="text-xs text-blue-600">Your browsing stays within The People's Health Community</p>
                    </div>
                    <div className="p-3 bg-white rounded border-l-4 border-purple-500">
                      <p className="text-sm text-purple-700 font-medium">✓ Health-Focused</p>
                      <p className="text-xs text-purple-600">Content filtered for health and wellness relevance</p>
                    </div>
                  </div>
                  
                  {socialUrl && (
                    <div className="mt-6 pt-4 border-t">
                      <p className="text-sm text-gray-500 mb-3">External Link (opens in new tab):</p>
                      <a
                        href={socialUrl}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="inline-flex items-center gap-2 px-4 py-2 bg-gray-800 text-white rounded-lg hover:bg-gray-700 transition-colors"
                      >
                        <ExternalLink className="w-4 h-4" />
                        Visit {currentPlatform.name}
                      </a>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Sidebar */}
          <div>
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Community Actions</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <Link href={`/chat?user=${userId}`}>
                  <Button className="w-full" variant="outline">
                    <MessageCircle className="w-4 h-4 mr-2" />
                    Send Message
                  </Button>
                </Link>
                
                <Button className="w-full" variant="outline">
                  <Share2 className="w-4 h-4 mr-2" />
                  Share Profile
                </Button>

                <Link href="/community">
                  <Button className="w-full" variant="outline">
                    <Globe className="w-4 h-4 mr-2" />
                    Join Discussions
                  </Button>
                </Link>
              </CardContent>
            </Card>

            <Card className="mt-4">
              <CardHeader>
                <CardTitle className="text-lg">Safety Notice</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-sm text-gray-600 space-y-2">
                  <p>🛡️ This content is displayed within our secure platform</p>
                  <p>🔒 Your privacy is protected</p>
                  <p>💚 Community guidelines apply</p>
                  <p>📞 Report any concerns to our team</p>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}