import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Loader2, MapPin, Phone, Mail, ExternalLink, Users, Search, Building2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { PageHelpSystem } from "@/components/PageHelpSystem";

interface Advertisement {
  id: number;
  title: string;
  description: string;
  imageUrl: string;
  targetUrl: string;
  targetLocation: string;
  targetScope: string;
  impressions: number;
  clicks: number;
  advertiserName: string;
  companyName?: string;
  isFeatured?: boolean;
  isActive?: boolean;
}

const locationData = {
  "all": ["all"],
  "United Kingdom": ["all", "London", "Manchester", "Birmingham", "Liverpool", "Leeds", "Sheffield", "Bristol", "Nottingham", "Leicester", "Newcastle"],
  "United States": ["all", "New York", "Los Angeles", "Chicago", "Houston", "Phoenix", "Philadelphia", "San Antonio", "San Diego", "Dallas"],
  "Canada": ["all", "Toronto", "Montreal", "Vancouver", "Calgary", "Edmonton", "Ottawa", "Winnipeg", "Quebec City"],
  "Australia": ["all", "Sydney", "Melbourne", "Brisbane", "Perth", "Adelaide", "Gold Coast", "Newcastle", "Canberra"],
  "Japan": ["all", "Tokyo", "Yokohama", "Osaka", "Nagoya", "Sapporo", "Fukuoka", "Kobe", "Kawasaki", "Kyoto"],
  "France": ["all", "Paris", "Marseille", "Lyon", "Toulouse", "Nice", "Nantes", "Strasbourg", "Montpellier"],
  "Germany": ["all", "Berlin", "Hamburg", "Munich", "Cologne", "Frankfurt", "Stuttgart", "Düsseldorf", "Dortmund"],
  "Spain": ["all", "Madrid", "Barcelona", "Valencia", "Seville", "Zaragoza", "Málaga", "Murcia", "Palma"],
  "Italy": ["all", "Rome", "Milan", "Naples", "Turin", "Palermo", "Genoa", "Bologna", "Florence"],
  "Netherlands": ["all", "Amsterdam", "Rotterdam", "The Hague", "Utrecht", "Eindhoven", "Tilburg", "Groningen"]
};

export default function LocationAds() {
  const [selectedCountry, setSelectedCountry] = useState<string>("all");
  const [selectedLocation, setSelectedLocation] = useState<string>("all");
  const [isSearching, setIsSearching] = useState<boolean>(false);
  const [hasSearched, setHasSearched] = useState<boolean>(false);
  const { toast } = useToast();

  const countries = Object.keys(locationData);
  const availableLocations = locationData[selectedCountry as keyof typeof locationData] || ["all"];

  const { data: advertisements = [], isLoading } = useQuery({
    queryKey: ["/api/advertisements"],
    queryFn: async () => {
      const response = await fetch("/api/advertisements");
      if (!response.ok) throw new Error("Failed to fetch advertisements");
      return response.json();
    }
  });

  const handleCountryChange = (country: string) => {
    setSelectedCountry(country);
    setSelectedLocation("all");
    setHasSearched(false);
  };

  const handleLocationChange = (location: string) => {
    setSelectedLocation(location);
    setHasSearched(false);
  };

  const handleSearch = () => {
    setIsSearching(true);
    setTimeout(() => {
      setIsSearching(false);
      setHasSearched(true);
      toast({ 
        title: "Search Complete", 
        description: `Found ${filteredAds.length} businesses in ${selectedLocation === "all" ? selectedCountry : selectedLocation}` 
      });
    }, 1000);
  };

  // Filter advertisements based on selection
  const filteredAds = (advertisements as Advertisement[]).filter((ad: Advertisement) => {
    if (!ad.isActive) return false;
    
    if (selectedCountry === "all") return true;
    
    const countryLocations = locationData[selectedCountry as keyof typeof locationData] || [];
    
    if (selectedLocation === "all") {
      return countryLocations.some(loc => 
        loc === "all" || ad.targetLocation?.toLowerCase().includes(loc.toLowerCase())
      );
    }
    
    return ad.targetLocation?.toLowerCase().includes(selectedLocation.toLowerCase());
  });

  const handleBusinessClick = async (ad: Advertisement) => {
    try {
      // Record the click
      await fetch(`/api/advertisements/${ad.id}/click`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' }
      });
      
      // Open the business URL
      if (ad.targetUrl) {
        window.open(ad.targetUrl, '_blank');
      }
      
      toast({ 
        title: "Visiting Business", 
        description: `Opening ${ad.title}` 
      });
    } catch (error) {
      toast({ 
        title: "Visit Business", 
        description: `Opening ${ad.title}` 
      });
      if (ad.targetUrl) {
        window.open(ad.targetUrl, '_blank');
      }
    }
  };

  return (
    <div className="min-h-screen bg-white">
      {/* Instructions Button */}
      <div className="fixed top-4 left-1/2 transform -translate-x-1/2 z-50">
        <button 
          onClick={() => {
            alert(`Business Directory Instructions:

1. Select a country from the dropdown menu
2. Choose a specific city or leave as 'All Countries' for broader search  
3. Click 'Search Businesses' to find local services
4. Browse business cards showing company details and services
5. Click any business card to view full profile with contact information
6. Use 'Call', 'Email', 'Website', or 'Get Directions' buttons for direct contact
7. Perfect for travelers seeking local services or residents finding nearby businesses

Tips:
• Business directory covers restaurants, shops, services, and professional businesses
• Each business shows location, contact details, and website links
• Tap anywhere on business cards to access full company profiles
• Great for finding quality services when traveling or in new areas`);
          }}
          className="bg-white border border-gray-300 hover:bg-gray-50 px-3 py-1 text-xs font-bold rounded shadow-sm"
        >
          Instructions
        </button>
      </div>
      
      <div className="container mx-auto px-4 py-8 max-w-7xl">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="flex items-center justify-center gap-3 mb-4">
            <div className="p-3 bg-blue-600 rounded-full">
              <MapPin className="w-8 h-8 text-white" />
            </div>
            <h1 className="text-4xl font-bold text-gray-900">Business Directory</h1>
          </div>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Discover businesses worldwide with contact details and direct website access. 
            Perfect for travelers and locals seeking quality services.
          </p>
        </div>

        {/* Search Controls */}
        <Card className="mb-8 bg-white border shadow-sm">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-blue-800">
              <Search className="w-5 h-5" />
              Search by Location
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 items-end">
              {/* Country Selection */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Country</label>
                <Select value={selectedCountry} onValueChange={handleCountryChange}>
                  <SelectTrigger className="bg-white border-gray-300">
                    <SelectValue placeholder="Select Country" />
                  </SelectTrigger>
                  <SelectContent className="bg-white border border-gray-300 shadow-lg z-[9999] max-h-60 overflow-y-auto">
                    <SelectItem value="all">All Countries</SelectItem>
                    {countries.filter(c => c !== "all").map((country) => (
                      <SelectItem key={country} value={country}>{country}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {/* Location Selection */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">City/Location</label>
                <Select value={selectedLocation} onValueChange={handleLocationChange}>
                  <SelectTrigger className="bg-white border-gray-300">
                    <SelectValue placeholder="Select Location" />
                  </SelectTrigger>
                  <SelectContent className="bg-white border border-gray-300 shadow-lg z-[9999] max-h-60 overflow-y-auto">
                    {availableLocations.map((location) => (
                      <SelectItem key={location} value={location}>
                        {location === "all" ? "All Locations" : location}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {/* Search Button */}
              <div>
                <Button 
                  onClick={handleSearch}
                  disabled={isSearching}
                  className="w-full bg-blue-600 hover:bg-blue-700 text-white"
                >
                  {isSearching ? (
                    <>
                      <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                      Searching...
                    </>
                  ) : (
                    <>
                      <Search className="w-4 h-4 mr-2" />
                      Search Businesses
                    </>
                  )}
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Results Section */}
        {hasSearched && (
          <>
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-2xl font-bold text-gray-900">
                {selectedCountry === "all" ? "All Businesses" :
                 selectedLocation === "all" ? `Businesses in ${selectedCountry}` :
                 `Businesses in ${selectedLocation}`}
              </h2>
              <div className="flex items-center gap-2 text-gray-600">
                <Users className="w-5 h-5" />
                <span className="font-medium">{filteredAds.length} advertisements found</span>
              </div>
            </div>

            {/* Business Cards */}
            {isLoading ? (
              <div className="text-center py-12">
                <Loader2 className="w-8 h-8 animate-spin mx-auto mb-4" />
                <p className="text-gray-600">Loading businesses...</p>
              </div>
            ) : filteredAds.length === 0 ? (
              <Card className="bg-white border shadow-sm">
                <CardContent className="p-8 text-center">
                  <Building2 className="w-12 h-12 mx-auto mb-4 text-gray-400" />
                  <h3 className="text-lg font-medium text-gray-900 mb-2">No businesses found</h3>
                  <p className="text-gray-500">Try searching in a different location or select "All Countries"</p>
                </CardContent>
              </Card>
            ) : (
              <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
                {filteredAds.map((ad: Advertisement) => (
                  <Card key={ad.id} className="bg-white border shadow-sm hover:shadow-md transition-shadow cursor-pointer">
                    <CardContent className="p-0">
                      {/* Business Image */}
                      {ad.imageUrl && (
                        <div className="aspect-video overflow-hidden rounded-t-lg">
                          <img 
                            src={ad.imageUrl} 
                            alt={ad.title}
                            className="w-full h-full object-cover"
                          />
                        </div>
                      )}
                      
                      {/* Business Info */}
                      <div className="p-4">
                        <div className="flex items-start justify-between mb-2">
                          <h3 className="font-semibold text-lg text-gray-900 line-clamp-1">
                            {ad.title}
                          </h3>
                          <span className="text-xs bg-blue-100 text-blue-800 px-2 py-1 rounded-full ml-2">
                            Advertisement
                          </span>
                        </div>
                        
                        <p className="text-gray-600 text-sm mb-3 line-clamp-2">
                          {ad.description}
                        </p>
                        
                        <div className="flex items-center gap-1 text-xs text-gray-500 mb-4">
                          <MapPin className="w-3 h-3" />
                          <span>{ad.targetLocation}</span>
                        </div>
                        
                        {/* Action Buttons */}
                        <div className="grid grid-cols-2 gap-2">
                          <Button 
                            size="sm" 
                            variant="outline"
                            onClick={() => handleBusinessClick(ad)}
                            className="flex items-center gap-1"
                          >
                            <ExternalLink className="w-3 h-3" />
                            Visit
                          </Button>
                          <Button 
                            size="sm" 
                            variant="outline"
                            onClick={() => {
                              const mapUrl = `https://maps.google.com/?q=${encodeURIComponent(ad.title + ' ' + ad.targetLocation)}`;
                              window.open(mapUrl, '_blank');
                              toast({ title: "Opening Map", description: `Finding ${ad.title} on Google Maps` });
                            }}
                            className="flex items-center gap-1"
                          >
                            <MapPin className="w-3 h-3" />
                            Map
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </>
        )}

        {/* Initial State */}
        {!hasSearched && (
          <Card className="bg-white border shadow-sm">
            <CardContent className="p-8 text-center">
              <Search className="w-12 h-12 mx-auto mb-4 text-gray-400" />
              <h3 className="text-lg font-medium text-gray-900 mb-2">Ready to Search</h3>
              <p className="text-gray-500">Select a country and location, then click "Search Businesses" to find local services</p>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}