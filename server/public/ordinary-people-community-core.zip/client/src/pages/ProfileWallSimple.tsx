import React, { useState, useEffect } from 'react';
import { useParams, useLocation } from 'wouter';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { useToast } from '@/hooks/use-toast';
import { Camera, Heart, MessageCircle, ArrowLeft, Home, Settings, Edit } from 'lucide-react';
import { auth } from '@/lib/firebase';
import { User as FirebaseUser, onAuthStateChanged } from 'firebase/auth';

interface User {
  id: number;
  firebaseUid: string;
  name: string;
  bio?: string;
  location?: string;
  profileImageUrl?: string;
  coverImageUrl?: string;
  coverImageFileId?: number;
}

interface WallPost {
  id: number;
  userId: number;
  authorId: number;
  content: string;
  mediaUrl?: string;
  likes: number;
  createdAt: string;
  author: {
    id: number;
    name: string;
    profileImageUrl?: string;
  };
}

export default function ProfileWallSimple() {
  const { userId } = useParams();
  const [location, setLocation] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  const [newPostContent, setNewPostContent] = useState('');
  const [currentUser, setCurrentUser] = useState<FirebaseUser | null>(null);
  const [authLoading, setAuthLoading] = useState(true);

  // Monitor Firebase auth state
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (user) => {
      setCurrentUser(user);
      setAuthLoading(false);
    });

    return () => unsubscribe();
  }, []);

  const isOwnProfile = !userId || userId === currentUser?.uid;

  // Fetch profile user data
  const { data: profileUser, isLoading } = useQuery<User>({
    queryKey: ['/api/users/profile', userId || currentUser?.uid],
    queryFn: async () => {
      const targetUid = userId || currentUser?.uid;
      if (!targetUid) throw new Error('No user ID available');
      
      const response = await fetch(`/api/users/profile?uid=${targetUid}`);
      if (!response.ok) {
        throw new Error('Failed to fetch user profile');
      }
      return response.json();
    },
    enabled: !authLoading && !!(userId || currentUser?.uid)
  });

  // Fetch wall posts
  const { data: posts = [] } = useQuery<WallPost[]>({
    queryKey: ['/api/wall-posts', profileUser?.id],
    queryFn: async () => {
      if (!profileUser?.id) throw new Error('No user ID available');
      
      const response = await fetch(`/api/profile-wall/${profileUser.id}/posts`);
      if (!response.ok) {
        throw new Error('Failed to fetch wall posts');
      }
      return response.json();
    },
    enabled: !!profileUser?.id
  });

  const handleCreatePost = async () => {
    if (!newPostContent.trim()) return;

    try {
      const response = await fetch('/api/wall-posts', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          userId: profileUser?.id,
          authorId: profileUser?.id,
          content: newPostContent,
          postType: 'post'
        }),
      });

      if (response.ok) {
        setNewPostContent('');
        toast({ title: 'Post created successfully!' });
        queryClient.invalidateQueries({ queryKey: ['/api/wall-posts'] });
      }
    } catch (error) {
      toast({ title: 'Error creating post', variant: 'destructive' });
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">Loading profile...</div>
      </div>
    );
  }

  if (!profileUser) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">Profile not found</div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white border-b px-4 py-3">
        <div className="max-w-4xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Button 
              variant="ghost" 
              onClick={() => setLocation('/')}
              className="flex items-center gap-2"
            >
              <ArrowLeft className="h-4 w-4" />
              Back
            </Button>
            <Button 
              variant="ghost" 
              onClick={() => setLocation('/dashboard')}
              className="flex items-center gap-2"
            >
              <Home className="h-4 w-4" />
              Dashboard
            </Button>
          </div>
        </div>
      </div>

      {/* Cover Photo Section */}
      <div className="max-w-4xl mx-auto">
        <div className="relative">
          <div className="h-48 md:h-64 bg-gradient-to-r from-blue-400 to-purple-600 relative overflow-hidden">
            {profileUser.coverImageUrl && (
              <img 
                src={profileUser.coverImageUrl} 
                alt="Cover" 
                className="w-full h-full object-cover"
              />
            )}
          </div>

          {/* Avatar */}
          <div className="absolute -bottom-10 left-6">
            <div className="relative">
              <div className="w-24 h-24 md:w-32 md:h-32 rounded-full bg-gray-300 border-4 border-white overflow-hidden">
                {profileUser.profileImageUrl ? (
                  <img 
                    src={profileUser.profileImageUrl} 
                    alt={profileUser.name} 
                    className="w-full h-full object-cover"
                  />
                ) : (
                  <div className="w-full h-full bg-gray-300 flex items-center justify-center text-gray-600 font-bold text-2xl">
                    {profileUser.name?.charAt(0) || 'U'}
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Profile Information */}
      <Card className="max-w-4xl mx-auto mt-16 mb-6 bg-white border shadow-sm">
        <CardContent className="pt-6 pb-4">
          <div className="flex flex-col md:flex-row md:items-start gap-4">
            <div className="flex-1">
              <h1 className="text-2xl font-bold text-gray-900 mb-2">
                {profileUser.name || 'User Profile'}
              </h1>
              <p className="text-gray-600 mb-2">
                {profileUser.bio || 'No bio available'}
              </p>
              <p className="text-gray-500 text-sm">
                📍 {profileUser.location || 'Location not specified'}
              </p>
            </div>

            {/* Action Buttons */}
            <div className="flex flex-wrap gap-2">
              {isOwnProfile && (
                <Button 
                  variant="outline" 
                  size="sm"
                  onClick={() => setLocation('/profile-settings')}
                >
                  <Edit className="h-4 w-4 mr-2" />
                  Edit Profile
                </Button>
              )}
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Post Creation */}
      {isOwnProfile && (
        <Card className="max-w-4xl mx-auto mb-6">
          <CardContent className="p-4">
            <div className="space-y-4">
              <Textarea
                placeholder="What's on your mind?"
                value={newPostContent}
                onChange={(e) => setNewPostContent(e.target.value)}
                className="min-h-[100px] resize-none"
              />
              <div className="flex justify-between items-center">
                <div className="flex gap-2">
                  <Button variant="ghost" size="sm">
                    <Camera className="h-4 w-4 mr-2" />
                    Photo
                  </Button>
                </div>
                <Button 
                  onClick={handleCreatePost}
                  disabled={!newPostContent.trim()}
                  className="bg-pink-600 hover:bg-pink-700"
                >
                  Post
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Posts Feed */}
      <div className="max-w-4xl mx-auto space-y-4 pb-8">
        {posts.map((post) => (
          <Card key={post.id} className="bg-white">
            <CardContent className="p-4">
              <div className="flex items-start gap-3 mb-3">
                <div className="w-10 h-10 rounded-full bg-gray-300 flex items-center justify-center text-sm font-bold">
                  {post.author?.profileImageUrl ? (
                    <img 
                      src={post.author.profileImageUrl} 
                      alt={post.author.name}
                      className="w-full h-full rounded-full object-cover"
                    />
                  ) : (
                    post.author?.name?.charAt(0) || 'U'
                  )}
                </div>
                <div className="flex-1">
                  <h3 className="font-semibold text-sm">{post.author?.name || 'Unknown User'}</h3>
                  <p className="text-xs text-gray-500">
                    {new Date(post.createdAt).toLocaleDateString()}
                  </p>
                </div>
              </div>
              
              <p className="text-gray-800 mb-3">{post.content}</p>
              
              {post.mediaUrl && (
                <div className="mb-3">
                  <img 
                    src={post.mediaUrl} 
                    alt="Post media"
                    className="max-w-full h-auto rounded-lg"
                  />
                </div>
              )}
              
              <div className="flex items-center gap-4 pt-2 border-t">
                <Button variant="ghost" size="sm" className="text-gray-600">
                  <Heart className="h-4 w-4 mr-1" />
                  {post.likes}
                </Button>
                <Button variant="ghost" size="sm" className="text-gray-600">
                  <MessageCircle className="h-4 w-4 mr-1" />
                  Comment
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}