import SocialMediaHub from "@/components/SocialMediaHub";
import { BackButton } from "@/components/BackButton";

import { AskAIButton } from "@/components/AskAIButton";
import { SEO } from "@/components/SEO";

export default function SocialHub() {
  return (
    <div className="min-h-screen bg-gray-50">
      <SEO 
        title="Social Media Hub - Connect All Your Platforms"
        description="Connect your social media accounts and manage cross-platform posting from one central hub. Post to Twitter, Facebook, Instagram, LinkedIn and YouTube simultaneously."
        keywords="social media management, cross platform posting, social media hub, multi platform posting"
      />
      
      <div className="bg-white shadow-sm border-b">
        <div className="max-w-6xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <BackButton />
              <div>
                <h1 className="text-2xl font-bold text-gray-900">Social Media Hub</h1>
                <p className="text-gray-600">Connect and manage all your social platforms</p>
              </div>
            </div>
            
            <div className="flex items-center gap-3">
              <AskAIButton />
            </div>
          </div>
        </div>
      </div>
      
      <SocialMediaHub />
    </div>
  );
}