import React, { useState } from "react";
import { useParams, useLocation } from "wouter";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from "@/components/ui/alert-dialog";
import { ArrowLeft, Plus, Image, Folder, Heart, MessageCircle, Share2, Users, Edit, Trash2, X, ArrowRight } from "lucide-react";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";

interface Gallery {
  id: number;
  name: string;
  images: Photo[];
  coverImage?: string;
  description?: string;
  userId: number;
  likes: number;
  comments: Comment[];
  isLiked: boolean;
}

interface Photo {
  id: number;
  url: string;
  caption?: string;
  likes: number;
  comments: Comment[];
  isLiked: boolean;
  createdAt: string;
}

interface Comment {
  id: number;
  text: string;
  userName: string;
  userAvatar?: string;
  createdAt: string;
}

export default function GalleryView() {
  const { userId } = useParams();
  const [, setLocation] = useLocation();
  const { appUser } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [selectedGallery, setSelectedGallery] = useState<Gallery | null>(null);
  const [selectedPhoto, setSelectedPhoto] = useState<Photo | null>(null);
  const [currentPhotoIndex, setCurrentPhotoIndex] = useState(0);
  const [editingGallery, setEditingGallery] = useState<Gallery | null>(null);
  const [editingPhoto, setEditingPhoto] = useState<Photo | null>(null);
  const [newComment, setNewComment] = useState("");
  const [showShareDialog, setShowShareDialog] = useState(false);

  // Mutations for social interactions
  const likeGalleryMutation = useMutation({
    mutationFn: async (galleryId: number) => {
      const response = await fetch(`/api/galleries/${galleryId}/like`, { 
        method: 'POST',
        headers: { 'Content-Type': 'application/json' }
      });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/galleries'] });
      toast({ title: "Gallery liked!" });
    }
  });

  const likePhotoMutation = useMutation({
    mutationFn: async (photoId: number) => {
      const response = await fetch(`/api/photos/${photoId}/like`, { 
        method: 'POST',
        headers: { 'Content-Type': 'application/json' }
      });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/galleries'] });
      toast({ title: "Photo liked!" });
    }
  });

  const addCommentMutation = useMutation({
    mutationFn: async ({ itemId, type, text }: { itemId: number; type: 'gallery' | 'photo'; text: string }) => {
      const response = await fetch(`/api/gallerys/${itemId}/comments`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ text })
      });
      if (!response.ok) throw new Error('Failed to add comment');
      return response.json();
    },
    onSuccess: async (data, variables) => {
      // Create wall notification for gallery comment
      if (variables.type === 'gallery') {
        try {
          await fetch('/api/profile-wall-posts', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              content: `${appUser?.name || 'User'} commented on a photo gallery: "${variables.text}"`,
              mediaUrl: null,
              isNotification: true,
              notificationType: 'gallery_comment'
            })
          });
        } catch (error) {
          console.log('Failed to create wall notification:', error);
        }
      }
      
      // Optimistic update - add comment immediately to UI
      queryClient.setQueryData(['/api/galleries'], (oldData: any) => {
        if (!oldData) return oldData;
        return oldData.map((gallery: any) => {
          if (gallery.id === variables.itemId && variables.type === 'gallery') {
            return {
              ...gallery,
              comments: [
                ...(gallery.comments || []),
                {
                  id: Date.now(),
                  text: variables.text,
                  userName: appUser?.name || 'User',
                  createdAt: 'just now'
                }
              ]
            };
          }
          return gallery;
        });
      });
      
      // Invalidate both galleries and wall posts to show new notification
      queryClient.invalidateQueries({ queryKey: ['/api/galleries'] });
      queryClient.invalidateQueries({ queryKey: ['/api/profile-wall-posts'] });
      setNewComment("");
      toast({ title: "Comment posted to gallery and shared to wall!" });
    }
  });

  const deleteGalleryMutation = useMutation({
    mutationFn: async (galleryId: number) => {
      const response = await fetch(`/api/galleries/${galleryId}`, { 
        method: 'DELETE',
        headers: { 'Content-Type': 'application/json' }
      });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/galleries'] });
      setSelectedGallery(null);
      toast({ title: "Gallery deleted!" });
    }
  });

  const deletePhotoMutation = useMutation({
    mutationFn: async (photoId: number) => {
      const response = await fetch(`/api/photos/${photoId}`, { 
        method: 'DELETE',
        headers: { 'Content-Type': 'application/json' }
      });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/galleries'] });
      setSelectedPhoto(null);
      toast({ title: "Photo deleted!" });
    }
  });

  const updateGalleryMutation = useMutation({
    mutationFn: async ({ id, name, description }: { id: number; name: string; description?: string }) => {
      const response = await fetch(`/api/galleries/${id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name, description })
      });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/galleries'] });
      setEditingGallery(null);
      toast({ title: "Gallery updated!" });
    }
  });

  const updatePhotoMutation = useMutation({
    mutationFn: async ({ id, caption }: { id: number; caption: string }) => {
      const response = await fetch(`/api/photos/${id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ caption })
      });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/galleries'] });
      setEditingPhoto(null);
      toast({ title: "Photo updated!" });
    }
  });

  // Helper functions
  const handlePhotoNavigation = (direction: 'prev' | 'next') => {
    if (!selectedGallery) return;
    const totalPhotos = selectedGallery.images.length;
    if (direction === 'prev') {
      setCurrentPhotoIndex((prev) => (prev - 1 + totalPhotos) % totalPhotos);
    } else {
      setCurrentPhotoIndex((prev) => (prev + 1) % totalPhotos);
    }
  };

  const handleShare = (type: 'single' | 'multi') => {
    const currentItem = selectedPhoto || selectedGallery;
    if (!currentItem) return;
    
    const shareText = selectedPhoto 
      ? `Check out this photo: ${selectedPhoto.caption || 'Amazing photo!'}`
      : `Check out my album: ${selectedGallery?.name}`;
    
    if (type === 'single') {
      navigator.share?.({ 
        title: shareText,
        url: window.location.href 
      });
    } else {
      // Multi-share to all connected social platforms
      setShowShareDialog(true);
    }
  };

  // Demo galleries with full social features - replace with real API
  const mockGalleries: Gallery[] = [
    {
      id: 1,
      name: "Holiday Photos",
      description: "Summer vacation memories from Spain",
      userId: parseInt(userId || '4'),
      likes: 12,
      isLiked: false,
      comments: [
        {
          id: 1,
          text: "Amazing photos! Looks like you had a great time.",
          userName: "Sarah Johnson",
          createdAt: "2 hours ago"
        }
      ],
      images: [
        {
          id: 101,
          url: "https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=500",
          caption: "Beautiful sunset over the Mediterranean",
          likes: 8,
          isLiked: true,
          comments: [
            {
              id: 201,
              text: "Stunning view!",
              userName: "Mike Brown",
              createdAt: "1 hour ago"
            }
          ],
          createdAt: "3 days ago"
        },
        {
          id: 102,
          url: "https://images.unsplash.com/photo-1559827260-dc66d52bef19?w=500",
          caption: "Beach day perfection",
          likes: 5,
          isLiked: false,
          comments: [],
          createdAt: "3 days ago"
        },
        {
          id: 103,
          url: "https://images.unsplash.com/photo-1544551763-46a013bb70d5?w=500",
          caption: "Local market discoveries",
          likes: 3,
          isLiked: false,
          comments: [],
          createdAt: "2 days ago"
        }
      ]
    },
    {
      id: 2,
      name: "Family Memories",
      description: "Special moments with loved ones",
      userId: parseInt(userId || '4'),
      likes: 8,
      isLiked: true,
      comments: [],
      images: [
        {
          id: 104,
          url: "https://images.unsplash.com/photo-1511895426328-dc8714191300?w=500",
          caption: "Family dinner celebration",
          likes: 6,
          isLiked: true,
          comments: [
            {
              id: 202,
              text: "Such a lovely family!",
              userName: "Emma Wilson",
              createdAt: "5 hours ago"
            }
          ],
          createdAt: "1 week ago"
        },
        {
          id: 105,
          url: "https://images.unsplash.com/photo-1578662996442-48f60103fc96?w=500",
          caption: "Birthday surprise",
          likes: 4,
          isLiked: false,
          comments: [],
          createdAt: "1 week ago"
        }
      ]
    },
    {
      id: 3,
      name: "Work Events",
      description: "Professional milestones and team activities",
      userId: parseInt(userId || '4'),
      likes: 3,
      isLiked: false,
      comments: [],
      images: [
        {
          id: 106,
          url: "https://images.unsplash.com/photo-1556761175-b413da4baf72?w=500",
          caption: "Team building success",
          likes: 2,
          isLiked: false,
          comments: [],
          createdAt: "2 weeks ago"
        }
      ]
    }
  ];

  const { data: galleries = [], isLoading } = useQuery({
    queryKey: ['/api/galleries'],
    queryFn: async () => {
      const response = await fetch('/api/galleries');
      if (!response.ok) throw new Error('Failed to fetch galleries');
      return response.json();
    }
  });

  // Photo enlargement dialog with social features
  if (selectedPhoto) {
    const currentPhoto = selectedGallery?.images[currentPhotoIndex];
    const isOwner = appUser?.id === selectedGallery?.userId;
    
    return (
      <Dialog open={true} onOpenChange={() => setSelectedPhoto(null)}>
        <DialogContent className="max-w-4xl w-full h-[90vh] p-0">
          <div className="flex h-full">
            {/* Photo Display */}
            <div className="flex-1 relative bg-black">
              <img 
                src={currentPhoto?.url || '/placeholder.jpg'} 
                alt={currentPhoto?.caption || 'Photo'}
                className="w-full h-full object-contain"
              />
              
              {/* Navigation Arrows */}
              {selectedGallery && selectedGallery.images.length > 1 && (
                <>
                  <Button
                    onClick={() => handlePhotoNavigation('prev')}
                    className="absolute left-4 top-1/2 transform -translate-y-1/2 bg-black/50 hover:bg-black/70"
                    size="sm"
                  >
                    <ArrowLeft className="w-4 h-4" />
                  </Button>
                  <Button
                    onClick={() => handlePhotoNavigation('next')}
                    className="absolute right-4 top-1/2 transform -translate-y-1/2 bg-black/50 hover:bg-black/70"
                    size="sm"
                  >
                    <ArrowRight className="w-4 h-4" />
                  </Button>
                </>
              )}
              
              {/* Close Button */}
              <Button
                onClick={() => setSelectedPhoto(null)}
                className="absolute top-4 right-4 bg-black/50 hover:bg-black/70"
                size="sm"
              >
                <X className="w-4 h-4" />
              </Button>
            </div>
            
            {/* Social Panel */}
            <div className="w-80 bg-white border-l flex flex-col">
              {/* Photo Info */}
              <div className="p-4 border-b">
                <div className="flex items-center justify-between mb-2">
                  <h3 className="font-semibold">Photo Details</h3>
                  {isOwner && (
                    <div className="flex gap-2">
                      <Button 
                        size="sm" 
                        variant="outline"
                        onClick={() => setEditingPhoto(currentPhoto || null)}
                      >
                        <Edit className="w-3 h-3" />
                      </Button>
                      <AlertDialog>
                        <AlertDialogTrigger asChild>
                          <Button size="sm" variant="destructive">
                            <Trash2 className="w-3 h-3" />
                          </Button>
                        </AlertDialogTrigger>
                        <AlertDialogContent>
                          <AlertDialogHeader>
                            <AlertDialogTitle>Delete Photo</AlertDialogTitle>
                            <AlertDialogDescription>
                              Are you sure you want to delete this photo? This action cannot be undone.
                            </AlertDialogDescription>
                          </AlertDialogHeader>
                          <AlertDialogFooter>
                            <AlertDialogCancel>Cancel</AlertDialogCancel>
                            <AlertDialogAction onClick={() => currentPhoto && deletePhotoMutation.mutate(currentPhoto.id)}>
                              Delete
                            </AlertDialogAction>
                          </AlertDialogFooter>
                        </AlertDialogContent>
                      </AlertDialog>
                    </div>
                  )}
                </div>
                <p className="text-sm text-gray-600 mb-2">{currentPhoto?.caption || 'No caption'}</p>
                <p className="text-xs text-gray-400">{currentPhoto?.createdAt}</p>
              </div>
              
              {/* Social Actions */}
              <div className="p-4 border-b">
                <div className="flex gap-2 mb-3">
                  <Button 
                    size="sm" 
                    variant={currentPhoto?.isLiked ? "default" : "outline"}
                    onClick={() => currentPhoto && likePhotoMutation.mutate(currentPhoto.id)}
                    className="flex items-center gap-1"
                  >
                    <Heart className={`w-3 h-3 ${currentPhoto?.isLiked ? 'fill-current' : ''}`} />
                    {currentPhoto?.likes || 0}
                  </Button>
                  <Button size="sm" variant="outline" onClick={() => handleShare('single')}>
                    <Share2 className="w-3 h-3 mr-1" />
                    Share
                  </Button>
                  <Button size="sm" variant="outline" onClick={() => handleShare('multi')}>
                    <Users className="w-3 h-3 mr-1" />
                    Multi-Share
                  </Button>
                </div>
              </div>
              
              {/* Comments Section - Wall Style */}
              <div className="flex-1 p-4 overflow-y-auto">
                <h4 className="font-medium mb-4 flex items-center gap-2">
                  <MessageCircle className="w-5 h-5" />
                  Photo Comments ({currentPhoto?.comments?.length || 0})
                </h4>
                
                {/* Comment Input Box */}
                <div className="mb-4 p-3 bg-gray-50 rounded-lg">
                  <div className="flex gap-2">
                    <div className="w-8 h-8 bg-blue-600 rounded-full flex items-center justify-center text-white font-medium text-sm">
                      {appUser?.name?.charAt(0) || 'U'}
                    </div>
                    <div className="flex-1">
                      <Textarea
                        placeholder="Write a comment about this photo..."
                        value={newComment}
                        onChange={(e) => setNewComment(e.target.value)}
                        className="min-h-[60px] resize-none border-gray-200 focus:border-blue-500 text-sm"
                      />
                      <div className="flex gap-2 mt-2">
                        <Button 
                          size="sm"
                          onClick={() => currentPhoto && addCommentMutation.mutate({
                            itemId: currentPhoto.id,
                            type: 'photo',
                            text: newComment
                          })}
                          disabled={!newComment.trim()}
                          className="bg-blue-600 hover:bg-blue-700 text-white"
                        >
                          <MessageCircle className="w-3 h-3 mr-1" />
                          Post
                        </Button>
                        <Button 
                          size="sm"
                          variant="outline"
                          onClick={() => setNewComment('')}
                          disabled={!newComment.trim()}
                        >
                          Clear
                        </Button>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Comments Feed */}
                <div className="space-y-3">
                  {currentPhoto?.comments?.length === 0 ? (
                    <div className="text-center py-6 text-gray-500">
                      <MessageCircle className="w-8 h-8 mx-auto mb-2 text-gray-300" />
                      <p className="text-sm">No comments yet. Be the first!</p>
                    </div>
                  ) : (
                    currentPhoto?.comments?.map((comment) => (
                      <div key={comment.id} className="bg-white border rounded-lg p-3 hover:shadow-sm transition-shadow">
                        <div className="flex gap-2">
                          <div className="w-8 h-8 bg-gradient-to-br from-blue-500 to-purple-600 rounded-full flex items-center justify-center text-white font-medium text-sm">
                            {comment.userName.charAt(0)}
                          </div>
                          <div className="flex-1">
                            <div className="flex items-center gap-2 mb-1">
                              <span className="font-semibold text-sm">{comment.userName}</span>
                              <span className="text-xs text-gray-500">•</span>
                              <span className="text-xs text-gray-500">{comment.createdAt}</span>
                            </div>
                            <p className="text-sm text-gray-800 leading-relaxed">{comment.text}</p>
                            
                            {/* Comment Actions */}
                            <div className="flex items-center gap-3 mt-2 pt-1 border-t border-gray-100">
                              <button className="flex items-center gap-1 text-xs text-gray-600 hover:text-blue-600 transition-colors">
                                <Heart className="w-3 h-3" />
                                Like
                              </button>
                              <button className="flex items-center gap-1 text-xs text-gray-600 hover:text-blue-600 transition-colors">
                                <MessageCircle className="w-3 h-3" />
                                Reply
                              </button>
                              <button 
                                onClick={() => handleShare('single')}
                                className="flex items-center gap-1 text-xs text-gray-600 hover:text-blue-600 transition-colors"
                              >
                                <Share2 className="w-3 h-3" />
                                Share
                              </button>
                              <button 
                                onClick={() => handleShare('multi')}
                                className="flex items-center gap-1 text-xs text-gray-600 hover:text-green-600 transition-colors"
                              >
                                <Users className="w-3 h-3" />
                                Multi-Share
                              </button>
                            </div>
                          </div>
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </div>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    );
  }

  // Gallery view with social features
  if (selectedGallery) {
    const isOwner = appUser?.id === selectedGallery.userId;
    
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-purple-50 p-4">
        <div className="max-w-4xl mx-auto">
          {/* Gallery Header */}
          <div className="mb-6">
            <Button 
              onClick={() => setSelectedGallery(null)}
              variant="outline"
              className="flex items-center gap-2 mb-4"
            >
              <ArrowLeft className="w-4 h-4" />
              Back to Albums
            </Button>
            <div className="flex flex-col gap-2">
              <h1 className="text-2xl font-bold">{selectedGallery.name}</h1>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-4">
                  <span className="flex items-center gap-1 text-sm text-gray-600">
                    <Heart className="w-4 h-4" />
                    {selectedGallery.likes} Likes
                  </span>
                  <span className="flex items-center gap-1 text-sm text-gray-600">
                    <MessageCircle className="w-4 h-4" />
                    {selectedGallery.comments.length} Comments
                  </span>
                  <span className="text-sm text-gray-600">• {selectedGallery.images.length} Photos</span>
                </div>
                <Button 
                  onClick={() => handleShare('multi')}
                  variant="outline"
                  size="sm"
                  className="flex items-center gap-1"
                >
                  <Share2 className="w-4 h-4" />
                  Share Gallery
                </Button>
              </div>
              {selectedGallery.description && (
                <p className="text-gray-600">{selectedGallery.description}</p>
              )}
            </div>
            {isOwner && (
              <div className="flex gap-2 mt-4">
                <Button 
                  size="sm" 
                  variant="outline"
                  onClick={() => setEditingGallery(selectedGallery)}
                >
                  <Edit className="w-3 h-3 mr-1" />
                  Edit
                </Button>
                <AlertDialog>
                  <AlertDialogTrigger asChild>
                    <Button size="sm" variant="destructive">
                      <Trash2 className="w-3 h-3 mr-1" />
                      Delete
                    </Button>
                  </AlertDialogTrigger>
                  <AlertDialogContent>
                    <AlertDialogHeader>
                      <AlertDialogTitle>Delete Gallery</AlertDialogTitle>
                      <AlertDialogDescription>
                        Are you sure you want to delete this gallery? This will also delete all photos in it. This action cannot be undone.
                      </AlertDialogDescription>
                    </AlertDialogHeader>
                    <AlertDialogFooter>
                      <AlertDialogCancel>Cancel</AlertDialogCancel>
                      <AlertDialogAction onClick={() => deleteGalleryMutation.mutate(selectedGallery.id)}>
                        Delete Gallery
                      </AlertDialogAction>
                    </AlertDialogFooter>
                  </AlertDialogContent>
                </AlertDialog>
              </div>
            )}
          </div>
          
          {/* Gallery Social Stats */}
          <Card className="mb-6">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-4">
                  <Button 
                    variant={selectedGallery.isLiked ? "default" : "outline"}
                    onClick={() => likeGalleryMutation.mutate(selectedGallery.id)}
                    className="flex items-center gap-2"
                  >
                    <Heart className={`w-4 h-4 ${selectedGallery.isLiked ? 'fill-current' : ''}`} />
                    {selectedGallery.likes} Likes
                  </Button>
                  <span className="text-sm text-gray-600">
                    {selectedGallery.comments?.length || 0} Comments • {selectedGallery.images.length} Photos
                  </span>
                </div>
                <div className="flex gap-2">
                  <Button size="sm" variant="outline" onClick={() => handleShare('single')}>
                    <Share2 className="w-3 h-3 mr-1" />
                    Share Gallery
                  </Button>
                  <Button size="sm" variant="outline" onClick={() => handleShare('multi')}>
                    <Users className="w-3 h-3 mr-1" />
                    Multi-Share
                  </Button>
                </div>
              </div>
              {selectedGallery.description && (
                <p className="text-sm text-gray-600 mt-2">{selectedGallery.description}</p>
              )}
            </CardContent>
          </Card>
          
          {/* Photo Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mb-6">
            {selectedGallery.images.map((photo, index) => (
              <Card key={photo.id || index} className="overflow-hidden hover:shadow-lg transition-shadow">
                <CardContent className="p-0 relative group">
                  <img 
                    src={photo.url || '/placeholder.jpg'} 
                    alt={photo.caption || `Photo ${index + 1}`}
                    className="w-full h-48 object-cover cursor-pointer"
                    onClick={() => {
                      setSelectedPhoto(photo);
                      setCurrentPhotoIndex(index);
                    }}
                  />
                  <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                    <div className="text-white text-center">
                      <p className="font-medium">Click to enlarge</p>
                      {photo.caption && (
                        <p className="text-sm mt-1">{photo.caption}</p>
                      )}
                    </div>
                  </div>
                  {/* Photo stats overlay */}
                  <div className="absolute bottom-2 left-2 bg-black/70 text-white px-2 py-1 rounded text-xs flex items-center gap-2">
                    <span className="flex items-center gap-1">
                      <Heart className="w-3 h-3" />
                      {photo.likes || 0}
                    </span>
                    <span className="flex items-center gap-1">
                      <MessageCircle className="w-3 h-3" />
                      {photo.comments?.length || 0}
                    </span>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
          
          {/* Gallery Comments - Wall Style */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <MessageCircle className="w-5 h-5" />
                Gallery Comments ({selectedGallery.comments?.length || 0})
              </CardTitle>
            </CardHeader>
            <CardContent>
              {/* Comment Input Box - Top of section */}
              <div className="mb-6 p-4 bg-gray-50 rounded-lg">
                <div className="flex gap-3">
                  <div className="w-10 h-10 bg-blue-600 rounded-full flex items-center justify-center text-white font-medium">
                    {appUser?.name?.charAt(0) || 'U'}
                  </div>
                  <div className="flex-1">
                    <Textarea
                      placeholder="Write a comment about this gallery..."
                      value={newComment}
                      onChange={(e) => setNewComment(e.target.value)}
                      className="min-h-[80px] resize-none border-gray-200 focus:border-blue-500"
                    />
                    <div className="flex gap-2 mt-3">
                      <Button 
                        onClick={() => addCommentMutation.mutate({
                          itemId: selectedGallery.id,
                          type: 'gallery',
                          text: newComment
                        })}
                        disabled={!newComment.trim()}
                        className="bg-blue-600 hover:bg-blue-700 text-white px-6"
                      >
                        <MessageCircle className="w-4 h-4 mr-2" />
                        Post Comment
                      </Button>
                      <Button 
                        variant="outline"
                        onClick={() => setNewComment('')}
                        disabled={!newComment.trim()}
                      >
                        Clear
                      </Button>
                    </div>
                  </div>
                </div>
              </div>

              {/* Comments Feed - Wall Style */}
              <div className="space-y-4">
                {selectedGallery.comments?.length === 0 ? (
                  <div className="text-center py-8 text-gray-500">
                    <MessageCircle className="w-12 h-12 mx-auto mb-3 text-gray-300" />
                    <p>No comments yet. Be the first to comment!</p>
                  </div>
                ) : (
                  selectedGallery.comments?.map((comment) => (
                    <div key={comment.id} className="bg-white border rounded-lg p-4 hover:shadow-sm transition-shadow">
                      <div className="flex gap-3">
                        <div className="w-10 h-10 bg-gradient-to-br from-blue-500 to-purple-600 rounded-full flex items-center justify-center text-white font-medium shadow-sm">
                          {comment.userName.charAt(0)}
                        </div>
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-2">
                            <span className="font-semibold text-gray-900">{comment.userName}</span>
                            <span className="text-sm text-gray-500">•</span>
                            <span className="text-sm text-gray-500">{comment.createdAt}</span>
                          </div>
                          <p className="text-gray-800 leading-relaxed">{comment.text}</p>
                          
                          {/* Comment Actions */}
                          <div className="flex items-center gap-4 mt-3 pt-2 border-t border-gray-100">
                            <button className="flex items-center gap-1 text-sm text-gray-600 hover:text-blue-600 transition-colors">
                              <Heart className="w-4 h-4" />
                              Like
                            </button>
                            <button className="flex items-center gap-1 text-sm text-gray-600 hover:text-blue-600 transition-colors">
                              <MessageCircle className="w-4 h-4" />
                              Reply
                            </button>
                            <button 
                              onClick={() => handleShare('single')}
                              className="flex items-center gap-1 text-sm text-gray-600 hover:text-blue-600 transition-colors"
                            >
                              <Share2 className="w-4 h-4" />
                              Share
                            </button>
                            <button 
                              onClick={() => handleShare('multi')}
                              className="flex items-center gap-1 text-sm text-gray-600 hover:text-green-600 transition-colors"
                            >
                              <Users className="w-4 h-4" />
                              Multi-Share
                            </button>
                          </div>
                        </div>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  // Edit Gallery Dialog
  if (editingGallery) {
    return (
      <Dialog open={true} onOpenChange={() => setEditingGallery(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Edit Gallery</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <label className="text-sm font-medium">Gallery Name</label>
              <Input
                value={editingGallery.name}
                onChange={(e) => setEditingGallery({...editingGallery, name: e.target.value})}
                placeholder="Enter gallery name"
              />
            </div>
            <div>
              <label className="text-sm font-medium">Description</label>
              <Textarea
                value={editingGallery.description || ''}
                onChange={(e) => setEditingGallery({...editingGallery, description: e.target.value})}
                placeholder="Enter gallery description"
              />
            </div>
            <div className="flex gap-2 justify-end">
              <Button variant="outline" onClick={() => setEditingGallery(null)}>
                Cancel
              </Button>
              <Button 
                onClick={() => updateGalleryMutation.mutate({
                  id: editingGallery.id,
                  name: editingGallery.name,
                  description: editingGallery.description
                })}
              >
                Save Changes
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    );
  }

  // Edit Photo Dialog
  if (editingPhoto) {
    return (
      <Dialog open={true} onOpenChange={() => setEditingPhoto(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Edit Photo</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <img 
                src={editingPhoto.url} 
                alt="Photo preview"
                className="w-full h-48 object-cover rounded-lg"
              />
            </div>
            <div>
              <label className="text-sm font-medium">Photo Caption</label>
              <Textarea
                value={editingPhoto.caption || ''}
                onChange={(e) => setEditingPhoto({...editingPhoto, caption: e.target.value})}
                placeholder="Enter photo caption"
              />
            </div>
            <div className="flex gap-2 justify-end">
              <Button variant="outline" onClick={() => setEditingPhoto(null)}>
                Cancel
              </Button>
              <Button 
                onClick={() => updatePhotoMutation.mutate({
                  id: editingPhoto.id,
                  caption: editingPhoto.caption || ''
                })}
              >
                Save Changes
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    );
  }

  // Multi-Share Dialog
  if (showShareDialog) {
    const shareText = selectedPhoto 
      ? `Check out this photo: ${selectedPhoto.caption || 'Amazing photo!'}`
      : `Check out my album: ${selectedGallery?.name || 'My Album'}`;
    
    return (
      <Dialog open={true} onOpenChange={() => setShowShareDialog(false)}>
        <DialogContent className="max-w-xs w-[85vw] p-3 text-sm">
          <DialogHeader className="pb-2">
            <DialogTitle className="text-base">Share to Multiple Platforms</DialogTitle>
          </DialogHeader>
          <div className="space-y-3">
            <p className="text-xs text-gray-600">Share this {selectedPhoto ? 'photo' : 'gallery'} to your social media accounts:</p>
            <div className="bg-gray-50 p-2 rounded text-xs">
              <p className="font-medium">{shareText}</p>
            </div>
            <div className="space-y-3">
              {/* Wall-to-Group Sharing */}
              <div className="border-b pb-2">
                <h4 className="text-xs font-medium mb-1">Share to Community Groups</h4>
                <div className="grid grid-cols-2 gap-1">
                  <Button variant="outline" size="sm" className="text-xs py-1 px-2" onClick={() => {
                    // Share to Profile Wall
                    fetch('/api/profile-wall-posts', {
                      method: 'POST',
                      headers: { 'Content-Type': 'application/json' },
                      body: JSON.stringify({
                        content: `Shared from gallery: ${shareText}`,
                        mediaUrl: selectedPhoto?.url || null,
                        isShared: true
                      })
                    });
                    toast({ title: "Shared to Profile Wall!" });
                  }}>
                    Profile Wall
                  </Button>
                  <Button variant="outline" onClick={() => {
                    // Share to Community Discussion
                    const discussionText = `Gallery Share: ${shareText}`;
                    navigator.clipboard.writeText(discussionText);
                    toast({ title: "Copied! Paste in any discussion group" });
                  }}>
                    Discussion Groups
                  </Button>
                </div>
              </div>

              {/* Social Media Multi-Share */}
              <div>
                <h4 className="text-xs font-medium mb-1">Multi-Platform Social Share</h4>
                <div className="grid grid-cols-2 gap-1">
                  <Button variant="outline" size="sm" className="text-xs py-1 px-2" onClick={() => {
                    window.open(`https://facebook.com/sharer/sharer.php?u=${encodeURIComponent(window.location.href)}&quote=${encodeURIComponent(shareText)}`, '_blank');
                  }}>
                    Facebook
                  </Button>
                  <Button variant="outline" size="sm" className="text-xs py-1 px-2" onClick={() => {
                    window.open(`https://twitter.com/intent/tweet?text=${encodeURIComponent(shareText)}&url=${encodeURIComponent(window.location.href)}`, '_blank');
                  }}>
                    Twitter
                  </Button>
                  <Button variant="outline" size="sm" className="text-xs py-1 px-2" onClick={() => {
                    window.open(`https://linkedin.com/sharing/share-offsite/?url=${encodeURIComponent(window.location.href)}`, '_blank');
                  }}>
                    LinkedIn
                  </Button>
                  <Button variant="outline" size="sm" className="text-xs py-1 px-2" onClick={() => {
                    window.open(`https://wa.me/?text=${encodeURIComponent(shareText + ' ' + window.location.href)}`, '_blank');
                  }}>
                    WhatsApp
                  </Button>
                  <Button variant="outline" size="sm" className="text-xs py-1 px-2" onClick={() => {
                    window.open(`https://telegram.me/share/url?url=${encodeURIComponent(window.location.href)}&text=${encodeURIComponent(shareText)}`, '_blank');
                  }}>
                    Telegram
                  </Button>
                  <Button variant="outline" size="sm" className="text-xs py-1 px-2" onClick={() => {
                    window.open(`https://www.instagram.com/`, '_blank');
                    navigator.clipboard.writeText(shareText);
                    toast({ title: "Text copied! Paste in Instagram" });
                  }}>
                    Instagram
                  </Button>
                </div>
              </div>

              {/* Share All Button */}
              <Button 
                className="w-full bg-green-600 hover:bg-green-700 text-white"
                onClick={() => {
                  // Open all platforms simultaneously
                  const platforms = [
                    `https://facebook.com/sharer/sharer.php?u=${encodeURIComponent(window.location.href)}&quote=${encodeURIComponent(shareText)}`,
                    `https://twitter.com/intent/tweet?text=${encodeURIComponent(shareText)}&url=${encodeURIComponent(window.location.href)}`,
                    `https://linkedin.com/sharing/share-offsite/?url=${encodeURIComponent(window.location.href)}`,
                    `https://wa.me/?text=${encodeURIComponent(shareText + ' ' + window.location.href)}`,
                    `https://telegram.me/share/url?url=${encodeURIComponent(window.location.href)}&text=${encodeURIComponent(shareText)}`
                  ];
                  
                  platforms.forEach(url => window.open(url, '_blank'));
                  
                  // Also share to wall
                  fetch('/api/profile-wall-posts', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                      content: `Multi-shared gallery: ${shareText}`,
                      mediaUrl: selectedPhoto?.url || null,
                      isShared: true
                    })
                  });
                  
                  toast({ title: "Shared to ALL platforms and wall!" });
                }}
              >
                Share to ALL Platforms + Wall
              </Button>
            </div>
            <Button 
              variant="outline" 
              className="w-full" 
              onClick={() => {
                navigator.clipboard.writeText(shareText + ' ' + window.location.href);
                toast({ title: "Link copied to clipboard!" });
                setShowShareDialog(false);
              }}
            >
              Copy Link
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    );
  }

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-50 p-4 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p>Loading your albums...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 p-4">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="flex flex-col gap-4 mb-6 md:flex-row md:items-center md:justify-between">
          <div className="flex items-center gap-4">
            <Button 
              onClick={() => setLocation('/profile-wall/4')}
              variant="outline"
              className="whitespace-nowrap px-4 py-2 text-sm font-medium"
            >
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Profile
            </Button>
            <h1 className="text-2xl font-bold">My Albums</h1>
          </div>
          
          <Button 
            onClick={() => setLocation(`/create-gallery/${userId}`)}
            className="bg-blue-600 text-white whitespace-nowrap px-4 py-2 text-sm font-medium"
          >
            <Plus className="w-4 h-4 mr-2" />
            New Album
          </Button>
        </div>

        {/* Galleries Grid - Compact Format */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-3">
          {galleries.map((gallery) => (
            <Card 
              key={gallery.id} 
              className="hover:shadow-md transition-shadow"
            >
              <CardContent className="p-3">
                <div className="flex items-center justify-between">
                  <div className="flex-1">
                    <h3 className="font-medium text-sm mb-1">{gallery.name}</h3>
                    <p className="text-xs text-gray-500">
                      {gallery.images.length} {gallery.images.length === 1 ? 'photo' : 'photos'}
                    </p>
                  </div>
                  <Button 
                    size="sm"
                    onClick={() => setSelectedGallery(gallery)}
                    className="bg-blue-600 hover:bg-blue-700 text-white text-xs px-3 py-1"
                  >
                    Open
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {galleries.length === 0 && (
          <div className="text-center py-12">
            <Folder className="w-16 h-16 text-gray-300 mx-auto mb-4" />
            <h3 className="text-xl font-semibold text-gray-600 mb-2">No galleries yet</h3>
            <p className="text-gray-500 mb-6">Create your first gallery to organize your photos</p>
            <Button 
              onClick={() => setLocation(`/create-gallery/${userId}`)}
              className="bg-blue-600 text-white"
            >
              <Plus className="w-4 h-4 mr-2" />
              Create Your First Gallery
            </Button>
          </div>
        )}
      </div>
    </div>
  );
}