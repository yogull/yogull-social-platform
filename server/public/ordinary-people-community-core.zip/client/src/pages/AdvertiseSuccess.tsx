import { Link } from "wouter";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Store, Check, Mail, Phone, ArrowRight } from "lucide-react";

export default function AdvertiseSuccess() {
  return (
    <div className="min-h-screen bg-gray-50 py-8 px-4">
      <div className="max-w-2xl mx-auto">
        {/* Success Header */}
        <div className="text-center mb-8">
          <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <Check className="w-10 h-10 text-green-600" />
          </div>
          
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Payment Successful!</h1>
          <p className="text-lg text-gray-600">
            Welcome to the GoHealMe Business Community
          </p>
        </div>

        {/* Success Details */}
        <Card className="mb-6 border-green-200 bg-green-50">
          <CardHeader>
            <CardTitle className="text-green-800 flex items-center gap-2">
              <Store className="w-5 h-5" />
              Your Advertising Package is Active
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <div className="flex items-center gap-2 text-green-700">
                <Check className="w-4 h-4" />
                <span>£24.00 annual payment processed successfully</span>
              </div>
              <div className="flex items-center gap-2 text-green-700">
                <Check className="w-4 h-4" />
                <span>Carousel advertisements now active across 5 pages</span>
              </div>
              <div className="flex items-center gap-2 text-green-700">
                <Check className="w-4 h-4" />
                <span>Your dedicated online store is being set up</span>
              </div>
              <div className="flex items-center gap-2 text-green-700">
                <Check className="w-4 h-4" />
                <span>Location-based targeting enabled</span>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Next Steps */}
        <Card className="mb-6">
          <CardHeader>
            <CardTitle className="text-gray-800">What Happens Next?</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex items-start gap-3">
                <div className="w-6 h-6 bg-purple-100 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
                  <span className="text-xs font-bold text-purple-600">1</span>
                </div>
                <div>
                  <h3 className="font-semibold text-gray-800">Email Confirmation</h3>
                  <p className="text-sm text-gray-600">You'll receive a confirmation email with your advertising details and setup instructions.</p>
                </div>
              </div>
              
              <div className="flex items-start gap-3">
                <div className="w-6 h-6 bg-purple-100 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
                  <span className="text-xs font-bold text-purple-600">2</span>
                </div>
                <div>
                  <h3 className="font-semibold text-gray-800">Store Setup</h3>
                  <p className="text-sm text-gray-600">Our team will contact you within 24 hours to help set up your dedicated online store and advertising materials.</p>
                </div>
              </div>
              
              <div className="flex items-start gap-3">
                <div className="w-6 h-6 bg-purple-100 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
                  <span className="text-xs font-bold text-purple-600">3</span>
                </div>
                <div>
                  <h3 className="font-semibold text-gray-800">Go Live</h3>
                  <p className="text-sm text-gray-600">Your carousel ads and store will be live within 48 hours, reaching our health-conscious community.</p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Contact Information */}
        <Card className="mb-6">
          <CardHeader>
            <CardTitle className="text-gray-800">Need Help?</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <div className="flex items-center gap-3">
                <Mail className="w-5 h-5 text-gray-500" />
                <div>
                  <p className="font-medium text-gray-800">Email Support</p>
                  <p className="text-sm text-gray-600">ordinarypeoplecommunity.com@gmail.com</p>
                </div>
              </div>
              
              <div className="flex items-center gap-3">
                <Phone className="w-5 h-5 text-gray-500" />
                <div>
                  <p className="font-medium text-gray-800">Phone Support</p>
                  <p className="text-sm text-gray-600">+44 7711 776 304</p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Action Buttons */}
        <div className="flex flex-col sm:flex-row gap-4">
          <Link href="/" className="flex-1">
            <Button variant="outline" className="w-full">
              Return to Dashboard
            </Button>
          </Link>
          
          <Link href="/community" className="flex-1">
            <Button className="w-full bg-purple-600 hover:bg-purple-700">
              Join Community Discussions
              <ArrowRight className="w-4 h-4 ml-2" />
            </Button>
          </Link>
        </div>

        {/* Footer Note */}
        <div className="text-center mt-8 p-4 bg-blue-50 rounded-lg">
          <p className="text-sm text-blue-800">
            <strong>Thank you for supporting Ordinary People Community!</strong>
          </p>
          <p className="text-xs text-blue-600 mt-1">
            Your investment helps us provide community resources and build a platform for open discussions.
          </p>
        </div>
      </div>
    </div>
  );
}