import React, { useState } from "react";
import { useLocation } from "wouter";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ArrowLeft, Heart, MessageCircle, Send } from "lucide-react";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";

export default function GallerySimple() {
  const [location, setLocation] = useLocation();
  const { appUser } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const [selectedAlbum, setSelectedAlbum] = useState<'holiday' | 'family' | null>(null);
  const [newComment, setNewComment] = useState<{[key: string]: string}>({});
  const [showComments, setShowComments] = useState<{[key: string]: boolean}>({});
  const [photoComments, setPhotoComments] = useState<{[key: string]: any[]}>({
    h1: [
      { id: 1, text: "Beautiful sunset! Where was this taken?", userName: "Sarah Johnson", createdAt: "2 hours ago" },
      { id: 2, text: "Amazing colors in the sky", userName: "Mike Davis", createdAt: "1 hour ago" }
    ],
    h2: [
      { id: 3, text: "Love this hiking trail!", userName: "Emma Wilson", createdAt: "3 hours ago" }
    ],
    f1: [
      { id: 4, text: "Such a lovely family moment", userName: "Lisa Brown", createdAt: "4 hours ago" }
    ]
  });

  // Simple demo data
  const albums = {
    holiday: {
      name: "Holiday Photos",
      photos: [
        {
          id: "h1",
          url: "https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=800&h=600&fit=crop",
          caption: "Amazing sunset at the beach"
        },
        {
          id: "h2", 
          url: "https://images.unsplash.com/photo-1469474968028-56623f02e42e?w=800&h=600&fit=crop",
          caption: "Mountain hiking adventure"
        }
      ]
    },
    family: {
      name: "Family Memories",
      photos: [
        {
          id: "f1",
          url: "https://images.unsplash.com/photo-1511895426328-dc8714191300?w=800&h=600&fit=crop",
          caption: "Family dinner celebration"
        }
      ]
    }
  } as const;

  // Share to wall function
  const shareToWall = useMutation({
    mutationFn: async (data: { content: string; mediaUrl: string }) => {
      const response = await fetch('/api/profile-wall-posts', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userId: appUser?.id,
          authorId: appUser?.id,
          content: data.content,
          mediaUrl: data.mediaUrl,
          postType: 'image'
        })
      });
      if (!response.ok) throw new Error('Failed to share to wall');
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/profile-wall-posts'] });
      toast({ title: "Posted to your Profile Wall!" });
    }
  });

  const handleShare = (photo: { id: string; url: string; caption: string }, type: string) => {
    const content = `${type}: ${photo.caption}`;
    shareToWall.mutate({ content, mediaUrl: photo.url });
  };

  const handleAddComment = (photoId: string) => {
    const comment = newComment[photoId];
    if (!comment?.trim()) return;
    
    const newCommentObj = {
      id: Date.now(),
      text: comment,
      userName: appUser?.name || 'User',
      createdAt: 'Just now'
    };
    
    setPhotoComments(prev => ({
      ...prev,
      [photoId]: [...(prev[photoId] || []), newCommentObj]
    }));
    
    setNewComment(prev => ({ ...prev, [photoId]: '' }));
    toast({ title: "Comment added!" });
  };

  // Album view
  if (selectedAlbum && albums[selectedAlbum]) {
    const album = albums[selectedAlbum];
    return (
      <div className="min-h-screen bg-gray-50 p-4">
        <div className="max-w-2xl mx-auto">
          <div className="flex items-center gap-4 mb-6">
            <Button
              variant="outline"
              onClick={() => setSelectedAlbum(null)}
              className="flex items-center gap-2"
            >
              <ArrowLeft className="w-4 h-4" />
              Back
            </Button>
            <h1 className="text-2xl font-bold">{album.name}</h1>
          </div>

          <div className="space-y-6 max-w-sm mx-auto px-2">
            {album.photos.map((photo) => (
              <Card key={photo.id} className="bg-white w-full">
                <CardContent className="p-3">
                  <div className="flex items-center gap-3 mb-4">
                    <div className="w-10 h-10 bg-blue-600 rounded-full flex items-center justify-center text-white font-medium">
                      {appUser?.name?.charAt(0) || 'U'}
                    </div>
                    <div>
                      <h4 className="font-medium">{appUser?.name || 'User'}</h4>
                      <p className="text-sm text-gray-500">Just now</p>
                    </div>
                  </div>

                  <p className="mb-4 text-gray-800">{photo.caption}</p>

                  <div className="mb-4">
                    <img 
                      src={photo.url}
                      alt={photo.caption}
                      className="w-full max-w-lg rounded-lg"
                    />
                  </div>

                  <div className="flex items-center gap-4 text-sm text-gray-500 mb-4">
                    <span>❤️ 0 likes</span>
                    <span>💬 0 comments</span>
                  </div>

                  <div className="border-t pt-4 space-y-3">
                    <div className="flex items-center justify-center gap-4 mb-3">
                      <Button variant="ghost" size="sm" className="flex items-center gap-1">
                        <Heart className="h-4 w-4" />
                        <span className="text-xs">Like</span>
                      </Button>
                      <Button 
                        variant="ghost" 
                        size="sm"
                        className="flex items-center gap-1"
                        onClick={() => setShowComments(prev => ({ ...prev, [photo.id]: !showComments[photo.id] }))}
                      >
                        <MessageCircle className="h-4 w-4" />
                        <span className="text-xs">Comment</span>
                      </Button>
                    </div>
                    
                    <div className="grid grid-cols-3 gap-2 w-full">
                      <Button 
                        variant="outline" 
                        size="sm"
                        className="text-xs px-2 py-1 w-full"
                        onClick={() => handleShare(photo, "🏛️ OPC Share")}
                      >
                        OPC
                      </Button>
                      <Button 
                        variant="outline" 
                        size="sm"
                        className="text-xs px-2 py-1 w-full"
                        onClick={() => handleShare(photo, "📱 Media Share")}
                      >
                        Media
                      </Button>
                      <Button 
                        variant="outline" 
                        size="sm"
                        className="text-xs px-2 py-1 w-full"
                        onClick={() => handleShare(photo, "🔄 Multi-Share")}
                      >
                        Multi
                      </Button>
                    </div>
                  </div>

                  {/* Photo Comments Thread */}
                  <div className="mt-4 border-t pt-4">
                    <h4 className="font-medium mb-3">Comments ({photoComments[photo.id]?.length || 0})</h4>
                    
                    {/* Existing Comments */}
                    <div className="space-y-3 mb-4">
                      {photoComments[photo.id]?.map((comment) => (
                        <div key={comment.id} className="flex gap-3">
                          <div className="w-8 h-8 bg-gray-300 rounded-full flex items-center justify-center text-xs">
                            {comment.userName.charAt(0)}
                          </div>
                          <div className="flex-1">
                            <div className="bg-gray-100 rounded-lg p-3">
                              <div className="flex items-center gap-2 mb-1">
                                <span className="font-medium text-sm">{comment.userName}</span>
                                <span className="text-xs text-gray-500">{comment.createdAt}</span>
                              </div>
                              <p className="text-sm">{comment.text}</p>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>

                    {/* Add Comment */}
                    <div className="flex gap-2">
                      <div className="w-8 h-8 bg-blue-600 rounded-full flex items-center justify-center text-white text-xs">
                        {appUser?.name?.charAt(0) || 'U'}
                      </div>
                      <div className="flex-1 flex gap-2">
                        <Input
                          placeholder="Write a comment..."
                          value={newComment[photo.id] || ''}
                          onChange={(e) => setNewComment(prev => ({ ...prev, [photo.id]: e.target.value }))}
                          className="flex-1"
                        />
                        <Button 
                          size="sm"
                          onClick={() => handleAddComment(photo.id)}
                        >
                          <Send className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </div>
    );
  }

  // Main gallery list
  return (
    <div className="min-h-screen bg-gray-50 p-4">
      <div className="max-w-2xl mx-auto">
        <div className="flex items-center gap-4 mb-6">
          <Button
            variant="outline"
            onClick={() => setLocation('/profile-wall/4')}
            className="flex items-center gap-2"
          >
            <ArrowLeft className="w-4 h-4" />
            Back to Profile
          </Button>
          <h1 className="text-2xl font-bold">Photo Albums</h1>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <Card className="cursor-pointer hover:shadow-md">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-lg font-semibold mb-1">Holiday Photos</h3>
                  <p className="text-sm text-gray-500">2 photos</p>
                </div>
                <Button 
                  onClick={() => setSelectedAlbum('holiday')}
                  className="bg-blue-600 hover:bg-blue-700"
                >
                  Open
                </Button>
              </div>
            </CardContent>
          </Card>

          <Card className="cursor-pointer hover:shadow-md">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-lg font-semibold mb-1">Family Memories</h3>
                  <p className="text-sm text-gray-500">1 photo</p>
                </div>
                <Button 
                  onClick={() => setSelectedAlbum('family')}
                  className="bg-blue-600 hover:bg-blue-700"
                >
                  Open
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}