import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { apiRequest } from "@/lib/queryClient";
import { Search, Store, MapPin, User, Package, Heart, MessageCircle, Share2, ArrowLeft, Home, UserCircle } from "lucide-react";
import type { PersonalShop, PersonalShopAffiliateLink } from "@shared/schema";

const COUNTRIES = [
  "United Kingdom", "United States", "Canada", "Australia", "Germany", 
  "France", "Italy", "Spain", "Netherlands", "Ireland"
];

const UK_AREAS = [
  "London", "Manchester", "Birmingham", "Liverpool", "Leeds", "Sheffield", 
  "Bristol", "Nottingham", "Newcastle", "Edinburgh", "Glasgow", "Cardiff"
];

const CATEGORIES = [
  "Electronics", "Health & Wellness", "Fashion", "Home & Garden", "Sports & Fitness",
  "Beauty & Personal Care", "Books & Media", "Automotive", "Food & Beverages", "Toys & Games"
];

const BRANDS = [
  "Amazon", "Apple", "Nike", "Adidas", "Samsung", "Sony", "LG", "HP", "Dell",
  "Calvin Klein", "H&M", "Zara", "IKEA", "John Lewis", "Boots", "Superdrug"
];

export default function PersonalShopSearch() {
  const [, setLocation] = useLocation();
  const [searchTerm, setSearchTerm] = useState("");
  const [filters, setFilters] = useState({
    country: "all",
    area: "all",
    category: "all",
    brand: "all"
  });
  const [activeTab, setActiveTab] = useState("shops");

  // Search personal shops
  const { data: shops, isLoading: shopsLoading, refetch: refetchShops } = useQuery({
    queryKey: ["/api/personal-shops/search", searchTerm, filters],
    queryFn: async () => {
      const params = new URLSearchParams();
      if (searchTerm) params.append("q", searchTerm);
      if (filters.country && filters.country !== "all") params.append("country", filters.country);
      if (filters.area && filters.area !== "all") params.append("area", filters.area);
      if (filters.category && filters.category !== "all") params.append("category", filters.category);
      if (filters.brand && filters.brand !== "all") params.append("brand", filters.brand);
      
      const response = await fetch(`/api/personal-shops/search?${params}`);
      return response.json();
    },
    enabled: activeTab === "shops"
  });

  // Search affiliate links
  const { data: links, isLoading: linksLoading, refetch: refetchLinks } = useQuery({
    queryKey: ["/api/affiliate-links/search", searchTerm, filters],
    queryFn: async () => {
      const params = new URLSearchParams();
      if (searchTerm) params.append("q", searchTerm);
      if (filters.country) params.append("country", filters.country);
      if (filters.area) params.append("area", filters.area);
      if (filters.category) params.append("category", filters.category);
      if (filters.brand) params.append("brand", filters.brand);
      
      const response = await fetch(`/api/affiliate-links/search?${params}`);
      return response.json();
    },
    enabled: activeTab === "products"
  });

  const handleSearch = async () => {
    console.log('Search triggered with:', { searchTerm, filters, activeTab });
    
    // If searching for businesses/locations, redirect to business directory
    if (searchTerm.toLowerCase().includes('derby') || 
        searchTerm.toLowerCase().includes('business') ||
        searchTerm.toLowerCase().includes('shop') ||
        searchTerm.toLowerCase().includes('store')) {
      console.log('Redirecting to business directory for location search:', searchTerm);
      setLocation('/business-directory');
      return;
    }
    
    if (activeTab === "shops") {
      refetchShops();
    } else {
      refetchLinks();
    }
  };

  const clearFilters = () => {
    setSearchTerm("");
    setFilters({ country: "all", area: "all", category: "all", brand: "all" });
  };

  return (
    <div className="max-w-7xl mx-auto p-6">
      {/* Header with Navigation */}
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-4">
          <Button 
            variant="outline" 
            onClick={() => setLocation('/')}
            className="flex items-center gap-2"
          >
            <Home className="w-4 h-4" />
            Dashboard
          </Button>
          <Button 
            variant="outline" 
            onClick={() => setLocation('/profile-wall')}
            className="flex items-center gap-2"
          >
            <UserCircle className="w-4 h-4" />
            Profile
          </Button>
        </div>
        <h1 className="text-2xl font-bold">Personal Shop Search</h1>
      </div>

      <div className="mb-8">
        <p className="text-gray-600">
          Discover affiliate products and personal shops from community members around the world
        </p>
      </div>

      {/* Search and Filters */}
      <div className="bg-white border rounded-lg p-6 mb-8 shadow-sm">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4 mb-4">
          <div className="lg:col-span-2">
            <label className="block text-sm font-medium mb-2">Search</label>
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
              <Input
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder="Search by name, product, shop..."
                className="pl-10"
                onKeyPress={(e) => e.key === 'Enter' && handleSearch()}
              />
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium mb-2">Country</label>
            <Select value={filters.country} onValueChange={(value) => setFilters(prev => ({ ...prev, country: value }))}>
              <SelectTrigger>
                <SelectValue placeholder="Any country" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Any country</SelectItem>
                {COUNTRIES.map(country => (
                  <SelectItem key={country} value={country}>{country}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div>
            <label className="block text-sm font-medium mb-2">Area/City</label>
            <Select value={filters.area} onValueChange={(value) => setFilters(prev => ({ ...prev, area: value }))}>
              <SelectTrigger>
                <SelectValue placeholder="Any area" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Any area</SelectItem>
                {UK_AREAS.map(area => (
                  <SelectItem key={area} value={area}>{area}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div>
            <label className="block text-sm font-medium mb-2">Category</label>
            <Select value={filters.category} onValueChange={(value) => setFilters(prev => ({ ...prev, category: value }))}>
              <SelectTrigger>
                <SelectValue placeholder="Any category" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Any category</SelectItem>
                {CATEGORIES.map(category => (
                  <SelectItem key={category} value={category}>{category}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div>
            <label className="block text-sm font-medium mb-2">Brand</label>
            <Select value={filters.brand} onValueChange={(value) => setFilters(prev => ({ ...prev, brand: value }))}>
              <SelectTrigger>
                <SelectValue placeholder="Any brand" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Any brand</SelectItem>
                {BRANDS.map(brand => (
                  <SelectItem key={brand} value={brand}>{brand}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="flex items-end gap-2">
            <Button onClick={handleSearch} className="bg-blue-600 hover:bg-blue-700">
              <Search className="w-4 h-4 mr-2" />
              Search
            </Button>
            <Button variant="outline" onClick={clearFilters}>
              Clear All
            </Button>
          </div>
        </div>

        {/* Active Filters */}
        {(searchTerm || Object.values(filters).some(f => f)) && (
          <div className="mt-4 pt-4 border-t">
            <div className="flex flex-wrap gap-2">
              <span className="text-sm font-medium">Active filters:</span>
              {searchTerm && (
                <Badge variant="secondary">
                  Search: {searchTerm}
                </Badge>
              )}
              {filters.country && (
                <Badge variant="secondary">
                  <MapPin className="w-3 h-3 mr-1" />
                  {filters.country}
                </Badge>
              )}
              {filters.area && (
                <Badge variant="secondary">
                  {filters.area}
                </Badge>
              )}
              {filters.category && (
                <Badge variant="secondary">
                  {filters.category}
                </Badge>
              )}
              {filters.brand && (
                <Badge variant="secondary">
                  {filters.brand}
                </Badge>
              )}
            </div>
          </div>
        )}
      </div>

      {/* Results Tabs */}
      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-2 mb-6">
          <TabsTrigger value="shops" className="flex items-center gap-2">
            <Store className="w-4 h-4" />
            Personal Shops ({shops?.length || 0})
          </TabsTrigger>
          <TabsTrigger value="products" className="flex items-center gap-2">
            <Package className="w-4 h-4" />
            Affiliate Products ({links?.length || 0})
          </TabsTrigger>
        </TabsList>

        <TabsContent value="shops">
          {shopsLoading ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {[1, 2, 3, 4, 5, 6].map(i => (
                <div key={i} className="animate-pulse">
                  <div className="h-32 bg-gray-200 rounded-lg mb-4"></div>
                  <div className="h-4 bg-gray-200 rounded mb-2"></div>
                  <div className="h-3 bg-gray-200 rounded mb-1"></div>
                  <div className="h-3 bg-gray-200 rounded w-1/2"></div>
                </div>
              ))}
            </div>
          ) : shops?.length ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {shops.map((shop: PersonalShop & { user: { name: string; email: string } }) => (
                <Card key={shop.id} className="hover:shadow-lg transition-shadow cursor-pointer"
                      onClick={() => setLocation(`/personal-shop/${shop.id}`)}>
                  <div className="h-32 bg-gradient-to-r from-purple-500 to-pink-500 relative">
                    <div className="absolute inset-0 bg-black bg-opacity-30"></div>
                    <div className="absolute bottom-3 left-3 text-white">
                      <h3 className="font-bold text-lg">{shop.shopName}</h3>
                      <div className="flex items-center gap-1 text-sm opacity-90">
                        <User className="w-3 h-3" />
                        {shop.user.name}
                      </div>
                    </div>
                  </div>
                  <CardContent className="p-4">
                    <p className="text-gray-600 text-sm mb-3 line-clamp-2">
                      {shop.description || "No description provided"}
                    </p>
                    <div className="flex justify-between items-center">
                      <Badge variant="secondary">
                        {shop.totalAffiliateLinks} {shop.totalAffiliateLinks === 1 ? 'Product' : 'Products'}
                      </Badge>
                      <Button 
                        size="sm" 
                        variant="outline"
                        onClick={(e) => {
                          e.stopPropagation();
                          setLocation(`/personal-shop/${shop.id}`);
                        }}
                      >
                        Visit Shop
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : (
            <div className="text-center py-12">
              <Store className="w-16 h-16 mx-auto text-gray-400 mb-4" />
              <h3 className="text-xl font-semibold mb-2">No shops found</h3>
              <p className="text-gray-600 mb-4">Try adjusting your search criteria</p>
              <div className="space-x-2">
                <Button 
                  onClick={() => setLocation('/business-profile/1')}
                  variant="outline"
                  size="sm"
                >
                  Test Business Profile
                </Button>
                <Button 
                  onClick={() => setLocation('/business/1')}
                  variant="outline"
                  size="sm"
                >
                  Test Business Alt
                </Button>
              </div>
            </div>
          )}
        </TabsContent>

        <TabsContent value="products">
          {linksLoading ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {[1, 2, 3, 4, 5, 6, 7, 8].map(i => (
                <div key={i} className="animate-pulse">
                  <div className="h-48 bg-gray-200 rounded-lg mb-4"></div>
                  <div className="h-4 bg-gray-200 rounded mb-2"></div>
                  <div className="h-3 bg-gray-200 rounded mb-1"></div>
                  <div className="h-3 bg-gray-200 rounded w-1/2"></div>
                </div>
              ))}
            </div>
          ) : links?.length ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {links.map((link: PersonalShopAffiliateLink & { 
                shop: { shopName: string; user: { name: string; email: string } } 
              }) => (
                <Card key={link.id} className="overflow-hidden hover:shadow-lg transition-shadow">
                  <div className="relative">
                    {link.productImageUrl ? (
                      <img 
                        src={link.productImageUrl} 
                        alt={link.title}
                        className="w-full h-48 object-cover"
                      />
                    ) : (
                      <div className="w-full h-48 bg-gray-200 flex items-center justify-center">
                        <Package className="w-12 h-12 text-gray-400" />
                      </div>
                    )}
                    {link.isSharedToWalls && (
                      <Badge className="absolute top-2 left-2 bg-green-500">
                        Community Shared
                      </Badge>
                    )}
                  </div>
                  <CardContent className="p-4">
                    <div className="flex justify-between items-start mb-2">
                      <h3 className="font-semibold text-lg line-clamp-1">{link.title}</h3>
                      {link.price && (
                        <span className="text-lg font-bold text-green-600">{link.price}</span>
                      )}
                    </div>
                    
                    <div className="flex gap-2 mb-3">
                      <Badge variant="outline" className="text-xs">{link.brand}</Badge>
                      <Badge variant="outline" className="text-xs">{link.category}</Badge>
                    </div>

                    <div className="mb-3">
                      <div className="flex items-center gap-1 text-sm text-gray-600">
                        <Store className="w-3 h-3" />
                        <span>{link.shop.shopName}</span>
                      </div>
                      <div className="flex items-center gap-1 text-sm text-gray-500">
                        <User className="w-3 h-3" />
                        <span>{link.shop.user.name}</span>
                      </div>
                    </div>

                    {link.description && (
                      <p className="text-gray-600 text-sm mb-4 line-clamp-2">{link.description}</p>
                    )}
                    
                    {/* Social Actions */}
                    <div className="flex justify-between items-center pt-3 border-t">
                      <div className="flex gap-3">
                        <Button variant="ghost" size="sm" className="p-1">
                          <Heart className="w-4 h-4 mr-1" />
                          <span className="text-xs">{link.likes}</span>
                        </Button>
                        <Button variant="ghost" size="sm" className="p-1">
                          <MessageCircle className="w-4 h-4 mr-1" />
                          <span className="text-xs">{link.comments}</span>
                        </Button>
                        <Button variant="ghost" size="sm" className="p-1">
                          <Share2 className="w-4 h-4 mr-1" />
                          <span className="text-xs">{link.shares}</span>
                        </Button>
                      </div>
                      
                      {/* Public image is clickable for everyone */}
                      <Button 
                        size="sm" 
                        className="bg-blue-600 hover:bg-blue-700 text-xs px-2 py-1"
                        onClick={() => window.open(link.productImageUrl, '_blank')}
                      >
                        View Product
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : (
            <div className="text-center py-12">
              <Package className="w-16 h-16 mx-auto text-gray-400 mb-4" />
              <h3 className="text-xl font-semibold mb-2">No products found</h3>
              <p className="text-gray-600">Try adjusting your search criteria</p>
            </div>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
}