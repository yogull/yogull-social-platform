import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/hooks/use-toast';
import { Camera, ArrowLeft, Home, Users, Share2 } from 'lucide-react';
import { Link } from 'wouter';
import { auth } from '@/lib/firebase';
import { onAuthStateChanged } from 'firebase/auth';

export default function WorkingProfileWall() {
  const { toast } = useToast();
  const [user, setUser] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (user) => {
      setUser(user);
      setLoading(false);
    });
    return () => unsubscribe();
  }, []);

  const handleImageUpload = (type: 'profile' | 'cover') => {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = 'image/*';
    
    input.onchange = async (e) => {
      const file = (e.target as HTMLInputElement).files?.[0];
      if (!file) return;
      
      const reader = new FileReader();
      reader.onload = async (e) => {
        const base64 = e.target?.result as string;
        
        try {
          const response = await fetch('/api/files/upload', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              fileName: `${type}_${Date.now()}.jpg`,
              fileData: base64,
              userId: 4 // Default user ID
            })
          });
          
          if (response.ok) {
            const result = await response.json();
            toast({ title: `${type} image uploaded successfully!` });
            
            // Force page refresh to show image
            setTimeout(() => {
              window.location.reload();
            }, 1000);
          }
        } catch (error) {
          toast({ title: "Upload failed", variant: "destructive" });
        }
      };
      
      reader.readAsDataURL(file);
    };
    
    input.click();
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-white flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p>Loading profile...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-white">
      {/* Navigation */}
      <div className="bg-white border-b">
        <div className="max-w-4xl mx-auto px-4 py-3">
          <div className="flex items-center gap-4">
            <Link href="/dashboard">
              <Button variant="outline" size="sm">
                <ArrowLeft className="h-4 w-4 mr-2" />
                Back
              </Button>
            </Link>
            <Link href="/dashboard">
              <Button variant="outline" size="sm">
                <Home className="h-4 w-4 mr-2" />
                Dashboard
              </Button>
            </Link>
            <Link href="/social">
              <Button className="bg-green-600 hover:bg-green-700" size="sm">
                <Users className="h-4 w-4 mr-2" />
                Social
              </Button>
            </Link>
          </div>
        </div>
      </div>

      <div className="max-w-4xl mx-auto">
        {/* Cover Photo */}
        <div className="relative">
          <div 
            className="h-48 bg-gradient-to-r from-blue-500 to-purple-600 cursor-pointer"
            onClick={() => handleImageUpload('cover')}
          >
            <div className="absolute inset-0 flex items-center justify-center">
              <div className="text-white text-center">
                <Camera className="h-12 w-12 mx-auto mb-2" />
                <p className="text-lg font-medium">Add Cover Photo</p>
              </div>
            </div>
          </div>
          
          <Button
            onClick={() => handleImageUpload('cover')}
            className="absolute top-4 right-4 bg-black/50 hover:bg-black/70 text-white"
            size="sm"
          >
            <Camera className="h-4 w-4 mr-2" />
            Edit Cover
          </Button>
        </div>

        {/* Profile Info */}
        <div className="px-6 pb-6">
          <div className="flex items-end -mt-16 mb-4">
            <div className="relative">
              <div 
                className="w-32 h-32 rounded-full bg-gradient-to-br from-blue-400 to-purple-500 border-4 border-white cursor-pointer flex items-center justify-center"
                onClick={() => handleImageUpload('profile')}
              >
                <span className="text-white text-4xl font-bold">J</span>
              </div>
              
              <Button
                onClick={() => handleImageUpload('profile')}
                className="absolute bottom-2 right-2 w-8 h-8 rounded-full p-0 bg-blue-600 hover:bg-blue-700"
                size="sm"
              >
                <Camera className="h-4 w-4" />
              </Button>
            </div>
          </div>

          <div className="mb-6">
            <h1 className="text-3xl font-bold text-gray-900 mb-2">John Proctor</h1>
            <p className="text-gray-600 text-lg">Welcome to my profile on Ordinary People Community!</p>
          </div>

          {/* Action Buttons */}
          <div className="flex gap-4 mb-8">
            <Button
              onClick={() => {
                const url = window.location.href;
                const text = "Check out my profile on Ordinary People Community!";
                if (navigator.share) {
                  navigator.share({ title: 'My Profile', text, url });
                } else {
                  navigator.clipboard.writeText(`${text} ${url}`);
                  toast({ title: "Link copied to clipboard!" });
                }
              }}
              className="bg-blue-600 hover:bg-blue-700"
            >
              <Share2 className="h-4 w-4 mr-2" />
              Share Profile
            </Button>
            
            <Button
              onClick={() => handleImageUpload('profile')}
              variant="outline"
            >
              <Camera className="h-4 w-4 mr-2" />
              Add Photos
            </Button>
          </div>

          {/* Posts Section */}
          <div className="bg-white rounded-lg border shadow-sm p-6">
            <h2 className="text-xl font-semibold mb-4">Recent Posts</h2>
            <div className="text-center py-12 text-gray-500">
              <p className="text-lg">No posts yet</p>
              <p className="text-sm mt-2">Share your thoughts with the community!</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}