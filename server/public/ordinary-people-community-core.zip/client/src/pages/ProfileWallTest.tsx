import React from 'react';
import { useParams } from 'wouter';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';

export default function ProfileWallTest() {
  const { userId } = useParams();
  
  return (
    <div className="min-h-screen bg-gray-50 p-4">
      <div className="max-w-4xl mx-auto">
        <Card className="mb-6 bg-white border shadow-sm">
          <CardContent className="p-6">
            <h1 className="text-2xl font-bold mb-4">Profile Wall Test</h1>
            <p className="text-gray-600 mb-4">Testing basic component rendering</p>
            <p className="text-sm text-gray-500">User ID: {userId || 'Not provided'}</p>
            
            <div className="mt-6">
              <Button className="bg-blue-600 text-white px-4 py-2 rounded">
                Test Button
              </Button>
            </div>
            
            <div className="mt-4 p-4 bg-green-50 border border-green-200 rounded">
              <p className="text-green-800">✓ Component is loading successfully</p>
              <p className="text-green-600 text-sm">This confirms React rendering is working</p>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}