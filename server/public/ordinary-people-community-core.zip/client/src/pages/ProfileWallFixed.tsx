import React, { useState, useEffect } from 'react';
import { useParams, useLocation } from 'wouter';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Camera, Upload, Users, MessageCircle, Share2, Video, Image as ImageIcon } from 'lucide-react';
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { SEO } from "@/components/SEO";
import { PageHelpSystem } from "@/components/PageHelpSystem";
import UniversalFeed from "@/components/UniversalFeed";
import { SocialMediaLinks } from "@/components/SocialMediaLinks";
import ImageCropper from "@/components/ImageCropper";

interface User {
  id: number;
  firebaseUid: string;
  email: string;
  name: string;
  bio?: string;
  location?: string;
  profileImageUrl?: string;
  isAdmin: boolean;
  isBlocked: boolean;
  blockedReason?: string;
  blockedAt?: Date;
  createdAt: Date;
  updatedAt: Date;
  credits: number;
  subscription: string;
  balance: number;
  facebookUsername?: string;
  twitterUsername?: string;
  instagramUsername?: string;
  linkedinUsername?: string;
  youtubeUsername?: string;
  whatsappNumber?: string;
  telegramUsername?: string;
  personalWebsite?: string;
}

interface ProfilePost {
  id: number;
  userId: number;
  content: string;
  mediaUrl?: string;
  mediaType?: string;
  likes: number;
  comments: number;
  shares: number;
  createdAt: Date;
  user: {
    id: number;
    name: string;
    profileImageUrl?: string;
  };
}

function ProfileWallFixed() {
  const { userId } = useParams<{ userId: string }>();
  const [, setLocation] = useLocation();
  const queryClient = useQueryClient();
  const { toast } = useToast();
  
  const [newPost, setNewPost] = useState('');
  const [selectedMedia, setSelectedMedia] = useState<File | null>(null);
  const [uploadProcessing, setUploadProcessing] = useState(false);
  const [showImageCropper, setShowImageCropper] = useState(false);
  const [selectedImageFile, setSelectedImageFile] = useState<File | null>(null);
  const [cropperAction, setCropperAction] = useState<'profile' | 'cover' | 'gallery'>('profile');

  // Get current user
  const { data: currentUser } = useQuery<User>({
    queryKey: ['/api/auth/me'],
    staleTime: 5 * 60 * 1000
  });

  // Get profile user data
  const { data: profileUser, isLoading: userLoading, error: userError } = useQuery<User>({
    queryKey: [`/api/users/${userId}`],
    enabled: !!userId && !isNaN(parseInt(userId))
  });

  // Get profile wall posts
  const { data: posts = [], isLoading: postsLoading } = useQuery({
    queryKey: ['/api/profile-wall', userId],
    enabled: !!userId
  });

  // Get user companies for shop button
  const { data: userCompanies = [] } = useQuery({
    queryKey: ['/api/companies/user', userId],
    enabled: !!userId
  });

  const isOwnProfile = currentUser?.id === profileUser?.id;

  // ALL HOOKS MUST BE DECLARED BEFORE ANY CONDITIONAL RETURNS
  
  // Handle unhandled rejections
  useEffect(() => {
    const handleUnhandledRejection = (event: PromiseRejectionEvent) => {
      console.error('Unhandled promise rejection:', event.reason);
      event.preventDefault();
    };

    window.addEventListener('unhandledrejection', handleUnhandledRejection);
    return () => window.removeEventListener('unhandledrejection', handleUnhandledRejection);
  }, []);

  // Create post mutation
  const createPostMutation = useMutation({
    mutationFn: async (postData: { content: string; mediaUrl?: string; mediaType?: string }) => {
      const response = await fetch('/api/profile-wall', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(postData),
      });
      return response.json();
    },
    onSuccess: () => {
      setNewPost("");
      setSelectedMedia(null);
      queryClient.invalidateQueries({ queryKey: ["/api/profile-wall"] });
      toast({
        title: "Success",
        description: "Your post has been shared!"
      });
    },
    onError: (error) => {
      console.error('Create post error:', error);
      toast({
        title: "Error",
        description: "Failed to create post. Please try again.",
        variant: "destructive"
      });
    }
  });

  // NOW handle loading and error states using conditional rendering in JSX
  if (userLoading) {
    return (
      <div className="min-h-screen bg-gray-50 dark:bg-gray-900 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p className="text-gray-600">Loading profile...</p>
        </div>
      </div>
    );
  }

  if (userError || !profileUser) {
    return (
      <div className="min-h-screen bg-gray-50 dark:bg-gray-900 flex items-center justify-center">
        <div className="text-center space-y-4">
          <h1 className="text-2xl font-bold">Profile Not Found</h1>
          <p className="text-gray-600">This profile may not exist or there was an error loading it.</p>
          <Button onClick={() => setLocation('/dashboard')} className="bg-blue-600 text-white">
            Back to Dashboard
          </Button>
        </div>
      </div>
    );
  }

  const handleImageUpload = (action: 'profile' | 'cover' | 'gallery') => {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = 'image/*';
    input.onchange = (e) => {
      const file = (e.target as HTMLInputElement).files?.[0];
      if (file) {
        setSelectedImageFile(file);
        setCropperAction(action);
        setShowImageCropper(true);
      }
    };
    input.click();
  };

  const handleVideoUpload = () => {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = 'video/*';
    input.onchange = (e) => {
      const file = (e.target as HTMLInputElement).files?.[0];
      if (file) {
        setSelectedMedia(file);
        toast({
          title: "Video Selected",
          description: "Video ready to post"
        });
      }
    };
    input.click();
  };

  const handleCreatePost = async () => {
    if (!newPost.trim() && !selectedMedia) return;

    let mediaUrl = '';
    let mediaType = '';

    if (selectedMedia) {
      setUploadProcessing(true);
      
      try {
        const reader = new FileReader();
        reader.onload = async () => {
          const base64Data = reader.result as string;
          
          const fileData = {
            fileName: selectedMedia.name,
            fileType: selectedMedia.type,
            base64Data: base64Data,
            fileSize: selectedMedia.size
          };

          const uploadResponse = await fetch('/api/files/upload', {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
            },
            body: JSON.stringify(fileData)
          });
          const uploadData = await uploadResponse.json();

          mediaUrl = uploadData.fileUrl;
          mediaType = selectedMedia.type.startsWith('video/') ? 'video' : 'image';
          
          await createPostMutation.mutateAsync({
            content: newPost.trim(),
            mediaUrl,
            mediaType
          });
          
          setUploadProcessing(false);
        };
        reader.readAsDataURL(selectedMedia);
      } catch (error) {
        console.error('Upload error:', error);
        setUploadProcessing(false);
        toast({
          title: "Upload Error",
          description: "Failed to upload media. Please try again.",
          variant: "destructive"
        });
      }
    } else {
      await createPostMutation.mutateAsync({
        content: newPost.trim()
      });
    }
  };

  const handleCropComplete = async (croppedImageBlob: Blob) => {
    if (!croppedImageBlob) return;

    setUploadProcessing(true);
    
    try {
      const reader = new FileReader();
      reader.onload = async () => {
        const base64Data = reader.result as string;
        
        const fileData = {
          fileName: `${cropperAction}_${Date.now()}.jpg`,
          fileType: 'image/jpeg',
          base64Data: base64Data,
          fileSize: croppedImageBlob.size
        };

        const uploadResponse = await fetch('/api/files/upload', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify(fileData)
        });
        const uploadData = await uploadResponse.json();

        if (cropperAction === 'profile') {
          await fetch(`/api/users/${profileUser!.id}`, {
            method: 'PATCH',
            headers: {
              'Content-Type': 'application/json',
            },
            body: JSON.stringify({ profileImageUrl: uploadData.fileUrl })
          });
        } else if (cropperAction === 'gallery') {
          await createPostMutation.mutateAsync({
            content: "Updated gallery",
            mediaUrl: uploadData.fileUrl,
            mediaType: 'image'
          });
        }

        queryClient.invalidateQueries({ queryKey: ['/api/users'] });
        queryClient.invalidateQueries({ queryKey: ['/api/profile-wall'] });
        
        setUploadProcessing(false);
        setShowImageCropper(false);
        setSelectedImageFile(null);
        
        toast({
          title: "Success",
          description: `${cropperAction === 'profile' ? 'Profile image' : 'Photo'} updated successfully!`
        });
      };
      reader.readAsDataURL(croppedImageBlob);
    } catch (error) {
      console.error('Crop upload error:', error);
      setUploadProcessing(false);
      toast({
        title: "Error",
        description: "Failed to update image. Please try again.",
        variant: "destructive"
      });
    }
  };

  const hasCompany = Array.isArray(userCompanies) && userCompanies.length > 0;

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      {profileUser && (
        <SEO
          title={`${profileUser.name} - Profile Wall`}
          description={`View ${profileUser.name}'s profile and posts on Ordinary People Community`}
          keywords={[profileUser.name, 'profile', 'community', 'posts', 'social']}
        />
      )}

      {userLoading ? (
        <div className="flex items-center justify-center min-h-screen">
          <div className="text-center">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto mb-4"></div>
            <p className="text-gray-600">Loading profile...</p>
          </div>
        </div>
      ) : userError || !profileUser ? (
        <div className="flex items-center justify-center min-h-screen">
          <div className="text-center space-y-4">
            <h1 className="text-2xl font-bold">Profile Not Found</h1>
            <p className="text-gray-600">This profile may not exist or there was an error loading it.</p>
            <Button onClick={() => setLocation('/dashboard')} className="bg-blue-600 text-white">
              Back to Dashboard
            </Button>
          </div>
        </div>
      ) : (
        <>
          <div className="hidden md:block">
            <PageHelpSystem currentPage="profileWall" />
          </div>

          <div className="max-w-2xl mx-auto p-4 space-y-6">
            {/* Profile Header */}
            <Card>
          <CardContent className="p-6">
            <div className="flex flex-col items-center space-y-4">
              <div className="relative">
                <img
                  src={profileUser.profileImageUrl || `data:image/svg+xml,${encodeURIComponent(`
                    <svg width="96" height="96" viewBox="0 0 96 96" fill="none" xmlns="http://www.w3.org/2000/svg">
                      <circle cx="48" cy="48" r="48" fill="url(#gradient)"/>
                      <path d="M48 52c8.837 0 16-7.163 16-16s-7.163-16-16-16-16 7.163-16 16 7.163 16 16 16zM48 60c-10.667 0-32 5.333-32 16v8h64v-8c0-10.667-21.333-16-32-16z" fill="white"/>
                      <defs>
                        <linearGradient id="gradient" x1="0%" y1="0%" x2="100%" y2="100%">
                          <stop offset="0%" style="stop-color:#3B82F6"/>
                          <stop offset="100%" style="stop-color:#8B5CF6"/>
                        </linearGradient>
                      </defs>
                    </svg>
                  `)}`}
                  alt={`${profileUser.name}'s profile`}
                  className="w-24 h-24 rounded-full object-cover border-4 border-white shadow-lg"
                />
                {isOwnProfile && (
                  <Button
                    size="sm"
                    className="absolute -bottom-1 -right-1 h-8 w-8 rounded-full p-0 bg-blue-500 hover:bg-blue-600"
                    onClick={() => handleImageUpload('profile')}
                    disabled={uploadProcessing}
                  >
                    <Camera className="h-4 w-4 text-white" />
                  </Button>
                )}
              </div>
              
              <div className="text-center space-y-2">
                <h1 className="text-2xl font-bold">{profileUser.name}</h1>
                {profileUser.bio && (
                  <p className="text-gray-600 text-sm">{profileUser.bio}</p>
                )}
                {profileUser.location && (
                  <p className="text-gray-500 text-xs">{profileUser.location}</p>
                )}
              </div>

              {/* Social Media Links */}
              <SocialMediaLinks 
                userId={profileUser.id}
                currentUser={currentUser}
                socialLinks={{
                  facebookUrl: profileUser.facebookUsername ? `https://facebook.com/${profileUser.facebookUsername}` : undefined,
                  twitterUrl: profileUser.twitterUsername ? `https://twitter.com/${profileUser.twitterUsername}` : undefined,
                  instagramUrl: profileUser.instagramUsername ? `https://instagram.com/${profileUser.instagramUsername}` : undefined,
                  linkedinUrl: profileUser.linkedinUsername ? `https://linkedin.com/in/${profileUser.linkedinUsername}` : undefined,
                  youtubeUrl: profileUser.youtubeUsername ? `https://youtube.com/c/${profileUser.youtubeUsername}` : undefined,
                  whatsappUrl: profileUser.whatsappNumber ? `https://wa.me/${profileUser.whatsappNumber}` : undefined,
                  telegramUrl: profileUser.telegramUsername ? `https://t.me/${profileUser.telegramUsername}` : undefined,
                  personalWebsite: profileUser.personalWebsite
                }}
                isOwnProfile={isOwnProfile}
              />

              {/* Action Buttons */}
              <div className="flex flex-wrap gap-2 justify-center">
                {hasCompany && (
                  <Button
                    onClick={() => setLocation(`/business/${userCompanies[0].id}`)}
                    className="bg-green-600 hover:bg-green-700 text-white"
                  >
                    Visit Shop
                  </Button>
                )}
                
                <Button
                  onClick={() => setLocation(`/chat?user=${profileUser.id}`)}
                  variant="outline"
                  className="flex items-center gap-2"
                >
                  <MessageCircle className="h-4 w-4" />
                  Message
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Create Post Section - Only for own profile */}
        {isOwnProfile && (
          <Card>
            <CardContent className="p-4">
              <div className="space-y-3">
                <Textarea
                  placeholder="What's on your mind?"
                  value={newPost}
                  onChange={(e) => setNewPost(e.target.value)}
                  className="min-h-[80px] resize-none"
                />
                
                {selectedMedia && (
                  <div className="flex items-center gap-2 p-2 bg-gray-100 rounded">
                    <span className="text-sm text-gray-600">
                      {selectedMedia.type.startsWith('video/') ? 'Video' : 'Photo'} selected: {selectedMedia.name}
                    </span>
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => setSelectedMedia(null)}
                    >
                      Remove
                    </Button>
                  </div>
                )}
                
                <div className="flex items-center justify-between">
                  <div className="flex gap-2">
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => handleImageUpload('gallery')}
                      className="flex items-center gap-2"
                    >
                      <ImageIcon className="h-4 w-4" />
                      Photo
                    </Button>
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={handleVideoUpload}
                      className="flex items-center gap-2"
                    >
                      <Video className="h-4 w-4" />
                      Video
                    </Button>
                  </div>
                  
                  <Button
                    onClick={handleCreatePost}
                    disabled={(!newPost.trim() && !selectedMedia) || createPostMutation.isPending || uploadProcessing}
                    className="bg-blue-600 hover:bg-blue-700 text-white"
                  >
                    {uploadProcessing ? 'Uploading...' : 'Post'}
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Posts Feed - Facebook Style */}
        <UniversalFeed
          posts={Array.isArray(posts) ? posts : []}
          currentUser={currentUser}
          type="profile"
          enableComments={true}
          enableSharing={true}
        />

        {/* Image Cropper Modal */}
        <ImageCropper
          open={showImageCropper}
          onOpenChange={(open) => {
            setShowImageCropper(open);
            if (!open) {
              setSelectedImageFile(null);
            }
          }}
          onImageCropped={async (croppedImageBase64) => {
            // Convert base64 to blob for handleCropComplete
            const response = await fetch(croppedImageBase64);
            const blob = await response.blob();
            await handleCropComplete(blob);
            setShowImageCropper(false);
            setSelectedImageFile(null);
          }}
          aspectRatio={cropperAction === 'profile' ? 1 : 16/9}
          title={cropperAction === 'profile' ? 'Crop Profile Picture' : cropperAction === 'cover' ? 'Crop Cover Photo' : 'Crop Image'}
        />
        </div>
      </>
      )}
    </div>
  );
}

export default ProfileWallFixed;