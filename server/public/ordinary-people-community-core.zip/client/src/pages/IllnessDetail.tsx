import { useState } from "react";
import { useParams, Link } from "wouter";
import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useToast } from "@/hooks/use-toast";
import { ArrowLeft, Brain, Heart, Users, AlertTriangle, MessageCircle, BookOpen, Send } from "lucide-react";

interface IllnessData {
  id: string;
  title: string;
  description: string;
  category: string;
  severity: 'mild' | 'moderate' | 'severe';
  prevalence: string;
  symptoms: string[];
  causes: string[];
  treatments: string[];
  supportTips: string[];
  whatToSay: string[];
  whatNotToSay: string[];
  resources: Array<{
    title: string;
    url: string;
    description: string;
  }>;
}

interface Comment {
  id: number;
  content: string;
  author: string;
  createdAt: string;
}

const illnessData: Record<string, IllnessData> = {
  "brain-injury": {
    id: "brain-injury",
    title: "Traumatic Brain Injury (TBI)",
    description: "A traumatic brain injury occurs when an external force injures the brain. It can range from mild concussions to severe brain damage.",
    category: "Neurological",
    severity: "severe",
    prevalence: "700,000 annually in UK",
    symptoms: [
      "Headaches or migraines",
      "Memory problems and confusion",
      "Difficulty concentrating",
      "Mood changes and irritability",
      "Sleep disturbances",
      "Sensitivity to light and sound",
      "Fatigue and loss of energy",
      "Balance and coordination issues"
    ],
    causes: [
      "Motor vehicle accidents",
      "Falls (especially in elderly)",
      "Sports-related injuries",
      "Violent assaults",
      "Explosive blasts (military)",
      "Workplace accidents"
    ],
    treatments: [
      "Rest and gradual return to activities",
      "Cognitive rehabilitation therapy",
      "Physical therapy for balance/coordination",
      "Speech therapy if needed",
      "Medications for symptoms (headaches, sleep)",
      "Occupational therapy",
      "Mental health counseling"
    ],
    supportTips: [
      "Be patient - recovery takes time",
      "Provide quiet, calm environments",
      "Help with organization and reminders",
      "Encourage rest when needed",
      "Assist with daily tasks without taking over",
      "Listen without judgment",
      "Learn about their specific symptoms"
    ],
    whatToSay: [
      "How are you feeling today?",
      "What can I do to help?",
      "It's okay to rest when you need to",
      "Your recovery is important",
      "I'm here if you need anything",
      "Take your time",
      "You're doing great"
    ],
    whatNotToSay: [
      "You look fine to me",
      "Just push through it",
      "Everyone gets headaches",
      "Are you sure it's that bad?",
      "You should be better by now",
      "At least it wasn't worse",
      "Try to think positive"
    ],
    resources: [
      {
        title: "Brain Injury Association of America",
        url: "https://www.biausa.org",
        description: "Comprehensive resources and support for brain injury survivors"
      },
      {
        title: "CDC TBI Information",
        url: "https://www.cdc.gov/traumaticbraininjury",
        description: "Medical information and prevention strategies"
      }
    ]
  },
  "dementia": {
    id: "dementia",
    title: "Dementia & Alzheimer's",
    description: "Dementia is a general term for cognitive decline that interferes with daily life. Alzheimer's is the most common type.",
    category: "Neurological",
    severity: "severe",
    prevalence: "55 million worldwide",
    symptoms: [
      "Memory loss affecting daily activities",
      "Difficulty with familiar tasks",
      "Problems with language and communication",
      "Disorientation to time and place",
      "Poor judgment and decision making",
      "Mood and personality changes",
      "Withdrawal from social activities"
    ],
    causes: [
      "Age (primary risk factor)",
      "Genetics and family history",
      "Cardiovascular disease",
      "Diabetes",
      "Head injuries",
      "Lifestyle factors",
      "Environmental factors"
    ],
    treatments: [
      "Medications to slow progression",
      "Cognitive stimulation activities",
      "Regular physical exercise",
      "Social engagement",
      "Maintaining routines",
      "Nutritional support",
      "Managing other health conditions"
    ],
    supportTips: [
      "Maintain familiar routines",
      "Communicate clearly and simply",
      "Use visual cues and reminders",
      "Create a safe, calm environment",
      "Be patient with repetition",
      "Focus on feelings, not facts",
      "Take care of yourself as caregiver"
    ],
    whatToSay: [
      "I'm here with you",
      "You're safe",
      "Let's do this together",
      "I love spending time with you",
      "You're important to me",
      "How are you feeling?",
      "Tell me about..."
    ],
    whatNotToSay: [
      "Don't you remember?",
      "We just talked about this",
      "You're wrong",
      "Try to remember",
      "Think harder",
      "You used to know this",
      "That's not how it happened"
    ],
    resources: [
      {
        title: "Alzheimer's Association",
        url: "https://www.alz.org",
        description: "Leading resource for Alzheimer's and dementia information"
      },
      {
        title: "National Institute on Aging",
        url: "https://www.nia.nih.gov",
        description: "Research and information on aging-related conditions"
      }
    ]
  },
  "emf-illness": {
    id: "emf-illness",
    title: "EMF Sensitivity & Illness",
    description: "Electromagnetic hypersensitivity (EHS) is sensitivity to electromagnetic fields, causing various health symptoms.",
    category: "Environmental",
    severity: "moderate",
    prevalence: "3-5% of population",
    symptoms: [
      "Headaches and migraines",
      "Fatigue and weakness",
      "Sleep disturbances",
      "Difficulty concentrating",
      "Memory problems",
      "Skin tingling or burning",
      "Heart palpitations",
      "Nausea and dizziness"
    ],
    causes: [
      "Cell phone and wireless radiation",
      "WiFi routers and smart devices",
      "Power lines and electrical wiring",
      "Microwave ovens",
      "Bluetooth devices",
      "Smart meters",
      "5G and cellular towers"
    ],
    treatments: [
      "EMF avoidance and reduction",
      "Grounding and earthing",
      "Nutritional support (antioxidants)",
      "Detoxification protocols",
      "Stress reduction techniques",
      "EMF protection devices",
      "Environmental modifications"
    ],
    supportTips: [
      "Take their symptoms seriously",
      "Help create low-EMF spaces",
      "Offer to use wired connections",
      "Support their avoidance strategies",
      "Be understanding of limitations",
      "Research EMF reduction together",
      "Respect their need for distance from devices"
    ],
    whatToSay: [
      "I believe what you're experiencing",
      "How can I help reduce EMF exposure?",
      "What devices should I turn off?",
      "Let me know if you need space",
      "Your health comes first",
      "I'll support your choices",
      "What makes you feel better?"
    ],
    whatNotToSay: [
      "It's all in your head",
      "EMFs can't hurt you",
      "Just ignore it",
      "The government says it's safe",
      "You're being paranoid",
      "Everyone uses these devices",
      "You can't avoid technology"
    ],
    resources: [
      {
        title: "Environmental Health Trust",
        url: "https://ehtrust.org",
        description: "Research and education on environmental health risks"
      },
      {
        title: "EMF Safety Network",
        url: "https://emfsafetynetwork.org",
        description: "Information and advocacy for EMF awareness"
      }
    ]
  },
  "myocarditis": {
    id: "myocarditis",
    title: "Myocarditis",
    description: "Myocarditis is inflammation of the heart muscle that can affect the heart's ability to pump blood and can cause rapid or abnormal heart rhythms.",
    category: "Cardiovascular",
    severity: "severe",
    prevalence: "7-14 per 100,000 people in UK",
    symptoms: [
      "Chest pain or pressure",
      "Shortness of breath",
      "Rapid or irregular heartbeat",
      "Fatigue and weakness",
      "Swelling in legs, ankles, or feet",
      "Light-headedness or fainting",
      "Flu-like symptoms (fever, headache, body aches)",
      "Difficulty exercising or reduced exercise tolerance"
    ],
    causes: [
      "Viral infections (COVID-19, flu, common cold)",
      "Bacterial infections",
      "Certain medications and vaccines",
      "Autoimmune diseases",
      "Radiation therapy",
      "Certain chemicals and toxins",
      "Illegal drugs (cocaine, amphetamines)"
    ],
    treatments: [
      "Rest and activity restriction",
      "Anti-inflammatory medications",
      "Heart failure medications (ACE inhibitors, beta-blockers)",
      "Diuretics for fluid retention",
      "Immunosuppressive therapy in severe cases",
      "Heart rhythm medications if needed",
      "Regular cardiac monitoring",
      "Gradual return to activity with medical supervision"
    ],
    supportTips: [
      "Encourage complete rest during acute phase",
      "Help monitor symptoms and medication schedules",
      "Assist with daily activities to reduce strain",
      "Provide emotional support - recovery can be frightening",
      "Learn CPR and emergency procedures",
      "Help maintain heart-healthy diet",
      "Support gradual return to activities as cleared by doctor"
    ],
    whatToSay: [
      "Your heart needs time to heal",
      "I'm here to help with anything you need",
      "It's okay to feel scared - this is treatable",
      "Let's follow the doctor's instructions together",
      "Your rest is important for recovery",
      "I believe in your strength to get through this",
      "We'll take this one day at a time"
    ],
    whatNotToSay: [
      "You're too young to have heart problems",
      "Just push through the fatigue",
      "It's probably just anxiety",
      "You should be fine by now",
      "At least it's not a heart attack",
      "Maybe you're overreacting",
      "Exercise will make you feel better"
    ],
    resources: [
      {
        title: "Myocarditis Foundation",
        url: "https://www.myocarditisfoundation.org",
        description: "Patient support and research for myocarditis"
      },
      {
        title: "American Heart Association",
        url: "https://www.heart.org",
        description: "Heart health information and resources"
      },
      {
        title: "Cardiomyopathy Association",
        url: "https://www.cardiomyopathy.org",
        description: "Support for heart muscle diseases"
      }
    ]
  },
  "heart-problems": {
    id: "heart-problems",
    title: "Heart Problems & Cardiovascular Issues",
    description: "Various heart conditions including coronary artery disease, heart failure, arrhythmias, and other cardiovascular disorders that affect heart function.",
    category: "Cardiovascular",
    severity: "severe",
    prevalence: "170,000 deaths annually in UK",
    symptoms: [
      "Chest pain or discomfort",
      "Shortness of breath",
      "Fatigue and weakness",
      "Irregular heartbeat or palpitations",
      "Swelling in legs, feet, or abdomen",
      "Dizziness or lightheadedness",
      "Nausea or loss of appetite",
      "Persistent cough or wheezing"
    ],
    causes: [
      "High blood pressure",
      "High cholesterol",
      "Diabetes",
      "Smoking and tobacco use",
      "Family history of heart disease",
      "Obesity and physical inactivity",
      "Stress and poor sleep",
      "Age and gender factors"
    ],
    treatments: [
      "Lifestyle modifications (diet, exercise, smoking cessation)",
      "Medications (blood thinners, statins, blood pressure drugs)",
      "Cardiac procedures (angioplasty, stents, bypass surgery)",
      "Implantable devices (pacemakers, defibrillators)",
      "Cardiac rehabilitation programs",
      "Regular monitoring and follow-up care",
      "Stress management and mental health support"
    ],
    supportTips: [
      "Help maintain heart-healthy diet and exercise routine",
      "Assist with medication management and schedules",
      "Provide transportation to medical appointments",
      "Learn to recognize emergency warning signs",
      "Encourage stress reduction activities",
      "Support lifestyle changes without being pushy",
      "Be patient with activity limitations"
    ],
    whatToSay: [
      "I'm here to support your heart health journey",
      "Let's work together on healthy changes",
      "Your health is worth prioritizing",
      "It's okay to take things slowly",
      "I'm proud of the changes you're making",
      "How can I help you feel better today?",
      "Your efforts to stay healthy inspire me"
    ],
    whatNotToSay: [
      "You brought this on yourself",
      "Just don't think about it",
      "You look fine to me",
      "A little stress won't hurt",
      "You're too young for heart problems",
      "Just lose weight and you'll be fine",
      "Don't be so dramatic about chest pain"
    ],
    resources: [
      {
        title: "American Heart Association",
        url: "https://www.heart.org",
        description: "Comprehensive heart health information"
      },
      {
        title: "Heart Foundation",
        url: "https://www.heartfoundation.org",
        description: "Prevention and support resources"
      },
      {
        title: "CardioSmart",
        url: "https://www.cardiosmart.org",
        description: "Patient education and tools"
      }
    ]
  },
  "cancer": {
    id: "cancer",
    title: "Cancer Support & Information",
    description: "Cancer encompasses over 100 different diseases characterized by abnormal cell growth. Support and information for patients, families, and caregivers.",
    category: "Oncology",
    severity: "severe",
    prevalence: "375,000 new cases annually in UK",
    symptoms: [
      "Unexplained weight loss",
      "Persistent fatigue",
      "Fever that doesn't go away",
      "Pain that doesn't improve",
      "Skin changes or new lumps",
      "Changes in bowel or bladder habits",
      "Persistent cough or hoarseness",
      "Unusual bleeding or discharge"
    ],
    causes: [
      "Genetic mutations and family history",
      "Environmental toxins and chemicals",
      "Tobacco and alcohol use",
      "Radiation exposure",
      "Certain viruses and infections",
      "Age and hormonal factors",
      "Poor diet and obesity",
      "Chronic inflammation"
    ],
    treatments: [
      "Surgery to remove tumors",
      "Chemotherapy and targeted therapy",
      "Radiation therapy",
      "Immunotherapy",
      "Hormone therapy",
      "Stem cell or bone marrow transplant",
      "Palliative care for symptom management",
      "Clinical trials and experimental treatments"
    ],
    supportTips: [
      "Provide practical help with daily tasks",
      "Offer emotional support without judgment",
      "Help coordinate care and appointments",
      "Assist with nutrition and meal preparation",
      "Respect their need for rest and privacy",
      "Stay positive but acknowledge their feelings",
      "Help maintain connections with others"
    ],
    whatToSay: [
      "I'm here for you through this journey",
      "What do you need most right now?",
      "You're stronger than you know",
      "It's okay to have bad days",
      "I believe in your ability to fight this",
      "Let me help you with practical things",
      "Your courage inspires me"
    ],
    whatNotToSay: [
      "Everything happens for a reason",
      "Stay positive - attitude is everything",
      "I know exactly how you feel",
      "You should try this alternative treatment",
      "At least it's not...",
      "God only gives you what you can handle",
      "You look great for someone with cancer"
    ],
    resources: [
      {
        title: "American Cancer Society",
        url: "https://www.cancer.org",
        description: "Comprehensive cancer information and support"
      },
      {
        title: "National Cancer Institute",
        url: "https://www.cancer.gov",
        description: "Research and treatment information"
      },
      {
        title: "CancerCare",
        url: "https://www.cancercare.org",
        description: "Free support services for cancer patients"
      }
    ]
  },
  "stroke": {
    id: "stroke",
    title: "Stroke",
    description: "A stroke occurs when blood flow to part of the brain is interrupted or reduced, preventing brain tissue from getting oxygen and nutrients.",
    category: "Cardiovascular",
    severity: "severe",
    prevalence: "100,000 strokes annually in UK",
    symptoms: [
      "Sudden weakness or numbness in face, arm, or leg",
      "Sudden confusion or trouble speaking",
      "Sudden trouble seeing in one or both eyes",
      "Sudden trouble walking or loss of balance",
      "Sudden severe headache with no known cause",
      "Difficulty swallowing",
      "Loss of consciousness or awareness",
      "Memory problems and cognitive changes"
    ],
    causes: [
      "Blood clot blocking artery (ischemic stroke)",
      "Bleeding in the brain (hemorrhagic stroke)",
      "High blood pressure and hypertension",
      "Atrial fibrillation and heart disease",
      "Diabetes and metabolic conditions",
      "Smoking and substance use",
      "Age and family history"
    ],
    treatments: [
      "Emergency medical intervention (clot-busting drugs)",
      "Physical therapy and rehabilitation",
      "Speech and language therapy",
      "Occupational therapy for daily activities",
      "Medications to prevent future strokes",
      "Blood pressure and diabetes management",
      "Lifestyle modifications and support"
    ],
    supportTips: [
      "Be patient with communication difficulties",
      "Help with mobility and daily tasks safely",
      "Encourage rehabilitation participation",
      "Understand fatigue and cognitive changes",
      "Support emotional recovery and adjustment",
      "Learn about stroke warning signs",
      "Create safe, accessible environments"
    ],
    whatToSay: [
      "Take your time, I'm here to listen",
      "Your recovery progress is impressive",
      "What can I help you with today?",
      "It's okay to rest when you need to",
      "You're working so hard on recovery",
      "I'm proud of your determination",
      "Let me know if you need assistance"
    ],
    whatNotToSay: [
      "You should be better by now",
      "Just try harder to speak clearly",
      "You're being too slow",
      "Stop making excuses",
      "At least you survived",
      "You look fine to me",
      "Why can't you remember that?"
    ],
    resources: [
      {
        title: "Stroke Association UK",
        url: "https://www.stroke.org.uk",
        description: "UK's leading stroke charity providing support and information"
      },
      {
        title: "NHS Stroke Information",
        url: "https://www.nhs.uk/conditions/stroke",
        description: "Comprehensive NHS guidance on stroke prevention and recovery"
      },
      {
        title: "Different Strokes",
        url: "https://www.differentstrokes.co.uk",
        description: "Support for younger stroke survivors and their families"
      }
    ]
  },
  "autism": {
    id: "autism",
    title: "Autism Spectrum Disorder (ASD)",
    description: "Autism is a developmental condition that affects communication, social interaction, and behavior. It presents differently in each individual.",
    category: "Neurodevelopmental",
    severity: "moderate",
    prevalence: "700,000 people in UK",
    symptoms: [
      "Difficulty with social communication and interaction",
      "Repetitive behaviors or interests",
      "Sensory sensitivities (light, sound, touch, taste)",
      "Need for routine and predictability",
      "Challenges with nonverbal communication",
      "Difficulty understanding social cues",
      "Intense focus on specific interests",
      "Motor coordination differences"
    ],
    causes: [
      "Genetic factors and family history",
      "Brain development differences",
      "Advanced parental age",
      "Prenatal factors",
      "Multiple genes involved",
      "Environmental factors (research ongoing)"
    ],
    treatments: [
      "Early intervention and behavioral therapy",
      "Speech and language therapy",
      "Occupational therapy for daily skills",
      "Social skills training",
      "Educational support and accommodations",
      "Sensory integration therapy",
      "Family support and training",
      "Medication for associated conditions"
    ],
    supportTips: [
      "Learn about their specific needs and preferences",
      "Create predictable routines and environments",
      "Use clear, direct communication",
      "Respect their sensory needs",
      "Focus on their strengths and interests",
      "Be patient with social differences",
      "Advocate for appropriate accommodations"
    ],
    whatToSay: [
      "What works best for you?",
      "I appreciate your unique perspective",
      "How can I support you better?",
      "Your way of thinking is valuable",
      "What are your interests?",
      "I'm here to learn and understand",
      "You have important contributions to make"
    ],
    whatNotToSay: [
      "You don't look autistic",
      "Everyone's a little autistic",
      "You're so high-functioning",
      "Have you tried not being autistic?",
      "You should make eye contact",
      "Just act normal",
      "You're using autism as an excuse"
    ],
    resources: [
      {
        title: "National Autistic Society UK",
        url: "https://www.autism.org.uk",
        description: "UK's leading autism charity providing support and information"
      },
      {
        title: "NHS Autism Information",
        url: "https://www.nhs.uk/conditions/autism",
        description: "Comprehensive NHS guidance on autism spectrum disorders"
      },
      {
        title: "Autism Education Trust",
        url: "https://www.autismeducationtrust.org.uk",
        description: "Educational resources and training for autism support"
      }
    ]
  },
  "diabetes-1": {
    id: "diabetes-1",
    title: "Diabetes Type 1",
    description: "Type 1 diabetes is an autoimmune condition where the body doesn't produce insulin. It requires lifelong insulin therapy and careful blood sugar management.",
    category: "Endocrine",
    severity: "severe",
    prevalence: "400,000 people in UK",
    symptoms: [
      "Frequent urination and excessive thirst",
      "Unexplained weight loss",
      "Extreme fatigue and weakness",
      "Blurred vision",
      "Slow-healing cuts and wounds",
      "Frequent infections",
      "Fruity-smelling breath",
      "Nausea and vomiting"
    ],
    causes: [
      "Autoimmune destruction of insulin-producing cells",
      "Genetic predisposition",
      "Environmental triggers (viruses, stress)",
      "Family history of Type 1 diabetes",
      "Usually develops in childhood or young adulthood"
    ],
    treatments: [
      "Insulin therapy (multiple daily injections or pump)",
      "Blood glucose monitoring",
      "Carbohydrate counting",
      "Regular exercise routine",
      "Healthy diet planning",
      "Regular medical check-ups",
      "Continuous glucose monitoring",
      "Ketone monitoring"
    ],
    supportTips: [
      "Learn about blood sugar management",
      "Help with meal planning and carb counting",
      "Recognize signs of high/low blood sugar",
      "Support their exercise routine",
      "Keep emergency glucose supplies handy",
      "Understand their daily insulin schedule",
      "Be patient with blood sugar fluctuations"
    ],
    whatToSay: [
      "How can I help with your blood sugar management?",
      "What snacks should I keep on hand?",
      "How are you feeling right now?",
      "Would you like me to check your supplies?",
      "You're doing a great job managing this",
      "What's your blood sugar level?",
      "Let me know if you need anything"
    ],
    whatNotToSay: [
      "You can't eat that",
      "Should you be eating sugar?",
      "Just watch your diet better",
      "You brought this on yourself",
      "At least it's not Type 2",
      "You should try to cure it naturally",
      "You're lucky it's manageable"
    ],
    resources: [
      {
        title: "Diabetes UK",
        url: "https://www.diabetes.org.uk",
        description: "UK's leading diabetes charity with comprehensive support"
      },
      {
        title: "JDRF UK",
        url: "https://jdrf.org.uk",
        description: "Type 1 diabetes research and support charity"
      },
      {
        title: "NHS Diabetes Information",
        url: "https://www.nhs.uk/conditions/type-1-diabetes",
        description: "Comprehensive NHS guidance on Type 1 diabetes"
      }
    ]
  },
  "diabetes-2": {
    id: "diabetes-2", 
    title: "Diabetes Type 2",
    description: "Type 2 diabetes occurs when the body becomes resistant to insulin or doesn't produce enough. It can often be managed through lifestyle changes and medication.",
    category: "Endocrine",
    severity: "moderate",
    prevalence: "4.9 million people in UK",
    symptoms: [
      "Increased thirst and frequent urination",
      "Fatigue and weakness",
      "Slow-healing wounds",
      "Frequent infections",
      "Blurred vision",
      "Tingling in hands and feet",
      "Unexplained weight changes",
      "Skin darkening in body folds"
    ],
    causes: [
      "Insulin resistance",
      "Obesity and excess weight",
      "Physical inactivity",
      "Poor diet high in processed foods",
      "Age (over 45)",
      "Family history",
      "High blood pressure",
      "Gestational diabetes history"
    ],
    treatments: [
      "Healthy diet and portion control",
      "Regular physical exercise",
      "Weight management",
      "Blood glucose monitoring",
      "Oral medications (metformin, etc.)",
      "Insulin therapy if needed",
      "Regular health screenings",
      "Stress management"
    ],
    supportTips: [
      "Support healthy meal planning",
      "Encourage regular exercise",
      "Help with medication reminders",
      "Learn about healthy cooking",
      "Support weight management goals",
      "Understand their dietary needs",
      "Help monitor blood sugar levels"
    ],
    whatToSay: [
      "How can I support your health goals?",
      "Would you like to exercise together?",
      "What healthy meals can we prepare?",
      "How are your energy levels today?",
      "You're making great progress",
      "What does your doctor recommend?",
      "I'm proud of your commitment"
    ],
    whatNotToSay: [
      "You did this to yourself",
      "Just lose weight and you'll be fine",
      "You can't eat anything good anymore",
      "It's not that serious",
      "You should have taken better care of yourself",
      "At least it's not Type 1",
      "You're being too strict with your diet"
    ],
    resources: [
      {
        title: "Diabetes UK",
        url: "https://www.diabetes.org.uk",
        description: "Comprehensive Type 2 diabetes support and information"
      },
      {
        title: "NHS Type 2 Diabetes",
        url: "https://www.nhs.uk/conditions/type-2-diabetes",
        description: "NHS guidance on managing Type 2 diabetes"
      },
      {
        title: "Diabetes Prevention Programme",
        url: "https://www.england.nhs.uk/diabetes/diabetes-prevention",
        description: "NHS programme for preventing Type 2 diabetes"
      }
    ]
  },
  "depression": {
    id: "depression",
    title: "Depression",
    description: "Depression is a common mental health condition that causes persistent sadness and loss of interest in activities. It affects how you feel, think, and behave.",
    category: "Mental Health",
    severity: "moderate",
    prevalence: "4.5 million adults in UK",
    symptoms: [
      "Persistent sadness or low mood",
      "Loss of interest in activities once enjoyed",
      "Changes in appetite and sleep patterns",
      "Fatigue and loss of energy",
      "Difficulty concentrating or making decisions",
      "Feelings of worthlessness or guilt",
      "Restlessness or feeling slowed down",
      "Thoughts of death or suicide"
    ],
    causes: [
      "Chemical imbalances in the brain",
      "Genetic predisposition",
      "Life events and trauma",
      "Chronic stress",
      "Medical conditions",
      "Medication side effects",
      "Substance abuse",
      "Seasonal changes"
    ],
    treatments: [
      "Cognitive Behavioral Therapy (CBT)",
      "Antidepressant medications",
      "Regular exercise and physical activity",
      "Mindfulness and meditation",
      "Support groups and counseling",
      "Light therapy for seasonal depression",
      "Lifestyle changes and stress management",
      "Electroconvulsive therapy for severe cases"
    ],
    supportTips: [
      "Listen without judgment or trying to fix",
      "Encourage professional help and treatment",
      "Help with daily tasks when needed",
      "Maintain regular contact and check-ins",
      "Learn about depression to understand better",
      "Be patient with their recovery process",
      "Encourage self-care and healthy habits"
    ],
    whatToSay: [
      "I'm here for you",
      "This isn't your fault",
      "You're not alone in this",
      "What can I do to help?",
      "Your feelings are valid",
      "I believe you can get through this",
      "Would you like to talk about it?"
    ],
    whatNotToSay: [
      "Just think positive",
      "Snap out of it",
      "Others have it worse",
      "You have so much to be grateful for",
      "It's all in your head",
      "You need to try harder",
      "Depression isn't real"
    ],
    resources: [
      {
        title: "NHS Mental Health Services",
        url: "https://www.nhs.uk/mental-health",
        description: "Comprehensive NHS mental health support and services"
      },
      {
        title: "Mind UK",
        url: "https://www.mind.org.uk",
        description: "Mental health charity providing information and support"
      },
      {
        title: "Samaritans",
        url: "https://www.samaritans.org",
        description: "24/7 confidential emotional support for anyone in distress"
      }
    ]
  },
  "anxiety": {
    id: "anxiety",
    title: "Anxiety Disorders",
    description: "Anxiety disorders involve excessive worry, fear, or nervousness that interferes with daily activities. They are among the most common mental health conditions.",
    category: "Mental Health",
    severity: "moderate",
    prevalence: "8.2 million people in UK",
    symptoms: [
      "Excessive worry or fear",
      "Restlessness and feeling on edge",
      "Difficulty concentrating",
      "Irritability and mood changes",
      "Physical symptoms (rapid heartbeat, sweating)",
      "Sleep disturbances",
      "Muscle tension and headaches",
      "Avoidance of anxiety-triggering situations"
    ],
    causes: [
      "Genetic predisposition",
      "Brain chemistry imbalances",
      "Traumatic experiences",
      "Chronic stress",
      "Medical conditions",
      "Substance use",
      "Personality factors",
      "Environmental stressors"
    ],
    treatments: [
      "Cognitive Behavioral Therapy (CBT)",
      "Exposure therapy",
      "Anti-anxiety medications",
      "Relaxation techniques and deep breathing",
      "Mindfulness and meditation",
      "Regular exercise",
      "Support groups",
      "Lifestyle modifications"
    ],
    supportTips: [
      "Learn about their specific anxiety triggers",
      "Practice patience during anxiety episodes",
      "Help create calming environments",
      "Encourage gradual exposure to fears",
      "Support their treatment and therapy",
      "Learn grounding techniques together",
      "Avoid enabling avoidance behaviors"
    ],
    whatToSay: [
      "I'm here to support you",
      "Let's take this one step at a time",
      "Your feelings are understandable",
      "What helps you feel calmer?",
      "You've handled this before",
      "Breathe with me",
      "This feeling will pass"
    ],
    whatNotToSay: [
      "Just calm down",
      "There's nothing to worry about",
      "You're being irrational",
      "Stop overthinking",
      "It's all in your head",
      "You need to face your fears",
      "Everyone gets anxious sometimes"
    ],
    resources: [
      {
        title: "Anxiety UK",
        url: "https://www.anxietyuk.org.uk",
        description: "Charity providing support for anxiety disorders"
      },
      {
        title: "NHS Anxiety Information",
        url: "https://www.nhs.uk/mental-health/conditions/anxiety",
        description: "Comprehensive NHS guidance on anxiety disorders"
      },
      {
        title: "No Panic",
        url: "https://nopanic.org.uk",
        description: "Support for panic attacks and anxiety disorders"
      }
    ]
  },
  "arthritis": {
    id: "arthritis",
    title: "Arthritis",
    description: "Arthritis involves inflammation of one or more joints, causing pain and stiffness that typically worsens with age. The most common types are osteoarthritis and rheumatoid arthritis.",
    category: "Musculoskeletal",
    severity: "moderate",
    prevalence: "10 million people in UK",
    symptoms: [
      "Joint pain and stiffness",
      "Swelling around joints",
      "Reduced range of motion",
      "Morning stiffness lasting over an hour",
      "Fatigue and general malaise",
      "Warmth and redness around joints",
      "Joint deformity in severe cases",
      "Difficulty with daily activities"
    ],
    causes: [
      "Age-related wear and tear (osteoarthritis)",
      "Autoimmune response (rheumatoid arthritis)",
      "Genetic predisposition",
      "Previous joint injuries",
      "Obesity putting extra stress on joints",
      "Infections affecting joints",
      "Repetitive joint use",
      "Hormonal factors"
    ],
    treatments: [
      "Anti-inflammatory medications",
      "Physical therapy and exercise",
      "Weight management",
      "Hot and cold therapy",
      "Joint injections (corticosteroids)",
      "Disease-modifying drugs for RA",
      "Joint replacement surgery",
      "Occupational therapy"
    ],
    supportTips: [
      "Help with daily tasks during flare-ups",
      "Encourage gentle exercise and movement",
      "Assist with home modifications for accessibility",
      "Support medication and appointment schedules",
      "Learn about their specific type of arthritis",
      "Be patient with limitations and bad days",
      "Help maintain social connections and activities"
    ],
    whatToSay: [
      "How are your joints feeling today?",
      "What can I help you with?",
      "Let's take our time",
      "Your pace is fine with me",
      "Would heat or cold help right now?",
      "I admire how you manage this",
      "What activities bring you joy?"
    ],
    whatNotToSay: [
      "You're too young for arthritis",
      "Just push through the pain",
      "You should exercise more",
      "It's just part of getting older",
      "Have you tried this miracle cure?",
      "You don't look like you're in pain",
      "At least it's not cancer"
    ],
    resources: [
      {
        title: "Arthritis Action",
        url: "https://www.arthritisaction.org.uk",
        description: "UK charity providing arthritis support and information"
      },
      {
        title: "NHS Arthritis Information",
        url: "https://www.nhs.uk/conditions/arthritis",
        description: "Comprehensive NHS guidance on arthritis types and treatment"
      },
      {
        title: "National Rheumatoid Arthritis Society",
        url: "https://www.nras.org.uk",
        description: "Support and advocacy for people with rheumatoid arthritis"
      }
    ]
  },
  "ibs": {
    id: "ibs",
    title: "Irritable Bowel Syndrome (IBS)",
    description: "IBS is a common digestive disorder affecting the large intestine, causing cramping, abdominal pain, bloating, gas, and changes in bowel habits.",
    category: "Gastrointestinal",
    severity: "moderate",
    prevalence: "13 million people in UK",
    symptoms: [
      "Abdominal pain and cramping",
      "Bloating and gas",
      "Diarrhea, constipation, or alternating",
      "Changes in stool appearance",
      "Mucus in stool",
      "Feeling of incomplete bowel emptying",
      "Urgency to have bowel movements",
      "Symptoms worsen with stress"
    ],
    causes: [
      "Abnormal gut-brain communication",
      "Food sensitivities and intolerances",
      "Stress and anxiety",
      "Hormonal changes",
      "Gut microbiome imbalances",
      "Previous gastroenteritis",
      "Genetic predisposition",
      "Certain medications"
    ],
    treatments: [
      "Dietary modifications (FODMAP diet)",
      "Stress management techniques",
      "Regular exercise",
      "Medications for symptoms",
      "Probiotics and fiber supplements",
      "Cognitive behavioral therapy",
      "Antispasmodic medications",
      "Lifestyle changes"
    ],
    supportTips: [
      "Learn about trigger foods and help avoid them",
      "Be understanding about sudden bathroom needs",
      "Help plan meals and grocery shopping",
      "Support stress management activities",
      "Be flexible with plans and activities",
      "Learn about IBS to understand better",
      "Encourage professional medical support"
    ],
    whatToSay: [
      "How is your stomach feeling today?",
      "What foods are safe for you right now?",
      "Should we plan for bathroom breaks?",
      "I understand this is unpredictable",
      "What helps you feel more comfortable?",
      "Your health comes first",
      "Let me know if you need to leave early"
    ],
    whatNotToSay: [
      "It's just stress",
      "Everyone has stomach problems",
      "You should eat more fiber",
      "It's all in your head",
      "Just avoid trigger foods",
      "You're being too sensitive",
      "Try this diet I heard about"
    ],
    resources: [
      {
        title: "The IBS Network",
        url: "https://www.theibsnetwork.org",
        description: "UK charity providing IBS support and information"
      },
      {
        title: "NHS IBS Information",
        url: "https://www.nhs.uk/conditions/irritable-bowel-syndrome-ibs",
        description: "Comprehensive NHS guidance on IBS management"
      },
      {
        title: "Guts UK",
        url: "https://www.gutsuk.org",
        description: "Charity supporting digestive health research and awareness"
      }
    ]
  },
  "sleep-disorders": {
    id: "sleep-disorders",
    title: "Sleep Disorders",
    description: "Sleep disorders encompass various conditions that affect the quality, timing, and amount of sleep, including insomnia, sleep apnea, and restless leg syndrome.",
    category: "Sleep Health",
    severity: "moderate",
    prevalence: "16 million adults in UK",
    symptoms: [
      "Difficulty falling or staying asleep",
      "Excessive daytime sleepiness",
      "Loud snoring or breathing interruptions",
      "Restless legs or limb movements",
      "Waking up feeling unrefreshed",
      "Morning headaches",
      "Difficulty concentrating during the day",
      "Mood changes and irritability"
    ],
    causes: [
      "Stress and anxiety",
      "Medical conditions (sleep apnea, RLS)",
      "Medications and substances",
      "Poor sleep hygiene",
      "Shift work or irregular schedules",
      "Age-related changes",
      "Environmental factors",
      "Neurological conditions"
    ],
    treatments: [
      "Sleep hygiene improvements",
      "Cognitive behavioral therapy for insomnia",
      "CPAP therapy for sleep apnea",
      "Medications for specific conditions",
      "Lifestyle modifications",
      "Relaxation techniques",
      "Sleep study evaluations",
      "Treatment of underlying conditions"
    ],
    supportTips: [
      "Help create a calm bedtime environment",
      "Support consistent sleep schedules",
      "Encourage good sleep hygiene practices",
      "Be understanding about sleep difficulties",
      "Help with CPAP equipment if needed",
      "Support medical treatment compliance",
      "Be patient with daytime fatigue"
    ],
    whatToSay: [
      "How did you sleep last night?",
      "What helps you sleep better?",
      "Would you like help with your bedtime routine?",
      "I understand you're tired",
      "Your sleep health is important",
      "Let's make sure your room is comfortable",
      "Would you like to take a nap?"
    ],
    whatNotToSay: [
      "Just try to sleep",
      "Everyone has trouble sleeping sometimes",
      "You sleep too much",
      "Stop thinking about it",
      "You should be more tired",
      "It's all in your head",
      "Just take a sleeping pill"
    ],
    resources: [
      {
        title: "The Sleep Charity",
        url: "https://thesleepcharity.org.uk",
        description: "UK charity providing sleep support and information"
      },
      {
        title: "NHS Sleep Problems",
        url: "https://www.nhs.uk/conditions/insomnia",
        description: "Comprehensive NHS guidance on sleep disorders"
      },
      {
        title: "British Sleep Society",
        url: "https://www.sleepsociety.org.uk",
        description: "Professional organization promoting sleep health"
      }
    ]
  },
  "bipolar-disorder": {
    id: "bipolar-disorder",
    title: "Bipolar Disorder",
    description: "Bipolar disorder is a mental health condition characterized by extreme mood swings, including manic episodes (elevated mood) and depressive episodes.",
    category: "Mental Health",
    severity: "severe",
    prevalence: "1.3 million people in UK",
    symptoms: [
      "Manic episodes: elevated mood, increased energy",
      "Depressive episodes: persistent sadness, low energy",
      "Rapid speech and racing thoughts during mania",
      "Decreased need for sleep during manic episodes",
      "Impulsive behavior and poor judgment",
      "Extreme changes in activity levels",
      "Difficulty concentrating",
      "Mood swings lasting days to weeks"
    ],
    causes: [
      "Genetic predisposition",
      "Brain structure and chemistry differences",
      "Environmental stressors",
      "Traumatic life events",
      "Substance abuse",
      "Sleep disruption",
      "Hormonal imbalances",
      "Seasonal changes"
    ],
    treatments: [
      "Mood stabilizing medications",
      "Psychotherapy and counseling",
      "Cognitive behavioral therapy",
      "Family therapy and education",
      "Lifestyle management",
      "Sleep regulation",
      "Stress management",
      "Regular monitoring and medication adjustments"
    ],
    supportTips: [
      "Learn to recognize mood episode warning signs",
      "Support medication compliance",
      "Help maintain regular sleep schedules",
      "Encourage professional treatment",
      "Be patient during mood episodes",
      "Create a stable, supportive environment",
      "Learn about triggers and warning signs"
    ],
    whatToSay: [
      "I'm here to support you",
      "How are you feeling today?",
      "What can I do to help right now?",
      "Your treatment is important",
      "I notice you seem different today",
      "Let's stick to your routine",
      "Would you like to talk to your doctor?"
    ],
    whatNotToSay: [
      "Just calm down",
      "You're being dramatic",
      "Everyone has mood swings",
      "You should be grateful",
      "Stop taking your medication",
      "You're fine when you're on medication",
      "It's just a phase"
    ],
    resources: [
      {
        title: "Bipolar UK",
        url: "https://www.bipolaruk.org",
        description: "UK charity supporting people with bipolar disorder"
      },
      {
        title: "NHS Bipolar Disorder",
        url: "https://www.nhs.uk/conditions/bipolar-disorder",
        description: "Comprehensive NHS information on bipolar disorder"
      },
      {
        title: "Mind - Bipolar Disorder",
        url: "https://www.mind.org.uk/information-support/types-of-mental-health-problems/bipolar-disorder",
        description: "Detailed information and support for bipolar disorder"
      }
    ]
  },
  "adhd": {
    id: "adhd",
    title: "ADHD (Attention Deficit Hyperactivity Disorder)",
    description: "ADHD is a neurodevelopmental condition affecting attention, hyperactivity, and impulsivity. It can significantly impact daily functioning and relationships.",
    category: "Mental Health",
    severity: "moderate",
    prevalence: "2.6 million adults in UK",
    symptoms: [
      "Difficulty sustaining attention",
      "Hyperactivity and restlessness",
      "Impulsive behavior and decisions",
      "Difficulty organizing tasks",
      "Forgetfulness in daily activities",
      "Easily distracted by external stimuli",
      "Difficulty following instructions",
      "Procrastination and time management issues"
    ],
    causes: [
      "Genetic factors (highly heritable)",
      "Brain development differences",
      "Prenatal exposure to toxins",
      "Premature birth or low birth weight",
      "Head injuries",
      "Environmental factors",
      "Lead exposure in early childhood",
      "Neurotransmitter imbalances"
    ],
    treatments: [
      "Stimulant and non-stimulant medications",
      "Behavioral therapy and coaching",
      "Cognitive behavioral therapy",
      "Organizational skills training",
      "Mindfulness and meditation",
      "Regular exercise and physical activity",
      "Educational accommodations",
      "Support groups and peer support"
    ],
    supportTips: [
      "Help with organization and time management",
      "Break tasks into smaller, manageable steps",
      "Provide clear, consistent routines",
      "Use reminders and visual cues",
      "Be patient with attention difficulties",
      "Encourage strengths and interests",
      "Support medication management"
    ],
    whatToSay: [
      "Let's break this task down together",
      "What helps you focus best?",
      "Your brain works differently, and that's okay",
      "I appreciate your creativity",
      "Would you like a reminder for that?",
      "Let's take a movement break",
      "You have many strengths"
    ],
    whatNotToSay: [
      "Just try harder to focus",
      "You're being lazy",
      "Everyone gets distracted sometimes",
      "You don't need medication",
      "Sit still and pay attention",
      "You're too old to have ADHD",
      "It's just an excuse"
    ],
    resources: [
      {
        title: "ADHD Foundation",
        url: "https://www.adhdfoundation.org.uk",
        description: "UK charity providing ADHD support and awareness"
      },
      {
        title: "NHS ADHD Information",
        url: "https://www.nhs.uk/conditions/attention-deficit-hyperactivity-disorder-adhd",
        description: "Comprehensive NHS guidance on ADHD"
      },
      {
        title: "ADDISS",
        url: "https://www.addiss.co.uk",
        description: "National ADHD information and support service"
      }
    ]
  }
};

export default function IllnessDetail() {
  const { illnessId } = useParams();
  const { toast } = useToast();
  const [comment, setComment] = useState("");
  
  const illness = illnessData[illnessId || ""];

  // Mock comments for demonstration
  const { data: comments = [] } = useQuery<Comment[]>({
    queryKey: [`/api/illness-comments/${illnessId}`],
    queryFn: async () => [
      {
        id: 1,
        content: "Thank you for this comprehensive guide. It really helps me understand what my partner is going through.",
        author: "Sarah M.",
        createdAt: "2024-06-15T10:30:00Z"
      },
      {
        id: 2,
        content: "The 'what not to say' section is so important. I wish more people understood these conditions better.",
        author: "Mike R.",
        createdAt: "2024-06-14T15:45:00Z"
      }
    ]
  });

  const addCommentMutation = useMutation({
    mutationFn: async (content: string) => {
      // In a real app, this would post to the API
      return { id: Date.now(), content, author: "You", createdAt: new Date().toISOString() };
    },
    onSuccess: () => {
      setComment("");
      toast({
        title: "Comment Added",
        description: "Your comment has been posted successfully.",
      });
    },
  });

  if (!illness) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <AlertTriangle className="w-16 h-16 text-gray-400 mx-auto mb-4" />
          <h2 className="text-xl font-semibold text-gray-900 mb-2">Guide Not Found</h2>
          <p className="text-gray-600 mb-4">The illness guide you're looking for doesn't exist.</p>
          <Link href="/illness-guides">
            <Button>Back to All Guides</Button>
          </Link>
        </div>
      </div>
    );
  }

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case "mild": return "bg-green-100 text-green-800";
      case "moderate": return "bg-yellow-100 text-yellow-800";
      case "severe": return "bg-red-100 text-red-800";
      default: return "bg-gray-100 text-gray-800";
    }
  };

  const handleSubmitComment = () => {
    if (!comment.trim()) return;
    addCommentMutation.mutate(comment.trim());
  };

  return (
    <div className="min-h-screen bg-gray-50 mobile-safe w-full max-w-[65vw] mx-auto px-2 sm:px-4 py-4 overflow-x-hidden">
      <div className="w-full">
        {/* Header */}
        <div className="mb-6">
          <Link href="/illness-guides">
            <Button variant="outline" className="mb-4">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to All Guides
            </Button>
          </Link>
          
          <div className="flex items-start justify-between">
            <div>
              <h1 className="text-3xl font-bold text-gray-900 mb-2">{illness.title}</h1>
              <p className="text-lg text-gray-600 mb-4">{illness.description}</p>
              <div className="flex gap-2 mb-4">
                <Badge variant="outline">{illness.category}</Badge>
                <Badge className={getSeverityColor(illness.severity)}>{illness.severity}</Badge>
                <Badge variant="outline">Affects: {illness.prevalence}</Badge>
              </div>
            </div>
          </div>
        </div>

        {/* Content Tabs */}
        <Tabs defaultValue="overview" className="space-y-6">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="support">How to Help</TabsTrigger>
            <TabsTrigger value="resources">Resources</TabsTrigger>
            <TabsTrigger value="community">Community</TabsTrigger>
          </TabsList>

          <TabsContent value="overview">
            <div className="grid md:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <AlertTriangle className="w-5 h-5" />
                    Common Symptoms
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-2">
                    {illness.symptoms.map((symptom, index) => (
                      <li key={index} className="flex items-start gap-2">
                        <div className="w-1.5 h-1.5 bg-red-500 rounded-full mt-2 flex-shrink-0" />
                        <span className="text-gray-700">{symptom}</span>
                      </li>
                    ))}
                  </ul>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Brain className="w-5 h-5" />
                    Common Causes
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-2">
                    {illness.causes.map((cause, index) => (
                      <li key={index} className="flex items-start gap-2">
                        <div className="w-1.5 h-1.5 bg-blue-500 rounded-full mt-2 flex-shrink-0" />
                        <span className="text-gray-700">{cause}</span>
                      </li>
                    ))}
                  </ul>
                </CardContent>
              </Card>

              <Card className="md:col-span-2">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Heart className="w-5 h-5" />
                    Treatment Approaches
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid md:grid-cols-2 gap-4">
                    {illness.treatments.map((treatment, index) => (
                      <div key={index} className="flex items-start gap-2">
                        <div className="w-1.5 h-1.5 bg-green-500 rounded-full mt-2 flex-shrink-0" />
                        <span className="text-gray-700">{treatment}</span>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="support">
            <div className="grid md:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-green-700">What TO Say</CardTitle>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-3">
                    {illness.whatToSay.map((phrase, index) => (
                      <li key={index} className="flex items-start gap-2 p-3 bg-green-50 rounded-lg">
                        <div className="w-1.5 h-1.5 bg-green-500 rounded-full mt-2 flex-shrink-0" />
                        <span className="text-green-800 font-medium">"{phrase}"</span>
                      </li>
                    ))}
                  </ul>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-red-700">What NOT to Say</CardTitle>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-3">
                    {illness.whatNotToSay.map((phrase, index) => (
                      <li key={index} className="flex items-start gap-2 p-3 bg-red-50 rounded-lg">
                        <div className="w-1.5 h-1.5 bg-red-500 rounded-full mt-2 flex-shrink-0" />
                        <span className="text-red-800 font-medium">"{phrase}"</span>
                      </li>
                    ))}
                  </ul>
                </CardContent>
              </Card>

              <Card className="md:col-span-2">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Users className="w-5 h-5" />
                    How to Provide Support
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid md:grid-cols-2 gap-4">
                    {illness.supportTips.map((tip, index) => (
                      <div key={index} className="flex items-start gap-2 p-3 bg-blue-50 rounded-lg">
                        <div className="w-1.5 h-1.5 bg-blue-500 rounded-full mt-2 flex-shrink-0" />
                        <span className="text-blue-800">{tip}</span>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="resources">
            <div className="space-y-4">
              {illness.resources.map((resource, index) => (
                <Card key={index}>
                  <CardContent className="p-6">
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <h3 className="text-lg font-semibold text-gray-900 mb-2">{resource.title}</h3>
                        <p className="text-gray-600 mb-4">{resource.description}</p>
                        <a 
                          href={resource.url} 
                          target="_blank" 
                          rel="noopener noreferrer"
                          className="text-blue-600 hover:text-blue-800 font-medium"
                        >
                          Visit Resource →
                        </a>
                      </div>
                      <BookOpen className="w-6 h-6 text-gray-400 ml-4" />
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="community">
            <div className="space-y-6">
              {/* Add Comment Section */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <MessageCircle className="w-5 h-5" />
                    Share Your Experience
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <Textarea
                      placeholder="Share your experience, ask questions, or offer support to others..."
                      value={comment}
                      onChange={(e) => setComment(e.target.value)}
                      rows={4}
                    />
                    <Button 
                      onClick={handleSubmitComment}
                      disabled={!comment.trim() || addCommentMutation.isPending}
                      className="w-full"
                    >
                      <Send className="w-4 h-4 mr-2" />
                      {addCommentMutation.isPending ? "Posting..." : "Post Comment"}
                    </Button>
                  </div>
                </CardContent>
              </Card>

              {/* Comments */}
              <div className="space-y-4">
                {comments.map((comment) => (
                  <Card key={comment.id}>
                    <CardContent className="p-4">
                      <div className="flex justify-between items-start mb-2">
                        <span className="font-medium text-gray-900">{comment.author}</span>
                        <span className="text-sm text-gray-500">
                          {new Date(comment.createdAt).toLocaleDateString()}
                        </span>
                      </div>
                      <p className="text-gray-700">{comment.content}</p>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}