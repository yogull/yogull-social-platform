import { Supplement } from "@shared/schema";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/useAuth";
import { useTutorial } from "@/hooks/useTutorial";
import { Sidebar } from "@/components/Sidebar";
import { MobileNav } from "@/components/MobileNav";
import { SupplementForm } from "@/components/SupplementForm";
import { TutorialPopup } from "@/components/TutorialPopup";
import { PageHeader } from "@/components/PageHeader";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useLocation } from "wouter";

export default function Supplements() {
  const { appUser, loading } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [location] = useLocation();
  const { shouldShowTutorial, getTutorialSteps, markTutorialComplete } = useTutorial();

  const { data: supplements, isLoading: supplementsLoading } = useQuery<Supplement[]>({
    queryKey: [`/api/supplements/${appUser?.id}`],
    enabled: !!appUser?.id,
  });

  const deleteSupplementMutation = useMutation({
    mutationFn: async (supplementId: number) => {
      return apiRequest("DELETE", `/api/supplements/${supplementId}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/supplements/${appUser?.id}`] });
      queryClient.invalidateQueries({ queryKey: [`/api/dashboard/${appUser?.id}`] });
      toast({
        title: "Supplement removed",
        description: "The supplement has been removed from your list.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to remove supplement. Please try again.",
        variant: "destructive",
      });
    },
  });

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="animate-pulse text-center">
          <div className="w-16 h-16 bg-gray-200 rounded-xl mx-auto mb-4"></div>
          <div className="h-4 bg-gray-200 rounded w-32 mx-auto"></div>
        </div>
      </div>
    );
  }

  if (!appUser) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-xl font-semibold text-gray-900 mb-2">Please sign in</h2>
          <a href="/login" className="text-primary hover:text-primary/80">
            Go to login page
          </a>
        </div>
      </div>
    );
  }

  const getSupplementIcon = (name: string) => {
    const nameLower = name.toLowerCase();
    if (nameLower.includes('vitamin')) return 'fas fa-capsules';
    if (nameLower.includes('omega') || nameLower.includes('fish')) return 'fas fa-tablets';
    if (nameLower.includes('magnesium') || nameLower.includes('mineral')) return 'fas fa-pills';
    return 'fas fa-capsules';
  };

  const getFrequencyColor = (frequency: string) => {
    switch (frequency) {
      case 'daily': return 'bg-primary text-primary-foreground';
      case 'twice_daily': return 'bg-blue-500 text-white';
      case 'three_times_daily': return 'bg-purple-500 text-white';
      case 'weekly': return 'bg-orange-500 text-white';
      default: return 'bg-gray-500 text-white';
    }
  };

  const formatFrequency = (frequency: string) => {
    return frequency.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase());
  };

  return (
    <div className="lg:flex lg:h-screen">
      <Sidebar user={appUser} />
      <MobileNav user={appUser} />
      
      <main className="flex-1 overflow-auto">
        <div className="bg-white border-b border-gray-200 px-4 lg:px-8 py-6">
          <PageHeader 
            title="Supplements" 
            subtitle="Manage your supplement routine"
          />
          <div className="flex items-center space-x-3 mt-4">
            <Badge variant="secondary" className="text-sm">
              <i className="fas fa-pills mr-1"></i>
              {supplements?.length || 0} Active
            </Badge>
          </div>
        </div>

        <div className="p-4 lg:p-8 space-y-8 pb-20 lg:pb-8">
          {/* Add Supplement Form */}
          <SupplementForm userId={appUser.id} />

          {/* Supplements List */}
          <div className="space-y-6">
            <h3 className="text-xl font-semibold text-gray-900">Your Supplements</h3>
            
            {supplementsLoading ? (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {[...Array(4)].map((_, i) => (
                  <div key={i} className="animate-pulse">
                    <div className="h-32 bg-gray-200 rounded-xl"></div>
                  </div>
                ))}
              </div>
            ) : !supplements || supplements.length === 0 ? (
              <Card>
                <CardContent className="p-8 text-center">
                  <i className="fas fa-pills text-4xl text-gray-300 mb-4"></i>
                  <h4 className="text-lg font-medium text-gray-900 mb-2">No supplements yet</h4>
                  <p className="text-gray-600 mb-4">
                    Add your first supplement using the form above to start tracking your health routine.
                  </p>
                </CardContent>
              </Card>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {supplements.map((supplement) => (
                  <Card key={supplement.id} className="hover:shadow-md transition-shadow">
                    <CardContent className="p-6">
                      <div className="flex items-start justify-between mb-4">
                        <div className="flex items-center space-x-3">
                          <div className="w-12 h-12 bg-primary rounded-xl flex items-center justify-center">
                            <i className={`${getSupplementIcon(supplement.name)} text-white text-lg`}></i>
                          </div>
                          <div>
                            <h4 className="font-semibold text-gray-900">{supplement.name}</h4>
                            <p className="text-sm text-gray-600">{supplement.dosage}</p>
                          </div>
                        </div>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => {
                            if (confirm(`Are you sure you want to delete ${supplement.name}? This cannot be undone.`)) {
                              deleteSupplementMutation.mutate(supplement.id);
                            }
                          }}
                          className="text-red-600 hover:text-red-700 hover:bg-red-50 p-3 w-10 h-10"
                          disabled={deleteSupplementMutation.isPending}
                          title="Delete supplement"
                        >
                          <i className="fas fa-trash text-lg"></i>
                        </Button>
                      </div>

                      <div className="space-y-3">
                        <div className="flex items-center justify-between">
                          <span className="text-sm text-gray-600">Frequency</span>
                          <Badge className={getFrequencyColor(supplement.frequency)}>
                            {formatFrequency(supplement.frequency)}
                          </Badge>
                        </div>

                        <div className="flex items-center justify-between">
                          <span className="text-sm text-gray-600">Time</span>
                          <span className="text-sm font-medium text-gray-900">
                            {supplement.specificTime || supplement.timeOfDay.replace(/_/g, ' ')}
                          </span>
                        </div>

                        {supplement.notes && (
                          <div className="pt-2 border-t border-gray-100">
                            <p className="text-sm text-gray-600">
                              <i className="fas fa-sticky-note mr-2 text-gray-400"></i>
                              {supplement.notes}
                            </p>
                          </div>
                        )}
                      </div>

                      <div className="mt-4 pt-4 border-t border-gray-100">
                        <div className="flex items-center space-x-2 text-xs text-gray-500">
                          <i className="fas fa-calendar-plus"></i>
                          <span>
                            Added {new Date(supplement.createdAt).toLocaleDateString()}
                          </span>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </div>
        </div>
      </main>

      {/* Tutorial popup for first-time visitors */}
      {shouldShowTutorial(location) && (
        <TutorialPopup
          page={location}
          steps={getTutorialSteps(location)}
          onComplete={() => markTutorialComplete(location)}
          onSkip={() => markTutorialComplete(location)}
        />
      )}
    </div>
  );
}
