import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Progress } from "@/components/ui/progress";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { Activity, Plus, Timer, Target, Dumbbell, Calendar, TrendingUp } from "lucide-react";
import type { Exercise, Workout, ExerciseLog, FitnessGoal } from "@shared/schema";

interface TodaysWorkout {
  id: string;
  name: string;
  category: string;
  difficulty: string;
  estimatedDuration: number;
  exercises: {
    name: string;
    sets: number;
    reps?: number;
    duration?: number;
    restTime: number;
  }[];
}

const todaysWorkouts: TodaysWorkout[] = [
  {
    id: "morning-cardio",
    name: "Morning Energy Blast",
    category: "cardio",
    difficulty: "beginner",
    estimatedDuration: 20,
    exercises: [
      { name: "Jumping Jacks", sets: 3, duration: 60, restTime: 30 },
      { name: "High Knees", sets: 3, duration: 45, restTime: 30 },
      { name: "Burpees", sets: 2, reps: 10, restTime: 60 },
      { name: "Mountain Climbers", sets: 3, duration: 45, restTime: 30 },
      { name: "Cool Down Walk", sets: 1, duration: 300, restTime: 0 }
    ]
  },
  {
    id: "strength-basics",
    name: "Full Body Strength",
    category: "strength",
    difficulty: "intermediate",
    estimatedDuration: 35,
    exercises: [
      { name: "Push-ups", sets: 3, reps: 12, restTime: 60 },
      { name: "Bodyweight Squats", sets: 3, reps: 15, restTime: 60 },
      { name: "Plank", sets: 3, duration: 45, restTime: 45 },
      { name: "Lunges (each leg)", sets: 2, reps: 10, restTime: 60 },
      { name: "Tricep Dips", sets: 2, reps: 8, restTime: 60 },
      { name: "Glute Bridges", sets: 3, reps: 15, restTime: 45 }
    ]
  },
  {
    id: "flexibility-flow",
    name: "Evening Flexibility Flow",
    category: "flexibility",
    difficulty: "beginner",
    estimatedDuration: 15,
    exercises: [
      { name: "Cat-Cow Stretch", sets: 2, reps: 10, restTime: 15 },
      { name: "Child's Pose", sets: 1, duration: 60, restTime: 0 },
      { name: "Downward Dog", sets: 2, duration: 30, restTime: 15 },
      { name: "Seated Forward Fold", sets: 2, duration: 45, restTime: 15 },
      { name: "Supine Spinal Twist", sets: 2, duration: 30, restTime: 15 },
      { name: "Legs Up Wall", sets: 1, duration: 180, restTime: 0 }
    ]
  },
  {
    id: "hiit-power",
    name: "HIIT Power Session",
    category: "cardio",
    difficulty: "advanced",
    estimatedDuration: 25,
    exercises: [
      { name: "Jump Squats", sets: 4, reps: 15, restTime: 45 },
      { name: "Push-up to T", sets: 3, reps: 8, restTime: 60 },
      { name: "Sprint in Place", sets: 4, duration: 30, restTime: 30 },
      { name: "Plank Jacks", sets: 3, reps: 12, restTime: 45 },
      { name: "Bicycle Crunches", sets: 3, reps: 20, restTime: 45 }
    ]
  }
];

export default function ExerciseTracker() {
  const [activeTab, setActiveTab] = useState("today");
  const [selectedWorkout, setSelectedWorkout] = useState<TodaysWorkout | null>(null);
  const [workoutInProgress, setWorkoutInProgress] = useState(false);
  const [currentExerciseIndex, setCurrentExerciseIndex] = useState(0);
  const [currentSet, setCurrentSet] = useState(1);
  const [timer, setTimer] = useState(0);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Queries
  const { data: exerciseLogs = [] } = useQuery({
    queryKey: ["/api/exercise-logs"],
    enabled: activeTab === "logs"
  });

  const { data: fitnessGoals = [] } = useQuery({
    queryKey: ["/api/fitness-goals"],
    enabled: activeTab === "goals"
  });

  // Mutations
  const logExerciseMutation = useMutation({
    mutationFn: (data: any) => apiRequest("/api/exercise-logs", {
      method: "POST",
      body: JSON.stringify(data)
    }),
    onSuccess: () => {
      toast({ title: "Exercise logged successfully!" });
      queryClient.invalidateQueries({ queryKey: ["/api/exercise-logs"] });
    }
  });

  const createGoalMutation = useMutation({
    mutationFn: (data: any) => apiRequest("/api/fitness-goals", {
      method: "POST",
      body: JSON.stringify(data)
    }),
    onSuccess: () => {
      toast({ title: "Fitness goal created!" });
      queryClient.invalidateQueries({ queryKey: ["/api/fitness-goals"] });
    }
  });

  const startWorkout = (workout: TodaysWorkout) => {
    setSelectedWorkout(workout);
    setWorkoutInProgress(true);
    setCurrentExerciseIndex(0);
    setCurrentSet(1);
    setTimer(0);
    toast({ title: `Starting ${workout.name}!`, description: "Let's get moving!" });
  };

  const completeExercise = () => {
    if (!selectedWorkout) return;
    
    const exercise = selectedWorkout.exercises[currentExerciseIndex];
    
    // Log the exercise
    logExerciseMutation.mutate({
      exerciseId: null,
      workoutId: null,
      sets: currentSet,
      reps: exercise.reps || null,
      duration: exercise.duration || null,
      difficulty: "moderate",
      completed: true,
      notes: `${selectedWorkout.name} - ${exercise.name}`
    });

    // Move to next exercise or complete workout
    if (currentExerciseIndex < selectedWorkout.exercises.length - 1) {
      setCurrentExerciseIndex(currentExerciseIndex + 1);
      setCurrentSet(1);
    } else {
      completeWorkout();
    }
  };

  const completeWorkout = () => {
    setWorkoutInProgress(false);
    setSelectedWorkout(null);
    toast({ 
      title: "Workout Complete!", 
      description: "Great job! Your progress has been saved." 
    });
  };

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case "beginner": return "bg-green-100 text-green-800";
      case "intermediate": return "bg-yellow-100 text-yellow-800";
      case "advanced": return "bg-red-100 text-red-800";
      default: return "bg-gray-100 text-gray-800";
    }
  };

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case "cardio": return Activity;
      case "strength": return Dumbbell;
      case "flexibility": return Target;
      default: return Activity;
    }
  };

  return (
    <div className="container mx-auto px-4 py-8 max-w-6xl">
      <div className="mb-8">
        <h1 className="text-3xl font-bold mb-2 flex items-center gap-3">
          <Activity className="w-8 h-8 text-blue-600" />
          Exercise Tracker
        </h1>
        <p className="text-gray-600">
          Track your daily workouts, set fitness goals, and monitor your progress
        </p>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="today" className="flex items-center gap-2">
            <Calendar className="w-4 h-4" />
            Today's Workouts
          </TabsTrigger>
          <TabsTrigger value="logs" className="flex items-center gap-2">
            <Timer className="w-4 h-4" />
            Exercise Logs
          </TabsTrigger>
          <TabsTrigger value="goals" className="flex items-center gap-2">
            <Target className="w-4 h-4" />
            Fitness Goals
          </TabsTrigger>
          <TabsTrigger value="progress" className="flex items-center gap-2">
            <TrendingUp className="w-4 h-4" />
            Progress
          </TabsTrigger>
        </TabsList>

        <TabsContent value="today" className="space-y-6">
          {workoutInProgress && selectedWorkout ? (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center justify-between">
                  <span>{selectedWorkout.name} - In Progress</span>
                  <Button onClick={completeWorkout} variant="outline">
                    End Workout
                  </Button>
                </CardTitle>
                <CardDescription>
                  Exercise {currentExerciseIndex + 1} of {selectedWorkout.exercises.length}
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <Progress 
                    value={(currentExerciseIndex / selectedWorkout.exercises.length) * 100} 
                    className="w-full"
                  />
                  
                  {selectedWorkout.exercises[currentExerciseIndex] && (
                    <div className="bg-blue-50 p-6 rounded-lg">
                      <h3 className="text-xl font-semibold mb-3">
                        {selectedWorkout.exercises[currentExerciseIndex].name}
                      </h3>
                      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-4">
                        <div>
                          <Label className="text-sm font-medium">Sets</Label>
                          <p className="text-lg">{selectedWorkout.exercises[currentExerciseIndex].sets}</p>
                        </div>
                        {selectedWorkout.exercises[currentExerciseIndex].reps && (
                          <div>
                            <Label className="text-sm font-medium">Reps</Label>
                            <p className="text-lg">{selectedWorkout.exercises[currentExerciseIndex].reps}</p>
                          </div>
                        )}
                        {selectedWorkout.exercises[currentExerciseIndex].duration && (
                          <div>
                            <Label className="text-sm font-medium">Duration</Label>
                            <p className="text-lg">{selectedWorkout.exercises[currentExerciseIndex].duration}s</p>
                          </div>
                        )}
                        <div>
                          <Label className="text-sm font-medium">Rest</Label>
                          <p className="text-lg">{selectedWorkout.exercises[currentExerciseIndex].restTime}s</p>
                        </div>
                      </div>
                      <div className="flex gap-3">
                        <Button onClick={completeExercise} className="flex-1">
                          Complete Exercise
                        </Button>
                        <Button 
                          onClick={() => setCurrentSet(currentSet + 1)} 
                          variant="outline"
                          disabled={currentSet >= selectedWorkout.exercises[currentExerciseIndex].sets}
                        >
                          Next Set ({currentSet}/{selectedWorkout.exercises[currentExerciseIndex].sets})
                        </Button>
                      </div>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {todaysWorkouts.map((workout) => {
                const IconComponent = getCategoryIcon(workout.category);
                return (
                  <Card key={workout.id} className="hover:shadow-lg transition-shadow">
                    <CardHeader>
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-3">
                          <IconComponent className="w-6 h-6 text-blue-600" />
                          <div>
                            <CardTitle className="text-lg">{workout.name}</CardTitle>
                            <CardDescription>
                              {workout.estimatedDuration} minutes • {workout.exercises.length} exercises
                            </CardDescription>
                          </div>
                        </div>
                        <Badge className={getDifficultyColor(workout.difficulty)}>
                          {workout.difficulty}
                        </Badge>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-3">
                        <div className="text-sm text-gray-600">
                          <strong>Exercises:</strong>
                        </div>
                        <div className="grid grid-cols-1 gap-2">
                          {workout.exercises.slice(0, 3).map((exercise, index) => (
                            <div key={index} className="flex justify-between text-sm">
                              <span>{exercise.name}</span>
                              <span className="text-gray-500">
                                {exercise.reps ? `${exercise.sets} × ${exercise.reps}` : 
                                 exercise.duration ? `${exercise.sets} × ${exercise.duration}s` : 
                                 `${exercise.sets} sets`}
                              </span>
                            </div>
                          ))}
                          {workout.exercises.length > 3 && (
                            <div className="text-sm text-gray-500">
                              +{workout.exercises.length - 3} more exercises
                            </div>
                          )}
                        </div>
                        <Button 
                          onClick={() => startWorkout(workout)} 
                          className="w-full mt-4"
                          disabled={workoutInProgress}
                        >
                          Start Workout
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          )}
        </TabsContent>

        <TabsContent value="logs" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Recent Exercise Logs</CardTitle>
              <CardDescription>
                Track your completed exercises and monitor your progress over time
              </CardDescription>
            </CardHeader>
            <CardContent>
              {exerciseLogs.length === 0 ? (
                <div className="text-center py-8 text-gray-500">
                  <Activity className="w-12 h-12 mx-auto mb-4 opacity-50" />
                  <p>No exercise logs yet. Complete a workout to see your progress here!</p>
                </div>
              ) : (
                <div className="space-y-4">
                  {exerciseLogs.map((log: ExerciseLog) => (
                    <div key={log.id} className="border rounded-lg p-4">
                      <div className="flex justify-between items-start">
                        <div>
                          <h3 className="font-semibold">{log.notes || "Exercise Session"}</h3>
                          <p className="text-sm text-gray-600">
                            {new Date(log.date).toLocaleDateString()} • 
                            {log.sets} sets • 
                            {log.duration ? `${log.duration}s` : `${log.reps} reps`}
                          </p>
                        </div>
                        <Badge variant="outline" className={getDifficultyColor(log.difficulty || "moderate")}>
                          {log.difficulty || "moderate"}
                        </Badge>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="goals" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Fitness Goals</CardTitle>
              <CardDescription>
                Set and track your fitness objectives
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                {fitnessGoals.map((goal: FitnessGoal) => (
                  <div key={goal.id} className="border rounded-lg p-4">
                    <div className="flex justify-between items-start mb-3">
                      <div>
                        <h3 className="font-semibold">{goal.title}</h3>
                        <p className="text-sm text-gray-600">{goal.description}</p>
                      </div>
                      <Badge variant={goal.achieved ? "default" : "secondary"}>
                        {goal.achieved ? "Achieved" : "Active"}
                      </Badge>
                    </div>
                    <div className="space-y-2">
                      <div className="flex justify-between text-sm">
                        <span>Progress</span>
                        <span>{goal.currentValue}/{goal.targetValue} {goal.unit}</span>
                      </div>
                      <Progress 
                        value={goal.targetValue ? (goal.currentValue / goal.targetValue) * 100 : 0} 
                        className="w-full"
                      />
                    </div>
                  </div>
                ))}
                
                {fitnessGoals.length === 0 && (
                  <div className="text-center py-8 text-gray-500">
                    <Target className="w-12 h-12 mx-auto mb-4 opacity-50" />
                    <p>No fitness goals set yet. Create your first goal to get started!</p>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="progress" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">This Week</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold text-blue-600">
                  {exerciseLogs.filter((log: ExerciseLog) => {
                    const logDate = new Date(log.date);
                    const weekAgo = new Date();
                    weekAgo.setDate(weekAgo.getDate() - 7);
                    return logDate >= weekAgo;
                  }).length}
                </div>
                <p className="text-sm text-gray-600">Workouts completed</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Total Sessions</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold text-green-600">
                  {exerciseLogs.length}
                </div>
                <p className="text-sm text-gray-600">All time</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Active Goals</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold text-purple-600">
                  {fitnessGoals.filter((goal: FitnessGoal) => goal.isActive && !goal.achieved).length}
                </div>
                <p className="text-sm text-gray-600">In progress</p>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}