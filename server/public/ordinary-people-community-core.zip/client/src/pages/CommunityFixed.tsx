import React, { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/useAuth";
import { useTutorial } from "@/hooks/useTutorial";
import { PageHeader } from "@/components/PageHeader";
import { TutorialPopup } from "@/components/TutorialPopup";
import { SupportBanner } from "@/components/SupportBanner";
import { AdCarousel } from "@/components/AdCarousel";
import { AdvertisingButton } from "@/components/AdvertisingButton";

import { useLocation, Link } from "wouter";
import { PageHelpSystem } from "@/components/PageHelpSystem";
import { Heart, MessageCircle, Share2, Upload, X, Plus, Grid, List, Trash2 } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { User, BlogPost } from "@shared/schema";
import SocialActions from "@/components/SocialActions";

export default function CommunityFixed() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const { appUser, loading } = useAuth();
  const [isCreating, setIsCreating] = useState(false);
  const [selectedImage, setSelectedImage] = useState<File | null>(null);
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [location] = useLocation();
  const { shouldShowTutorial, getTutorialSteps, markTutorialComplete } = useTutorial();

  const [formData, setFormData] = useState({
    title: "",
    content: "",
    category: "General",
    tags: "",
    isPublic: true
  });

  const COMMUNITY_CATEGORIES = [
    "General Discussion",
    "Government & Policy", 
    "Local Council Issues",
    "Environmental Concerns",
    "5G & EMF Concerns",
    "Wi-Fi Health Effects",
    "Alternative Medicine",
    "Supplement Discussion",
    "Personal Experiences",
    "Daily Life Issues",
    "Technology & Society",
    "Community Support"
  ];

  const { data: posts = [], isLoading, error } = useQuery<BlogPost[]>({
    queryKey: ["/api/blog/posts"],
    retry: 3,
    staleTime: 30000,
  });

  // Filter posts for community categories only
  const communityPosts = posts.filter(post => 
    COMMUNITY_CATEGORIES.includes(post.category)
  );

  const createPostMutation = useMutation({
    mutationFn: async (data: any) => {
      return apiRequest("POST", "/api/blog/posts", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/blog/posts"] });
      toast({ title: "Community post created successfully!" });
      resetForm();
    },
    onError: () => {
      toast({ title: "Failed to create community post", variant: "destructive" });
    }
  });

  const deletePostMutation = useMutation({
    mutationFn: async (postId: number) => {
      return apiRequest("DELETE", `/api/blog/posts/${postId}`, {});
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/blog/posts"] });
      toast({ title: "Post deleted successfully" });
    },
    onError: () => {
      toast({ title: "Failed to delete post", variant: "destructive" });
    }
  });

  const deletePost = (postId: number) => {
    if (!confirm('Are you sure you want to delete this post? This action cannot be undone.')) {
      return;
    }
    deletePostMutation.mutate(postId);
  };

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (!file.type.startsWith('image/')) {
        toast({
          title: "Invalid File Type",
          description: "Please select an image file",
          variant: "destructive"
        });
        return;
      }

      if (file.size > 5 * 1024 * 1024) {
        toast({
          title: "File Too Large",
          description: "Please select an image smaller than 5MB",
          variant: "destructive"
        });
        return;
      }

      setSelectedImage(file);
      const reader = new FileReader();
      reader.onload = (e) => setImagePreview(e.target?.result as string);
      reader.readAsDataURL(file);
    }
  };

  const resetForm = () => {
    setFormData({
      title: "",
      content: "",
      category: "General Discussion",
      tags: "",
      isPublic: true
    });
    setSelectedImage(null);
    setImagePreview(null);
    setIsCreating(false);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.title.trim() || !formData.content.trim()) {
      toast({
        title: "Missing Information",
        description: "Please fill in both title and content",
        variant: "destructive"
      });
      return;
    }

    let imageData = null;
    if (selectedImage) {
      try {
        const reader = new FileReader();
        imageData = await new Promise((resolve) => {
          reader.onload = () => resolve(reader.result);
          reader.readAsDataURL(selectedImage);
        });
      } catch (error) {
        toast({
          title: "Image Upload Failed",
          description: "Could not process image",
          variant: "destructive"
        });
        return;
      }
    }

    const postData = {
      ...formData,
      imageData,
      tags: formData.tags.split(',').map(tag => tag.trim()).filter(Boolean)
    };

    createPostMutation.mutate(postData);
  };

  if (loading) return <div>Loading...</div>;
  if (!appUser) return <div>Please log in to access community discussions.</div>;

  const tutorialSteps = getTutorialSteps('community');

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="bg-white shadow-sm border-b border-gray-200 mb-6">
        <div className="container mx-auto px-4 py-6">
          <div className="flex items-center justify-between mb-4">
            <a 
              href="/"
              className="flex items-center px-4 py-2 bg-gray-600 hover:bg-gray-700 text-white rounded-lg transition-colors"
            >
              <span className="mr-2">←</span>
              Back to Dashboard
            </a>
          </div>
          <h1 className="text-3xl font-bold text-gray-800 mb-2">Community Blog</h1>
          <p className="text-gray-600">Join discussions on government, daily life, and topics away from elite control</p>
        </div>
      </div>
      
      <SupportBanner />
      <AdCarousel scope="local" position="left" />
      <AdvertisingButton />
      
      <div className="container mx-auto px-4 py-6 max-w-4xl">
        
        {/* Create New Post */}
        <Card className="mb-6">
          <CardHeader>
            <CardTitle className="flex items-center justify-between">
              <span>Share Your Thoughts</span>
              <Button
                onClick={() => setIsCreating(!isCreating)}
                variant={isCreating ? "outline" : "default"}
                size="sm"
              >
                {isCreating ? <X className="w-4 h-4 mr-2" /> : <Plus className="w-4 h-4 mr-2" />}
                {isCreating ? "Cancel" : "New Post"}
              </Button>
            </CardTitle>
          </CardHeader>
          
          {isCreating && (
            <CardContent>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="title">Post Title</Label>
                    <Input
                      id="title"
                      value={formData.title}
                      onChange={(e) => setFormData({...formData, title: e.target.value})}
                      placeholder="What's on your mind?"
                    />
                  </div>
                  
                  <div>
                    <Label htmlFor="category">Category</Label>
                    <Select value={formData.category} onValueChange={(value) => setFormData({...formData, category: value})}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select category" />
                      </SelectTrigger>
                      <SelectContent>
                        {COMMUNITY_CATEGORIES.map((category) => (
                          <SelectItem key={category} value={category}>
                            {category}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div>
                  <Label htmlFor="content">Your Message</Label>
                  <Textarea
                    id="content"
                    value={formData.content}
                    onChange={(e) => setFormData({...formData, content: e.target.value})}
                    placeholder="Share your thoughts, experiences, or ask questions..."
                    rows={4}
                  />
                </div>

                <div>
                  <Label htmlFor="tags">Tags (optional)</Label>
                  <Input
                    id="tags"
                    value={formData.tags}
                    onChange={(e) => setFormData({...formData, tags: e.target.value})}
                    placeholder="Add tags separated by commas"
                  />
                </div>

                <div>
                  <Label htmlFor="image">Add Image (optional)</Label>
                  <Input
                    id="image"
                    type="file"
                    accept="image/*"
                    onChange={handleImageChange}
                    className="cursor-pointer"
                  />
                  {imagePreview && (
                    <div className="mt-2 relative">
                      <img src={imagePreview} alt="Preview" className="max-w-xs max-h-48 rounded-lg" />
                      <Button
                        type="button"
                        variant="destructive"
                        size="sm"
                        className="absolute top-2 right-2"
                        onClick={() => {
                          setSelectedImage(null);
                          setImagePreview(null);
                        }}
                      >
                        <X className="w-4 h-4" />
                      </Button>
                    </div>
                  )}
                </div>

                <Button 
                  type="submit" 
                  disabled={createPostMutation.isPending}
                  className="w-full"
                >
                  {createPostMutation.isPending ? "Posting..." : "Share Post"}
                </Button>
              </form>
            </CardContent>
          )}
        </Card>

        {/* Community Posts */}
        <div className="space-y-6">
          {isLoading ? (
            <div className="text-center py-8">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto mb-4"></div>
              Loading community discussions...
            </div>
          ) : error ? (
            <Card>
              <CardContent className="text-center py-8">
                <h3 className="text-lg font-semibold mb-2 text-red-600">Unable to load discussions</h3>
                <p className="text-gray-600 mb-4">There was an issue loading community posts. Please try refreshing the page.</p>
                <Button onClick={() => window.location.reload()}>
                  Refresh Page
                </Button>
              </CardContent>
            </Card>
          ) : communityPosts.length === 0 ? (
            <Card>
              <CardContent className="text-center py-8">
                <h3 className="text-lg font-semibold mb-2">No discussions yet</h3>
                <p className="text-gray-600 mb-4">Be the first to start a community discussion!</p>
                <Button onClick={() => setIsCreating(true)}>
                  <Plus className="w-4 h-4 mr-2" />
                  Create First Post
                </Button>
              </CardContent>
            </Card>
          ) : (
            communityPosts.map((post) => (
              <Card key={post.id} className="hover:shadow-md transition-shadow">
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <CardTitle className="text-xl mb-2">{post.title}</CardTitle>
                      <div className="flex items-center gap-3 text-sm text-gray-600 mb-3">
                        <span>By User {post.userId}</span>
                        <span>•</span>
                        <Badge variant="secondary">{post.category}</Badge>
                        <span>•</span>
                        <span>{new Date(post.createdAt).toLocaleDateString()}</span>
                      </div>
                    </div>
                    {/* Delete button for user's own posts */}
                    {appUser && post.userId === appUser.id && (
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => deletePost(post.id)}
                        className="text-red-600 hover:text-red-700 hover:bg-red-50"
                        title="Delete Post"
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    )}
                  </div>
                </CardHeader>
                
                <CardContent>
                  {post.imageUrl && (
                    <img 
                      src={post.imageUrl} 
                      alt="Post image" 
                      className="w-full max-h-64 object-cover rounded-lg mb-4"
                    />
                  )}
                  
                  <div className="prose max-w-none mb-4">
                    <p className="text-gray-700 whitespace-pre-wrap">{post.content}</p>
                  </div>

                  {post.tags && post.tags.length > 0 && (
                    <div className="flex flex-wrap gap-2 mb-4">
                      {post.tags.map((tag, index) => (
                        <Badge key={index} variant="outline" className="text-xs">
                          #{tag}
                        </Badge>
                      ))}
                    </div>
                  )}

                  <div className="flex items-center gap-4 pt-3 border-t">
                    <button className="flex items-center gap-2 text-gray-600 hover:text-blue-600">
                      <Heart className="w-4 h-4" />
                      <span>{post.likes || 0}</span>
                    </button>
                    <button className="flex items-center gap-2 text-gray-600 hover:text-blue-600">
                      <MessageCircle className="w-4 h-4" />
                      <span>Comment</span>
                    </button>
                    <button className="flex items-center gap-2 text-gray-600 hover:text-blue-600">
                      <Share2 className="w-4 h-4" />
                      <span>Share</span>
                    </button>
                  </div>
                </CardContent>
              </Card>
            ))
          )}
        </div>
      </div>

      <PageHelpSystem currentPage="community" />
      
      {shouldShowTutorial('community') && (
        <TutorialPopup
          page="community"
          steps={tutorialSteps}
          onComplete={() => markTutorialComplete('community')}
          onSkip={() => markTutorialComplete('community')}
        />
      )}
    </div>
  );
}