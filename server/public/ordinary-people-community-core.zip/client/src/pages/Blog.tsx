import React, { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/useAuth";
import { useTutorial } from "@/hooks/useTutorial";
import { PageHeader } from "@/components/PageHeader";
import { TutorialPopup } from "@/components/TutorialPopup";
import { SupportBanner } from "@/components/SupportBanner";
import { AdCarousel } from "@/components/AdCarousel";
import { AdvertisingButton } from "@/components/AdvertisingButton";
import { PageHelpSystem } from "@/components/PageHelpSystem";
import { useLocation, Link } from "wouter";
import { Heart, MessageCircle, Share2, Upload, X, Plus, Grid, List, Trash2 } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { User, BlogPost } from "@shared/schema";
import SocialActions from "@/components/SocialActions";
import { UniversalBackButton } from "@/components/UniversalBackButton";

export default function Blog() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const { appUser, loading } = useAuth();
  const [isCreating, setIsCreating] = useState(false);
  const [selectedImage, setSelectedImage] = useState<File | null>(null);
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [location] = useLocation();
  const { shouldShowTutorial, getTutorialSteps, markTutorialComplete } = useTutorial();

  const [formData, setFormData] = useState({
    title: "",
    content: "",
    category: "General",
    tags: "",
    isPublic: true
  });

  const BLOG_CATEGORIES = [
    "Health/Wellness Tips",
    "Supplement Reviews", 
    "Mental Health/Wellness",
    "Nutrition & Diet",
    "Exercise & Fitness",
    "Personal Stories",
    "Medical News",
    "Alternative Medicine",
    "Sleep & Recovery",
    "Chronic Illness Support"
  ];

  const { data: posts = [], isLoading } = useQuery<BlogPost[]>({
    queryKey: ["/api/blog/posts"],
  });

  const createPostMutation = useMutation({
    mutationFn: async (data: any) => {
      return apiRequest("POST", "/api/blog/posts", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/blog/posts"] });
      toast({ title: "Blog post created successfully!" });
      resetForm();
    },
    onError: () => {
      toast({ title: "Failed to create blog post", variant: "destructive" });
    }
  });

  const deletePostMutation = useMutation({
    mutationFn: async (postId: number) => {
      return apiRequest("DELETE", `/api/blog/posts/${postId}`, {});
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/blog/posts"] });
      toast({ title: "Blog post deleted successfully" });
    },
    onError: () => {
      toast({ title: "Failed to delete blog post", variant: "destructive" });
    }
  });

  const deletePost = (postId: number) => {
    if (!confirm('Are you sure you want to delete this blog post? This action cannot be undone.')) {
      return;
    }
    deletePostMutation.mutate(postId);
  };

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (!file.type.startsWith('image/')) {
        toast({
          title: "Invalid File Type",
          description: "Please select an image file",
          variant: "destructive",
        });
        return;
      }

      if (file.size > 5 * 1024 * 1024) {
        toast({
          title: "File Too Large",
          description: "Please select an image smaller than 5MB",
          variant: "destructive",
        });
        return;
      }

      setSelectedImage(file);
      const reader = new FileReader();
      reader.onload = (e) => {
        setImagePreview(e.target?.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const removeImage = () => {
    setSelectedImage(null);
    setImagePreview(null);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    try {
      let imageUrl = "";
      
      if (selectedImage) {
        const reader = new FileReader();
        imageUrl = await new Promise<string>((resolve, reject) => {
          reader.onload = () => resolve(reader.result as string);
          reader.onerror = reject;
          reader.readAsDataURL(selectedImage);
        });
      }

      const postData = {
        title: formData.title,
        content: formData.content,
        imageUrl,
        tags: formData.tags.split(',').map(t => t.trim()).filter(Boolean),
        isPublic: formData.isPublic
      };

      createPostMutation.mutate(postData);
    } catch (error) {
      toast({
        title: "Error Processing Image",
        description: "Failed to process the uploaded image",
        variant: "destructive",
      });
    }
  };

  const resetForm = () => {
    setFormData({
      title: "",
      content: "",
      category: "General",
      tags: "",
      isPublic: true
    });
    setSelectedImage(null);
    setImagePreview(null);
    setIsCreating(false);
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    });
  };

  if (!appUser) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-xl font-semibold text-gray-900 mb-2">Please Sign In</h2>
          <p className="text-gray-600 mb-4">Join our health community to share your journey</p>
          <a href="/login" className="text-primary hover:text-primary/80">
            Go to login page
          </a>
        </div>
      </div>
    );
  }

  return (
    <div className="mobile-safe w-full max-w-[65vw] mx-auto space-y-4 sm:space-y-6 px-2 sm:px-4 py-4 overflow-x-hidden">
      
      {/* Universal Navigation */}
      <UniversalBackButton />
      
      {/* Advertising Button - Top of Page */}
      <AdvertisingButton />
      <div className="flex justify-between items-start">
        <PageHeader 
          title="Health Community" 
          subtitle="Share your wellness journey and connect with others"
        />
        <Button onClick={() => setIsCreating(true)} className="flex items-center gap-2">
          <Plus className="w-4 h-4" />
          Create Post
        </Button>
      </div>

      {/* Blog Categories */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Grid className="w-5 h-5" />
            Explore Categories
          </CardTitle>
          <CardDescription>
            Browse health/wellness topics or click a category to view dedicated posts
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-3">
            {BLOG_CATEGORIES.map((category) => (
              <Link key={category} href={`/blog/category/${encodeURIComponent(category)}`}>
                <Button variant="outline" className="w-full text-xs h-auto py-3 px-2">
                  <div className="text-center">
                    <div className="font-medium line-clamp-2">{category}</div>
                  </div>
                </Button>
              </Link>
            ))}
          </div>
        </CardContent>
      </Card>

      {isCreating && (
        <Card>
          <CardHeader>
            <CardTitle>Create a New Post</CardTitle>
            <CardDescription>
              Share your health journey, tips, or experiences with the community
            </CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <Label htmlFor="title">Post Title</Label>
                <Input
                  id="title"
                  value={formData.title}
                  onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                  placeholder="e.g., My 30-day supplement journey results"
                  required
                />
              </div>

              <div>
                <Label htmlFor="category">Category</Label>
                <select
                  id="category"
                  value={formData.category}
                  onChange={(e) => setFormData({ ...formData, category: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary"
                  required
                >
                  {BLOG_CATEGORIES.map((category) => (
                    <option key={category} value={category}>
                      {category}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <Label htmlFor="content">Content</Label>
                <Textarea
                  id="content"
                  value={formData.content}
                  onChange={(e) => setFormData({ ...formData, content: e.target.value })}
                  placeholder="Share your story, tips, or experiences..."
                  rows={6}
                  required
                />
              </div>

              <div>
                <Label>Post Image</Label>
                <div className="space-y-4">
                  <div className="flex items-center gap-4">
                    <input
                      type="file"
                      id="imageUpload"
                      accept="image/*"
                      onChange={handleImageChange}
                      className="hidden"
                    />
                    <label
                      htmlFor="imageUpload"
                      className="flex items-center gap-2 px-4 py-2 bg-primary text-white rounded-md cursor-pointer hover:bg-primary/90 transition-colors"
                    >
                      <Upload className="w-4 h-4" />
                      Add Image
                    </label>
                    <span className="text-sm text-muted-foreground">
                      Optional (max 5MB)
                    </span>
                  </div>

                  {imagePreview && (
                    <div className="relative w-full max-w-md">
                      <img
                        src={imagePreview}
                        alt="Preview"
                        className="w-full h-48 object-cover rounded-lg border"
                      />
                      <Button
                        type="button"
                        variant="destructive"
                        size="sm"
                        className="absolute top-2 right-2"
                        onClick={removeImage}
                      >
                        <X className="w-4 h-4" />
                      </Button>
                    </div>
                  )}
                </div>
              </div>

              <div>
                <Label htmlFor="tags">Tags (comma-separated)</Label>
                <Input
                  id="tags"
                  value={formData.tags}
                  onChange={(e) => setFormData({ ...formData, tags: e.target.value })}
                  placeholder="nutrition, fitness, supplements, wellness"
                />
              </div>

              <div className="flex justify-between items-center">
                <label className="flex items-center space-x-2">
                  <input
                    type="checkbox"
                    checked={formData.isPublic}
                    onChange={(e) => setFormData({ ...formData, isPublic: e.target.checked })}
                    className="rounded"
                  />
                  <span className="text-sm">Make this post public</span>
                </label>

                <div className="flex gap-2">
                  <Button type="button" variant="outline" onClick={resetForm}>
                    Cancel
                  </Button>
                  <Button type="submit" disabled={createPostMutation.isPending}>
                    {createPostMutation.isPending ? "Publishing..." : "Publish Post"}
                  </Button>
                </div>
              </div>
            </form>
          </CardContent>
        </Card>
      )}

      {/* Advertisement Carousels */}
      <div className="relative">
        {/* Left carousel - Local ads */}
        <div className="fixed left-0 top-1/2 transform -translate-y-1/2 z-20 hidden lg:block">
          <AdCarousel 
            location="Nottingham" 
            scope="local" 
            position="left"
          />
        </div>

        {/* Right carousel - National ads */}
        <div className="fixed right-0 top-1/2 transform -translate-y-1/2 z-20 hidden lg:block">
          <AdCarousel 
            scope="national" 
            position="right"
          />
        </div>
      </div>

      {/* Support Banner */}
      <SupportBanner />

      <div className="space-y-6">
        <h3 className="text-lg font-semibold">Community Posts</h3>
        
        {isLoading ? (
          <div className="grid gap-6">
            {[...Array(3)].map((_, i) => (
              <Card key={i} className="animate-pulse">
                <CardHeader>
                  <div className="h-4 bg-muted rounded w-3/4"></div>
                  <div className="h-3 bg-muted rounded w-1/2"></div>
                </CardHeader>
                <CardContent>
                  <div className="h-32 bg-muted rounded"></div>
                </CardContent>
              </Card>
            ))}
          </div>
        ) : posts.length === 0 ? (
          <Card>
            <CardContent className="text-center py-8">
              <p className="text-muted-foreground">No posts yet. Be the first to share your health journey!</p>
            </CardContent>
          </Card>
        ) : (
          <div className="grid gap-6">
            {posts.map((post) => (
              <Card key={post.id} className="overflow-hidden">
                <CardHeader>
                  <div className="flex justify-between items-start">
                    <div>
                      <CardTitle className="text-lg">{post.title}</CardTitle>
                      <CardDescription>
                        Posted on {formatDate(post.createdAt.toString())}
                      </CardDescription>
                    </div>
                    <div className="flex items-center gap-2">
                      {post.tags?.map((tag) => (
                        <Badge key={tag} variant="secondary" className="text-xs">
                          {tag}
                        </Badge>
                      ))}
                      {/* Delete button for user's own posts */}
                      {appUser && post.userId === appUser.id && (
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => deletePost(post.id)}
                          className="text-red-600 hover:text-red-700 hover:bg-red-50"
                          title="Delete Post"
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      )}
                    </div>
                  </div>
                </CardHeader>
                
                {post.imageUrl && (
                  <div className="px-6">
                    <img
                      src={post.imageUrl}
                      alt={post.title}
                      className="w-full h-64 object-cover rounded-lg"
                    />
                  </div>
                )}
                
                <CardContent className="pt-4">
                  <p className="text-gray-700 whitespace-pre-wrap">{post.content}</p>
                  
                  <SocialActions
                    itemId={post.id}
                    itemType="blog"
                    initialLikes={post.likes || 0}
                    initialComments={0}
                    isLiked={false}
                    showComments={true}
                  />
                </CardContent>
              </Card>
            ))}
          </div>
        )}

      {/* Tutorial popup for first-time visitors */}
      {shouldShowTutorial(location) && (
        <TutorialPopup
          page={location}
          steps={getTutorialSteps(location)}
          onComplete={() => markTutorialComplete(location)}
          onSkip={() => markTutorialComplete(location)}
        />
      )}
      </div>
    </div>
  );
}