import { useEffect } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Heart, CheckCircle, Home } from "lucide-react";
import { useLocation } from "wouter";

export default function DonateSuccess() {
  const [, setLocation] = useLocation();

  useEffect(() => {
    // Auto-redirect to dashboard after 10 seconds
    const timer = setTimeout(() => {
      setLocation("/");
    }, 10000);

    return () => clearTimeout(timer);
  }, [setLocation]);

  return (
    <div className="min-h-screen bg-gradient-to-br from-pink-50 to-purple-50 flex items-center justify-center p-4">
      <Card className="w-full max-w-lg text-center">
        <CardContent className="py-12">
          <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-6">
            <CheckCircle className="w-12 h-12 text-green-600" />
          </div>
          
          <h1 className="text-3xl font-bold text-gray-900 mb-4">Thank You!</h1>
          
          <div className="space-y-4 mb-8">
            <p className="text-lg text-gray-700">
              Your £1 donation has been successfully processed.
            </p>
            <p className="text-gray-600">
              Your support helps keep GoHealMe running as a free platform for our 
              health/wellness community. Every contribution makes a difference!
            </p>
          </div>

          <div className="flex items-center justify-center gap-2 mb-8 text-pink-600">
            <Heart className="w-5 h-5 fill-current" />
            <span className="font-semibold">Ordinary People Community</span>
            <Heart className="w-5 h-5 fill-current" />
          </div>

          <Button 
            onClick={() => setLocation("/")}
            className="w-full bg-gradient-to-r from-pink-500 to-purple-500 hover:opacity-90"
          >
            <Home className="w-4 h-4 mr-2" />
            Return to Dashboard
          </Button>

          <p className="text-sm text-gray-500 mt-4">
            Redirecting automatically in 10 seconds...
          </p>
        </CardContent>
      </Card>
    </div>
  );
}