import React, { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { ArrowLeft, Heart, MessageCircle, Send, Plus, Share2, Users } from "lucide-react";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";

export default function GalleryFixed() {
  const [location, setLocation] = useLocation();
  const { appUser } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const [selectedAlbum, setSelectedAlbum] = useState<string | null>(null);
  const [showCreateAlbum, setShowCreateAlbum] = useState(false);
  const [newAlbumName, setNewAlbumName] = useState("");
  const [newComment, setNewComment] = useState<{[key: string]: string}>({});

  // Albums state with localStorage persistence
  const [albums, setAlbums] = useState(() => {
    const saved = localStorage.getItem('gallery-albums');
    return saved ? JSON.parse(saved) : [
      { id: 'holiday', name: 'Holiday Photos', photoCount: 2 },
      { id: 'family', name: 'Family Memories', photoCount: 1 }
    ];
  });

  // Album photos state with localStorage persistence
  const [albumPhotosState, setAlbumPhotosState] = useState(() => {
    const saved = localStorage.getItem('gallery-photos');
    return saved ? JSON.parse(saved) : {};
  });

  // Save albums to localStorage
  useEffect(() => {
    localStorage.setItem('gallery-albums', JSON.stringify(albums));
  }, [albums]);

  // Save photos to localStorage
  useEffect(() => {
    localStorage.setItem('gallery-photos', JSON.stringify(albumPhotosState));
  }, [albumPhotosState]);

  // Photo comments state
  const [photoComments, setPhotoComments] = useState<{[key: string]: any[]}>({
    h1: [
      { id: 1, text: "Beautiful sunset! Where was this taken?", userName: "Sarah Johnson", createdAt: "2 hours ago" },
      { id: 2, text: "Amazing colors in the sky!", userName: "Mike Davis", createdAt: "1 hour ago" }
    ],
    h2: [
      { id: 3, text: "Love this hiking trail!", userName: "Emma Wilson", createdAt: "3 hours ago" }
    ],
    f1: [
      { id: 4, text: "Such a lovely family moment", userName: "Lisa Brown", createdAt: "4 hours ago" }
    ]
  });

  // Clear old photos if storage is full
  const clearOldPhotos = () => {
    try {
      localStorage.removeItem('gallery-photos');
      localStorage.removeItem('gallery-albums');
      setAlbumPhotosState({});
      toast({
        title: "Storage Cleared",
        description: "Old photos removed to make space for new uploads.",
      });
      return true;
    } catch (e) {
      return false;
    }
  };

  // Check localStorage space before storing
  const checkStorageQuota = (data: string) => {
    try {
      const testKey = 'storage-test';
      localStorage.setItem(testKey, data);
      localStorage.removeItem(testKey);
      return true;
    } catch (e) {
      // Try clearing old photos and test again
      clearOldPhotos();
      try {
        localStorage.setItem('gallery_test_key', data);
        localStorage.removeItem('gallery_test_key');
        return true;
      } catch (e2) {
        return false;
      }
    }
  };

  // Convert files to base64 and store with size limits
  const handleFileUpload = async (files: FileList, albumId: string) => {
    console.log(`Starting upload for ${files.length} files to album ${albumId}`);
    const newPhotos: any[] = [];
    
    for (let i = 0; i < files.length; i++) {
      const file = files[i];
      console.log(`Processing file ${i + 1}: ${file.name}, size: ${file.size} bytes`);
      
      // Limit file size to 10MB for better user experience
      if (file.size > 10 * 1024 * 1024) {
        console.log(`File ${file.name} too large: ${file.size} bytes`);
        toast({
          title: "File Too Large",
          description: `${file.name} exceeds 10MB limit. Please use a smaller image.`,
          variant: "destructive"
        });
        continue;
      }
      
      const reader = new FileReader();
      
      await new Promise((resolve) => {
        reader.onload = (e) => {
          const result = e.target?.result as string;
          console.log(`File ${file.name} converted to base64, length: ${result.length}`);
          
          // Check if we can store this data
          if (!checkStorageQuota(result)) {
            console.log(`Storage quota check failed for ${file.name}`);
            toast({
              title: "Storage Full",
              description: "Browser storage is full. Please remove some photos to add new ones.",
              variant: "destructive"
            });
            resolve(null);
            return;
          }
          
          const photoId = `${albumId}_${Date.now()}_${i}`;
          const newPhoto = {
            id: photoId,
            url: result,
            caption: file.name.replace(/\.[^/.]+$/, ""),
            uploadedAt: new Date().toISOString()
          };
          console.log(`Created photo object for ${file.name}:`, photoId);
          newPhotos.push(newPhoto);
          resolve(null);
        };
        
        reader.onerror = (error) => {
          console.error(`Failed to read file ${file.name}:`, error);
          resolve(null);
        };
        reader.readAsDataURL(file);
      });
    }

    console.log(`Upload complete. Total photos processed: ${newPhotos.length}`);
    
    // Only proceed if we have photos to add
    if (newPhotos.length === 0) {
      console.log("No photos to add - showing error message");
      toast({
        title: "No Photos Added",
        description: "No photos were uploaded. Please check file sizes and storage space.",
        variant: "destructive"
      });
      return;
    }

    // Update album photos state with error handling
    try {
      const updatedPhotos = [...(albumPhotosState[albumId]?.photos || []), ...newPhotos];
      const updatedAlbumData = {
        name: albums.find((a: any) => a.id === albumId)?.name || 'Unknown Album',
        photos: updatedPhotos
      };
      
      setAlbumPhotosState((prev: any) => ({
        ...prev,
        [albumId]: updatedAlbumData
      }));

      // Store in localStorage with error handling
      try {
        localStorage.setItem('gallery-photos', JSON.stringify({
          ...albumPhotosState,
          [albumId]: updatedAlbumData
        }));
      } catch (storageError) {
        console.error('Failed to save to localStorage:', storageError);
        toast({
          title: "Storage Warning",
          description: "Photos uploaded but may not persist after page refresh.",
          variant: "destructive"
        });
      }

      // Update album photo count
      setTimeout(() => {
        setAlbums((prev: any) => prev.map((album: any) => 
          album.id === albumId 
            ? { ...album, photoCount: updatedPhotos.length }
            : album
        ));
      }, 100);

      toast({
        title: "Photos Uploaded Successfully",
        description: `Added ${newPhotos.length} photo(s) to the album!`
      });
    } catch (error) {
      console.error('Upload error:', error);
      toast({
        title: "Upload Failed",
        description: "Failed to upload photos. Please try again.",
        variant: "destructive"
      });
    }
  };

  // Get album photos from state or fallback to demo data
  const getAlbumPhotos = (albumId: string) => {
    // Check if we have user-uploaded photos for this album
    if (albumPhotosState[albumId]?.photos?.length > 0) {
      return albumPhotosState[albumId];
    }
    
    // Fallback to demo data for default albums
    const demoData: {[key: string]: any} = {
      holiday: {
        name: "Holiday Photos",
        photos: [
          {
            id: "h1",
            url: "https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=800&h=600&fit=crop",
            caption: "Amazing sunset at the beach"
          },
          {
            id: "h2", 
            url: "https://images.unsplash.com/photo-1469474968028-56623f02e42e?w=800&h=600&fit=crop",
            caption: "Mountain hiking adventure"
          }
        ]
      },
      family: {
        name: "Family Memories",
        photos: [
          {
            id: "f1",
            url: "https://images.unsplash.com/photo-1511895426328-dc8714191300?w=800&h=600&fit=crop",
            caption: "Family dinner celebration"
          }
        ]
      }
    };
    
    return demoData[albumId] || { 
      name: albums.find((a: any) => a.id === albumId)?.name || 'Unknown Album', 
      photos: [] 
    };
  };

  // Share to wall function
  const shareToWall = useMutation({
    mutationFn: async (data: { content: string; mediaUrl: string }) => {
      const response = await fetch('/api/profile-wall-posts', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userId: appUser?.id,
          authorId: appUser?.id,
          content: data.content,
          mediaUrl: data.mediaUrl,
          postType: 'image'
        })
      });
      if (!response.ok) throw new Error('Failed to share to wall');
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/profile-wall-posts'] });
      toast({ title: "Posted to your Profile Wall!" });
    }
  });

  const handleShare = (photo: { id: string; url: string; caption: string }, type: string) => {
    const content = `${type}: ${photo.caption}`;
    shareToWall.mutate({ content, mediaUrl: photo.url });
  };

  const handleAddComment = (photoId: string) => {
    const comment = newComment[photoId];
    if (!comment?.trim()) return;
    
    const newCommentObj = {
      id: Date.now(),
      text: comment,
      userName: appUser?.name || 'User',
      createdAt: 'Just now'
    };
    
    setPhotoComments((prev: any) => ({
      ...prev,
      [photoId]: [...(prev[photoId] || []), newCommentObj]
    }));
    
    setNewComment((prev: any) => ({ ...prev, [photoId]: '' }));
    
    // Hide the comment dropdown after posting
    const commentSection = document.getElementById(`comments-${photoId}`);
    if (commentSection) {
      commentSection.style.display = 'none';
    }
    
    toast({ title: "Comment added!" });
  };

  const handleCreateAlbum = () => {
    if (!newAlbumName.trim()) return;
    
    const newAlbum = {
      id: Date.now().toString(),
      name: newAlbumName,
      photoCount: 0
    };
    
    setAlbums((prev: any) => [...prev, newAlbum]);
    setNewAlbumName("");
    setShowCreateAlbum(false);
    
    toast({
      title: "Album Created",
      description: `"${newAlbum.name}" has been created successfully!`
    });
  };

  // Album view
  if (selectedAlbum) {
    const currentAlbum = getAlbumPhotos(selectedAlbum);
    const dynamicAlbum = albums.find((a: any) => a.id === selectedAlbum);
    
    return (
      <div className="min-h-screen bg-gray-50 p-4">
        <div className="max-w-2xl mx-auto">
          <div className="flex items-center gap-4 mb-6">
            <Button 
              variant="ghost" 
              onClick={() => setSelectedAlbum(null)}
              className="flex items-center gap-2"
            >
              <ArrowLeft className="w-4 h-4" />
              Back
            </Button>
            <h1 className="text-2xl font-bold">
              {currentAlbum?.name || dynamicAlbum?.name || 'Album'}
            </h1>
          </div>

          {/* Add Photos Button for existing albums */}
          {currentAlbum?.photos?.length > 0 && (
            <div className="flex justify-center mb-4">
              <Button
                onClick={() => {
                  const input = document.createElement('input');
                  input.type = 'file';
                  input.accept = 'image/*';
                  input.multiple = true;
                  input.onchange = async (e) => {
                    const files = (e.target as HTMLInputElement).files;
                    if (files && files.length > 0 && selectedAlbum) {
                      await handleFileUpload(files, selectedAlbum);
                    }
                  };
                  input.click();
                }}
                className="bg-green-600 hover:bg-green-700 text-white px-4 py-2"
                size="sm"
              >
                + Add More Photos
              </Button>
            </div>
          )}

          <div className="space-y-6 max-w-sm mx-auto px-2">
            {currentAlbum?.photos?.length > 0 ? 
              currentAlbum.photos.map((photo: any) => (
                <Card key={photo.id} className="bg-white w-full">
                <CardContent className="p-3">
                  <div className="flex items-center gap-3 mb-4">
                    <div className="w-10 h-10 bg-blue-600 rounded-full flex items-center justify-center text-white font-medium">
                      {appUser?.name?.charAt(0) || 'U'}
                    </div>
                    <div>
                      <h4 className="font-medium">{appUser?.name || 'User'}</h4>
                      <p className="text-sm text-gray-500">Just now</p>
                    </div>
                  </div>

                  <p className="mb-4 text-gray-800">{photo.caption}</p>

                  <div className="mb-4">
                    <img 
                      src={photo.url}
                      alt={photo.caption}
                      className="w-full max-w-lg rounded-lg"
                    />
                  </div>

                  <div className="flex items-center gap-4 text-sm text-gray-500 mb-4">
                    <span>❤️ 0 likes</span>
                    <span>💬 {photoComments[photo.id]?.length || 0} comments</span>
                  </div>

                  {/* Clear Action Buttons - Same as Profile Wall */}
                  <div className="border-t pt-4 space-y-3">
                    <div className="flex items-center justify-between gap-2">
                      <Button 
                        variant="outline" 
                        size="sm" 
                        className="flex items-center gap-2 flex-1 bg-blue-50 hover:bg-blue-100 border-blue-200"
                        onClick={() => toast({ title: "Liked!", description: "Photo liked successfully" })}
                      >
                        <Heart className="h-4 w-4 text-blue-600" />
                        <span className="text-sm font-medium text-blue-600">Like</span>
                      </Button>
                      <Button 
                        variant="outline" 
                        size="sm" 
                        className="flex items-center gap-2 flex-1 bg-green-50 hover:bg-green-100 border-green-200"
                        onClick={() => {
                          const shareDialog = document.getElementById(`share-dialog-${photo.id}`);
                          if (shareDialog) {
                            shareDialog.style.display = shareDialog.style.display === 'none' ? 'block' : 'none';
                            if (shareDialog.style.display === 'block') {
                              shareDialog.scrollIntoView({ behavior: 'smooth' });
                            }
                          }
                        }}
                      >
                        <Share2 className="h-4 w-4 text-green-600" />
                        <span className="text-sm font-medium text-green-600">Share</span>
                      </Button>
                      <Button 
                        variant="outline" 
                        size="sm" 
                        className="flex items-center gap-2 flex-1 bg-purple-50 hover:bg-purple-100 border-purple-200"
                        onClick={() => {
                          const commentSection = document.getElementById(`comments-${photo.id}`);
                          if (commentSection) {
                            commentSection.style.display = commentSection.style.display === 'none' ? 'block' : 'none';
                            if (commentSection.style.display === 'block') {
                              commentSection.scrollIntoView({ behavior: 'smooth' });
                            }
                          }
                        }}
                      >
                        <MessageCircle className="h-4 w-4 text-purple-600" />
                        <span className="text-sm font-medium text-purple-600">Make Comment</span>
                      </Button>
                    </div>

                    {/* Share Dialog - Hidden by default, same as Profile Wall */}
                    <div id={`share-dialog-${photo.id}`} style={{ display: 'none' }} className="mt-4 bg-green-50 rounded-lg p-4 border-2 border-green-200">
                      <h4 className="font-medium text-green-800 mb-3">Share this photo</h4>
                      <div className="space-y-3">
                        <div className="grid grid-cols-2 gap-2">
                          <button 
                            className="flex items-center gap-2 p-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
                            onClick={() => {
                              window.open(`https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(window.location.href)}`, '_blank');
                              toast({ title: "Shared", description: "Opening Facebook share" });
                            }}
                          >
                            <span className="text-sm font-medium">Facebook</span>
                          </button>
                          <button 
                            className="flex items-center gap-2 p-3 bg-sky-500 text-white rounded-lg hover:bg-sky-600 transition-colors"
                            onClick={() => {
                              window.open(`https://twitter.com/intent/tweet?url=${encodeURIComponent(window.location.href)}&text=Check out this photo!`, '_blank');
                              toast({ title: "Shared", description: "Opening Twitter share" });
                            }}
                          >
                            <span className="text-sm font-medium">Twitter</span>
                          </button>
                          <button 
                            className="flex items-center gap-2 p-3 bg-blue-700 text-white rounded-lg hover:bg-blue-800 transition-colors"
                            onClick={() => {
                              window.open(`https://www.linkedin.com/sharing/share-offsite/?url=${encodeURIComponent(window.location.href)}`, '_blank');
                              toast({ title: "Shared", description: "Opening LinkedIn share" });
                            }}
                          >
                            <span className="text-sm font-medium">LinkedIn</span>
                          </button>
                          <button 
                            className="flex items-center gap-2 p-3 bg-green-500 text-white rounded-lg hover:bg-green-600 transition-colors"
                            onClick={() => {
                              window.open(`https://wa.me/?text=Check out this photo! ${encodeURIComponent(window.location.href)}`, '_blank');
                              toast({ title: "Shared", description: "Opening WhatsApp share" });
                            }}
                          >
                            <span className="text-sm font-medium">WhatsApp</span>
                          </button>
                        </div>
                        <div className="border-t pt-3">
                          <button 
                            className="w-full p-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 transition-colors text-sm"
                            onClick={() => {
                              navigator.clipboard.writeText(window.location.href);
                              toast({ title: "Copied!", description: "Photo link copied to clipboard" });
                            }}
                          >
                            Copy Link
                          </button>
                        </div>
                      </div>
                    </div>

                    {/* Comments Section - Standardized Format */}
                    <div className="space-y-3">
                      {photoComments[photo.id]?.map((comment: any) => (
                        <div key={comment.id} className="bg-white border rounded-lg p-3 shadow-sm">
                          <div className="flex items-start gap-3">
                            <div className="w-8 h-8 bg-blue-600 rounded-full flex items-center justify-center text-white text-sm font-medium">
                              {comment.userName.charAt(0)}
                            </div>
                            <div className="flex-1">
                              <div className="flex items-center gap-2 mb-2">
                                <span className="font-semibold text-sm text-gray-900">{comment.userName}</span>
                                <span className="text-xs text-gray-500">{comment.createdAt}</span>
                              </div>
                              <p className="text-sm text-gray-800 mb-3">{comment.text}</p>
                              
                              {/* Comment Action Buttons - Same as Profile Wall */}
                              <div className="flex items-center gap-4">
                                <button 
                                  className="flex items-center gap-1 text-xs text-gray-500 hover:text-blue-600 transition-colors"
                                  onClick={() => toast({ title: "Like added", description: "Comment liked successfully" })}
                                >
                                  <Heart className="h-3 w-3" />
                                  <span>Like</span>
                                </button>
                                <button 
                                  className="flex items-center gap-1 text-xs text-gray-500 hover:text-green-600 transition-colors"
                                  onClick={() => toast({ title: "Reply", description: "Reply feature coming soon" })}
                                >
                                  <MessageCircle className="h-3 w-3" />
                                  <span>Reply</span>
                                </button>
                                <button 
                                  className="flex items-center gap-1 text-xs text-gray-500 hover:text-purple-600 transition-colors"
                                  onClick={() => {
                                    navigator.clipboard.writeText(`${comment.userName}: ${comment.text}`);
                                    toast({ title: "Shared", description: "Comment copied to clipboard" });
                                  }}
                                >
                                  <Share2 className="h-3 w-3" />
                                  <span>Share</span>
                                </button>
                                <button 
                                  className="flex items-center gap-1 text-xs text-gray-500 hover:text-orange-600 transition-colors"
                                  onClick={() => toast({ title: "Multi-Share", description: "Sharing to all connected platforms" })}
                                >
                                  <Users className="h-3 w-3" />
                                  <span>Multi-Share</span>
                                </button>
                              </div>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>

                    {/* Dropdown Comment Box - Hidden by default, same as Profile Wall */}
                    <div id={`comments-${photo.id}`} style={{ display: 'none' }} className="mt-4 bg-gray-50 rounded-lg p-4 border-2 border-purple-200">
                      <div className="flex gap-3 items-start">
                        <div className="w-10 h-10 bg-blue-600 rounded-full flex items-center justify-center text-white text-sm font-bold">
                          {appUser?.name?.charAt(0) || 'U'}
                        </div>
                        <div className="flex-1">
                          <div className="bg-white rounded-lg border-2 border-gray-200 p-3 mb-2">
                            <Input
                              placeholder="What's on your mind about this photo?"
                              value={newComment[photo.id] || ''}
                              onChange={(e) => setNewComment((prev: any) => ({ ...prev, [photo.id]: e.target.value }))}
                              onKeyPress={(e) => {
                                if (e.key === 'Enter' && newComment[photo.id]?.trim()) {
                                  handleAddComment(photo.id);
                                }
                              }}
                              className="border-0 p-0 h-auto resize-none focus-visible:ring-0 text-sm"
                            />
                          </div>
                          {/* Destination Selection - Same as Profile Wall */}
                          <div className="mb-3">
                            <label className="text-xs font-medium text-gray-700 mb-2 block">Share to:</label>
                            <select 
                              className="w-full p-2 border border-gray-300 rounded text-xs bg-white"
                              defaultValue="gallery"
                            >
                              <option value="gallery">Gallery Comments</option>
                              <option value="profile-wall">My Profile Wall</option>
                              <option value="community">Community Discussion</option>
                              <option value="health">Health Discussion</option>
                              <option value="general">General Discussion</option>
                            </select>
                          </div>

                          {/* Multi-Share Options - Same as Profile Wall */}
                          <div className="mb-3">
                            <label className="text-xs font-medium text-gray-700 mb-2 block">Multi-Share Options:</label>
                            <div className="flex flex-wrap gap-2">
                              <button className="px-2 py-1 bg-blue-100 text-blue-800 text-xs rounded hover:bg-blue-200">
                                Facebook
                              </button>
                              <button className="px-2 py-1 bg-sky-100 text-sky-800 text-xs rounded hover:bg-sky-200">
                                Twitter
                              </button>
                              <button className="px-2 py-1 bg-pink-100 text-pink-800 text-xs rounded hover:bg-pink-200">
                                Instagram
                              </button>
                              <button className="px-2 py-1 bg-blue-100 text-blue-800 text-xs rounded hover:bg-blue-200">
                                LinkedIn
                              </button>
                              <button className="px-2 py-1 bg-green-100 text-green-800 text-xs rounded hover:bg-green-200">
                                WhatsApp
                              </button>
                              <button className="px-2 py-1 bg-purple-100 text-purple-800 text-xs rounded hover:bg-purple-200">
                                All Platforms
                              </button>
                            </div>
                          </div>

                          <div className="flex items-center justify-between">
                            <div className="flex items-center gap-2">
                              <Button 
                                size="sm"
                                onClick={() => handleAddComment(photo.id)}
                                disabled={!newComment[photo.id]?.trim()}
                                className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-1 text-xs font-medium"
                              >
                                Post Comment
                              </Button>
                              <Button 
                                variant="ghost" 
                                size="sm"
                                onClick={() => setNewComment((prev: any) => ({ ...prev, [photo.id]: '' }))}
                                className="text-gray-500 hover:text-gray-700 px-4 py-1 text-xs"
                              >
                                Clear
                              </Button>
                            </div>
                            <span className="text-xs text-gray-400">
                              Press Enter to post
                            </span>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>
                </Card>
              ))
            : (
              <div className="text-center py-8">
                <p className="text-gray-500">This album is empty.</p>
                <p className="text-sm text-gray-400 mt-2">Add photos to get started!</p>
                <div className="mt-6">
                  <Button
                    onClick={() => {
                      const input = document.createElement('input');
                      input.type = 'file';
                      input.accept = 'image/*';
                      input.multiple = true;
                      input.onchange = async (e) => {
                        const files = (e.target as HTMLInputElement).files;
                        if (files && files.length > 0 && selectedAlbum) {
                          await handleFileUpload(files, selectedAlbum);
                        }
                      };
                      input.click();
                    }}
                    className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-2"
                  >
                    Add Photos
                  </Button>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    );
  }

  // Main gallery list
  return (
    <div className="min-h-screen bg-gray-50 p-4">
      <div className="max-w-2xl mx-auto">
        <div className="flex flex-col gap-4 mb-6 md:flex-row md:items-center md:justify-between">
          <div className="flex items-center gap-4">
            <Button 
              variant="ghost" 
              onClick={() => setLocation('/profile-wall/4')}
              className="flex items-center gap-2"
            >
              <ArrowLeft className="w-4 h-4" />
              Back
            </Button>
            <h1 className="text-3xl font-bold text-gray-800">Photo Albums</h1>
          </div>
          <div className="flex gap-2">
            <Button 
              variant="ghost" 
              onClick={() => setLocation('/dashboard')}
              className="flex items-center gap-2 px-3 py-2"
            >
              Dashboard
            </Button>
            <Button 
              onClick={() => setShowCreateAlbum(true)}
              className="bg-green-600 hover:bg-green-700 text-white text-xs px-3 py-2"
            >
              New Album
            </Button>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {albums.map((album: any) => (
            <Card key={album.id} className="cursor-pointer hover:shadow-md">
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="text-lg font-semibold mb-1">{album.name}</h3>
                    <p className="text-sm text-gray-500">{album.photoCount} photos</p>
                  </div>
                  <Button 
                    onClick={() => setSelectedAlbum(album.id)}
                    className="bg-blue-600 hover:bg-blue-700"
                  >
                    Open
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Create Album Dialog */}
        <Dialog open={showCreateAlbum} onOpenChange={setShowCreateAlbum}>
          <DialogContent className="sm:max-w-md">
            <DialogHeader>
              <DialogTitle>Create New Album</DialogTitle>
            </DialogHeader>
            <div className="space-y-4 pt-4">
              <div>
                <Label htmlFor="albumName">Album Name</Label>
                <Input
                  id="albumName"
                  value={newAlbumName}
                  onChange={(e) => setNewAlbumName(e.target.value)}
                  placeholder="Enter album name..."
                  className="mt-1"
                />
              </div>
              <div className="flex gap-2 pt-4">
                <Button 
                  variant="outline" 
                  onClick={() => setShowCreateAlbum(false)}
                  className="flex-1"
                >
                  Cancel
                </Button>
                <Button 
                  onClick={handleCreateAlbum}
                  disabled={!newAlbumName.trim()}
                  className="flex-1 bg-blue-600 hover:bg-blue-700"
                >
                  Create Album
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>
    </div>
  );
}