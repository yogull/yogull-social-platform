import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/useAuth";
import { Plus, Edit, Save, X, ExternalLink, Shield, Brain, Heart, Zap } from "lucide-react";
import { PageHeader } from "@/components/PageHeader";

interface IllnessGuide {
  id: string;
  title: string;  
  description: string;
  category: string;
  severity: 'mild' | 'moderate' | 'severe';
  prevalence: string;
  symptoms: string[];
  treatments: string[];
  supportInfo: string;
  icon: string;
  color: string;
}

const initialIllnesses: IllnessGuide[] = [
  {
    id: "brain-injury",
    title: "Traumatic Brain Injury (TBI)",
    description: "Understanding brain injuries, symptoms, recovery strategies, and how to support those affected.",
    category: "Neurological",
    severity: "severe",
    prevalence: "2.8 million cases annually in US",
    symptoms: ["Memory problems", "Headaches", "Confusion", "Mood changes", "Sleep issues"],
    treatments: ["Cognitive therapy", "Physical therapy", "Occupational therapy", "Speech therapy"],
    supportInfo: "TBI recovery requires patience and comprehensive support. Connect with local brain injury support groups.",
    icon: "Brain",
    color: "red"
  },
  {
    id: "dementia",
    title: "Dementia & Alzheimer's",
    description: "Comprehensive guide to dementia types, early signs, care strategies, and family support resources.",
    category: "Neurological",
    severity: "severe",
    prevalence: "55 million people worldwide",
    symptoms: ["Memory loss", "Confusion", "Language problems", "Behavioral changes", "Difficulty with daily tasks"],
    treatments: ["Medication management", "Cognitive stimulation", "Social engagement", "Structured routines"],
    supportInfo: "Early diagnosis and family support are crucial. Consider joining Alzheimer's support networks.",
    icon: "Brain",
    color: "purple"
  },
  {
    id: "diabetes-type-1",
    title: "Diabetes Type 1",
    description: "Managing Type 1 diabetes, insulin therapy, blood sugar monitoring, and lifestyle adjustments.",
    category: "Endocrine",
    severity: "severe",
    prevalence: "1.6 million Americans",
    symptoms: ["Frequent urination", "Excessive thirst", "Unexplained weight loss", "Fatigue", "Blurred vision"],
    treatments: ["Insulin therapy", "Blood glucose monitoring", "Carbohydrate counting", "Regular exercise"],
    supportInfo: "Requires lifelong insulin management. Join diabetes support groups and work with endocrinologists.",
    icon: "Heart",
    color: "blue"
  },
  {
    id: "diabetes-type-2",
    title: "Diabetes Type 2",
    description: "Understanding Type 2 diabetes, blood sugar control, diet management, and preventing complications.",
    category: "Endocrine",
    severity: "moderate",
    prevalence: "37 million Americans",
    symptoms: ["Increased thirst", "Frequent urination", "Fatigue", "Slow healing wounds", "Tingling in hands/feet"],
    treatments: ["Lifestyle changes", "Medication", "Diet modification", "Regular monitoring", "Exercise"],
    supportInfo: "Often manageable through diet and lifestyle. Early intervention prevents complications.",
    icon: "Heart",
    color: "green"
  },
  {
    id: "skin-rashes",
    title: "Skin Rashes (General)",
    description: "Identifying and treating various skin rashes, causes, symptoms, and when to seek medical help.",
    category: "Dermatological",
    severity: "mild",
    prevalence: "Very common - affects most people",
    symptoms: ["Redness", "Itching", "Bumps or blisters", "Scaling", "Burning sensation"],
    treatments: ["Topical creams", "Antihistamines", "Avoiding triggers", "Cool compresses", "Moisturizing"],
    supportInfo: "Most rashes are temporary. See a dermatologist for persistent or severe rashes.",
    icon: "Heart",
    color: "pink"
  },
  {
    id: "eczema",
    title: "Eczema (Atopic Dermatitis)",
    description: "Managing eczema symptoms, identifying triggers, skincare routines, and treatment options.",
    category: "Dermatological",
    severity: "moderate",
    prevalence: "31 million Americans",
    symptoms: ["Dry itchy skin", "Redness", "Scaling", "Cracking", "Weeping or crusting"],
    treatments: ["Moisturizing", "Topical corticosteroids", "Avoiding triggers", "Cool baths", "Prescription medications"],
    supportInfo: "Chronic condition requiring consistent skincare routine. Identify and avoid personal triggers.",
    icon: "Heart",
    color: "orange"
  },
  {
    id: "psoriasis",
    title: "Psoriasis",
    description: "Understanding psoriasis, managing flare-ups, treatment options, and living with chronic skin condition.",
    category: "Dermatological",
    severity: "moderate",
    prevalence: "8 million Americans",
    symptoms: ["Thick red patches", "Silvery scales", "Itching", "Burning", "Joint pain"],
    treatments: ["Topical treatments", "Light therapy", "Systemic medications", "Biologics", "Moisturizing"],
    supportInfo: "Autoimmune condition with various treatment options. Work with dermatologist for management plan.",
    icon: "Heart",
    color: "red"
  },
  {
    id: "emf-sensitivity",
    title: "EMF Sensitivity",
    description: "Understanding electromagnetic field sensitivity, symptoms, and practical protection strategies.",
    category: "Environmental",
    severity: "moderate", 
    prevalence: "3-5% of population reports symptoms",
    symptoms: ["Headaches", "Fatigue", "Sleep disruption", "Skin irritation", "Concentration issues"],
    treatments: ["EMF reduction", "Shielding devices", "Lifestyle changes", "Grounding techniques"],
    supportInfo: "Reduce exposure by creating EMF-free zones in your home and limiting device usage.",
    icon: "Zap",
    color: "yellow"
  },
  {
    id: "chronic-fatigue",
    title: "Chronic Fatigue Syndrome",
    description: "Managing chronic fatigue, energy conservation, and improving quality of life.",
    category: "Autoimmune",
    severity: "moderate",
    prevalence: "1-2.5 million Americans",
    symptoms: ["Extreme fatigue", "Brain fog", "Muscle pain", "Sleep problems", "Post-exertional malaise"],
    treatments: ["Pacing strategies", "Sleep hygiene", "Gentle exercise", "Stress management"],
    supportInfo: "Focus on energy management and avoid overexertion. Work with CFS specialists.",
    icon: "Heart",
    color: "orange"
  },
  {
    id: "depression",
    title: "Depression",
    description: "Understanding depression, treatment options, coping strategies, and support resources.",
    category: "Mental Health",
    severity: "moderate",
    prevalence: "21 million American adults",
    symptoms: ["Persistent sadness", "Loss of interest", "Fatigue", "Sleep changes", "Difficulty concentrating"],
    treatments: ["Therapy", "Medication", "Lifestyle changes", "Support groups", "Exercise"],
    supportInfo: "Depression is treatable. Reach out for professional help and maintain social connections.",
    icon: "Brain",
    color: "blue"
  },
  {
    id: "anxiety",
    title: "Anxiety Disorders",
    description: "Managing anxiety, panic attacks, coping techniques, and treatment approaches.",
    category: "Mental Health",
    severity: "moderate",
    prevalence: "40 million American adults",
    symptoms: ["Excessive worry", "Restlessness", "Rapid heartbeat", "Sweating", "Difficulty sleeping"],
    treatments: ["Cognitive therapy", "Medication", "Relaxation techniques", "Lifestyle modifications", "Mindfulness"],
    supportInfo: "Anxiety is highly treatable. Practice breathing exercises and seek professional support.",
    icon: "Brain",
    color: "purple"
  },
  {
    id: "arthritis",
    title: "Arthritis",
    description: "Understanding arthritis types, joint pain management, and maintaining mobility.",
    category: "Musculoskeletal",
    severity: "moderate",
    prevalence: "58 million Americans",
    symptoms: ["Joint pain", "Stiffness", "Swelling", "Reduced range of motion", "Fatigue"],
    treatments: ["Anti-inflammatory medications", "Physical therapy", "Exercise", "Heat/cold therapy", "Weight management"],
    supportInfo: "Stay active with gentle exercises. Work with rheumatologist for comprehensive care.",
    icon: "Heart",
    color: "red"
  },
  {
    id: "ibs",
    title: "Irritable Bowel Syndrome (IBS)",
    description: "Managing IBS symptoms, dietary modifications, stress management, and treatment options.",
    category: "Digestive",
    severity: "moderate",
    prevalence: "25-45 million Americans",
    symptoms: ["Abdominal pain", "Bloating", "Diarrhea or constipation", "Gas", "Mucus in stool"],
    treatments: ["Dietary changes", "Stress management", "Probiotics", "Medications", "Fiber supplements"],
    supportInfo: "Identify trigger foods and manage stress. Work with gastroenterologist for treatment plan.",
    icon: "Heart",
    color: "green"
  }
];

export default function IllnessAdmin() {
  const { toast } = useToast();
  const [illnesses, setIllnesses] = useState<IllnessGuide[]>(initialIllnesses);
  const [editingIllness, setEditingIllness] = useState<IllnessGuide | null>(null);
  const [isAdding, setIsAdding] = useState(false);
  const { appUser, loading } = useAuth();

  const [formData, setFormData] = useState({
    title: "",
    description: "",
    category: "",
    severity: "moderate" as 'mild' | 'moderate' | 'severe',
    prevalence: "",
    symptoms: "",
    treatments: "",
    supportInfo: "",
    color: "blue"
  });

  const categories = ["Neurological", "Environmental", "Autoimmune", "Mental Health", "Digestive", "Cardiovascular", "Endocrine", "Dermatological", "Musculoskeletal"];
  const severityLevels = ["mild", "moderate", "severe"];
  const colors = ["red", "purple", "yellow", "orange", "blue", "green", "pink"];

  const startEdit = (illness: IllnessGuide) => {
    setEditingIllness(illness);
    setFormData({
      title: illness.title,
      description: illness.description,
      category: illness.category,
      severity: illness.severity,
      prevalence: illness.prevalence,
      symptoms: illness.symptoms.join(", "),
      treatments: illness.treatments.join(", "),
      supportInfo: illness.supportInfo,
      color: illness.color
    });
    setIsAdding(false);
  };

  const startAdd = () => {
    setIsAdding(true);
    setEditingIllness(null);
    setFormData({
      title: "",
      description: "",
      category: "",
      severity: "moderate",
      prevalence: "",
      symptoms: "",
      treatments: "",
      supportInfo: "",
      color: "blue"
    });
  };

  const handleSave = () => {
    if (!formData.title || !formData.description) {
      toast({
        title: "Missing Information",
        description: "Please fill in title and description",
        variant: "destructive"
      });
      return;
    }

    const illnessData: IllnessGuide = {
      id: editingIllness?.id || formData.title.toLowerCase().replace(/\s+/g, '-'),
      title: formData.title,
      description: formData.description,
      category: formData.category,
      severity: formData.severity,
      prevalence: formData.prevalence,
      symptoms: formData.symptoms.split(",").map(s => s.trim()).filter(s => s),
      treatments: formData.treatments.split(",").map(t => t.trim()).filter(t => t),
      supportInfo: formData.supportInfo,
      icon: formData.category === "Neurological" ? "Brain" : formData.category === "Environmental" ? "Zap" : "Heart",
      color: formData.color
    };

    if (editingIllness) {
      setIllnesses(prev => prev.map(illness => 
        illness.id === editingIllness.id ? illnessData : illness
      ));
      toast({
        title: "Updated Successfully",
        description: `${formData.title} has been updated`
      });
    } else {
      setIllnesses(prev => [...prev, illnessData]);
      toast({
        title: "Added Successfully", 
        description: `${formData.title} has been added`
      });
    }

    setEditingIllness(null);
    setIsAdding(false);
  };

  const handleCancel = () => {
    setEditingIllness(null);
    setIsAdding(false);
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full" />
      </div>
    );
  }

  if (!appUser?.isAdmin) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="w-16 h-16 bg-red-100 rounded-xl flex items-center justify-center mx-auto mb-4">
            <Shield className="w-8 h-8 text-red-600" />
          </div>
          <h2 className="text-xl font-semibold text-gray-900 mb-2">Admin Access Required</h2>
          <p className="text-gray-600 mb-4">You need administrator privileges to access this page</p>
          <a href="/" className="text-primary hover:text-primary/80">
            Return to dashboard
          </a>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-start">
        <PageHeader 
          title="Illness Guide Management" 
          subtitle="Update illness information, symptoms, and treatments"
        />
        <Button onClick={startAdd} className="flex items-center gap-2">
          <Plus className="w-4 h-4" />
          Add New Guide
        </Button>
      </div>

      {(isAdding || editingIllness) && (
        <Card>
          <CardHeader>
            <CardTitle>{editingIllness ? "Edit Illness Guide" : "Add New Illness Guide"}</CardTitle>
            <CardDescription>
              {editingIllness ? "Update illness information" : "Add a new illness guide"}
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="title">Illness Title</Label>
                  <Input
                    id="title"
                    value={formData.title}
                    onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                    placeholder="e.g., Chronic Fatigue Syndrome"
                  />
                </div>
                <div>
                  <Label htmlFor="category">Category</Label>
                  <Select value={formData.category} onValueChange={(value) => setFormData({ ...formData, category: value })}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select category" />
                    </SelectTrigger>
                    <SelectContent>
                      {categories.map((cat) => (
                        <SelectItem key={cat} value={cat}>{cat}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div>
                <Label htmlFor="description">Description</Label>
                <Textarea
                  id="description"
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  placeholder="Brief description of the illness and guide content"
                  rows={3}
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                  <Label htmlFor="severity">Severity</Label>
                  <Select value={formData.severity} onValueChange={(value) => setFormData({ ...formData, severity: value as 'mild' | 'moderate' | 'severe' })}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {severityLevels.map((level) => (
                        <SelectItem key={level} value={level}>{level}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="prevalence">Prevalence</Label>
                  <Input
                    id="prevalence"
                    value={formData.prevalence}
                    onChange={(e) => setFormData({ ...formData, prevalence: e.target.value })}
                    placeholder="e.g., 1-2% of population"
                  />
                </div>
                <div>
                  <Label htmlFor="color">Color Theme</Label>
                  <Select value={formData.color} onValueChange={(value) => setFormData({ ...formData, color: value })}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {colors.map((color) => (
                        <SelectItem key={color} value={color}>{color}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div>
                <Label htmlFor="symptoms">Symptoms (comma-separated)</Label>
                <Textarea
                  id="symptoms"
                  value={formData.symptoms}
                  onChange={(e) => setFormData({ ...formData, symptoms: e.target.value })}
                  placeholder="Memory problems, Headaches, Fatigue, etc."
                  rows={2}
                />
              </div>

              <div>
                <Label htmlFor="treatments">Treatments (comma-separated)</Label>
                <Textarea
                  id="treatments"
                  value={formData.treatments}
                  onChange={(e) => setFormData({ ...formData, treatments: e.target.value })}
                  placeholder="Physical therapy, Medication, Lifestyle changes, etc."
                  rows={2}
                />
              </div>

              <div>
                <Label htmlFor="supportInfo">Support Information</Label>
                <Textarea
                  id="supportInfo"
                  value={formData.supportInfo}
                  onChange={(e) => setFormData({ ...formData, supportInfo: e.target.value })}
                  placeholder="Support tips, resources, and guidance for patients and families"
                  rows={3}
                />
              </div>

              <div className="flex gap-2">
                <Button onClick={handleSave} className="flex items-center gap-2">
                  <Save className="w-4 h-4" />
                  {editingIllness ? "Update Guide" : "Add Guide"}
                </Button>
                <Button variant="outline" onClick={handleCancel} className="flex items-center gap-2">
                  <X className="w-4 h-4" />
                  Cancel
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      <div className="grid gap-4">
        {illnesses.map((illness) => (
          <Card key={illness.id}>
            <CardHeader>
              <div className="flex justify-between items-start">
                <div>
                  <CardTitle className="flex items-center gap-2">
                    {illness.icon === "Brain" && <Brain className="w-5 h-5" />}
                    {illness.icon === "Heart" && <Heart className="w-5 h-5" />}
                    {illness.icon === "Zap" && <Zap className="w-5 h-5" />}
                    {illness.title}
                  </CardTitle>
                  <CardDescription>{illness.description}</CardDescription>
                </div>
                <Button variant="outline" size="sm" onClick={() => startEdit(illness)}>
                  <Edit className="w-4 h-4" />
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div className="flex flex-wrap gap-2">
                  <Badge variant="secondary">{illness.category}</Badge>
                  <Badge variant={illness.severity === 'severe' ? 'destructive' : illness.severity === 'moderate' ? 'default' : 'secondary'}>
                    {illness.severity}
                  </Badge>
                  <Badge variant="outline">{illness.prevalence}</Badge>
                </div>
                
                <div>
                  <p className="font-medium text-sm mb-1">Symptoms:</p>
                  <p className="text-sm text-gray-600">{illness.symptoms.join(", ")}</p>
                </div>
                
                <div>
                  <p className="font-medium text-sm mb-1">Treatments:</p>
                  <p className="text-sm text-gray-600">{illness.treatments.join(", ")}</p>
                </div>
                
                <div>
                  <p className="font-medium text-sm mb-1">Support Info:</p>
                  <p className="text-sm text-gray-600">{illness.supportInfo}</p>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Quick Actions</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex gap-2">
            <Button 
              onClick={() => window.open('/illness-guides', '_blank')}
              className="flex items-center gap-2"
            >
              <ExternalLink className="w-4 h-4" />
              View Live Guides
            </Button>
            <Button 
              variant="outline"
              onClick={() => window.open('/contact', '_blank')}
              className="flex items-center gap-2"
            >
              Get Support
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}