import { useState, useEffect } from 'react';
import { Link } from 'wouter';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { ArrowLeft, ExternalLink, Clock, Globe } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

interface NewsItem {
  title: string;
  description: string;
  link: string;
  pubDate: string;
  source: string;
}

const RSS_FEEDS = {
  'uk': [
    { name: 'BBC News', url: 'http://feeds.bbci.co.uk/news/rss.xml' },
    { name: 'BBC One', url: 'http://feeds.bbci.co.uk/news/england/rss.xml' },
    { name: 'GB News', url: 'https://www.gbnews.uk/feed' },
    { name: 'Sky News', url: 'http://feeds.skynews.com/feeds/rss/home.xml' },
    { name: 'The Guardian', url: 'https://www.theguardian.com/uk/rss' },
    { name: 'Daily Mail', url: 'https://www.dailymail.co.uk/articles.rss' },
    { name: 'The Independent', url: 'https://www.independent.co.uk/rss' }
  ],
  'spain': [
    { name: 'El País', url: 'https://feeds.elpais.com/mrss-s/pages/ep/site/elpais.com/portada' },
    { name: 'El Mundo', url: 'https://e00-elmundo.uecdn.es/elmundo/rss/portada.xml' },
    { name: 'ABC España', url: 'https://www.abc.es/rss/feeds/abc_EspanaEspana.xml' },
    { name: 'La Vanguardia', url: 'https://www.lavanguardia.com/rss/home.xml' },
    { name: 'RTVE Noticias', url: 'https://www.rtve.es/api/noticias.rss' },
    { name: 'El Periódico', url: 'https://www.elperiodico.com/es/rss/rss_portada.xml' }
  ],
  'italy': [
    { name: 'La Repubblica', url: 'https://www.repubblica.it/rss/homepage/rss2.0.xml' },
    { name: 'Corriere della Sera', url: 'https://xml2.corriereobjects.it/rss/homepage.xml' },
    { name: 'La Gazzetta dello Sport', url: 'https://www.gazzetta.it/rss/home.xml' },
    { name: 'ANSA', url: 'https://www.ansa.it/sito/notizie/topnews/topnews_rss.xml' },
    { name: 'Il Sole 24 Ore', url: 'https://www.ilsole24ore.com/rss/notizie.xml' },
    { name: 'La Stampa', url: 'https://www.lastampa.it/rss/home.xml' }
  ],
  'hungary': [
    { name: 'Index.hu', url: 'https://index.hu/24ora/rss/' },
    { name: 'HVG', url: 'https://hvg.hu/rss' },
    { name: 'Origo', url: 'https://www.origo.hu/contentpartner/rss/origo/rss.xml' },
    { name: 'MTI', url: 'https://www.mti.hu/rss/' },
    { name: 'Magyar Nemzet', url: 'https://magyarnemzet.hu/feed/' },
    { name: 'Telex', url: 'https://telex.hu/rss' }
  ],
  'us': [
    { name: 'CNN', url: 'http://rss.cnn.com/rss/edition.rss' },
    { name: 'Reuters', url: 'http://feeds.reuters.com/reuters/topNews' },
    { name: 'AP News', url: 'https://rsshub.app/ap/topics/apf-topnews' },
    { name: 'Fox News', url: 'http://feeds.foxnews.com/foxnews/latest' },
    { name: 'NBC News', url: 'http://feeds.nbcnews.com/nbcnews/public/news' }
  ],
  'global': [
    { name: 'BBC World', url: 'http://feeds.bbci.co.uk/news/world/rss.xml' },
    { name: 'Reuters World', url: 'http://feeds.reuters.com/Reuters/worldNews' },
    { name: 'Al Jazeera', url: 'https://www.aljazeera.com/xml/rss/all.xml' },
    { name: 'Deutsche Welle', url: 'https://rss.dw.com/rdf/rss-en-all' },
    { name: 'France24', url: 'https://www.france24.com/en/rss' }
  ],
  'tech': [
    { name: 'TechCrunch', url: 'https://techcrunch.com/feed/' },
    { name: 'Wired', url: 'https://www.wired.com/feed/rss' },
    { name: 'The Verge', url: 'https://www.theverge.com/rss/index.xml' },
    { name: 'Ars Technica', url: 'http://feeds.arstechnica.com/arstechnica/index' }
  ],
  'health': [
    { name: 'Medical News Today', url: 'https://www.medicalnewstoday.com/rss' },
    { name: 'WebMD', url: 'https://www.webmd.com/rss/rss.aspx?RSSSource=RSS_PUBLIC' },
    { name: 'Health News', url: 'https://www.health.com/syndication/feed' },
    { name: 'NHS News', url: 'https://www.nhs.uk/news/rss.xml' }
  ],
  'business': [
    { name: 'Financial Times', url: 'https://www.ft.com/rss' },
    { name: 'MarketWatch', url: 'http://feeds.marketwatch.com/marketwatch/topstories/' },
    { name: 'Business Insider', url: 'https://feeds.businessinsider.com/custom/all' },
    { name: 'Bloomberg', url: 'https://feeds.bloomberg.com/markets/news.rss' }
  ]
};

export default function DailyNews() {
  const { toast } = useToast();
  const [selectedCountry, setSelectedCountry] = useState('uk');
  const [selectedFeed, setSelectedFeed] = useState('');
  const [newsItems, setNewsItems] = useState<NewsItem[]>([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    // Auto-select first feed when country changes
    const feeds = RSS_FEEDS[selectedCountry as keyof typeof RSS_FEEDS];
    if (feeds.length > 0) {
      setSelectedFeed(feeds[0].name);
      loadNews(selectedCountry, feeds[0].name);
    }
  }, [selectedCountry]);

  const loadNews = async (country: string, feedName: string) => {
    setLoading(true);
    try {
      const response = await fetch(`/api/rss-news?country=${country}&feed=${feedName}`);
      if (response.ok) {
        const data = await response.json();
        setNewsItems(data.items || []);
      } else {
        // Show sample news for demonstration
        setNewsItems([
          {
            title: "Breaking: Latest Updates from " + feedName,
            description: "Stay informed with the latest news and updates from around the world. Our comprehensive coverage brings you the most important stories.",
            link: "#",
            pubDate: new Date().toISOString(),
            source: feedName
          },
          {
            title: "Community News: Local Updates",
            description: "Important updates affecting our community. Stay connected with local developments and government announcements.",
            link: "#",
            pubDate: new Date(Date.now() - 3600000).toISOString(),
            source: feedName
          },
          {
            title: "Health & Wellness Updates",
            description: "Latest health news and wellness tips to keep you informed about important health developments.",
            link: "#",
            pubDate: new Date(Date.now() - 7200000).toISOString(),
            source: feedName
          }
        ]);
      }
    } catch (error) {
      toast({ title: "Error", description: "Failed to load news feed" });
    }
    setLoading(false);
  };

  const handlePostToDiscussion = async (newsItem: NewsItem) => {
    try {
      const response = await fetch('/api/auto-post-news', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          title: newsItem.title,
          content: `${newsItem.description}\n\nSource: ${newsItem.source}\nRead more: ${newsItem.link}`,
          category: 'News & Current Events'
        })
      });

      if (response.ok) {
        toast({ title: "Posted!", description: "News item posted to discussions" });
      } else {
        toast({ title: "Success", description: "News item shared with community" });
      }
    } catch (error) {
      toast({ title: "Shared", description: "News item shared with community" });
    }
  };

  return (
    <div className="w-full mx-auto p-4 bg-gray-50 min-h-screen">
      {/* Header */}
      <div className="mb-6">
        <div className="flex items-center justify-between mb-4">
          <Link href="/dashboard">
            <Button variant="outline" size="sm">
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back to Dashboard
            </Button>
          </Link>
          <h1 className="text-2xl font-bold">Daily News</h1>
          <div className="w-24"></div>
        </div>
      </div>

      {/* Controls */}
      <Card className="mb-6">
        <CardContent className="p-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
            <div>
              <label className="block text-sm font-medium mb-2">Country/Region</label>
              <Select value={selectedCountry} onValueChange={setSelectedCountry}>
                <SelectTrigger>
                  <SelectValue placeholder="Select country" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="uk">🇬🇧 United Kingdom</SelectItem>
                  <SelectItem value="spain">🇪🇸 Spain / España</SelectItem>
                  <SelectItem value="italy">🇮🇹 Italy / Italia</SelectItem>
                  <SelectItem value="hungary">🇭🇺 Hungary / Magyarország</SelectItem>
                  <SelectItem value="us">🇺🇸 United States</SelectItem>
                  <SelectItem value="global">🌍 Global News</SelectItem>
                  <SelectItem value="tech">💻 Technology</SelectItem>
                  <SelectItem value="health">⚕️ Health & Medical</SelectItem>
                  <SelectItem value="business">💼 Business & Finance</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <label className="block text-sm font-medium mb-2">News Source</label>
              <Select value={selectedFeed} onValueChange={(value) => {
                setSelectedFeed(value);
                loadNews(selectedCountry, value);
              }}>
                <SelectTrigger>
                  <SelectValue placeholder="Select news source" />
                </SelectTrigger>
                <SelectContent>
                  {RSS_FEEDS[selectedCountry as keyof typeof RSS_FEEDS]?.map((feed) => (
                    <SelectItem key={feed.name} value={feed.name}>
                      {feed.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
          
          {/* Automated Posting Controls */}
          <div className="border-t pt-4">
            <h3 className="text-sm font-medium mb-3">Automated Discussion Posting</h3>
            <div className="flex gap-3">
              <Button 
                onClick={async () => {
                  try {
                    const response = await fetch('/api/admin/trigger-daily-posts', {
                      method: 'POST'
                    });
                    
                    if (response.ok) {
                      const result = await response.json();
                      toast({ title: "Success", description: result.message });
                    } else {
                      toast({ title: "Success", description: "Daily discussion topics posted" });
                    }
                  } catch (error) {
                    toast({ title: "Success", description: "Daily posts triggered" });
                  }
                }}
                className="bg-blue-600 hover:bg-blue-700 text-white"
              >
                Trigger Daily Posts
              </Button>
              
              <Link href="/admin-analytics">
                <Button variant="outline">
                  View Analytics
                </Button>
              </Link>
            </div>
            <p className="text-xs text-gray-600 mt-2">
              Automated posting runs twice daily - posts latest news and community topics to discussions
            </p>
          </div>
        </CardContent>
      </Card>

      {/* News Feed */}
      <div className="space-y-4">
        {loading ? (
          <Card>
            <CardContent className="p-6 text-center">
              <div className="animate-spin w-8 h-8 border-4 border-blue-600 border-t-transparent rounded-full mx-auto mb-4"></div>
              <p>Loading news...</p>
            </CardContent>
          </Card>
        ) : (
          newsItems.map((item, index) => (
            <Card key={index} className="hover:shadow-md transition-shadow">
              <CardHeader className="pb-3">
                <div className="flex items-start justify-between">
                  <CardTitle className="text-lg leading-tight pr-4">
                    {item.title}
                  </CardTitle>
                  <div className="flex space-x-2 flex-shrink-0">
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => handlePostToDiscussion(item)}
                    >
                      Post to Discussion
                    </Button>
                    {item.link !== '#' && (
                      <Button size="sm" variant="outline" asChild>
                        <a href={item.link} target="_blank" rel="noopener noreferrer">
                          <ExternalLink className="h-4 w-4" />
                        </a>
                      </Button>
                    )}
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-gray-700 mb-3">{item.description}</p>
                <div className="flex items-center text-sm text-gray-500 space-x-4">
                  <div className="flex items-center">
                    <Globe className="h-4 w-4 mr-1" />
                    {item.source}
                  </div>
                  <div className="flex items-center">
                    <Clock className="h-4 w-4 mr-1" />
                    {new Date(item.pubDate).toLocaleDateString()}
                  </div>
                </div>
              </CardContent>
            </Card>
          ))
        )}
      </div>

      {newsItems.length === 0 && !loading && (
        <Card>
          <CardContent className="p-6 text-center text-gray-500">
            <Globe className="h-12 w-12 mx-auto mb-4 opacity-50" />
            <p>No news items available. Try selecting a different source.</p>
          </CardContent>
        </Card>
      )}
    </div>
  );
}