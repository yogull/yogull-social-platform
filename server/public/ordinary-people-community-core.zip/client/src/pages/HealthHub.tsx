import { Link } from "wouter";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { 
  Pill, 
  Calendar, 
  Activity, 
  BookOpen, 
  ArrowLeft,
  Heart,
  TrendingUp,
  FileText,
  AlertCircle
} from "lucide-react";

export default function HealthHub() {
  const healthSections = [
    {
      title: "Supplements",
      description: "Track your daily supplements and vitamins",
      icon: <Pill className="w-8 h-8" />,
      href: "/supplements",
      color: "bg-green-500"
    },
    {
      title: "Daily Log",
      description: "Log your daily supplement intake and health notes",
      icon: <Calendar className="w-8 h-8" />,
      href: "/daily-log",
      color: "bg-blue-500"
    },
    {
      title: "Biometrics",
      description: "Monitor vital signs, weight, and health metrics",
      icon: <Activity className="w-8 h-8" />,
      href: "/biometrics",
      color: "bg-red-500"
    },
    {
      title: "Illness Guides",
      description: "Comprehensive guides for various health conditions",
      icon: <BookOpen className="w-8 h-8" />,
      href: "/illness-guides",
      color: "bg-purple-500"
    }
  ];

  const quickStats = [
    {
      title: "Health Score",
      value: "85%",
      icon: <Heart className="w-5 h-5" />,
      color: "text-green-600"
    },
    {
      title: "Weekly Progress",
      value: "+12%",
      icon: <TrendingUp className="w-5 h-5" />,
      color: "text-blue-600"
    },
    {
      title: "Active Supplements",
      value: "8",
      icon: <Pill className="w-5 h-5" />,
      color: "text-purple-600"
    },
    {
      title: "Health Logs",
      value: "24",
      icon: <FileText className="w-5 h-5" />,
      color: "text-orange-600"
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-green-50 p-4">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <Link href="/">
            <Button variant="ghost" className="mb-4">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Dashboard
            </Button>
          </Link>
          
          <div className="text-center">
            <h1 className="text-4xl font-bold text-gray-800 mb-2">Health Hub</h1>
            <p className="text-xl text-gray-600">
              Your complete health tracking and wellness center
            </p>
          </div>
        </div>

        {/* Quick Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
          {quickStats.map((stat, index) => (
            <Card key={index} className="text-center">
              <CardContent className="p-4">
                <div className={`flex items-center justify-center mb-2 ${stat.color}`}>
                  {stat.icon}
                </div>
                <div className="text-2xl font-bold text-gray-800">{stat.value}</div>
                <div className="text-sm text-gray-600">{stat.title}</div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Health Sections */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
          {healthSections.map((section, index) => (
            <Link key={index} href={section.href}>
              <Card className="h-full hover:shadow-lg transition-shadow cursor-pointer group">
                <CardHeader>
                  <CardTitle className="flex items-center space-x-4">
                    <div className={`p-3 rounded-lg ${section.color} text-white group-hover:scale-110 transition-transform`}>
                      {section.icon}
                    </div>
                    <div>
                      <h3 className="text-xl font-semibold text-gray-800">{section.title}</h3>
                    </div>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-600 mb-4">{section.description}</p>
                  <Button className="w-full group-hover:bg-primary-dark transition-colors">
                    Access {section.title}
                  </Button>
                </CardContent>
              </Card>
            </Link>
          ))}
        </div>

        {/* Health Tips */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <AlertCircle className="w-5 h-5 text-blue-600" />
              <span>Daily Health Tips</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="bg-blue-50 p-4 rounded-lg">
                <h4 className="font-semibold text-blue-800 mb-2">Stay Hydrated</h4>
                <p className="text-blue-700 text-sm">Aim for 8 glasses of water daily to maintain optimal health.</p>
              </div>
              <div className="bg-green-50 p-4 rounded-lg">
                <h4 className="font-semibold text-green-800 mb-2">Regular Exercise</h4>
                <p className="text-green-700 text-sm">30 minutes of activity daily can significantly improve your wellbeing.</p>
              </div>
              <div className="bg-purple-50 p-4 rounded-lg">
                <h4 className="font-semibold text-purple-800 mb-2">Quality Sleep</h4>
                <p className="text-purple-700 text-sm">7-9 hours of sleep helps your body recover and maintain health.</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Quick Actions */}
        <Card>
          <CardHeader>
            <CardTitle>Quick Actions</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <Link href="/daily-log">
                <Button variant="outline" className="w-full">
                  <Calendar className="w-4 h-4 mr-2" />
                  Log Today
                </Button>
              </Link>
              <Link href="/supplements">
                <Button variant="outline" className="w-full">
                  <Pill className="w-4 h-4 mr-2" />
                  Add Supplement
                </Button>
              </Link>
              <Link href="/biometrics">
                <Button variant="outline" className="w-full">
                  <Activity className="w-4 h-4 mr-2" />
                  Record Vitals
                </Button>
              </Link>
              <Link href="/illness-guides">
                <Button variant="outline" className="w-full">
                  <BookOpen className="w-4 h-4 mr-2" />
                  Browse Guides
                </Button>
              </Link>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}