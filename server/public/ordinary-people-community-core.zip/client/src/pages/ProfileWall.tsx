import { useState, useRef, useEffect } from "react";
import { useParams, useLocation } from "wouter";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Heart, MessageCircle, Share2, Camera, Plus, Edit, Store, ShoppingBag, Settings, Key } from "lucide-react";

import { SocialMediaDiscoveryPopup } from "@/components/SocialMediaDiscoveryPopup";
import { apiRequest } from "@/lib/queryClient";
import { useFileUpload, useUserFiles } from "@/hooks/useFileUpload";
import { SimpleImageUpload } from "@/components/SimpleImageUpload";
import EnhancedGallery from "@/components/EnhancedGallery";
import { SocialMediaLinks } from "@/components/SocialMediaLinks";
import { SEO } from "@/components/SEO";
import { UniversalInstructionsButton } from "@/components/UniversalInstructionsButton";
import { SimpleInstructionsButton } from "@/components/SimpleInstructionsButton";
import { BackButton } from "@/components/BackButton";
import { PageNavigationGuide } from "@/components/PageNavigationGuide";

interface User {
  id: number;
  firebaseUid: string;
  email: string;
  name: string;
  bio?: string;
  location?: string;
  profileImageUrl?: string;
  isAdmin: boolean;
  isBlocked: boolean;
  blockedReason?: string;
  blockedAt?: Date;
  createdAt: Date;
  updatedAt: Date;
  credits: number;
  subscription: string;
  balance: number;
  facebookUsername?: string;
  twitterUsername?: string;
  instagramUsername?: string;
  linkedinUsername?: string;
  youtubeUsername?: string;
  whatsappNumber?: string;
  telegramUsername?: string;
  personalWebsite?: string;
}

interface ProfilePost {
  id: number;
  userId: number;
  content: string;
  mediaUrl?: string;
  mediaType?: string;
  likes: number;
  comments: number;
  shares: number;
  createdAt: Date;
  user: {
    id: number;
    name: string;
    profileImageUrl?: string;
  };
}

export default function ProfileWall() {
  const { userId } = useParams();
  const { appUser } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [location, setLocation] = useLocation();
  
  // Error recovery state
  const [hasError, setHasError] = useState(false);
  const [errorRetryCount, setErrorRetryCount] = useState(0);
  
  const [newPost, setNewPost] = useState("");
  const [selectedMedia, setSelectedMedia] = useState<{id: number, url: string, type: string} | null>(null);
  const [showEditProfile, setShowEditProfile] = useState(false);
  const [profileEditData, setProfileEditData] = useState({
    name: "",
    bio: "",
    location: ""
  });
  const [showImageUpload, setShowImageUpload] = useState(false);
  const [uploadType, setUploadType] = useState<'profile' | 'cover' | 'gallery'>('profile');
  const [expandedPost, setExpandedPost] = useState<number | null>(null);



  // Error recovery mechanism to prevent React crashes
  useEffect(() => {
    const handleError = (event: ErrorEvent | PromiseRejectionEvent) => {
      if (import.meta.env.DEV) {
        console.warn('ProfileWall error caught and suppressed:', event);
      }
      if (errorRetryCount < 3) {
        setErrorRetryCount(prev => prev + 1);
        setTimeout(() => setHasError(false), 1000);
      }
      event.preventDefault();
      return true;
    };

    const handleUnhandledRejection = (event: PromiseRejectionEvent) => {
      handleError(event);
    };

    window.addEventListener('error', handleError, true);
    window.addEventListener('unhandledrejection', handleUnhandledRejection);

    return () => {
      window.removeEventListener('error', handleError, true);
      window.removeEventListener('unhandledrejection', handleUnhandledRejection);
    };
  }, [errorRetryCount]);

  const fileInputRef = useRef<HTMLInputElement>(null);
  const coverFileInputRef = useRef<HTMLInputElement>(null);
  const galleryFileInputRef = useRef<HTMLInputElement>(null);

  // Fetch profile user data with aggressive caching
  const { data: profileUser, isLoading, error } = useQuery<User>({
    queryKey: [`/api/users/${userId}`],
    enabled: !!userId,
    retry: 1,
    retryDelay: 500,
    staleTime: 10 * 60 * 1000, // Cache for 10 minutes
    gcTime: 15 * 60 * 1000, // Keep in cache for 15 minutes
    throwOnError: false, // Prevent cross-origin errors from throwing
  });

  // Fetch profile posts with optimized caching
  const { data: posts = [], isLoading: postsLoading, error: postsError } = useQuery({
    queryKey: ["/api/profile-wall", userId],
    enabled: !!userId,
    retry: 1,
    retryDelay: 500,
    staleTime: 2 * 60 * 1000, // Cache for 2 minutes
    gcTime: 5 * 60 * 1000, // Keep in cache for 5 minutes
    throwOnError: false, // Prevent cross-origin errors from throwing
  });

  // Calculate if this is own profile before any conditional logic
  const isOwnProfile = appUser?.id === profileUser?.id;
  const hasConnectedSocial = profileUser?.facebookUsername || profileUser?.twitterUsername || profileUser?.instagramUsername;
  
  // Debug log for upload button visibility
  if (process.env.NODE_ENV === 'development') {
    console.log('Upload button debug:', {
      currentUserId: appUser?.id,
      profileUserId: profileUser?.id,
      isOwnProfile,
      hasProfileImage: !!profileUser?.profileImageUrl,
      showButtons: true // Always show for debugging
    });
  }

  // Fetch user files for galleries only when needed
  const { data: files = [], refetch: refetchFiles } = useUserFiles(profileUser?.id || 0);

  // Check if current user owns a company for shop button (only for own profile)
  const { data: userCompanies = [] } = useQuery({
    queryKey: ["/api/companies/user", appUser?.id],
    enabled: !!appUser?.id && isOwnProfile,
    staleTime: 10 * 60 * 1000, // Cache for 10 minutes
  });

  // Check if user has personal shop (optimized query)
  const { data: personalShop } = useQuery({
    queryKey: [`/api/personal-shops/user/${profileUser?.id}`],
    enabled: !!profileUser?.id,
    staleTime: 10 * 60 * 1000, // Cache for 10 minutes
  });

  // Type guard for personal shop
  const personalShopData = personalShop as { id: number; shopName: string; description?: string } | undefined;

  // File upload mutation
  const { uploadFile } = useFileUpload();
  const [uploadProcessing, setUploadProcessing] = useState(false);

  // Create post mutation
  const createPostMutation = useMutation({
    mutationFn: async (data: { content: string; mediaUrl?: string; mediaType?: string }) => {
      return apiRequest("POST", "/api/profile-wall", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/profile-wall", userId] });
      setNewPost("");
      toast({
        title: "Success",
        description: "Post created successfully!",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to create post.",
        variant: "destructive",
      });
    },
  });

  // Update profile mutation
  const updateProfileMutation = useMutation({
    mutationFn: async (data: { name: string; bio: string; location: string }) => {
      return apiRequest("PATCH", `/api/users/${profileUser?.id}`, data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/users", userId] });
      setShowEditProfile(false);
      toast({
        title: "Success",
        description: "Profile updated successfully!",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to update profile.",
        variant: "destructive",
      });
    },
  });

  const handleCreatePost = () => {
    if (!newPost.trim()) return;
    
    const postData: any = { content: newPost };
    
    // If media is selected, add it to the post
    if (selectedMedia) {
      postData.mediaUrl = selectedMedia.url;
      postData.mediaType = selectedMedia.type;
    }
    
    createPostMutation.mutate(postData);
    setNewPost("");
    setSelectedMedia(null);
  };

  const handleEditProfile = () => {
    if (profileUser) {
      setProfileEditData({
        name: profileUser.name || "",
        bio: profileUser.bio || "",
        location: profileUser.location || ""
      });
      setShowEditProfile(true);
    }
  };

  const handleSaveProfile = () => {
    updateProfileMutation.mutate(profileEditData);
  };

  const handleImageUpload = (type: 'profile' | 'cover' | 'gallery') => {
    console.log('Upload button clicked:', type, 'isOwnProfile:', isOwnProfile);
    setCropperAction(type);
    const input = type === 'cover' ? coverFileInputRef.current : 
                  type === 'gallery' ? galleryFileInputRef.current : 
                  fileInputRef.current;
    input?.click();
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setSelectedImageFile(file);
      setShowImageCropper(true);
    }
  };

  const handleCropComplete = async (croppedBlob: Blob | null, cropData: any) => {
    try {
      // Handle null blob (error case) - prevent crashes
      if (!croppedBlob) {
        toast({
          title: "Upload cancelled",
          description: "Image cropping was cancelled.",
        });
        setShowImageCropper(false);
        setSelectedImageFile(null);
        return;
      }
      
      const file = new File([croppedBlob], `${cropperAction}-image.jpg`, { type: 'image/jpeg' });
      console.log('BULLETPROOF: Created file for upload:', { name: file.name, size: file.size, type: file.type });
      
      // Upload file with proper profile image flag
      console.log('BULLETPROOF: Starting upload mutation...');
      try {
        if (uploadFile.mutateAsync) {
          await uploadFile.mutateAsync({
            file,
            galleryName: cropperAction === 'gallery' ? 'main' : undefined,
            caption: cropperAction === 'gallery' ? 'Profile image' : undefined,
            isProfileImage: cropperAction === 'profile',
          });
          console.log('BULLETPROOF: Upload completed successfully');
        } else {
          throw new Error('Upload function not available');
        }
      } catch (uploadError) {
        console.error('BULLETPROOF: Upload failed:', uploadError);
        throw uploadError; // Re-throw to be caught by outer try-catch
      }

      setShowImageCropper(false);
      setSelectedImageFile(null);
      setUploadProcessing(false);
      
      // Refresh data based on action  
      if (cropperAction === 'profile') {
        console.log('BULLETPROOF: Refreshing user data for profile image...');
        queryClient.invalidateQueries({ queryKey: [`/api/users/${userId}`] });
        queryClient.invalidateQueries({ queryKey: [`/api/users/${profileUser?.id}`] });
        
        // Refresh data without full page reload to prevent crashes
        setTimeout(() => {
          queryClient.refetchQueries({ queryKey: [`/api/users/${userId}`] });
        }, 1000);
      } else if (cropperAction === 'cover') {
        console.log('BULLETPROOF: Refreshing user data for cover image...');
        queryClient.invalidateQueries({ queryKey: [`/api/users/${userId}`] });
        queryClient.invalidateQueries({ queryKey: [`/api/users/${profileUser?.id}`] });
      } else {
        console.log('BULLETPROOF: Refreshing files for gallery...');
        refetchFiles();
        // Convert blob to base64 for preview when uploading for post
        const reader = new FileReader();
        reader.onload = () => {
          setSelectedMedia({
            id: Date.now(),
            url: reader.result as string,
            type: 'image'
          });
        };
        reader.readAsDataURL(croppedBlob);
      }

      // Force immediate cache invalidation and page reload for images
      queryClient.invalidateQueries({ queryKey: [`/api/users/${userId}`] });
      queryClient.invalidateQueries({ queryKey: [`/api/users/${profileUser?.id}`] });
      queryClient.invalidateQueries({ queryKey: ["/api/profile-wall", userId] });
      
      // Force immediate display with proper image refresh
      if (cropperAction === 'profile') {
        // Clear any cached profile images first
        const profileImages = document.querySelectorAll('img[src*="profile"]');
        profileImages.forEach(img => {
          const currentSrc = img.getAttribute('src');
          if (currentSrc) {
            img.setAttribute('src', currentSrc + '?t=' + Date.now());
          }
        });
        
        // Show success message
        toast({
          title: "Success!",
          description: "Profile image updated successfully! Page will refresh to show changes.",
        });
        
        // Force page refresh to show new image
        setTimeout(() => {
          window.location.reload();
        }, 2000);
      }
      
      toast({
        title: "Success",
        description: `${cropperAction === 'profile' ? 'Profile' : cropperAction === 'cover' ? 'Cover' : 'Gallery'} image updated successfully!`,
      });
      
      // Force immediate UI refresh for profile images
      if (cropperAction === 'profile') {
        // Add timestamp to force image refresh
        const timestamp = Date.now();
        setTimeout(() => {
          queryClient.refetchQueries({ queryKey: [`/api/users/${userId}`] });
          queryClient.refetchQueries({ queryKey: [`/api/users/${profileUser?.id}`] });
          // Force reload profile images with cache bust
          const avatars = document.querySelectorAll('img[alt*="profile"], img[src*="profile"]');
          avatars.forEach((img: any) => {
            if (img.src && img.src.includes('profile')) {
              const baseSrc = img.src.split('?')[0];
              img.src = `${baseSrc}?t=${timestamp}`;
            }
          });
        }, 500);
      }
    } catch (error) {
      console.error('Image upload error:', error);
      setUploadProcessing(false);
      setShowImageCropper(false);
      setSelectedImageFile(null);
      toast({
        title: "Error",
        description: "Failed to upload image. Please try again.",
        variant: "destructive",
      });
    }
  };

  const handleLike = async (postId: number) => {
    try {
      await apiRequest("POST", `/api/profile-wall/${postId}/like`);
      queryClient.invalidateQueries({ queryKey: ["/api/profile-wall", userId] });
      toast({
        title: "Liked",
        description: "Post liked successfully.",
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to like post.",
        variant: "destructive",
      });
    }
  };

  const handleShare = async (postId: number) => {
    try {
      await apiRequest("POST", `/api/profile-wall/${postId}/share`);
      toast({
        title: "Shared",
        description: "Post shared successfully.",
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to share post.",
        variant: "destructive",
      });
    }
  };

  const handleAddComment = async (postId: number, comment: string) => {
    try {
      await apiRequest("POST", `/api/profile-wall/${postId}/comment`, { comment });
      queryClient.invalidateQueries({ queryKey: ["/api/profile-wall"] });
      toast({
        title: "Comment added",
        description: "Your comment was posted successfully.",
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to add comment.",
        variant: "destructive",
      });
    }
  };

  // Handle loading and error states
  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-50 dark:bg-gray-900 flex items-center justify-center">
        <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full" />
      </div>
    );
  }

  if (error || !profileUser) {
    return (
      <div className="min-h-screen bg-gray-50 dark:bg-gray-900 flex items-center justify-center">
        <div className="text-center space-y-4">
          <h1 className="text-2xl font-bold">Profile Not Found</h1>
          <p className="text-gray-600">This profile may not exist or there was an error loading it.</p>
          <Button onClick={() => window.location.href = '/dashboard'} className="bg-blue-600 text-white">
            Back to Dashboard
          </Button>
        </div>
      </div>
    );
  }

  const hasCompany = Array.isArray(userCompanies) && userCompanies.length > 0;

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      <SEO
        title={`${profileUser.name} - Profile Wall`}
        description={`View ${profileUser.name}'s profile and posts on Ordinary People Community`}
        keywords={[profileUser.name, 'profile', 'community', 'posts', 'social']}
      />

      {/* Instructions button - desktop only to avoid mobile duplication */}
      <div className="hidden md:block">
        <SimpleInstructionsButton 
          currentPage="community"
        />
      </div>

      {/* Instructions Button */}


      <div className="max-w-[95vw] mx-auto p-2 space-y-4">
        {/* Profile Header */}
        <Card className="max-w-[72vw] mx-auto">
          <CardContent className="p-4">
            <div className="flex flex-col items-center space-y-4">
              <div className="relative">
                <img
                  key={`profile-${profileUser.id}-${profileUser.profileImageUrl || 'default'}`}
                  src={profileUser.profileImageUrl ? `${profileUser.profileImageUrl}?v=${Date.now()}` : `data:image/svg+xml,${encodeURIComponent(`
                    <svg width="96" height="96" viewBox="0 0 96 96" fill="none" xmlns="http://www.w3.org/2000/svg">
                      <circle cx="48" cy="48" r="48" fill="url(#gradient)"/>
                      <path d="M48 52c8.837 0 16-7.163 16-16s-7.163-16-16-16-16 7.163-16 16 7.163 16 16 16zM48 60c-10.667 0-32 5.333-32 16v8h64v-8c0-10.667-21.333-16-32-16z" fill="white"/>
                      <defs>
                        <linearGradient id="gradient" x1="0%" y1="0%" x2="100%" y2="100%">
                          <stop offset="0%" style="stop-color:#3B82F6"/>
                          <stop offset="100%" style="stop-color:#8B5CF6"/>
                        </linearGradient>
                      </defs>
                    </svg>
                  `)}`}
                  alt={`${profileUser.name}'s profile`}
                  className="w-24 h-24 rounded-full object-cover border-4 border-white shadow-lg"
                  onLoad={() => {
                    if (process.env.NODE_ENV === 'development') {
                      console.log('Profile image loaded:', profileUser.profileImageUrl);
                    }
                  }}
                  onError={(e) => {
                    if (process.env.NODE_ENV === 'development') {
                      console.log('Profile image error:', e);
                    }
                  }}
                />
                {!uploadProcessing && (
                  <Button
                    size="sm"
                    className="absolute -bottom-1 -right-1 h-8 w-8 rounded-full p-0 bg-orange-500 hover:bg-orange-600 border-2 border-white shadow-xl"
                    onClick={() => handleImageUpload('profile')}
                    title="Upload profile image"
                    disabled={uploadProcessing}
                  >
                    <Camera className="h-4 w-4 text-white" />
                  </Button>
                )}
                
                {uploadProcessing && (
                  <div className="absolute -bottom-1 -right-1 h-8 w-8 rounded-full bg-green-500 border-2 border-white shadow-xl flex items-center justify-center">
                    <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>
                  </div>
                )}
              </div>
              
              {/* Always visible upload button below profile */}
              <div className="flex gap-2 mt-2">
                <Button
                  size="sm"
                  className="bg-blue-500 hover:bg-blue-600 text-white"
                  onClick={() => handleImageUpload('profile')}
                >
                  <Camera className="h-4 w-4 mr-2" />
                  Change Photo
                </Button>
                <Button
                  size="sm"
                  variant="outline"
                  onClick={() => handleImageUpload('cover')}
                >
                  <Edit className="h-4 w-4 mr-2" />
                  Change Cover
                </Button>
              </div>

              <div className="text-center mt-3">
                <h1 className="text-base md:text-xl font-bold" style={{ marginTop: '8px' }}>{profileUser.name}</h1>
                {profileUser.bio && (
                  <p className="text-xs md:text-sm text-gray-600 dark:text-gray-300 mt-1">
                    {profileUser.bio}
                  </p>
                )}
                {profileUser.location && (
                  <p className="text-xs md:text-sm text-gray-500 dark:text-gray-400 mt-1">
                    📍 {profileUser.location}
                  </p>
                )}
              </div>

              {/* Action Buttons */}
              <div className="flex flex-wrap gap-2 justify-center">
                {isOwnProfile && (
                  <>
                    <Button size="sm" onClick={handleEditProfile}>
                      <Edit className="h-4 w-4 mr-1" />
                      Edit Profile
                    </Button>
                    <Button size="sm" variant="outline" onClick={() => setLocation('/profile-settings')}>
                      <Key className="h-4 w-4 mr-1" />
                      Password & Security
                    </Button>
                    {hasCompany && (
                      <Button 
                        size="sm" 
                        variant="outline" 
                        className="bg-green-600 hover:bg-green-700 text-white border-green-600"
                        onClick={() => setLocation(`/business-profile/${profileUser.id}`)}
                      >
                        <Store className="h-4 w-4 mr-1" />
                        Visit Shop
                      </Button>
                    )}
                    {personalShop ? (
                      <Button 
                        size="sm" 
                        className="bg-purple-600 hover:bg-purple-700 text-white"
                        onClick={() => {
                          // @ts-ignore - Temporary fix for TypeScript property access
                          console.log('Navigating to personal shop view:', personalShop.id);
                          // @ts-ignore - Temporary fix for TypeScript property access
                          setLocation(`/personal-shop-view/${personalShop.id}`);
                        }}
                      >
                        <ShoppingBag className="h-4 w-4 mr-1" />
                        My Personal Shop
                      </Button>
                    ) : (
                      <Button 
                        size="sm"
                        onClick={() => setLocation('/shop')}
                        className="bg-blue-600 hover:bg-blue-700 text-white font-semibold px-2 py-1 rounded-full shadow-lg animate-pulse hover:animate-none transition-all duration-300 transform hover:scale-105 text-xs w-16 flex items-center justify-center whitespace-nowrap"
                      >
                        Shop
                      </Button>
                    )}
                  </>
                )}
              </div>

              {/* Social Media Connection Cards */}
              <div className="mt-6">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-sm md:text-lg font-semibold flex items-center gap-2">
                    <Share2 className="w-4 h-4 md:w-5 md:h-5" />
                    Social Media Connections
                    {isOwnProfile && (
                      <span className="text-xs bg-green-100 text-green-700 px-2 py-1 rounded-full">
                        Facebook button below
                      </span>
                    )}
                  </h3>

                </div>
                
                {/* Help Card for First-Time Users */}
                {isOwnProfile && (!profileUser.facebookUsername && !profileUser.twitterUsername && !profileUser.instagramUsername) && (
                  <div className="mb-4 p-4 bg-blue-50 border border-blue-200 rounded-lg">
                    <div className="flex items-start gap-3">
                      <div className="flex-shrink-0 w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center">
                        <Share2 className="w-4 h-4 text-blue-600" />
                      </div>
                      <div className="flex-1">
                        <h4 className="font-medium text-blue-900 mb-1">Connect Your Social Media for Multi-Share Power!</h4>
                        <p className="text-sm text-blue-700 mb-3">
                          Connect Facebook, Twitter, Instagram & more to use our revolutionary Multi-Share system. 
                          Post once from OPC and automatically share to ALL your social media platforms simultaneously!
                        </p>
                        <div className="flex gap-2">
                          <Button 
                            size="sm" 
                            className="bg-blue-600 hover:bg-blue-700"
                            onClick={() => {
                              const element = document.querySelector('.social-media-links');
                              if (element) {
                                element.scrollIntoView({ behavior: 'smooth' });
                                // Trigger edit mode after scroll
                                setTimeout(() => {
                                  const editButton = element.querySelector('button[class*="edit"]') as HTMLButtonElement;
                                  if (editButton) editButton.click();
                                }, 500);
                              }
                            }}
                          >
                            Connect Now
                          </Button>

                        </div>
                      </div>
                    </div>
                  </div>
                )}
                
                <div className="social-media-links">
                  <SocialMediaLinks userId={profileUser.id} isOwnProfile={isOwnProfile} />
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Money Making Notification - Only for Own Profile */}
        {isOwnProfile && (
          <Card className="max-w-[72vw] mx-auto bg-gradient-to-r from-green-500 to-emerald-600 text-white border-0">
            <CardContent className="p-4">
              <div className="space-y-3">
                <div className="flex items-center gap-2">
                  <ShoppingBag className="h-6 w-6" />
                  <h3 className="text-lg font-bold">💰 We've Done Everything For You - Now Start Making Money!</h3>
                </div>
                <p className="text-sm opacity-90">
                  Your personal affiliate shop is ready! Every user gets their own shop to sell products with affiliate links. 
                  Zero setup required - just add your affiliate links and start earning commissions immediately.
                </p>
                <div className="bg-white/20 rounded-lg p-3 space-y-2">
                  <h4 className="font-semibold text-sm">How to Get Started:</h4>
                  <ul className="text-xs space-y-1 opacity-90">
                    <li>1. Visit your personal shop (button below)</li>
                    <li>2. Add products from Amazon, eBay, or any affiliate program</li>
                    <li>3. Paste your affiliate links when adding products</li>
                    <li>4. Share products to your Profile Wall and community</li>
                    <li>5. Earn commissions when people buy through your links</li>
                  </ul>
                </div>
                <div className="flex gap-2">
                  <Button 
                    size="sm" 
                    className="bg-white text-green-600 hover:bg-gray-100"
                    onClick={() => window.location.href = `/shop/${profileUser.id}`}
                  >
                    <Store className="h-4 w-4 mr-1" />
                    Open My Shop
                  </Button>
                  <Button 
                    size="sm" 
                    variant="outline" 
                    className="border-white text-white hover:bg-white/20"
                    onClick={() => window.location.href = `/about`}
                  >
                    Learn More
                  </Button>
                  {profileUser?.isAdmin && (
                    <Button 
                      size="sm" 
                      className="bg-red-600 text-white hover:bg-red-700"
                      onClick={() => window.location.href = `/admin/affiliate-shops`}
                    >
                      <Settings className="h-4 w-4 mr-1" />
                      Admin Shop Manager
                    </Button>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Create Post (Own Profile Only) */}
        {isOwnProfile && (
          <Card className="max-w-[72vw] mx-auto">
            <CardContent className="p-4">
              <div className="space-y-3">
                <Textarea
                  placeholder="Share something with your community..."
                  value={newPost}
                  onChange={(e) => setNewPost(e.target.value)}
                  className="min-h-[80px]"
                />
                {/* Show selected media preview */}
                {selectedMedia && (
                  <div className="border rounded-lg p-2 relative">
                    <img 
                      src={selectedMedia.url} 
                      alt="Selected media" 
                      className="w-20 h-20 object-cover rounded"
                    />
                    <Button
                      size="sm"
                      variant="ghost"
                      className="absolute -top-2 -right-2 h-6 w-6 p-0 bg-red-500 text-white rounded-full"
                      onClick={() => setSelectedMedia(null)}
                    >
                      ×
                    </Button>
                  </div>
                )}
                
                <div className="flex justify-between items-center">
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => handleImageUpload('gallery')}
                  >
                    <Camera className="h-4 w-4 mr-1" />
                    Add Media
                  </Button>
                  <Button 
                    onClick={handleCreatePost}
                    disabled={!newPost.trim() || createPostMutation.isPending}
                    className="bg-pink-600 text-white"
                  >
                    Post
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Facebook-Style Wall Feed */}
        <div className="space-y-4">
          {postsLoading ? (
            <Card className="max-w-[72vw] mx-auto">
              <CardContent className="p-4">
                <div className="animate-pulse">
                  <div className="h-4 bg-gray-200 rounded w-3/4 mb-2"></div>
                  <div className="h-4 bg-gray-200 rounded w-1/2"></div>
                </div>
              </CardContent>
            </Card>
          ) : Array.isArray(posts) && posts.length > 0 ? (
            posts.map((post: any) => (
              <Card key={post.id} className="max-w-[72vw] mx-auto shadow-sm border border-gray-200">
                <CardContent className="p-0">
                  {/* Post Header - Facebook Style */}
                  <div className="p-4 border-b border-gray-100">
                    <div className="flex items-center space-x-3">
                      <div className="w-10 h-10 rounded-full overflow-hidden bg-gray-100">
                        {profileUser?.profileImageUrl ? (
                          <img 
                            src={profileUser.profileImageUrl} 
                            alt={profileUser.name}
                            className="w-full h-full object-cover"
                          />
                        ) : (
                          <div className="w-full h-full bg-gradient-to-br from-blue-400 to-purple-500 flex items-center justify-center">
                            <span className="text-white font-bold text-sm">
                              {profileUser?.name?.charAt(0)?.toUpperCase() || 'U'}
                            </span>
                          </div>
                        )}
                      </div>
                      <div className="flex-1">
                        <h3 className="font-semibold text-sm">{profileUser?.name}</h3>
                        <p className="text-xs text-gray-500">
                          {new Date(post.createdAt).toLocaleDateString()} at {new Date(post.createdAt).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}
                        </p>
                      </div>
                    </div>
                  </div>

                  {/* Post Content */}
                  <div className="p-4">
                    <p className="text-sm text-gray-900 whitespace-pre-wrap">{post.content}</p>
                    
                    {/* Media Content */}
                    {post.mediaUrl && (
                      <div className="mt-3 rounded-lg overflow-hidden">
                        {post.mediaType === 'video' ? (
                          <video controls className="w-full max-h-96 object-cover">
                            <source src={post.mediaUrl} type="video/mp4" />
                            Your browser does not support the video tag.
                          </video>
                        ) : (
                          <img 
                            src={post.mediaUrl} 
                            alt="Post media" 
                            className="w-full max-h-96 object-cover cursor-pointer hover:opacity-90 transition-opacity"
                            onClick={() => window.open(post.mediaUrl, '_blank')}
                          />
                        )}
                      </div>
                    )}
                  </div>

                  {/* Engagement Stats */}
                  <div className="px-4 py-2 border-b border-gray-100">
                    <div className="flex items-center justify-between text-xs text-gray-500">
                      <span>{(post.likes || 0)} likes</span>
                      <div className="flex space-x-3">
                        <span>{(post.comments || 0)} comments</span>
                        <span>{(post.shares || 0)} shares</span>
                      </div>
                    </div>
                  </div>

                  {/* Action Buttons - Facebook Style */}
                  <div className="px-4 py-2">
                    <div className="flex justify-around">
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={() => handleLike(post.id)}
                        className="flex-1 flex items-center justify-center gap-2 py-2 hover:bg-gray-50 rounded-md transition-colors"
                      >
                        <Heart className={`h-4 w-4 ${post.userHasLiked ? 'fill-red-500 text-red-500' : 'text-gray-600'}`} />
                        <span className="text-sm font-medium text-gray-700">Like</span>
                      </Button>
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={() => {
                          // Toggle comment section
                          setExpandedPost(expandedPost === post.id ? null : post.id);
                        }}
                        className="flex-1 flex items-center justify-center gap-2 py-2 hover:bg-gray-50 rounded-md transition-colors"
                      >
                        <MessageCircle className="h-4 w-4 text-gray-600" />
                        <span className="text-sm font-medium text-gray-700">Comment</span>
                      </Button>
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={() => handleShare(post.id)}
                        className="flex-1 flex items-center justify-center gap-2 py-2 hover:bg-gray-50 rounded-md transition-colors"
                      >
                        <Share2 className="h-4 w-4 text-gray-600" />
                        <span className="text-sm font-medium text-gray-700">Share to OPC</span>
                      </Button>
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={() => {
                          // Multi-share functionality
                          if (navigator.share) {
                            navigator.share({
                              title: 'Ordinary People Community',
                              text: post.content,
                              url: window.location.href
                            });
                          }
                        }}
                        className="flex-1 flex items-center justify-center gap-2 py-2 hover:bg-gray-50 rounded-md transition-colors"
                      >
                        <Share2 className="h-4 w-4 text-green-600" />
                        <span className="text-sm font-medium text-green-700">Multi-Share</span>
                      </Button>
                    </div>
                  </div>

                  {/* Comments Section */}
                  {expandedPost === post.id && (
                    <div className="border-t border-gray-100 p-4 bg-gray-50">
                      <div className="space-y-3">
                        {/* Existing Comments */}
                        {post.comments && post.comments.length > 0 && (
                          <div className="space-y-2">
                            {post.comments.map((comment: any) => (
                              <div key={comment.id} className="flex space-x-2">
                                <div className="w-8 h-8 rounded-full bg-gray-200 flex-shrink-0"></div>
                                <div className="flex-1 bg-gray-100 rounded-lg p-2">
                                  <p className="text-xs font-semibold">{comment.userName}</p>
                                  <p className="text-sm">{comment.content}</p>
                                </div>
                              </div>
                            ))}
                          </div>
                        )}
                        
                        {/* Add Comment */}
                        <div className="space-y-2">
                          <div className="flex space-x-2">
                            <div className="w-8 h-8 rounded-full bg-blue-500 flex-shrink-0 flex items-center justify-center">
                              <span className="text-white text-xs font-bold">
                                {appUser?.name?.charAt(0)?.toUpperCase() || 'U'}
                              </span>
                            </div>
                            <div className="flex-1">
                              <input
                                type="text"
                                placeholder="Write a comment..."
                                className="w-full px-3 py-2 bg-gray-100 rounded-full text-sm border-0 focus:outline-none focus:ring-2 focus:ring-blue-500"
                                onKeyPress={(e) => {
                                  if (e.key === 'Enter' && e.currentTarget.value.trim()) {
                                    handleAddComment(post.id, e.currentTarget.value);
                                    e.currentTarget.value = '';
                                  }
                                }}
                            />
                          </div>
                          {/* Comment action buttons */}
                          <div className="flex justify-between mt-2">
                            <Button size="sm" variant="ghost" className="text-xs px-2 py-1">
                              <Heart className="h-3 w-3 mr-1" />
                              Like
                            </Button>
                            <Button size="sm" variant="ghost" className="text-xs px-2 py-1">
                              <Share2 className="h-3 w-3 mr-1" />
                              Share to OPC
                            </Button>
                            <Button size="sm" variant="ghost" className="text-xs px-2 py-1">
                              <Share2 className="h-3 w-3 mr-1 text-green-600" />
                              Multi-Share
                            </Button>
                          </div>
                        </div>
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>
            ))
          ) : (
            <Card className="max-w-[72vw] mx-auto">
              <CardContent className="p-8 text-center">
                <div className="text-gray-500">
                  <MessageCircle className="w-12 h-12 mx-auto mb-3 text-gray-300" />
                  <p className="text-sm">
                    {isOwnProfile 
                      ? "Share your first post with the community above!" 
                      : "No posts shared yet"
                    }
                  </p>
                </div>
              </CardContent>
            </Card>
          )}
        </div>

        {/* Gallery Section */}
        <Card className="max-w-[72vw] mx-auto">
          <CardContent className="p-4">
            <h2 className="text-lg font-bold mb-4 text-black">My Photos & Videos</h2>
            <EnhancedGallery userId={profileUser.id} isOwner={isOwnProfile} />
          </CardContent>
        </Card>
      </div>

      {/* Edit Profile Dialog */}
      <Dialog open={showEditProfile} onOpenChange={setShowEditProfile}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Edit Profile</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label htmlFor="name">Name</Label>
              <Input
                id="name"
                value={profileEditData.name}
                onChange={(e) => setProfileEditData(prev => ({ ...prev, name: e.target.value }))}
              />
            </div>
            <div>
              <Label htmlFor="bio">Bio</Label>
              <Textarea
                id="bio"
                value={profileEditData.bio}
                onChange={(e) => setProfileEditData(prev => ({ ...prev, bio: e.target.value }))}
              />
            </div>
            <div>
              <Label htmlFor="location">Location</Label>
              <Input
                id="location"
                value={profileEditData.location}
                onChange={(e) => setProfileEditData(prev => ({ ...prev, location: e.target.value }))}
              />
            </div>
            <div className="flex gap-2">
              <Button onClick={handleSaveProfile} disabled={updateProfileMutation.isPending}>
                Save Changes
              </Button>
              <Button variant="outline" onClick={() => setShowEditProfile(false)}>
                Cancel
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Image Cropper */}
      {selectedImageFile && (
        <ImageCropper
          isOpen={showImageCropper}
          onClose={() => setShowImageCropper(false)}
          imageFile={selectedImageFile}
          onCropComplete={handleCropComplete}
          aspectRatio={cropperAction === 'cover' ? 16/9 : 1}
        />
      )}

      {/* Hidden file inputs */}
      <input
        ref={fileInputRef}
        type="file"
        accept="image/*"
        className="hidden"
        onChange={handleFileSelect}
      />
      <input
        ref={coverFileInputRef}
        type="file"
        accept="image/*"
        className="hidden"
        onChange={handleFileSelect}
      />
      <input
        ref={galleryFileInputRef}
        type="file"
        accept="image/*,video/*"
        className="hidden"
        onChange={handleFileSelect}
      />
    </div>
  );
}