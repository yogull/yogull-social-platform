import { useState, useEffect } from 'react';
import { Link } from 'wouter';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { ArrowLeft, Mail, Building2, Users, TrendingUp, Calendar, RefreshCw } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

interface AnalyticsData {
  emails: {
    totalSent: number;
    todaySent: number;
    yesterdaySent: number;
    welcomeEmails: number;
    businessEmails: number;
    responseEmails: number;
  };
  businesses: {
    totalProfiles: number;
    createdToday: number;
    createdYesterday: number;
    activeProfiles: number;
    responseRate: number;
  };
  users: {
    totalUsers: number;
    activeToday: number;
    newSignups: number;
    postsCreated: number;
    discussionsStarted: number;
  };
  lastUpdated: string;
}

export default function AdminAnalytics() {
  const { toast } = useToast();
  const [analytics, setAnalytics] = useState<AnalyticsData | null>(null);
  const [loading, setLoading] = useState(true);

  const loadAnalytics = async () => {
    try {
      setLoading(true);
      const response = await fetch('/api/admin/analytics');
      if (response.ok) {
        const data = await response.json();
        setAnalytics(data);
      } else {
        throw new Error('Failed to load analytics');
      }
    } catch (error) {
      toast({ title: "Error", description: "Failed to load analytics data" });
    }
    setLoading(false);
  };

  const triggerDailyPosts = async () => {
    try {
      const response = await fetch('/api/admin/trigger-daily-posts', {
        method: 'POST'
      });
      
      if (response.ok) {
        const result = await response.json();
        toast({ title: "Success", description: result.message });
      } else {
        toast({ title: "Error", description: "Failed to trigger daily posts" });
      }
    } catch (error) {
      toast({ title: "Error", description: "Failed to trigger daily posts" });
    }
  };

  useEffect(() => {
    loadAnalytics();
  }, []);

  if (loading) {
    return (
      <div className="w-full mx-auto p-4 bg-gray-50 min-h-screen">
        <div className="flex items-center justify-center h-64">
          <div className="animate-spin w-8 h-8 border-4 border-blue-600 border-t-transparent rounded-full"></div>
        </div>
      </div>
    );
  }

  return (
    <div className="w-full mx-auto p-4 bg-gray-50 min-h-screen">
      {/* Header */}
      <div className="mb-6">
        <div className="flex items-center justify-between mb-4">
          <Link href="/admin">
            <Button variant="outline" size="sm">
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back to Admin
            </Button>
          </Link>
          <h1 className="text-2xl font-bold">Admin Analytics Dashboard</h1>
          <Button onClick={loadAnalytics} variant="outline" size="sm">
            <RefreshCw className="h-4 w-4 mr-2" />
            Refresh
          </Button>
        </div>
        
        {analytics && (
          <p className="text-sm text-gray-600">
            Last updated: {new Date(analytics.lastUpdated).toLocaleString()}
          </p>
        )}
      </div>

      {analytics && (
        <div className="space-y-6">
          {/* Email Statistics */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Mail className="h-5 w-5 mr-2 text-blue-600" />
                Email Statistics
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                <div className="text-center p-4 bg-blue-50 rounded-lg">
                  <div className="text-2xl font-bold text-blue-600">{analytics.emails.totalSent}</div>
                  <div className="text-sm text-gray-600">Total Sent</div>
                </div>
                <div className="text-center p-4 bg-green-50 rounded-lg">
                  <div className="text-2xl font-bold text-green-600">{analytics.emails.todaySent}</div>
                  <div className="text-sm text-gray-600">Sent Today</div>
                </div>
                <div className="text-center p-4 bg-purple-50 rounded-lg">
                  <div className="text-2xl font-bold text-purple-600">{analytics.emails.yesterdaySent}</div>
                  <div className="text-sm text-gray-600">Sent Yesterday</div>
                </div>
                <div className="text-center p-4 bg-orange-50 rounded-lg">
                  <div className="text-2xl font-bold text-orange-600">{analytics.emails.welcomeEmails}</div>
                  <div className="text-sm text-gray-600">Welcome Emails</div>
                </div>
                <div className="text-center p-4 bg-red-50 rounded-lg">
                  <div className="text-2xl font-bold text-red-600">{analytics.emails.businessEmails}</div>
                  <div className="text-sm text-gray-600">Business Emails</div>
                </div>
                <div className="text-center p-4 bg-teal-50 rounded-lg">
                  <div className="text-2xl font-bold text-teal-600">{analytics.emails.responseEmails}</div>
                  <div className="text-sm text-gray-600">Response Emails</div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Business Statistics */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Building2 className="h-5 w-5 mr-2 text-green-600" />
                Business Profile Statistics
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                <div className="text-center p-4 bg-green-50 rounded-lg">
                  <div className="text-2xl font-bold text-green-600">{analytics.businesses.totalProfiles}</div>
                  <div className="text-sm text-gray-600">Total Profiles</div>
                </div>
                <div className="text-center p-4 bg-blue-50 rounded-lg">
                  <div className="text-2xl font-bold text-blue-600">{analytics.businesses.createdToday}</div>
                  <div className="text-sm text-gray-600">Created Today</div>
                </div>
                <div className="text-center p-4 bg-purple-50 rounded-lg">
                  <div className="text-2xl font-bold text-purple-600">{analytics.businesses.createdYesterday}</div>
                  <div className="text-sm text-gray-600">Created Yesterday</div>
                </div>
                <div className="text-center p-4 bg-orange-50 rounded-lg">
                  <div className="text-2xl font-bold text-orange-600">{analytics.businesses.activeProfiles}</div>
                  <div className="text-sm text-gray-600">Active Profiles</div>
                </div>
                <div className="text-center p-4 bg-red-50 rounded-lg">
                  <div className="text-2xl font-bold text-red-600">{analytics.businesses.responseRate}%</div>
                  <div className="text-sm text-gray-600">Response Rate</div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* User Statistics */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Users className="h-5 w-5 mr-2 text-purple-600" />
                User Activity Statistics
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                <div className="text-center p-4 bg-purple-50 rounded-lg">
                  <div className="text-2xl font-bold text-purple-600">{analytics.users.totalUsers}</div>
                  <div className="text-sm text-gray-600">Total Users</div>
                </div>
                <div className="text-center p-4 bg-green-50 rounded-lg">
                  <div className="text-2xl font-bold text-green-600">{analytics.users.activeToday}</div>
                  <div className="text-sm text-gray-600">Active Today</div>
                </div>
                <div className="text-center p-4 bg-blue-50 rounded-lg">
                  <div className="text-2xl font-bold text-blue-600">{analytics.users.newSignups}</div>
                  <div className="text-sm text-gray-600">New Signups</div>
                </div>
                <div className="text-center p-4 bg-orange-50 rounded-lg">
                  <div className="text-2xl font-bold text-orange-600">{analytics.users.postsCreated}</div>
                  <div className="text-sm text-gray-600">Posts Created</div>
                </div>
                <div className="text-center p-4 bg-teal-50 rounded-lg">
                  <div className="text-2xl font-bold text-teal-600">{analytics.users.discussionsStarted}</div>
                  <div className="text-sm text-gray-600">Discussions Started</div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Quick Actions */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <TrendingUp className="h-5 w-5 mr-2 text-orange-600" />
                Quick Actions
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <Button 
                  onClick={triggerDailyPosts}
                  className="bg-blue-600 hover:bg-blue-700 text-white p-4 h-auto"
                >
                  <Calendar className="h-5 w-5 mr-2" />
                  <div>
                    <div className="font-semibold">Trigger Daily Posts</div>
                    <div className="text-sm opacity-90">Post automated discussion topics</div>
                  </div>
                </Button>
                <Link href="/location-ads">
                  <Button 
                    variant="outline"
                    className="w-full p-4 h-auto"
                  >
                    <Building2 className="h-5 w-5 mr-2" />
                    <div>
                      <div className="font-semibold">Manage Business Ads</div>
                      <div className="text-sm opacity-70">View and manage business advertisements</div>
                    </div>
                  </Button>
                </Link>
              </div>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  );
}