/**
 * Copyright (c) 2025 John Proctor. All rights reserved.
 * The People's Health Community Platform
 * Privacy Policy - Data Protection and Legal Compliance
 */

import { PageHeader } from "@/components/PageHeader";
import { useTranslation } from "@/hooks/useTranslation";

export default function Privacy() {
  const { t } = useTranslation();

  return (
    <div className="min-h-screen bg-gray-50">
      <PageHeader
        title="Privacy Policy"
        subtitle="Data Protection and Privacy Rights"
      />
      
      <div className="max-w-4xl mx-auto px-4 py-8 protected-content">
        <div className="bg-white rounded-lg shadow-sm p-8">
          <div className="prose max-w-none">
            
            <section className="mb-8">
              <h2 className="text-2xl font-bold text-gray-900 mb-4">1. Data Collection and Ownership</h2>
              <div className="space-y-4 text-gray-700">
                <p>
                  <strong>Platform Data Ownership:</strong> All aggregated data, usage analytics, and platform 
                  metrics collected through The People's Health Community are owned by John Proctor and 
                  constitute valuable intellectual property assets.
                </p>
                <p>
                  <strong>Personal Health Data:</strong> Your individual health information remains your property. 
                  We act as a secure custodian of this data and use it only as described in this policy.
                </p>
                <p>
                  <strong>Data We Collect:</strong>
                </p>
                <ul className="list-disc list-inside space-y-2 ml-4">
                  <li>Account information (name, email, profile data)</li>
                  <li>Health tracking data (supplements, biometrics, wellness metrics)</li>
                  <li>Community interactions (posts, comments, social connections)</li>
                  <li>Usage analytics and platform engagement metrics</li>
                  <li>Payment and subscription information</li>
                  <li>Device and browser information for security purposes</li>
                </ul>
              </div>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-bold text-gray-900 mb-4">2. Data Usage and Commercial Rights</h2>
              <div className="space-y-4 text-gray-700">
                <p>
                  <strong>Aggregated Analytics:</strong> We collect and own aggregated, anonymized data 
                  about health trends, supplement usage patterns, and community engagement. This data 
                  represents significant commercial value and may be used for:
                </p>
                <ul className="list-disc list-inside space-y-2 ml-4">
                  <li>Research and development of health insights</li>
                  <li>Platform improvement and feature development</li>
                  <li>Commercial partnerships and data licensing opportunities</li>
                  <li>Market research and trend analysis</li>
                  <li>Revenue generation through data insights (anonymized only)</li>
                </ul>
                <p>
                  <strong>AI and Machine Learning:</strong> Your data may be used to train and improve 
                  our AI health assistant and recommendation systems, always in anonymized form.
                </p>
              </div>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-bold text-gray-900 mb-4">3. Data Security and Protection</h2>
              <div className="space-y-4 text-gray-700">
                <p>
                  We implement industry-standard security measures to protect your data:
                </p>
                <ul className="list-disc list-inside space-y-2 ml-4">
                  <li>End-to-end encryption for sensitive health data</li>
                  <li>Firebase Authentication with multi-factor options</li>
                  <li>PostgreSQL database with row-level security</li>
                  <li>Regular security audits and penetration testing</li>
                  <li>GDPR and UK data protection law compliance</li>
                  <li>Secure cloud infrastructure with backup systems</li>
                </ul>
              </div>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-bold text-gray-900 mb-4">4. Third-Party Integrations</h2>
              <div className="space-y-4 text-gray-700">
                <p>
                  <strong>Service Providers:</strong> We work with trusted third parties:
                </p>
                <ul className="list-disc list-inside space-y-2 ml-4">
                  <li>Firebase (Google) - Authentication and real-time database</li>
                  <li>SendGrid - Email communications</li>
                  <li>Stripe - Payment processing</li>
                  <li>OpenAI - AI assistant capabilities</li>
                  <li>Replit - Hosting and development infrastructure</li>
                </ul>
                <p>
                  All third-party providers are bound by strict data processing agreements 
                  and comply with applicable privacy regulations.
                </p>
              </div>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-bold text-gray-900 mb-4">5. Commercial Data Rights</h2>
              <div className="space-y-4 text-gray-700">
                <p>
                  <strong>Platform Sale Considerations:</strong> In the event of a business sale, merger, 
                  or acquisition, aggregated user data and analytics represent significant commercial assets. 
                  Individual personal data will remain protected according to this policy.
                </p>
                <p>
                  <strong>Data Monetization:</strong> We reserve the right to generate revenue from 
                  anonymized, aggregated data insights through:
                </p>
                <ul className="list-disc list-inside space-y-2 ml-4">
                  <li>Health trend reports and market research</li>
                  <li>Supplement industry analytics</li>
                  <li>Wellness behavior insights</li>
                  <li>Community engagement patterns</li>
                </ul>
              </div>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-bold text-gray-900 mb-4">6. Your Privacy Rights</h2>
              <div className="space-y-4 text-gray-700">
                <p>Under UK GDPR and data protection laws, you have the right to:</p>
                <ul className="list-disc list-inside space-y-2 ml-4">
                  <li>Access your personal data</li>
                  <li>Correct inaccurate information</li>
                  <li>Request data deletion (subject to legal requirements)</li>
                  <li>Data portability (download your data)</li>
                  <li>Object to processing for marketing purposes</li>
                  <li>Lodge complaints with the Information Commissioner's Office</li>
                </ul>
                <p>
                  <strong>Important:</strong> Deleting your account removes your personal data but 
                  does not affect aggregated analytics that contribute to platform value.
                </p>
              </div>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-bold text-gray-900 mb-4">7. Marketing and Communications</h2>
              <div className="space-y-4 text-gray-700">
                <p>
                  We may use your email address to send:
                </p>
                <ul className="list-disc list-inside space-y-2 ml-4">
                  <li>Essential service notifications</li>
                  <li>Weekly health summary emails</li>
                  <li>Platform updates and new features</li>
                  <li>Community highlights and engagement</li>
                  <li>Marketing communications (with consent)</li>
                </ul>
                <p>
                  You can opt out of marketing emails while maintaining essential service communications.
                </p>
              </div>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-bold text-gray-900 mb-4">8. International Data Transfers</h2>
              <div className="space-y-4 text-gray-700">
                <p>
                  Your data may be processed in countries outside the UK/EU through our service providers. 
                  All transfers are protected by appropriate safeguards including Standard Contractual Clauses 
                  and adequacy decisions.
                </p>
              </div>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-bold text-gray-900 mb-4">9. Children's Privacy</h2>
              <div className="space-y-4 text-gray-700">
                <p>
                  The Platform is not intended for children under 16. We do not knowingly collect 
                  personal information from children under 16. If we become aware of such collection, 
                  we will delete the information immediately.
                </p>
              </div>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-bold text-gray-900 mb-4">10. Contact and Data Requests</h2>
              <div className="space-y-4 text-gray-700">
                <p>
                  For privacy questions, data requests, or to exercise your rights, contact us at:
                </p>
                <p>
                  <strong>Email:</strong> gohealme.org@gmail.com<br/>
                  <strong>Subject Line:</strong> Privacy Request - [Your Request Type]<br/>
                  <strong>Data Controller:</strong> John Proctor<br/>
                  <strong>Response Time:</strong> 30 days maximum
                </p>
              </div>
            </section>

            <div className="mt-8 pt-6 border-t border-gray-200">
              <p className="text-sm text-gray-500">
                Last updated: June 19, 2025<br/>
                © 2025 John Proctor - Ordinary People Community. All rights reserved.<br/>
                This policy is part of our intellectual property and may not be copied or reproduced.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}