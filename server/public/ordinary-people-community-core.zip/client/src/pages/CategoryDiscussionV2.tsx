import React, { useState, useEffect, useRef } from 'react';
import { useParams, Link } from 'wouter';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { ArrowLeft, MessageSquare, Users, Send, Plus, Image, X } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { apiRequest } from '@/lib/queryClient';
import { useAuth } from '@/hooks/useAuth';
// Using the Discussion and DiscussionMessage interfaces defined below instead of imports

interface Discussion {
  id: number;
  title: string;
  description: string;
  userId: number;
  categoryId: number;
  location: string | null;
  tags: string[] | null;
  messageCount: number;
  participantCount: number;
  isActive: boolean;
  createdAt: Date;
  updatedAt: Date;
}

interface DiscussionMessage {
  id: number;
  content: string;
  authorName: string;
  createdAt: string;
  imageUrl?: string;
}

interface Category {
  id: number;
  name: string;
  description: string;
  color: string;
}

export default function CategoryDiscussionV2() {
  const { categoryId } = useParams();
  const { toast } = useToast();
  const { appUser: user } = useAuth();
  const queryClient = useQueryClient();
  const messagesEndRef = useRef<HTMLDivElement>(null);
  
  const [selectedDiscussion, setSelectedDiscussion] = useState<number | null>(null);
  const [newDiscussionTitle, setNewDiscussionTitle] = useState('');
  const [newDiscussionContent, setNewDiscussionContent] = useState('');
  const [newMessage, setNewMessage] = useState('');
  const [showNewDiscussion, setShowNewDiscussion] = useState(false);
  const [selectedImage, setSelectedImage] = useState<File | null>(null);
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Auto-scroll to bottom when new messages arrive
  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  // Fetch category details
  const { data: category } = useQuery({
    queryKey: ['category', categoryId],
    queryFn: async () => {
      const response = await fetch(`/api/discussion-categories/${categoryId}`);
      if (!response.ok) throw new Error('Failed to fetch category');
      return await response.json();
    },
    enabled: !!categoryId
  });

  // Fetch discussions for this category
  const { data: discussions = [], isLoading: discussionsLoading } = useQuery({
    queryKey: ['discussions', categoryId],
    queryFn: async () => {
      const response = await fetch(`/api/community-discussions?categoryId=${categoryId}`);
      if (!response.ok) throw new Error('Failed to fetch discussions');
      return await response.json();
    },
    enabled: !!categoryId
  });

  // Fetch messages for selected discussion
  const { data: messages = [] } = useQuery({
    queryKey: ['discussion-messages', selectedDiscussion],
    queryFn: async () => {
      const response = await fetch(`/api/discussion-messages/${selectedDiscussion}`);
      if (!response.ok) throw new Error('Failed to fetch messages');
      return await response.json();
    },
    enabled: !!selectedDiscussion
  });

  // Auto-scroll when messages update (like social media)
  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  // Handle image selection
  const handleImageSelect = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      if (file.size > 5 * 1024 * 1024) { // 5MB limit
        toast({
          title: "Image too large",
          description: "Please select an image under 5MB",
          variant: "destructive"
        });
        return;
      }
      
      setSelectedImage(file);
      const reader = new FileReader();
      reader.onload = (e) => {
        setImagePreview(e.target?.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  // Clear selected image
  const clearImage = () => {
    setSelectedImage(null);
    setImagePreview(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  // Create new discussion mutation
  const createDiscussionMutation = useMutation({
    mutationFn: async (data: { title: string; content: string; categoryId: number }) => {
      return apiRequest('POST', '/api/community-discussions', data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['discussions', categoryId] });
      setNewDiscussionTitle('');
      setNewDiscussionContent('');
      setShowNewDiscussion(false);
      toast({ title: "Discussion created successfully!" });
    },
    onError: () => {
      toast({ title: "Failed to create discussion", variant: "destructive" });
    }
  });

  // Send message mutation with image support
  const sendMessageMutation = useMutation({
    mutationFn: async (data: { content: string; discussionId: number; imageData?: string }) => {
      return apiRequest('POST', '/api/discussion-messages', data);
    },
    onSuccess: (newMessage) => {
      // Immediately update messages with optimistic update
      queryClient.setQueryData(['discussion-messages', selectedDiscussion], (oldData: any) => {
        return oldData ? [...oldData, newMessage] : [newMessage];
      });
      queryClient.invalidateQueries({ queryKey: ['discussion-messages', selectedDiscussion] });
      queryClient.invalidateQueries({ queryKey: ['discussions', categoryId] });
      setNewMessage('');
      clearImage();
      toast({ title: "Message sent!", description: "Your message has been posted to the discussion." });
    },
    onError: () => {
      toast({ title: "Failed to send message", variant: "destructive" });
    }
  });

  const handleCreateDiscussion = () => {
    if (!newDiscussionTitle.trim() || !newDiscussionContent.trim()) {
      toast({ title: "Please fill in all fields", variant: "destructive" });
      return;
    }
    
    createDiscussionMutation.mutate({
      title: newDiscussionTitle,
      content: newDiscussionContent,
      categoryId: parseInt(categoryId!)
    });
  };

  const handleSendMessage = async () => {
    if ((!newMessage.trim() && !selectedImage) || !selectedDiscussion) return;
    
    let messageData: any = {
      content: newMessage,
      discussionId: selectedDiscussion
    };

    // Add image data if an image is selected
    if (selectedImage && imagePreview) {
      messageData.imageData = imagePreview;
    }
    
    sendMessageMutation.mutate(messageData);
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 to-pink-50 dark:from-gray-900 dark:to-gray-800 overflow-x-hidden">
      <div className="container mx-auto px-2 py-4 max-w-[95vw]">
        {/* Header */}
        <div className="flex items-center gap-3 mb-4">
          <Link href="/community" className="p-2 hover:bg-white/20 rounded-full transition-colors">
            <ArrowLeft className="w-5 h-5" />
          </Link>
          <div className="flex-1 min-w-0">
            <h1 className="text-xl font-bold text-gray-900 dark:text-white truncate">
              {category?.name || 'Discussion Category'}
            </h1>
            {category?.description && (
              <p className="text-sm text-gray-600 dark:text-gray-300 truncate">
                {category.description}
              </p>
            )}
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 max-w-full">
          {/* Discussions List */}
          <Card className="w-full max-w-[90vw] lg:max-w-none">
            <CardHeader className="p-3">
              <div className="flex items-center justify-between gap-2">
                <CardTitle className="text-lg truncate">Discussions</CardTitle>
                <Button
                  onClick={() => setShowNewDiscussion(!showNewDiscussion)}
                  size="sm"
                  className="shrink-0 ml-2"
                >
                  <Plus className="w-4 h-4 mr-1" />
                  New
                </Button>
              </div>
            </CardHeader>
            <CardContent className="p-3 space-y-3 max-h-[60vh] overflow-y-auto">
              {/* New Discussion Form */}
              {showNewDiscussion && (
                <div className="p-3 bg-gray-50 dark:bg-gray-800 rounded-lg space-y-2">
                  <Input
                    placeholder="Discussion title..."
                    value={newDiscussionTitle}
                    onChange={(e) => setNewDiscussionTitle(e.target.value)}
                    className="text-sm"
                  />
                  <Textarea
                    placeholder="What would you like to discuss?"
                    value={newDiscussionContent}
                    onChange={(e) => setNewDiscussionContent(e.target.value)}
                    rows={3}
                    className="text-sm resize-none"
                  />
                  <div className="flex gap-2">
                    <Button
                      onClick={handleCreateDiscussion}
                      disabled={createDiscussionMutation.isPending}
                      size="sm"
                      className="flex-1"
                    >
                      {createDiscussionMutation.isPending ? 'Creating...' : 'Create Discussion'}
                    </Button>
                    <Button
                      onClick={() => setShowNewDiscussion(false)}
                      variant="outline"
                      size="sm"
                    >
                      Cancel
                    </Button>
                  </div>
                </div>
              )}

              {/* Discussions List */}
              {discussionsLoading ? (
                <div className="text-center py-4 text-sm text-gray-500">Loading discussions...</div>
              ) : discussions.length === 0 ? (
                <div className="text-center py-4 text-sm text-gray-500">
                  No discussions yet. Be the first to start one!
                </div>
              ) : (
                discussions.map((discussion: Discussion) => (
                  <div
                    key={discussion.id}
                    onClick={() => setSelectedDiscussion(discussion.id)}
                    className={`p-3 rounded-lg border cursor-pointer transition-all max-w-full ${
                      selectedDiscussion === discussion.id
                        ? 'border-purple-500 bg-purple-50 dark:bg-purple-900/20'
                        : 'border-gray-200 hover:border-gray-300 bg-white dark:bg-gray-800'
                    }`}
                  >
                    <h3 className="font-medium text-sm text-gray-900 dark:text-white mb-1 truncate">
                      {discussion.title}
                    </h3>
                    <p className="text-xs text-gray-600 dark:text-gray-300 mb-2 line-clamp-2">
                      {discussion.description}
                    </p>
                    <div className="flex items-center justify-between text-xs text-gray-500">
                      <span className="truncate">by User #{discussion.userId}</span>
                      <div className="flex items-center gap-2 shrink-0">
                        <div className="flex items-center gap-1">
                          <MessageSquare className="w-3 h-3" />
                          <span>{discussion.messageCount}</span>
                        </div>
                        <div className="flex items-center gap-1">
                          <Users className="w-3 h-3" />
                          <span>{discussion.participantCount}</span>
                        </div>
                      </div>
                    </div>
                  </div>
                ))
              )}
            </CardContent>
          </Card>

          {/* Discussion Messages */}
          <Card className="w-full max-w-[95vw] lg:max-w-none">
            <CardHeader className="p-3">
              <CardTitle className="text-lg truncate">
                {selectedDiscussion ? 'Messages' : 'Select a Discussion'}
              </CardTitle>
            </CardHeader>
            <CardContent className="p-0">
              {selectedDiscussion ? (
                <>
                  {/* Live Chat Messages */}
                  <div className="p-3 max-h-[50vh] overflow-y-auto space-y-3" id="messages-container">
                    {messages.length === 0 ? (
                      <div className="text-center py-8 text-gray-500">
                        <MessageSquare className="w-12 h-12 mx-auto mb-2 opacity-50" />
                        <p className="font-medium">Start the conversation!</p>
                        <p className="text-sm">Be the first to share your thoughts</p>
                      </div>
                    ) : (
                      messages.map((message: any, index: number) => (
                        <div 
                          key={message.id} 
                          className={`p-3 rounded-lg border-l-4 transition-all duration-300 ${
                            index === messages.length - 1 && sendMessageMutation.isPending 
                              ? 'bg-green-50 border-l-green-400 shadow-md' 
                              : 'bg-white dark:bg-gray-800 border-l-blue-400 hover:shadow-sm'
                          }`}
                        >
                          <div className="flex items-center justify-between mb-2">
                            <span className="text-sm font-semibold text-blue-600 dark:text-blue-400">
                              {message.authorName}
                            </span>
                            <span className="text-xs text-gray-500">
                              {formatDate(message.createdAt)}
                            </span>
                          </div>
                          <p className="text-gray-800 dark:text-gray-200 leading-relaxed">
                            {message.content}
                          </p>
                          {/* Display image if present */}
                          {message.imageUrl && (
                            <div className="mt-2">
                              <img 
                                src={message.imageUrl} 
                                alt="Uploaded image" 
                                className="max-w-xs max-h-48 rounded-lg border cursor-pointer hover:opacity-90 transition-opacity"
                                onClick={() => window.open(message.imageUrl, '_blank')}
                              />
                            </div>
                          )}
                        </div>
                      ))
                    )}
                    {/* Auto-scroll anchor */}
                    <div ref={messagesEndRef} />
                  </div>
                  
                  {/* Enhanced Message Input */}
                  <div className="p-4 bg-gradient-to-r from-blue-50 to-purple-50 dark:from-gray-800 dark:to-gray-700 border-t-2 border-blue-200">
                    {/* Image Preview */}
                    {imagePreview && (
                      <div className="mb-3 relative">
                        <img 
                          src={imagePreview} 
                          alt="Preview" 
                          className="max-w-xs max-h-32 rounded-lg border"
                        />
                        <Button
                          size="sm"
                          variant="destructive"
                          className="absolute top-1 right-1 h-6 w-6 p-0"
                          onClick={clearImage}
                        >
                          <X className="w-3 h-3" />
                        </Button>
                      </div>
                    )}
                    
                    <div className="flex gap-3 items-end">
                      <div className="flex-1">
                        <label className="text-xs font-medium text-gray-600 dark:text-gray-300 mb-1 block">
                          Join the conversation
                        </label>
                        <Input
                          placeholder="Share your thoughts on this topic..."
                          value={newMessage}
                          onChange={(e) => setNewMessage(e.target.value)}
                          onKeyPress={(e) => e.key === 'Enter' && !e.shiftKey && handleSendMessage()}
                          className="border-2 border-blue-200 focus:border-blue-400 bg-white dark:bg-gray-800"
                          disabled={sendMessageMutation.isPending}
                        />
                      </div>
                      <div className="flex gap-2">
                        {/* Image Upload Button */}
                        <Button
                          type="button"
                          variant="outline"
                          size="sm"
                          onClick={() => fileInputRef.current?.click()}
                          className="px-3 py-2 h-10"
                        >
                          <Image className="w-4 h-4" />
                        </Button>
                        
                        {/* Send Button */}
                        <Button
                          onClick={handleSendMessage}
                          disabled={(!newMessage.trim() && !selectedImage) || sendMessageMutation.isPending}
                          className="bg-blue-600 hover:bg-blue-700 px-4 py-2 h-10"
                        >
                          {sendMessageMutation.isPending ? (
                            <div className="animate-spin w-4 h-4 border-2 border-white border-t-transparent rounded-full" />
                          ) : (
                            <>
                              <Send className="w-4 h-4 mr-1" />
                              Send
                            </>
                          )}
                        </Button>
                      </div>
                      
                      {/* Hidden File Input */}
                      <input
                        ref={fileInputRef}
                        type="file"
                        accept="image/*"
                        onChange={handleImageSelect}
                        className="hidden"
                      />
                    </div>
                    {newMessage.trim() && (
                      <p className="text-xs text-gray-500 mt-1">
                        Press Enter to send • Your message will appear above
                      </p>
                    )}
                  </div>
                </>
              ) : (
                <div className="p-6 text-center text-gray-500">
                  <MessageSquare className="w-12 h-12 mx-auto mb-2 text-gray-300" />
                  <p className="text-sm">Select a discussion to view messages</p>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}