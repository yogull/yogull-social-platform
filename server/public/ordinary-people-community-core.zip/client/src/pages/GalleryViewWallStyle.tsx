import React, { useState } from "react";
import { useParams, useLocation } from "wouter";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { ArrowLeft, Heart, MessageCircle, Send, X } from "lucide-react";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";

interface Gallery {
  id: number;
  name: string;
  images: Photo[];
  coverImage?: string;
  description?: string;
  userId: number;
  likes: number;
  comments: Comment[];
  isLiked: boolean;
}

interface Photo {
  id: number;
  url: string;
  caption?: string;
  likes: number;
  comments: Comment[];
  isLiked: boolean;
  createdAt: string;
}

interface Comment {
  id: number;
  text: string;
  userName: string;
  userAvatar?: string;
  createdAt: string;
}

export default function GalleryViewWallStyle() {
  const [location, setLocation] = useLocation();
  const { appUser } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Wall-style state management
  const [selectedGallery, setSelectedGallery] = useState<Gallery | null>(null);
  const [enlargedPhoto, setEnlargedPhoto] = useState<Photo | null>(null);
  const [newComment, setNewComment] = useState<{[key: number]: string}>({});
  const [showComments, setShowComments] = useState<{[key: number]: boolean}>({});

  // Demo gallery data - exactly like wall posts
  const demoGalleries: Gallery[] = [
    {
      id: 1,
      name: "Holiday Photos",
      userId: 4,
      likes: 12,
      isLiked: false,
      comments: [
        { id: 1, text: "Beautiful memories!", userName: "Sarah Johnson", createdAt: "2 hours ago" }
      ],
      images: [
        {
          id: 1,
          url: "https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=800&h=600&fit=crop",
          caption: "Amazing sunset at the beach",
          likes: 8,
          isLiked: false,
          createdAt: "3 days ago",
          comments: [
            { id: 1, text: "Stunning view!", userName: "Mike Chen", createdAt: "2 days ago" }
          ]
        },
        {
          id: 2,
          url: "https://images.unsplash.com/photo-1469474968028-56623f02e42e?w=800&h=600&fit=crop",
          caption: "Mountain hiking adventure",
          likes: 15,
          isLiked: true,
          createdAt: "5 days ago",
          comments: []
        }
      ]
    },
    {
      id: 2,
      name: "Family Memories",
      userId: 4,
      likes: 8,
      isLiked: true,
      comments: [],
      images: [
        {
          id: 3,
          url: "https://images.unsplash.com/photo-1511895426328-dc8714191300?w=800&h=600&fit=crop",
          caption: "Family dinner celebration",
          likes: 6,
          isLiked: false,
          createdAt: "1 week ago",
          comments: [
            { id: 2, text: "Love this photo!", userName: "Emma Wilson", createdAt: "6 days ago" }
          ]
        }
      ]
    }
  ];

  // Wall-style action handlers with actual posting
  const shareToWallMutation = useMutation({
    mutationFn: async (data: { content: string; mediaUrl?: string; caption?: string }) => {
      const response = await fetch('/api/profile-wall-posts', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userId: appUser?.id,
          content: data.content,
          mediaUrl: data.mediaUrl,
          caption: data.caption
        })
      });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/profile-wall-posts'] });
      toast({ title: "Posted to your Profile Wall!" });
    }
  });

  const handleOPCShare = (photo: Photo) => {
    shareToWallMutation.mutate({
      content: `Shared from gallery: ${photo.caption || 'Photo'}`,
      mediaUrl: photo.url,
      caption: photo.caption
    });
  };

  const handleMediaShare = (photo: Photo) => {
    shareToWallMutation.mutate({
      content: `📱 Media Share: ${photo.caption || 'Check out this photo!'}`,
      mediaUrl: photo.url,
      caption: photo.caption
    });
  };

  const handleMultiShare = (photo: Photo) => {
    shareToWallMutation.mutate({
      content: `🔄 Multi-Share: ${photo.caption || 'Sharing across all platforms!'}`,
      mediaUrl: photo.url,
      caption: photo.caption
    });
  };

  // Wall-style comment mutation
  const addCommentMutation = useMutation({
    mutationFn: async (data: { itemId: number; type: 'photo'; text: string }) => {
      const response = await fetch('/api/gallery-comments', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
      });
      return response.json();
    },
    onSuccess: (data, variables) => {
      setNewComment(prev => ({ ...prev, [variables.itemId]: '' }));
      toast({ title: "Comment posted successfully!" });
    }
  });

  // Photo enlargement view - Wall style (using overlay instead of Dialog)
  if (enlargedPhoto) {
    return (
      <div className="fixed inset-0 z-50 bg-black bg-opacity-75 flex items-center justify-center">
        <div className="relative max-w-4xl w-full h-[90vh] bg-white rounded-lg overflow-y-auto">
          <div className="relative min-h-full">
            <Button 
              onClick={() => setEnlargedPhoto(null)}
              variant="outline"
              size="sm"
              className="absolute top-4 right-4 z-50 bg-white/90 hover:bg-white"
            >
              <X className="w-4 h-4" />
            </Button>

            <div className="w-full h-80 bg-black flex items-center justify-center">
              <img 
                src={enlargedPhoto.url}
                alt={enlargedPhoto.caption || "Photo"}
                className="max-w-full max-h-full object-contain"
              />
            </div>

            <div className="p-6 bg-white">
              <div className="flex items-center justify-between mb-4">
                <div>
                  <h3 className="text-lg font-semibold">{enlargedPhoto.caption || "Photo"}</h3>
                  <p className="text-sm text-gray-500">{enlargedPhoto.createdAt}</p>
                </div>
                <div className="flex items-center gap-4">
                  <span className="flex items-center gap-1 text-sm text-gray-600">
                    ❤️ {enlargedPhoto.likes} likes
                  </span>
                  <span className="flex items-center gap-1 text-sm text-gray-600">
                    💬 {enlargedPhoto.comments?.length || 0} comments
                  </span>
                </div>
              </div>

              <div className="border-t pt-3 mb-4">
                <div className="flex items-center justify-between flex-wrap gap-2">
                  <div className="flex items-center gap-2">
                    <Button variant="ghost" size="sm" className="text-gray-600 hover:text-red-600">
                      <Heart className="h-4 w-4 mr-1" />
                      Like
                    </Button>
                    <Button 
                      variant="ghost" 
                      size="sm" 
                      className="text-gray-600 hover:text-blue-600"
                      onClick={() => setShowComments(prev => ({ ...prev, [enlargedPhoto.id]: !showComments[enlargedPhoto.id] }))}
                    >
                      <MessageCircle className="h-4 w-4 mr-1" />
                      Comment
                    </Button>
                  </div>
                  
                  <div className="flex items-center gap-1">
                    <Button variant="ghost" size="sm" onClick={() => handleOPCShare(enlargedPhoto)}>
                      🏛️ OPC
                    </Button>
                    <Button variant="ghost" size="sm" onClick={() => handleMediaShare(enlargedPhoto)}>
                      📱 Media
                    </Button>
                    <Button variant="ghost" size="sm" onClick={() => handleMultiShare(enlargedPhoto)}>
                      🔄 Multi
                    </Button>
                  </div>
                </div>
              </div>

              {showComments[enlargedPhoto.id] && (
                <div className="border-t pt-4">
                  <div className="flex gap-2 mb-4">
                    <Input
                      placeholder="Write a comment..."
                      value={newComment[enlargedPhoto.id] || ''}
                      onChange={(e) => setNewComment(prev => ({ ...prev, [enlargedPhoto.id]: e.target.value }))}
                      className="flex-1"
                    />
                    <Button 
                      size="sm"
                      onClick={() => addCommentMutation.mutate({
                        itemId: enlargedPhoto.id,
                        type: 'photo',
                        text: newComment[enlargedPhoto.id] || ''
                      })}
                      disabled={!newComment[enlargedPhoto.id] || newComment[enlargedPhoto.id].trim() === ''}
                    >
                      <Send className="h-4 w-4" />
                    </Button>
                  </div>
                  
                  <div className="space-y-3 max-h-60 overflow-y-auto">
                    {enlargedPhoto.comments?.map((comment) => (
                      <div key={comment.id} className="flex gap-3">
                        <div className="w-8 h-8 bg-gradient-to-br from-blue-500 to-purple-600 rounded-full flex items-center justify-center text-white font-medium text-sm">
                          {comment.userName.charAt(0)}
                        </div>
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-1">
                            <span className="font-semibold text-sm">{comment.userName}</span>
                            <span className="text-xs text-gray-500">{comment.createdAt}</span>
                          </div>
                          <p className="text-sm text-gray-800">{comment.text}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    );
  }

  // Gallery view - Wall style
  if (selectedGallery) {
    return (
      <div className="min-h-screen bg-gray-50 p-4">
        <div className="max-w-2xl mx-auto">
          <div className="flex items-center gap-4 mb-6">
            <Button
              variant="outline"
              onClick={() => setSelectedGallery(null)}
              className="flex items-center gap-2"
            >
              <ArrowLeft className="w-4 h-4" />
              Back to Gallery
            </Button>
            <h1 className="text-2xl font-bold">{selectedGallery.name}</h1>
          </div>

          <div className="space-y-4">
            {selectedGallery.images.map((photo) => (
              <Card key={photo.id} className="bg-white border shadow-sm">
                <CardContent className="p-4">
                  <div className="flex items-center gap-3 mb-3">
                    <div className="w-10 h-10 rounded-full overflow-hidden bg-gray-300">
                      <div className="w-full h-full bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center text-white font-medium">
                        {appUser?.name?.charAt(0) || 'U'}
                      </div>
                    </div>
                    <div className="flex-1">
                      <h4 className="font-medium text-gray-900">{appUser?.name || 'User'}</h4>
                      <p className="text-sm text-gray-500">{photo.createdAt}</p>
                    </div>
                  </div>

                  {photo.caption && (
                    <div className="mb-3">
                      <p className="text-gray-800">{photo.caption}</p>
                    </div>
                  )}

                  <div className="mb-3">
                    <img 
                      src={photo.url}
                      alt={photo.caption || "Photo"}
                      className="w-full max-w-md rounded-lg cursor-pointer hover:opacity-95 transition-opacity"
                      onClick={() => setEnlargedPhoto(photo)}
                    />
                  </div>

                  <div className="flex items-center gap-4 text-sm text-gray-500 mb-3">
                    <span>❤️ {photo.likes || 0} likes</span>
                    <span>💬 {photo.comments?.length || 0} comments</span>
                    <span>🔄 0 shares</span>
                  </div>

                  <div className="border-t pt-3">
                    <div className="flex items-center justify-between flex-wrap gap-2">
                      <div className="flex items-center gap-2">
                        <Button variant="ghost" size="sm" className="text-gray-600 hover:text-red-600">
                          <Heart className="h-4 w-4 mr-1" />
                          Like
                        </Button>
                        <Button 
                          variant="ghost" 
                          size="sm" 
                          className="text-gray-600 hover:text-blue-600"
                          onClick={() => setShowComments(prev => ({ ...prev, [photo.id]: !showComments[photo.id] }))}
                        >
                          <MessageCircle className="h-4 w-4 mr-1" />
                          Comment
                        </Button>
                      </div>
                      
                      <div className="flex items-center gap-1">
                        <Button variant="ghost" size="sm" onClick={() => handleOPCShare(photo)}>
                          🏛️ OPC
                        </Button>
                        <Button variant="ghost" size="sm" onClick={() => handleMediaShare(photo)}>
                          📱 Media
                        </Button>
                        <Button variant="ghost" size="sm" onClick={() => handleMultiShare(photo)}>
                          🔄 Multi
                        </Button>
                      </div>
                    </div>
                  </div>

                  {showComments[photo.id] && (
                    <div className="mt-4 border-t pt-4">
                      <div className="flex gap-2 mb-4">
                        <Input
                          placeholder="Write a comment..."
                          value={newComment[photo.id] || ''}
                          onChange={(e) => setNewComment(prev => ({ ...prev, [photo.id]: e.target.value }))}
                          className="flex-1"
                        />
                        <Button 
                          size="sm"
                          onClick={() => addCommentMutation.mutate({
                            itemId: photo.id,
                            type: 'photo',
                            text: newComment[photo.id] || ''
                          })}
                          disabled={!newComment[photo.id] || newComment[photo.id].trim() === ''}
                        >
                          <Send className="h-4 w-4" />
                        </Button>
                      </div>
                      
                      <div className="space-y-3">
                        {photo.comments?.map((comment) => (
                          <div key={comment.id} className="flex gap-3">
                            <div className="w-8 h-8 bg-gradient-to-br from-blue-500 to-purple-600 rounded-full flex items-center justify-center text-white font-medium text-sm">
                              {comment.userName.charAt(0)}
                            </div>
                            <div className="flex-1">
                              <div className="flex items-center gap-2 mb-1">
                                <span className="font-semibold text-sm">{comment.userName}</span>
                                <span className="text-xs text-gray-500">{comment.createdAt}</span>
                              </div>
                              <p className="text-sm text-gray-800">{comment.text}</p>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </div>
    );
  }

  // Main gallery list - compact design
  return (
    <div className="min-h-screen bg-gray-50 p-4">
      <div className="max-w-2xl mx-auto">
        <div className="flex items-center gap-4 mb-6">
          <Button
            variant="outline"
            onClick={() => setLocation('/profile-wall/4')}
            className="flex items-center gap-2"
          >
            <ArrowLeft className="w-4 h-4" />
            Back to Profile
          </Button>
          <h1 className="text-2xl font-bold">Photo Albums</h1>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {demoGalleries.map((gallery) => (
            <Card key={gallery.id} className="bg-white border shadow-sm hover:shadow-md transition-shadow cursor-pointer">
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="text-lg font-semibold mb-1">{gallery.name}</h3>
                    <p className="text-sm text-gray-500">{gallery.images.length} photos</p>
                  </div>
                  <Button 
                    onClick={() => setSelectedGallery(gallery)}
                    className="bg-blue-600 hover:bg-blue-700 text-white"
                  >
                    Open
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </div>
  );
}